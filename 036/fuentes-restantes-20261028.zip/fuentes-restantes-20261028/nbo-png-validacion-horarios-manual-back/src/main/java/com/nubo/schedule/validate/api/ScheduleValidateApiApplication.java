package com.nubo.schedule.validate.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScheduleValidateApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ScheduleValidateApiApplication.class, args);
    }

}
