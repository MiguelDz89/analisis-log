package com.nubo.schedule.query.api.helpers;

import com.nubo.schedule.query.api.models.dto.response.ScheduleStatusHistoryDto;
import com.nubo.schedule.query.api.models.entity.ScheduleStatusHistoryEntity;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class ScheduleStatusHistoryMapperUtil {

    public static ScheduleStatusHistoryDto toDto(ScheduleStatusHistoryEntity entity) {
        if (entity==null) return null;
        return ScheduleStatusHistoryDto.builder()
                .scheduleId(entity.getScheduleId())
                .time(entity.getTime())
                .detail(entity.getDetail())
                .build();
    }

    public static List<ScheduleStatusHistoryDto> toDtoList(List<ScheduleStatusHistoryEntity> entities) {
        if (entities==null || entities.isEmpty()) {
            return Collections.emptyList();
        }
        return entities.stream()
                .map(ScheduleStatusHistoryMapperUtil::toDto)
                .collect(Collectors.toList());
    }
}