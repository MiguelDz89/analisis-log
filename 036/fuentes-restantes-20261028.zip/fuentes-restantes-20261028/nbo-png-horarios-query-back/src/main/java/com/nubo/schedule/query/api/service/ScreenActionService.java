package com.nubo.schedule.query.api.service;

import com.nubo.schedule.query.api.models.dto.request.ParamsPageInDto;
import com.nubo.schedule.query.api.models.dto.response.PageResponseDto;
import com.nubo.schedule.query.api.models.dto.response.ScreenActionDto;

public interface ScreenActionService {

    PageResponseDto<ScreenActionDto> getScreenActions(ParamsPageInDto paramsPageInDto, Integer moduleId, Integer submoduleId);
}
