package com.nubo.schedule.query.api.helpers;

import com.nubo.schedule.query.api.models.dto.response.UserNuboDto;
import com.nubo.schedule.query.api.models.entity.UserNuboEntity;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class UserNuboMapperUtil {

    public static UserNuboDto toDto(UserNuboEntity entity) {
        if (entity==null) return null;
        return UserNuboDto.builder()
                .id(entity.getId())
                .userName(entity.getUserName())
                .firstName(entity.getFirstName())
                .lastName(entity.getLastName())
                .participant(entity.getParticipant()!=null ? ParticipantMapperUtil.toDto(entity.getParticipant()):null)
                .userType(entity.getUserType())
                .previousSession(entity.getPreviousSession())
                .build();
    }

    public static List<UserNuboDto> toDtoList(List<UserNuboEntity> entities) {
        if (entities==null || entities.isEmpty()) {
            return Collections.emptyList();
        }
        return entities.stream()
                .map(UserNuboMapperUtil::toDto)
                .collect(Collectors.toList());
    }
}