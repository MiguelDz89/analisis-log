package com.nubo.schedule.query.api.repository;

import com.nubo.schedule.query.api.models.entity.ParticipantEntity;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ParticipantRepository extends JpaRepository<ParticipantEntity, Long> {
}
