package com.nubo.schedule.query.api.helpers;

import com.nubo.schedule.query.api.models.dto.response.StatusDto;
import com.nubo.schedule.query.api.models.entity.StatusEntity;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class StatusMapperUtil {

    public static StatusDto toDto(StatusEntity entity) {
        if (entity==null) return null;
        return StatusDto.builder()
                .id(entity.getId())
                .description(entity.getDescription())
                .category(entity.getCategory())
                .lastModifyUser(entity.getLastModifyUser())
                .lastModifyApplication(entity.getLastModifyApplication())
                .lastModifyDate(entity.getLastModifyDate())
                .lastModifyIp(entity.getLastModifyIp())
                .build();
    }

    public static List<StatusDto> toDtoList(List<StatusEntity> entities) {
        if (entities==null || entities.isEmpty()) {
            return Collections.emptyList();
        }
        return entities.stream()
                .map(StatusMapperUtil::toDto)
                .collect(Collectors.toList());
    }
}