package com.nubo.schedule.query.api.helpers;

import com.nubo.schedule.query.api.models.dto.response.CountryDto;
import com.nubo.schedule.query.api.models.entity.CountryEntity;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class CountryMapperUtil {

    public static CountryDto toDto(CountryEntity entity) {
        if (entity==null) return null;
        return CountryDto.builder()
                .id(entity.getId())
                .code(entity.getCode())
                .name(entity.getName())
                .timeZone(entity.getTimeZone())
                .build();
    }

    public static List<CountryDto> toDtoList(List<CountryEntity> entities) {
        if (entities==null || entities.isEmpty()) {
            return Collections.emptyList();
        }
        return entities.stream()
                .map(CountryMapperUtil::toDto)
                .collect(Collectors.toList());
    }
}