package com.nubo.schedule.query.api.helpers;

import com.nubo.schedule.query.api.models.dto.response.MicroserviceDto;
import com.nubo.schedule.query.api.models.entity.MicroserviceEntity;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class MicroserviceMapperUtil {

    public static MicroserviceDto toDto(MicroserviceEntity entity) {
        if (entity==null) return null;
        return MicroserviceDto.builder()
                .id(entity.getId())
                .name(entity.getName())
                .build();
    }

    public static List<MicroserviceDto> toDtoList(List<MicroserviceEntity> entities) {
        if (entities==null || entities.isEmpty()) {
            return Collections.emptyList();
        }
        return entities.stream()
                .map(MicroserviceMapperUtil::toDto)
                .collect(Collectors.toList());
    }
}