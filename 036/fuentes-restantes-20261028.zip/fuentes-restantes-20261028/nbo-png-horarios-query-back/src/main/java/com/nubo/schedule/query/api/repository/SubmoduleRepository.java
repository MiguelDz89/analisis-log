package com.nubo.schedule.query.api.repository;

import com.nubo.schedule.query.api.models.entity.SubmoduleEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface SubmoduleRepository extends JpaRepository<SubmoduleEntity, Long>, JpaSpecificationExecutor<SubmoduleEntity> {

}