package com.nubo.schedule.query.api.repository;

import com.nubo.schedule.query.api.models.entity.MicroserviceEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface MicroserviceRepository extends JpaRepository<MicroserviceEntity, Long>, JpaSpecificationExecutor<MicroserviceEntity> {
}