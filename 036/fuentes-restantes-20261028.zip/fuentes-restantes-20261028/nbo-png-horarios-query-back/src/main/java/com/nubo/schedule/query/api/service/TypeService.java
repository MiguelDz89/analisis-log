package com.nubo.schedule.query.api.service;

import com.nubo.schedule.query.api.models.dto.response.PageResponseOutDto;
import com.nubo.schedule.query.api.models.dto.response.TypeDto;

public interface TypeService {

    PageResponseOutDto<TypeDto> getByCategory(String category, int page, int size, String sort, String order, boolean all);

}