package com.nubo.schedule.query.api.service;

import com.nubo.schedule.query.api.models.dto.response.CountryDto;
import com.nubo.schedule.query.api.models.dto.response.PageResponseOutDto;
import com.nubo.schedule.query.api.models.dto.response.TimeZoneDto;

public interface CountryService {

    PageResponseOutDto<CountryDto> getByCountryCodes(int page, int size, String sort, String order, boolean all);

    PageResponseOutDto<TimeZoneDto> getTimeZoneByCountryId(Long countryId, int page, int size, String sort, String order, boolean all);

}