package com.nubo.schedule.query.api.helpers;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nubo.schedule.query.api.models.dto.response.ScheduleDto;
import com.nubo.schedule.query.api.models.dto.response.ScheduleLogDto;
import com.nubo.schedule.query.api.models.entity.ScheduleLogEntity;
import com.nubo.schedule.query.api.repository.CountryRepository;
import com.nubo.schedule.query.api.repository.ModuleRepository;
import com.nubo.schedule.query.api.repository.StatusRepository;
import com.nubo.schedule.query.api.repository.TypeRepository;
import com.nubo.schedule.query.api.repository.UserNuboRepository;

@Component
public class ScheduleLogMapperUtil {

    private static final ObjectMapper objectMapper = new ObjectMapper();
    
    static {
        objectMapper.findAndRegisterModules();
    }

    @Autowired
    private TypeRepository typeRepository;
    
    @Autowired
    private CountryRepository countryRepository;
    
    @Autowired
    private ModuleRepository moduleRepository;
    
    @Autowired
    private StatusRepository statusRepository;
    
    @Autowired
    private UserNuboRepository userNuboRepository;

    public ScheduleLogDto toDto(ScheduleLogEntity entity) {
        if (entity == null) return null;
        return ScheduleLogDto.builder()
                .scheduleLogId(entity.getScheduleLogId())
                .scheduleId(entity.getScheduleId())
                .dataAfter(parseDataAfterToScheduleDto(entity.getDataAfter()))
                .time(entity.getTime())
                .lastModifyUser(entity.getLastModifyUser())
                .lastModifyApplication(entity.getLastModifyApplication())
                .lastModifyDate(entity.getLastModifyDate())
                .lastModifyIp(entity.getLastModifyIp())
                .build();
    }

    private ScheduleDto parseDataAfterToScheduleDto(String dataAfterJson) {
        if (dataAfterJson == null || dataAfterJson.trim().isEmpty()) {
            return null;
        }
        try {
            var jsonNode = objectMapper.readTree(dataAfterJson);
            
            return ScheduleDto.builder()
                    .id(jsonNode.has("SCHEDULE_ID") ? jsonNode.get("SCHEDULE_ID").asLong() : null)
                    .description(jsonNode.has("DESCRIPTION") ? jsonNode.get("DESCRIPTION").asText() : null)
                    .openingTime(jsonNode.has("OPENING_TIME") ? 
                        java.time.LocalTime.parse(jsonNode.get("OPENING_TIME").asText()) : null)
                    .closingTime(jsonNode.has("CLOSING_TIME") ? 
                        java.time.LocalTime.parse(jsonNode.get("CLOSING_TIME").asText()) : null)
                    .startDate(jsonNode.has("START_DATE") ? 
                        java.time.LocalDate.parse(jsonNode.get("START_DATE").asText()) : null)
                    .endDate(jsonNode.has("END_DATE") ? 
                        java.time.LocalDate.parse(jsonNode.get("END_DATE").asText()) : null)
                    .frequency(jsonNode.has("FREQUENCY") ? jsonNode.get("FREQUENCY").asInt() : null)
                    .internal(jsonNode.has("INTERNAL") ? jsonNode.get("INTERNAL").asBoolean() : null)
                    .lastModifyUser(jsonNode.has("LAST_MODIFY_USER") ? 
                        jsonNode.get("LAST_MODIFY_USER").asText() : null)
                    .lastModifyApplication(jsonNode.has("LAST_MODIFY_APPLIC") ? 
                        jsonNode.get("LAST_MODIFY_APPLIC").asText() : null)
                    .lastModifyDate(jsonNode.has("LAST_MODIFY_DATE") ? 
                        java.time.LocalDateTime.parse(jsonNode.get("LAST_MODIFY_DATE").asText().replace("+00:00", "")) : null)
                    .lastModifyIp(jsonNode.has("LAST_MODIFY_IP") ? 
                        jsonNode.get("LAST_MODIFY_IP").asText() : null)
                    .type(jsonNode.has("TYPE_ID") && !jsonNode.get("TYPE_ID").isNull() ? 
                        typeRepository.findById(jsonNode.get("TYPE_ID").asLong())
                                .map(TypeMapperUtil::toDto).orElse(null) : null)
                    .country(jsonNode.has("COUNTRY_ID") && !jsonNode.get("COUNTRY_ID").isNull() ? 
                        countryRepository.findById(jsonNode.get("COUNTRY_ID").asLong())
                                .map(CountryMapperUtil::toDto).orElse(null) : null)
                    .module(jsonNode.has("MODULE_ID") && !jsonNode.get("MODULE_ID").isNull() ? 
                        moduleRepository.findById(jsonNode.get("MODULE_ID").asLong())
                                .map(ModuleMapperUtil::toDto).orElse(null) : null)
                    .status(jsonNode.has("STATUS_ID") && !jsonNode.get("STATUS_ID").isNull() ? 
                        statusRepository.findById(jsonNode.get("STATUS_ID").asLong())
                                .map(StatusMapperUtil::toDto).orElse(null) : null)
                    .userNubo(jsonNode.has("USER_NUBO_ID") && !jsonNode.get("USER_NUBO_ID").isNull() ? 
                        userNuboRepository.findById(jsonNode.get("USER_NUBO_ID").asLong())
                                .map(UserNuboMapperUtil::toDto).orElse(null) : null)
                    .build();
        } catch (Exception e) {
            return null;
        }
    }

    public List<ScheduleLogDto> toDtoList(List<ScheduleLogEntity> entities) {
        if (entities == null || entities.isEmpty()) {
            return Collections.emptyList();
        }
        return entities.stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

}