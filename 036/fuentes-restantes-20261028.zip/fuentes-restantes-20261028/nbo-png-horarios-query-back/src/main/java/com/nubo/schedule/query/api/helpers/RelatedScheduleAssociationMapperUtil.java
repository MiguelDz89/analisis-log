package com.nubo.schedule.query.api.helpers;

import com.nubo.schedule.query.api.exception.ServiceException;
import com.nubo.schedule.query.api.exception.error.ErrorCode;
import com.nubo.schedule.query.api.models.dto.response.ScheduleAssociationDto;
import com.nubo.schedule.query.api.models.entity.RelatedScheduleEntity;
import com.nubo.schedule.query.api.models.entity.ScheduleEntity;
import com.nubo.schedule.query.api.repository.ScheduleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class RelatedScheduleAssociationMapperUtil {

    private final ScheduleRepository scheduleRepository;

    public ScheduleAssociationDto toDto(RelatedScheduleEntity entity) {
        if (entity == null) return null;
        ScheduleEntity scheduleEntity = getSchedule(entity.getRelatedScheduleId());
        return ScheduleAssociationDto.builder()
                .id(entity.getRelatedScheduleId())
                .description(scheduleEntity.getDescription())
                .schedule(ScheduleMapperUtil.toDto(scheduleEntity))
                .startTime(scheduleEntity.getOpeningTime())
                .endTime(scheduleEntity.getClosingTime())
                .country(CountryMapperUtil.toDto(scheduleEntity.getCountry()))
                .build();
    }

    public List<ScheduleAssociationDto> toDtoList(List<RelatedScheduleEntity> entities) {
        if (entities == null || entities.isEmpty()) {
            return Collections.emptyList();
        }
        return entities.stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    private ScheduleEntity getSchedule(Long scheduleId) {
        return scheduleRepository.findById(scheduleId)
                .orElseThrow(() -> new ServiceException(ErrorCode.SCHEDULE_NOT_FOUND, HttpStatus.NOT_FOUND));
    }

}