package com.nubo.schedule.query.api.service;

import com.nubo.schedule.query.api.models.dto.response.ScheduleStatusHistoryDto;
import com.nubo.schedule.query.api.models.dto.response.PageResponseOutDto;

public interface ScheduleStatusHistoryService {

    PageResponseOutDto<ScheduleStatusHistoryDto> getAllByUser(Long userId, int page, int size, String sort, String order, boolean all);

    PageResponseOutDto<ScheduleStatusHistoryDto> getByScheduleId(Long scheduleId, Long userId, int page, int size, String sort, String order, boolean all);

}