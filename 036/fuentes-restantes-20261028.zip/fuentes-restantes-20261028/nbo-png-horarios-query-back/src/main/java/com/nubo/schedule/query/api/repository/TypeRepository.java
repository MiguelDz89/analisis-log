package com.nubo.schedule.query.api.repository;

import com.nubo.schedule.query.api.models.entity.TypeEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TypeRepository extends JpaRepository<TypeEntity, Long> {

    List<TypeEntity> findByCategory(String category);
}