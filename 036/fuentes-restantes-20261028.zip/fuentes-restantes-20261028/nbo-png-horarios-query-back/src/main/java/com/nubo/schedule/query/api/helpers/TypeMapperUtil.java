package com.nubo.schedule.query.api.helpers;

import com.nubo.schedule.query.api.models.dto.response.TypeDto;
import com.nubo.schedule.query.api.models.entity.TypeEntity;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class TypeMapperUtil {

    public static TypeDto toDto(TypeEntity entity) {
        if (entity==null) return null;
        return TypeDto.builder()
                .id(entity.getId())
                .description(entity.getDescription())
                .category(entity.getCategory())
                .build();
    }

    public static List<TypeDto> toDtoList(List<TypeEntity> entities) {
        if (entities==null || entities.isEmpty()) {
            return Collections.emptyList();
        }
        return entities.stream()
                .map(TypeMapperUtil::toDto)
                .collect(Collectors.toList());
    }
}