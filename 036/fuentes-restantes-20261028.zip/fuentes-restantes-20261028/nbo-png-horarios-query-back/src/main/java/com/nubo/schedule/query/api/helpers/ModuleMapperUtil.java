package com.nubo.schedule.query.api.helpers;

import com.nubo.schedule.query.api.models.dto.response.ModuleDto;
import com.nubo.schedule.query.api.models.entity.ModuleEntity;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class ModuleMapperUtil {

    public static ModuleDto toDto(ModuleEntity entity) {
        if (entity==null) return null;
        return ModuleDto.builder()
                .id(entity.getId())
                .categoryId(entity.getCategoryId())
                .name(entity.getName())
                .description(entity.getDescription())
                .collapsible(entity.getCollapsible())
                .orderItem(entity.getOrderItem())
                .status(entity.getStatus()!=null ? StatusMapperUtil.toDto(entity.getStatus()):null)
                .moduleDeleted(entity.getModuleDeleted())
                .build();
    }

    public static List<ModuleDto> toDtoList(List<ModuleEntity> entities) {
        if (entities==null || entities.isEmpty()) {
            return Collections.emptyList();
        }
        return entities.stream()
                .map(ModuleMapperUtil::toDto)
                .collect(Collectors.toList());
    }
}