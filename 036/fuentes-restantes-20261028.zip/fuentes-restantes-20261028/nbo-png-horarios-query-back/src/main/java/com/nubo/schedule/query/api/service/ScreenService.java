package com.nubo.schedule.query.api.service;

import com.nubo.schedule.query.api.models.dto.response.ScreenDto;
import com.nubo.schedule.query.api.models.dto.response.PageResponseOutDto;

public interface ScreenService {

    PageResponseOutDto<ScreenDto> getAllByUser(Long userId, int page, int size, String sort, String order, boolean all);

}