package com.nubo.schedule.query.api.service;

import com.nubo.schedule.query.api.models.dto.response.RejectionReasonDto;
import com.nubo.schedule.query.api.models.dto.response.PageResponseOutDto;

public interface RejectionReasonService {

    PageResponseOutDto<RejectionReasonDto> getByCategoryAndReason(String category, String reason, int page, int size, String sort, String order, boolean all);

}