package com.nubo.schedule.query.api.helpers;

import com.nubo.schedule.query.api.models.dto.response.ScreenDto;
import com.nubo.schedule.query.api.models.entity.ScreenEntity;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class ScreenMapperUtil {

    public static ScreenDto toDto(ScreenEntity entity) {
        if (entity==null) return null;
        return ScreenDto.builder()
                .id(entity.getId())
                .code(entity.getCode())
                .description(entity.getDescription())
                .categoryId(entity.getCategoryId())
                .moduleId(entity.getModuleId())
                .submoduleId(entity.getSubmoduleId())
                .build();
    }

    public static List<ScreenDto> toDtoList(List<ScreenEntity> entities) {
        if (entities==null || entities.isEmpty()) {
            return Collections.emptyList();
        }
        return entities.stream()
                .map(ScreenMapperUtil::toDto)
                .collect(Collectors.toList());
    }
}