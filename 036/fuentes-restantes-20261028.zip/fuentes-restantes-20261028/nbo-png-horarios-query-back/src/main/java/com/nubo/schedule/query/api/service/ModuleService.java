package com.nubo.schedule.query.api.service;

import com.nubo.schedule.query.api.models.dto.response.ModuleDto;
import com.nubo.schedule.query.api.models.dto.response.PageResponseOutDto;

public interface ModuleService {

    PageResponseOutDto<ModuleDto> getAllByUser(Long userId, int page, int size, String sort, String order, boolean all);

    PageResponseOutDto<ModuleDto> searchModules(String name, String description, Integer categoryId, Integer id, int page, int size, String sort, String order, boolean all);

}