package com.nubo.schedule.query.api.helpers;

import com.nubo.schedule.query.api.models.dto.response.FrequencyDto;
import com.nubo.schedule.query.api.models.entity.FrequencyEntity;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class FrequencyMapperUtil {

    public static FrequencyDto toDto(FrequencyEntity entity) {
        if (entity==null) return null;
        return FrequencyDto.builder()
                .id(entity.getId())
                .description(entity.getDescription())
                .build();
    }

    public static List<FrequencyDto> toDtoList(List<FrequencyEntity> entities) {
        if (entities==null || entities.isEmpty()) {
            return Collections.emptyList();
        }
        return entities.stream()
                .map(FrequencyMapperUtil::toDto)
                .collect(Collectors.toList());
    }
}