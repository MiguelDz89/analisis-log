package com.nubo.schedule.query.api.repository;

import com.nubo.schedule.query.api.models.entity.FrequencyEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FrequencyRepository extends JpaRepository<FrequencyEntity, Long> {
}