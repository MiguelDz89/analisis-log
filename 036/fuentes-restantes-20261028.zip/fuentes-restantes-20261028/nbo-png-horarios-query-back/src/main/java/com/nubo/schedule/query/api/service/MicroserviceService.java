package com.nubo.schedule.query.api.service;

import com.nubo.schedule.query.api.models.dto.response.MicroserviceDto;
import com.nubo.schedule.query.api.models.dto.response.PageResponseOutDto;

public interface MicroserviceService {

    PageResponseOutDto<MicroserviceDto> getAllByUser(Long userId, int page, int size, String sort, String order, boolean all);

    PageResponseOutDto<MicroserviceDto> getBySubmoduleIdAndName(Integer submoduleId, String name, int page, int size, String sort, String order, boolean all);

}