package com.nubo.schedule.query.api.helpers;

import com.nubo.schedule.query.api.models.dto.response.ProcessDto;
import com.nubo.schedule.query.api.models.entity.ProcessEntity;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class ProcessMapperUtil {

    public static ProcessDto toDto(ProcessEntity entity) {
        if (entity==null) return null;
        return ProcessDto.builder()
                .id(entity.getId())
                .description(entity.getDescription())
                .build();
    }

    public static List<ProcessDto> toDtoList(List<ProcessEntity> entities) {
        if (entities==null || entities.isEmpty()) {
            return Collections.emptyList();
        }
        return entities.stream()
                .map(ProcessMapperUtil::toDto)
                .collect(Collectors.toList());
    }
}