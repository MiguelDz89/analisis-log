package com.nubo.schedule.query.api.service;

import com.nubo.schedule.query.api.models.dto.response.ProcessDto;
import com.nubo.schedule.query.api.models.dto.response.PageResponseOutDto;

public interface ProcessService {

    PageResponseOutDto<ProcessDto> getAllByUser(Long userId, int page, int size, String sort, String order, boolean all);

    PageResponseOutDto<ProcessDto> getAllByProcessWithFilters(Long processId, String description, int page, int size, String sort, String order, boolean all);

    PageResponseOutDto<ProcessDto> getByMicroserviceIdAndDescription(Integer microserviceId, String description, int page, int size, String sort, String order, boolean all);

}