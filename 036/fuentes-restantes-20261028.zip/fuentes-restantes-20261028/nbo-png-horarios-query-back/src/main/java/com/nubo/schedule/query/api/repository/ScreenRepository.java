package com.nubo.schedule.query.api.repository;

import com.nubo.schedule.query.api.models.entity.ScreenEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ScreenRepository extends JpaRepository<ScreenEntity, Long> {
}