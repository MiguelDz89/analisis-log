package com.nubo.schedule.query.api.repository;

import com.nubo.schedule.query.api.models.entity.ScheduleStatusHistoryEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ScheduleStatusHistoryRepository extends JpaRepository<ScheduleStatusHistoryEntity, ScheduleStatusHistoryEntity.ScheduleStatusHistoryId> {

    @Query("SELECT ssh FROM ScheduleStatusHistoryEntity ssh WHERE ssh.scheduleId IN " +
            "(SELECT s.id FROM ScheduleEntity s WHERE s.userNubo.id = :userNuboId)")
    List<ScheduleStatusHistoryEntity> findByScheduleUserNuboId(@Param("userNuboId") Long userNuboId);

    List<ScheduleStatusHistoryEntity> findByScheduleIdOrderByTimeDesc(Long scheduleId);
}