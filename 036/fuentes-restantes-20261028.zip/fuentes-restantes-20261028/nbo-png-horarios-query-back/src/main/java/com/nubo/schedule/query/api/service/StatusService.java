package com.nubo.schedule.query.api.service;

import com.nubo.schedule.query.api.models.dto.response.StatusDto;
import com.nubo.schedule.query.api.models.dto.response.PageResponseOutDto;

public interface StatusService {

    PageResponseOutDto<StatusDto> getByCategory(String category, int page, int size, String sort, String order, boolean all);

}