package com.nubo.schedule.query.api.helpers;

import com.nubo.schedule.query.api.models.dto.response.ScreenActionDto;
import com.nubo.schedule.query.api.models.entity.ScreenActionEntity;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class ScreenActionMapperUtil {

    public static ScreenActionDto toDto(ScreenActionEntity entity) {
        if (entity == null) return null;
        return ScreenActionDto.builder()
                .id(entity.getId())
                .code(entity.getCode())
                .description(entity.getDescription())
                .build();
    }

    public static List<ScreenActionDto> toDtoList(List<ScreenActionEntity> entities) {
        if (entities == null || entities.isEmpty()) {
            return Collections.emptyList();
        }
        return entities.stream()
                .map(ScreenActionMapperUtil::toDto)
                .collect(Collectors.toList());
    }

}
