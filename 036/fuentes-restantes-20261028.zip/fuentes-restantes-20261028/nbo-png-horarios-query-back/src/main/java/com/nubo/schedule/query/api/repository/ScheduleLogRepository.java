package com.nubo.schedule.query.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.nubo.schedule.query.api.models.entity.ScheduleLogEntity;

public interface ScheduleLogRepository extends JpaRepository<ScheduleLogEntity, Long>, JpaSpecificationExecutor<ScheduleLogEntity> {

}