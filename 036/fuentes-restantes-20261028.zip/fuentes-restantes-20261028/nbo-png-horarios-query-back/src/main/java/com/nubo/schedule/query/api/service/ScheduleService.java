package com.nubo.schedule.query.api.service;

import java.util.List;

import com.nubo.schedule.query.api.models.dto.response.PageResponseOutDto;
import com.nubo.schedule.query.api.models.dto.response.ScheduleDto;
import com.nubo.schedule.query.api.models.dto.response.ScheduleSummaryDto;

public interface ScheduleService {

    PageResponseOutDto<ScheduleDto> getAllByUser(Long userId);
    
    PageResponseOutDto<ScheduleDto> getAllByUser(Long userId, int page, int size, String sort, String order, boolean all);

    PageResponseOutDto<ScheduleDto> getAllSchedulesWithoutUser(
            List<String> countryCodes,
            List<String> screenActionCodes,
            List<Long> processIds,
            boolean extendClosingTime,
            int page, int size, String sort, String order);

    PageResponseOutDto<ScheduleDto> getAllSchedulesWithFilters(
            Long scheduleId, Long countryId,
            Long processId, String processSearch,
            Long moduleId, String moduleSearch,
            Long submoduleId, String submoduleSearch,
            Long stateId, String stateSearch,
            List<Long> countryIds, String countrySearch,
            String screenActionCode,
            Long userId,
            int page, int size, String sort, String order, boolean all);

    PageResponseOutDto<ScheduleDto> getAllSchedulesWithFiltersAndDescription(
            Long scheduleId, Long countryId,
            Long processId, String processSearch,
            Long moduleId, String moduleSearch,
            Long submoduleId, String submoduleSearch,
            Long stateId, String stateSearch,
            List<Long> countryIds, String countrySearch,
            String screenActionCode,
            String descriptionSearch,
            Long userId,
            int page, int size, String sort, String order, boolean all);

    PageResponseOutDto<ScheduleSummaryDto> getAllSchedulesSummaryWithFilters(
            Long scheduleId, Long countryId,
            Long processId, String processSearch,
            Long moduleId, String moduleSearch,
            Long submoduleId, String submoduleSearch,
            Long stateId, String stateSearch,
            List<Long> countryIds, String countrySearch,
            String screenActionCode,
            String descriptionSearch,
            Long userId,
            int page, int size, String sort, String order, boolean all);

    ScheduleDto getScheduleById(Long scheduleId);

    PageResponseOutDto<ScheduleDto> getSchedulesByScreenActionCode(String screenActionCode, int page, int size, String sort, String order, boolean all);
}