package com.nubo.schedule.query.api.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.nubo.schedule.query.api.models.entity.ScheduleEntity;

public interface ScheduleRepository extends JpaRepository<ScheduleEntity, Long>, JpaSpecificationExecutor<ScheduleEntity> {

    List<ScheduleEntity> findByUserNuboId(Long userNuboId);

    @Query("SELECT s FROM ScheduleEntity s WHERE s.process.id = :processId")
    List<ScheduleEntity> findByProcessId(@Param("processId") Long processId);

    @Query("SELECT s FROM ScheduleEntity s WHERE s.screenAction.code = :screenActionCode")
    List<ScheduleEntity> findByScreenActionCode(@Param("screenActionCode") String screenActionCode);

    Page<ScheduleEntity> findByCountry_CodeIn(List<String> countryCodes, Pageable page);

    Page<ScheduleEntity> findByCountry_CodeInAndScreenAction_CodeIn(List<String> countryCodes, List<String> screenActionCodes, Pageable page);

    Page<ScheduleEntity> findByCountry_CodeInAndProcessIdIn(List<String> countryCodes, List<Long> processIds, Pageable page);
}
