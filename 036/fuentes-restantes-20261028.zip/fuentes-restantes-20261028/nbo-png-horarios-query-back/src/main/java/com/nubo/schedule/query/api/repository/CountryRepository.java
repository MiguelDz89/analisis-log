package com.nubo.schedule.query.api.repository;

import com.nubo.schedule.query.api.models.entity.CountryEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CountryRepository extends JpaRepository<CountryEntity, Long> {

    List<CountryEntity> findByCodeIn(List<String> codes);
}