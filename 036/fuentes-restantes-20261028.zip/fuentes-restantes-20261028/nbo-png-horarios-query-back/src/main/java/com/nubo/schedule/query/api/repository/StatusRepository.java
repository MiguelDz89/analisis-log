package com.nubo.schedule.query.api.repository;

import com.nubo.schedule.query.api.models.entity.StatusEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface StatusRepository extends JpaRepository<StatusEntity, Long> {

    List<StatusEntity> findByCategory(String category);
}