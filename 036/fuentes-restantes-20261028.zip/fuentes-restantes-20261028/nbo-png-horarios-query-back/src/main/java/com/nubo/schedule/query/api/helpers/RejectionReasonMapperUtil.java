package com.nubo.schedule.query.api.helpers;

import com.nubo.schedule.query.api.models.dto.response.RejectionReasonDto;
import com.nubo.schedule.query.api.models.entity.RejectionReasonEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class RejectionReasonMapperUtil {

    private RejectionReasonMapperUtil() {
        throw new IllegalStateException("Utility class");
    }

    public static RejectionReasonDto toDto(RejectionReasonEntity entity) {
        return RejectionReasonDto.builder()
                .id(entity.getId())
                .reason(entity.getReason())
                .category(entity.getCategory())
                .build();
    }

    public static List<RejectionReasonDto> toDtoList(List<RejectionReasonEntity> entities) {
        if (entities==null) {
            return new ArrayList<>();
        }
        return entities.stream()
                .map(RejectionReasonMapperUtil::toDto)
                .collect(Collectors.toList());
    }
}