package com.nubo.schedule.query.api.helpers;

import com.nubo.schedule.query.api.exception.ServiceException;
import com.nubo.schedule.query.api.exception.error.ErrorCode;
import com.nubo.schedule.query.api.models.dto.response.ScheduleDto;
import com.nubo.schedule.query.api.models.dto.response.ScheduleSummaryDto;
import com.nubo.schedule.query.api.models.entity.ScheduleEntity;
import org.springframework.http.HttpStatus;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class ScheduleMapperUtil {

    public static ScheduleDto toDto(ScheduleEntity entity) {
        if (entity == null) return null;
        return ScheduleDto.builder()
                .id(entity.getId())
                .description(entity.getDescription())
                .openingTime(entity.getOpeningTime())
                .closingTime(entity.getClosingTime())
                .type(entity.getType() != null ? TypeMapperUtil.toDto(entity.getType()) : null)
                .startDate(entity.getStartDate())
                .endDate(entity.getEndDate())
                .country(entity.getCountry() != null ? CountryMapperUtil.toDto(entity.getCountry()) : null)
                .module(entity.getModule() != null ? ModuleMapperUtil.toDto(entity.getModule()) : null)
                .submodule(entity.getSubmodule() != null ? SubmoduleMapperUtil.toDto(entity.getSubmodule()) : null)
                .frequency(entity.getFrequency())
                .status(entity.getStatus() != null ? StatusMapperUtil.toDto(entity.getStatus()) : null)
                .internal(entity.getInternal())
                .userNubo(entity.getUserNubo() != null ? UserNuboMapperUtil.toDto(entity.getUserNubo()) : null)
                .lastModifyUser(entity.getLastModifyUser())
                .lastModifyApplication(entity.getLastModifyApplication())
                .lastModifyDate(entity.getLastModifyDate())
                .lastModifyIp(entity.getLastModifyIp())
                .dailyStatus(calculateDailyStatus(entity.getEndDate(), entity.getClosingTime(), entity.getCountry().getTimeZone()))
                .automatic(entity.getAutomatic())
                .process(entity.getProcess() != null ? ProcessMapperUtil.toDto(entity.getProcess()) : null)
                .screenAction(entity.getScreenAction() != null ? ScreenActionMapperUtil.toDto(entity.getScreenAction()): null)
                .build();
    }

    private static String calculateDailyStatus(LocalDate endDate, LocalTime closingTime,
                                               String timeZone) {
        if (endDate == null || closingTime == null) {
            return "Abierto";
        }

        ZonedDateTime countryZonedDateTime = getDateTimeCurrentByTimeZone(timeZone);

        LocalDate currentDate = countryZonedDateTime.toLocalDate();
        LocalTime currentTime = countryZonedDateTime.toLocalTime();

        // Si la fecha actual supera al endDate, está cerrado
        if (currentDate.isAfter(endDate)) {
            return "Cerrado";
        }

        // Si estamos en el endDate, comparamos con closingTime
        if (currentDate.isEqual(endDate) && currentTime.isAfter(closingTime)) {
            return "Cerrado";
        }

        return "Abierto";
    }

    public static List<ScheduleDto> toDtoList(List<ScheduleEntity> entities) {
        if (entities == null || entities.isEmpty()) {
            return Collections.emptyList();
        }
        return entities.stream()
                .map(ScheduleMapperUtil::toDto)
                .collect(Collectors.toList());
    }

    public static ScheduleSummaryDto toSummaryDto(ScheduleEntity entity) {
        if (entity == null) return null;
        return ScheduleSummaryDto.builder()
                .id(entity.getId())
                .description(entity.getDescription())
                .build();
    }

    public static List<ScheduleSummaryDto> toSummaryDtoList(List<ScheduleEntity> entities) {
        if (entities == null || entities.isEmpty()) {
            return Collections.emptyList();
        }
        return entities.stream()
                .map(ScheduleMapperUtil::toSummaryDto)
                .collect(Collectors.toList());
    }

    public static ZonedDateTime getDateTimeCurrentByTimeZone(String timeZone) {
        ZoneId zoneId = parseTimeZone(timeZone);

        ZonedDateTime zonedDateTime = ZonedDateTime.now(zoneId);

        return zonedDateTime;
    }

    public static ZoneId parseTimeZone(String timeZone) {
        try {
            if (timeZone.startsWith("UTC")) {
                String offset = timeZone.replace("UTC", "").trim();


                if (offset.contains(" a ")) {
                    offset = offset.split(" a ")[0].trim();
                }

                if (offset.isEmpty()) {
                    return ZoneId.of("UTC");
                }

                if (!offset.startsWith("+") && !offset.startsWith("-")) {
                    offset = "+" + offset;
                }

                offset = normalizeOffset(offset);

                return ZoneId.of(offset);
            }
            return ZoneId.of(timeZone);
        } catch (Exception e) {
            throw new ServiceException(ErrorCode.INVALID_TIMEZONE, HttpStatus.BAD_REQUEST);
        }
    }

    public static String normalizeOffset(String offset) {
        if (offset.matches("[+-]\\d:\\d{2}")) {
            return offset.substring(0, 1) + "0" + offset.substring(1);
        } else if (offset.matches("[+-]\\d{1}$")) {
            return offset.substring(0, 1) + "0" + offset.substring(1);
        }
        return offset;
    }

}