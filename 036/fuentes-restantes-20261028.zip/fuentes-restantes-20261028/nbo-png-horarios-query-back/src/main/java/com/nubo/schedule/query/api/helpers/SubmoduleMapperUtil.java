package com.nubo.schedule.query.api.helpers;

import com.nubo.schedule.query.api.models.dto.response.SubmoduleDto;
import com.nubo.schedule.query.api.models.entity.SubmoduleEntity;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class SubmoduleMapperUtil {

    public static SubmoduleDto toDto(SubmoduleEntity entity) {
        if (entity==null) return null;
        return SubmoduleDto.builder()
                .id(entity.getId())
                .description(entity.getDescription())
                .name(entity.getName())
                .collapsible(entity.getCollapsible())
                .orderItem(entity.getOrderItem())
                .status(entity.getStatus()!=null ? StatusMapperUtil.toDto(entity.getStatus()):null)
                .module(entity.getModule()!=null ? ModuleMapperUtil.toDto(entity.getModule()):null)
                .build();
    }

    public static List<SubmoduleDto> toDtoList(List<SubmoduleEntity> entities) {
        if (entities==null || entities.isEmpty()) {
            return Collections.emptyList();
        }
        return entities.stream()
                .map(SubmoduleMapperUtil::toDto)
                .collect(Collectors.toList());
    }
}