package com.nubo.schedule.query.api.helpers;

import com.nubo.schedule.query.api.models.dto.response.ParticipantDto;
import com.nubo.schedule.query.api.models.entity.ParticipantEntity;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class ParticipantMapperUtil {

    public static ParticipantDto toDto(ParticipantEntity entity) {
        if (entity==null) return null;
        return ParticipantDto.builder()
                .id(entity.getId())
                .code(entity.getCode())
                .documentNumber(entity.getDocumentNumber())
                .name(entity.getName())
                .shortName(entity.getShortName())
                .mnemonic(entity.getMnemonic())
                .registrationDate(entity.getRegistrationDate())
                .taxCode(entity.getTaxCode())
                .mainAddress(entity.getMainAddress())
                .webPage(entity.getWebPage())
                .phoneNumber(entity.getPhoneNumber())
                .nitClearingHouse(entity.getNitClearingHouse())
                .typeEntity(entity.getTypeEntity())
                .marginAccount(entity.getMarginAccount())
                .masterAccount(entity.getMasterAccount())
                .directAllocation(entity.getDirectAllocation())
                .marketMaker(entity.getMarketMaker())
                .enabled(entity.getEnabled())
                .custodian(entity.getCustodian())
                .build();
    }

    public static List<ParticipantDto> toDtoList(List<ParticipantEntity> entities) {
        if (entities==null || entities.isEmpty()) {
            return Collections.emptyList();
        }
        return entities.stream()
                .map(ParticipantMapperUtil::toDto)
                .collect(Collectors.toList());
    }
}