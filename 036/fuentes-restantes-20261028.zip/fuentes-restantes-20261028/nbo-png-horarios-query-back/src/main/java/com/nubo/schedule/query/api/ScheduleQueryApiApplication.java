package com.nubo.schedule.query.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScheduleQueryApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ScheduleQueryApiApplication.class, args);
    }

}
