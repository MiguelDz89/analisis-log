package com.nubo.schedule.query.api.repository;

import com.nubo.schedule.query.api.models.entity.RejectionReasonEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface RejectionReasonRepository extends JpaRepository<RejectionReasonEntity, Long>, JpaSpecificationExecutor<RejectionReasonEntity> {
}