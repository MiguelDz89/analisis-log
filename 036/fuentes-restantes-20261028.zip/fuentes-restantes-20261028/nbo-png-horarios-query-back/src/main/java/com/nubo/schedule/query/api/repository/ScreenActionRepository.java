package com.nubo.schedule.query.api.repository;

import com.nubo.schedule.query.api.models.entity.ScreenActionEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface ScreenActionRepository extends JpaRepository<ScreenActionEntity, Long>, JpaSpecificationExecutor<ScreenActionEntity> {

    List<ScreenActionEntity> findByCode(String code);
}
