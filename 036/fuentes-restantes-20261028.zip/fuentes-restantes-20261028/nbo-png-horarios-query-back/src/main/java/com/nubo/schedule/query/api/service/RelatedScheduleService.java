package com.nubo.schedule.query.api.service;

import com.nubo.schedule.query.api.models.dto.response.PageResponseOutDto;
import com.nubo.schedule.query.api.models.dto.response.ScheduleAssociationDto;

public interface RelatedScheduleService {

    PageResponseOutDto<ScheduleAssociationDto> getAllByScheduleId(Long scheduleId, int page, int size, String sort, String order, boolean all);

}