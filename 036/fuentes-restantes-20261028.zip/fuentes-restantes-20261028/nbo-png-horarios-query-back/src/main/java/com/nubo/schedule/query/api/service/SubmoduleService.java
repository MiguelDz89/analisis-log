package com.nubo.schedule.query.api.service;

import com.nubo.schedule.query.api.models.dto.response.PageResponseOutDto;
import com.nubo.schedule.query.api.models.dto.response.SubmoduleDto;

public interface SubmoduleService {

    PageResponseOutDto<SubmoduleDto> getAllByUser(Long userId, int page, int size, String sort, String order, boolean all);

    PageResponseOutDto<SubmoduleDto> getAllByModuleWithFilters(Long moduleId, String description, int page, int size, String sort, String order, boolean all);

}