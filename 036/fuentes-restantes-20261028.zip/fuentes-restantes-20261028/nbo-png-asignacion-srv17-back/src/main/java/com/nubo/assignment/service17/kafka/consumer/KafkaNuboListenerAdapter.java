package com.nubo.assignment.service17.kafka.consumer;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import com.nubo.assignment.service17.application.context.GlobalContext;
import com.nubo.assignment.service17.application.properties.PropertiesConfig;
import com.nubo.assignment.service17.application.util.ApplicationUtils;
import com.nubo.assignment.service17.models.enums.PropertiesEnum;
import com.nubo.assignment.service17.service.ProcessMessageService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Component
@RequiredArgsConstructor
@Slf4j
public class KafkaNuboListenerAdapter {

    private final ProcessMessageService processMessageService;
    private final PropertiesConfig propertiesConfig;

    @KafkaListener(
            topics = "#{propertiesConfig.kafkaNuboConsumerTopicNameAssignmentRequest}",
            containerFactory = "kafkaNuboListenerContainerFactory")
    public void listenKafka(@Payload String messageJson,
            @Header(KafkaHeaders.RECEIVED_PARTITION) int partition,
            @Header(KafkaHeaders.OFFSET) long offset,
            @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
            @Header(value = KafkaHeaders.DELIVERY_ATTEMPT, required = false) Integer retry) {
        log.info("New received Message -- Topic: {} -- Partition : {} -- Offset : {} -- retry: {}",
                topic, partition, offset, retry);
        this.setProperties();
        processMessageService.assignmentFractionSrv17(messageJson);

        GlobalContext.remove();
    }

    private void setProperties() {
        String clientUserContext = propertiesConfig.getApiName();
        GlobalContext.setProperty(PropertiesEnum.CLIENT_USER.getValue(), clientUserContext);
        GlobalContext.setProperty(PropertiesEnum.CLIENT_DATETIME.getValue(),
                ApplicationUtils.getLocalDateTimeNow());
    }

}
