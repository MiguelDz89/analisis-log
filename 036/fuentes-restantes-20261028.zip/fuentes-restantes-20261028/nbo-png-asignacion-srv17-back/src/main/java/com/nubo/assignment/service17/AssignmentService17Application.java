package com.nubo.assignment.service17;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssignmentService17Application {

	public static void main(String[] args) {
		SpringApplication.run(AssignmentService17Application.class, args);
	}

}
