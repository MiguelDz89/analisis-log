package com.nubo.assignment.service17.repository;

import com.nubo.assignment.service17.models.entity.SettlementEntity;
import com.nubo.assignment.service17.models.entity.SettlementKey;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface SettlementRepository extends JpaRepository<SettlementEntity, SettlementKey> {

    @Query("""
            SELECT COUNT(s)
            FROM SettlementEntity s
            WHERE s.trade.id = :tradeId AND s.side.id = :sideId
            """)
    Long countByTradeIdAndSideId(Long tradeId, Long sideId);

    @Query("""
            SELECT COALESCE(MAX(s.fraction), 0)
            FROM SettlementEntity s
            WHERE s.trade.id = :tradeId AND s.side.id = :sideId
            """)
    Integer findMaxFractionByTradeIdAndSideId(Long tradeId, Long sideId);
}