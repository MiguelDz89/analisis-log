package com.nubo.assignment.service17.helpers;

import com.nubo.assignment.service17.models.dto.response.ParticipantOutDto;
import com.nubo.assignment.service17.models.dto.response.SideOutDto;
import com.nubo.assignment.service17.models.entity.ParticipantEntity;
import com.nubo.assignment.service17.models.entity.SideEntity;

import org.springframework.util.ObjectUtils;

public final class MapperUtil {

    private MapperUtil() {
        // Private constructor to prevent instantiation
    }

    public static ParticipantOutDto participantEntityToParticipantOutDto(ParticipantEntity participantEntity) {
        if (ObjectUtils.isEmpty(participantEntity)) {
            return null;
        }
        return ParticipantOutDto.builder()
                .id(participantEntity.getId())
                .code(participantEntity.getCode())
                .name(participantEntity.getName())
                .build();
    }

    public static SideOutDto sideEntityToSideOutDto(SideEntity sideEntity) {
        if (ObjectUtils.isEmpty(sideEntity)) {
            return null;
        }
        return SideOutDto.builder()
                .id(sideEntity.getId())
                .name(sideEntity.getDescription())
                .build();
    }
}
