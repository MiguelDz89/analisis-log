package com.nubo.assignment.service17.kafka.producer;

import java.util.concurrent.CompletableFuture;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;

import com.nubo.assignment.service17.application.properties.PropertiesConfig;
import com.nubo.assignment.service17.application.properties.PropertiesContext;
import com.nubo.assignment.service17.application.util.ApplicationUtils;
import com.nubo.assignment.service17.models.dto.response.AssignmentOutDto;
import com.nubo.assignment.service17.models.dto.response.PackageCustodianOutDto;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Component
@RequiredArgsConstructor
@Slf4j
public class KafkaNuboProducerAdapter {

    private final PropertiesConfig propertiesConfig;
    private final KafkaTemplate<String, String> kafkaNuboTemplate;

    public void sendResponseSrv17(AssignmentOutDto assignmentOutDto) {
        String topic = propertiesConfig.getKafkaNuboProducerTopicNameAssignmentResponse();
        String jsonString = ApplicationUtils.convertObjectToJson(assignmentOutDto);
        ProducerRecord<String, String> record = new ProducerRecord<>(topic, jsonString);

        record.headers().add("client_user", PropertiesContext.getClientUser().getBytes());
        record.headers().add("timestamp", String.valueOf(System.currentTimeMillis()).getBytes());
        record.headers().add("service_id", "srv17".getBytes());

        CompletableFuture<SendResult<String, String>> future = kafkaNuboTemplate.send(record)
                .toCompletableFuture();

        future.thenAccept(result -> log.info("Send message -- Topic: {} -- offset: {} -- json: {} ",
                topic, result.getRecordMetadata().offset(), jsonString))
                .exceptionally(ex -> {
                    log.error("Error sending message to Kafka topic: {}, exception: {}", topic, ex.getMessage(), ex);
                    return null;
                });
    }

    public void sendCreatePackageCustodySync(PackageCustodianOutDto packageCustodianOutDto) {
        String topic = propertiesConfig.getKafkaNuboProducerTopicCreatePackageCustody();
        String jsonString = ApplicationUtils.convertObjectToJson(packageCustodianOutDto);
        try {
            kafkaNuboTemplate.send(topic, jsonString).get();
            log.debug("Send message -- Topic: {} -- json: {} ", topic, jsonString);
        } catch (Exception ex) {
            log.error("Error sending message to topic: {} -- json: {}, Exception: {}", topic, jsonString, ex);
        }
    }
}
