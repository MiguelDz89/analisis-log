package com.nubo.assignment.service17.service.impl;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.nubo.assignment.service17.application.util.ApplicationUtils;
import com.nubo.assignment.service17.client.operations.cmd.models.request.FractionClientInDto;
import com.nubo.assignment.service17.client.operations.cmd.models.response.FractionAccountOutDto;
import com.nubo.assignment.service17.client.operations.cmd.models.response.ParticipantBankAccountOutDto;
import com.nubo.assignment.service17.client.operations.cmd.models.response.SettlementOutDto;
import com.nubo.assignment.service17.client.operations.cmd.service.OperationsCmdClient;
import com.nubo.assignment.service17.exception.ServiceException;
import com.nubo.assignment.service17.exception.error.ErrorCode;
import com.nubo.assignment.service17.helpers.ExceptionMessageUtil;
import com.nubo.assignment.service17.helpers.MapperUtil;
import com.nubo.assignment.service17.helpers.ValidatorUtil;
import com.nubo.assignment.service17.kafka.producer.KafkaNuboProducerAdapter;
import com.nubo.assignment.service17.models.domain.TradeSide;
import com.nubo.assignment.service17.models.dto.request.AssignmentFractionInDto;
import com.nubo.assignment.service17.models.dto.request.AssignmentInDto;
import com.nubo.assignment.service17.models.dto.response.AssignmentOutDto;
import com.nubo.assignment.service17.models.dto.response.PackageCustodianOutDto;
import com.nubo.assignment.service17.models.entity.ParticipantEntity;
import com.nubo.assignment.service17.models.entity.SideEntity;
import com.nubo.assignment.service17.models.entity.TradeEntity;
import com.nubo.assignment.service17.models.enums.CustodianEquivalenceEnum;
import com.nubo.assignment.service17.models.enums.SideEnum;
import com.nubo.assignment.service17.repository.ParticipantRepository;
import com.nubo.assignment.service17.repository.SideRepository;
import com.nubo.assignment.service17.repository.TradeRepository;
import com.nubo.assignment.service17.service.ProcessMessageService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProcessMessageServiceImpl implements ProcessMessageService {

    private final KafkaNuboProducerAdapter kafkaNuboProducerAdapter;
    private final TradeRepository tradeRepository;
        private final ParticipantRepository participantRepository;
    private final SideRepository sideRepository;
    private final OperationsCmdClient operationsCmdClient;
    private final ValidatorUtil validatorUtil;
    private final ExceptionMessageUtil exceptionMessageUtil;

    @Override
    public void assignmentFractionSrv17(String messageJson) {
        log.info("Start method assignmentFractionSrv17");
        try {
            AssignmentInDto assignmentInDto = buildAssignmentInDto(messageJson);
            AssignmentOutDto assignmentOutDto = validateAssignment(assignmentInDto);
            kafkaNuboProducerAdapter.sendResponseSrv17(assignmentOutDto);
        } catch (Exception e) {
            AssignmentOutDto assignmentOutDto = AssignmentOutDto.builder()
                    .messageAssignment(exceptionMessageUtil.buildErrorMessage(e))
                    .timestamp(Instant.now())
                    .build();
            kafkaNuboProducerAdapter.sendResponseSrv17(assignmentOutDto);
        }
        log.info("End method assignmentFractionSrv17");
    }

    private AssignmentOutDto validateAssignment(AssignmentInDto assignmentInDto) {
        Optional<SideEntity> sideEntityOp = sideRepository.findById(assignmentInDto.getSide());
        Optional<TradeEntity> tradeEntityOp = tradeRepository.findByMatchIdAndMatchDate(assignmentInDto.getMatchId(),
                assignmentInDto.getOperationDate());

        if (tradeEntityOp.isEmpty() || sideEntityOp.isEmpty()) {
            return buildAssignmentOutDtoError(assignmentInDto, "Message does not exist in TRADE");
        }

        TradeEntity tradeEntity = tradeEntityOp.get();
        SideEntity sideEntity = sideEntityOp.get();

        ParticipantBankAccountOutDto participantBankAccountOutDto = operationsCmdClient
                .validateCudAccountFractionAssignment(tradeEntity.getId(), sideEntity.getId());

        String participantCode = assignmentInDto.getAffiliate().startsWith("CO0")
                ? assignmentInDto.getAffiliate()
                : "CO0" + assignmentInDto.getAffiliate();
        ParticipantEntity participantEntityBuy = tradeEntity.getParticipantBuy();
        ParticipantEntity participantEntitySell = tradeEntity.getParticipantSell();

        if (SideEnum.BUY.getId().equalsIgnoreCase(sideEntity.getId())
                && participantEntityBuy.getCode().equalsIgnoreCase(participantCode)) {
            TradeSide tradeSide = new TradeSide(tradeEntity.getId(), tradeEntity.getMatchId(),
                    tradeEntity.getMatchDate(), sideEntity, participantEntityBuy,
                    tradeEntity.getSourceQuoteBuyType(), tradeEntity.getAssignmentMarkBuy(),
                    assignmentInDto.getAffiliate(), participantBankAccountOutDto,
                    tradeEntity.getMarketId());
            return processAssignment(tradeSide, assignmentInDto.getAssignmentFractions());

        } else if (SideEnum.SELL.getId().equalsIgnoreCase(sideEntity.getId())
                && participantEntitySell.getCode().equalsIgnoreCase(participantCode)) {
            TradeSide tradeSide = new TradeSide(tradeEntity.getId(), tradeEntity.getMatchId(),
                    tradeEntity.getMatchDate(), sideEntity, participantEntitySell,
                    tradeEntity.getSourceQuoteSellType(), tradeEntity.getAssignmentMarkSell(),
                    assignmentInDto.getAffiliate(), participantBankAccountOutDto,
                    tradeEntity.getMarketId());
            return processAssignment(tradeSide, assignmentInDto.getAssignmentFractions());

        } else {
            log.warn("Participant code {} does not match BUY or SELL participant for sideId {}", participantCode,
                    sideEntity.getId());
            return buildAssignmentOutDtoError(assignmentInDto,
                    "Participant not found for sideId: " + sideEntity.getId());
        }
    }

    private AssignmentOutDto processAssignment(TradeSide tradeSide,
            List<AssignmentFractionInDto> assignmentFractionInDtoList) {
        log.debug("Processing assignment for TradeSide: {}, with {} fractions", tradeSide,
                assignmentFractionInDtoList.size());
        try {
            List<FractionClientInDto> fractionInDtoList = assignmentFractionInDtoList.stream()
                    .map(assignmentFractionInDto -> buildFractionClientInDto(tradeSide, assignmentFractionInDto))
                    .toList();
            List<SettlementOutDto> settlementOutDtoList;
            if (Boolean.TRUE.equals(tradeSide.assignmentMark())) {
                settlementOutDtoList = operationsCmdClient.fractionationUpdateAssignment(tradeSide.tradeId(),
                        tradeSide.sideEntity().getId(), fractionInDtoList);
            } else {
                settlementOutDtoList = operationsCmdClient.fractionationCreateAssignment(tradeSide.tradeId(),
                        tradeSide.sideEntity().getId(), fractionInDtoList);
            }

            processCreatePackage(tradeSide, assignmentFractionInDtoList, settlementOutDtoList);

            return buildAssignmentOutDto(tradeSide, "Assignment processed successfully");
        } catch (Exception e) {
            return buildAssignmentOutDto(tradeSide,
                    "Error processing assignment: " + exceptionMessageUtil.buildErrorMessage(e));
        }
    }

    private FractionClientInDto buildFractionClientInDto(TradeSide tradeSide,
            AssignmentFractionInDto assignmentFractionInDto) {
        FractionAccountOutDto fractionAccountOutDto = operationsCmdClient.validateAccountFractionAssignment(
                assignmentFractionInDto.getDvlDcvAccount(), tradeSide.tradeId(), tradeSide.sideEntity().getId(),
                tradeSide.sourceQuoteType().getId());

        return FractionClientInDto.builder()
                .investorAccountId(fractionAccountOutDto.getInvestorAccount() == null
                        ? null
                        : fractionAccountOutDto.getInvestorAccount().getId())
                .participantAccountId(fractionAccountOutDto.getParticipantAccount() == null
                        ? null
                        : fractionAccountOutDto.getParticipantAccount().getId())
                .directDepositorId(null)
                .fiduciarySpecialist(fractionAccountOutDto.getFiduciarySpecialist())
                .sourceQuoteTypeId(tradeSide.sourceQuoteType().getId())
                .reference(assignmentFractionInDto.getReference())
                .fractionQuantity(assignmentFractionInDto.getFractionalNominal())
                .commissionPercentage(assignmentFractionInDto.getCommissionPercentage() == null
                        ? BigDecimal.ZERO
                        : assignmentFractionInDto.getCommissionPercentage())
                .cashAccount(tradeSide.participantBankAccountOutDto().getBankAccount())
                .custodianId(resolveCustodianId(assignmentFractionInDto, fractionAccountOutDto))
                .ficAdministratorId(null)
                                .referencePackage(resolveReferencePackage(assignmentFractionInDto))
                .build();
    }

        private String resolveReferencePackage(AssignmentFractionInDto assignmentFractionInDto) {
                if (assignmentFractionInDto == null) {
                        return null;
                }
                if (assignmentFractionInDto.getReferencePackage() != null
                                && !assignmentFractionInDto.getReferencePackage().isBlank()) {
                        return assignmentFractionInDto.getReferencePackage();
                }
                return null;
        }

    private Long resolveCustodianId(AssignmentFractionInDto assignmentFractionInDto,
            FractionAccountOutDto fractionAccountOutDto) {
        Long inputCustodianId = assignmentFractionInDto.getCustodian();
        if (inputCustodianId != null) {
            if (inputCustodianId < 1) {
                throw new ServiceException(ErrorCode.VALIDATION_ERROR,
                        "Error de validación: El campo 'custodian' falta o tiene un valor inválido.");
            }

            CustodianEquivalenceEnum equivalence = CustodianEquivalenceEnum.fromSrvExch(inputCustodianId)
                    .orElseThrow(() -> new ServiceException(ErrorCode.VALIDATION_ERROR,
                            "Error de validación: El campo 'custodian' falta o tiene un valor inválido."));

            ParticipantEntity participantEntity = participantRepository
                    .findFirstByCodeAndCustodianTrueAndEnabledTrueOrderByIdAsc(equivalence.getParticipantCode())
                    .orElseThrow(() -> new ServiceException(ErrorCode.VALIDATION_ERROR,
                            "Error de validación: El campo 'custodian' falta o tiene un valor inválido."));

            return participantEntity.getId();
        }

        return fractionAccountOutDto.getCustodian() == null
                ? null
                : fractionAccountOutDto.getCustodian().getId();
    }

    private AssignmentOutDto buildAssignmentOutDtoError(AssignmentInDto assignmentInDto, String messageError) {
        return AssignmentOutDto.builder()
                .matchId(assignmentInDto.getMatchId())
                .matchDate(assignmentInDto.getOperationDate())
                .affiliate(assignmentInDto.getAffiliate())
                .messageAssignment(messageError)
                .timestamp(Instant.now())
                .build();
    }

    private AssignmentOutDto buildAssignmentOutDto(TradeSide tradeSide, String message) {
        return AssignmentOutDto.builder()
                .affiliate(tradeSide.affiliate())
                .tradeId(tradeSide.tradeId())
                .matchId(tradeSide.matchId())
                .matchDate(tradeSide.matchDate())
                .side(MapperUtil.sideEntityToSideOutDto(tradeSide.sideEntity()))
                .participant(MapperUtil.participantEntityToParticipantOutDto(tradeSide.participantEntity()))
                .timestamp(Instant.now())
                .messageAssignment(message)
                .build();
    }

    private AssignmentInDto buildAssignmentInDto(String messageJson) {
        AssignmentInDto assignmentInDto = ApplicationUtils.convertJsonToObject(messageJson, AssignmentInDto.class);
        validatorUtil.validateObject(assignmentInDto);
        return assignmentInDto;
    }

    private void processCreatePackage(TradeSide tradeSide, List<AssignmentFractionInDto> assignmentFractionInDtoList,
            List<SettlementOutDto> settlementOutDtoList) {
        log.info("Processing create package");
        Map<String, AssignmentFractionInDto> mapAccountNumberAndFraction = assignmentFractionInDtoList.stream()
                .filter(a -> a.getDvlDcvAccount() != null)
                .collect(Collectors.toMap(AssignmentFractionInDto::getDvlDcvAccount,
                        a -> a,
                        (existing, replacement) -> existing));

        for (SettlementOutDto settlementOutDto : settlementOutDtoList) {
            if (settlementOutDto.getCustodianStatus() == null) {
                if (settlementOutDto.getInvestorAccount() != null
                        && mapAccountNumberAndFraction
                                .containsKey(settlementOutDto.getInvestorAccount().getAccountNumber())) {
                    AssignmentFractionInDto fractionData = mapAccountNumberAndFraction
                            .get(settlementOutDto.getInvestorAccount().getAccountNumber());
                    PackageCustodianOutDto packageCustodianOutDto = PackageCustodianOutDto.builder()
                            .clientUser(tradeSide.affiliate())
                            .marketId(tradeSide.marketId())
                            .uniqueFractionId(settlementOutDto.getUniqueFractionId())
                            .participantId(tradeSide.participantEntity() != null
                                    ? tradeSide.participantEntity().getId()
                                    : 0L)
                            .codeSCB(fractionData.getReferenceCode())
                            .referencePackage(resolveReferencePackage(fractionData))
                            .build();
                    kafkaNuboProducerAdapter.sendCreatePackageCustodySync(packageCustodianOutDto);

                } else if (settlementOutDto.getParticipantAccount() != null
                        && mapAccountNumberAndFraction
                                .containsKey(settlementOutDto.getParticipantAccount().getAccountNumber())) {
                    AssignmentFractionInDto fractionData = mapAccountNumberAndFraction
                            .get(settlementOutDto.getParticipantAccount().getAccountNumber());
                    PackageCustodianOutDto packageCustodianOutDto = PackageCustodianOutDto.builder()
                            .clientUser(tradeSide.affiliate())
                            .marketId(tradeSide.marketId())
                            .uniqueFractionId(settlementOutDto.getUniqueFractionId())
                            .participantId(tradeSide.participantEntity() != null
                                    ? tradeSide.participantEntity().getId()
                                    : 0L)
                            .codeSCB(fractionData.getReferenceCode())
                            .referencePackage(resolveReferencePackage(fractionData))
                            .build();
                    kafkaNuboProducerAdapter.sendCreatePackageCustodySync(packageCustodianOutDto);
                }
            }
        }
    }
}
