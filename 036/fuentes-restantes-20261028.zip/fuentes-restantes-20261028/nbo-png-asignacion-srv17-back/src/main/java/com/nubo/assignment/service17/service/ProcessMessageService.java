package com.nubo.assignment.service17.service;

public interface ProcessMessageService {

    void assignmentFractionSrv17(String messageJson);

}
