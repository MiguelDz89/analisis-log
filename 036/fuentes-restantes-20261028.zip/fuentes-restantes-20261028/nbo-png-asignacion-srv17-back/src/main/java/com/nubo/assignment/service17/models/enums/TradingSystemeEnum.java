package com.nubo.assignment.service17.models.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.Arrays;

@Getter
@RequiredArgsConstructor
public enum TradingSystemeEnum {

    CRCP(2L);

    private final Long value;

    public static Long getValueByName(String name) {
        return Arrays.stream(TradingSystemeEnum.values())
                .filter(enumValue -> enumValue.name().equalsIgnoreCase(name))
                .map(TradingSystemeEnum::getValue)
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("No enum constant with name " + name));
    }

}
