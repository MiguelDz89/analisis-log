package com.nubo.assignment.service17.models.enums;

import lombok.Getter;

@Getter
public enum AccountTransactionTypeEnum {
    ACCOUNT_TX_TYPE_ALLOCATION_TO("ACCOUNT_TX_TYPE_ALLOCATION_TO");

    private final String code;

    AccountTransactionTypeEnum(String code) {
        this.code = code;
    }

}
