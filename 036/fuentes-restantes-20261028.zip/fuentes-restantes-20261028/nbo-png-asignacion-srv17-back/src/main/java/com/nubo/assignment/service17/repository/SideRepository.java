package com.nubo.assignment.service17.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nubo.assignment.service17.models.entity.SideEntity;

public interface SideRepository extends JpaRepository<SideEntity, String> {

}
