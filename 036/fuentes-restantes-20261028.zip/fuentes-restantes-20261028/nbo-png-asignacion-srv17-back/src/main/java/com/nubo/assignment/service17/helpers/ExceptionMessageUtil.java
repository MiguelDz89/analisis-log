package com.nubo.assignment.service17.helpers;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

import com.nubo.assignment.service17.application.util.ApplicationUtils;
import com.nubo.assignment.service17.exception.ClientException;
import com.nubo.assignment.service17.exception.error.ErrorResponse;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ExceptionMessageUtil {

    public String buildErrorMessage(Exception ex) {
        if (ex == null) {
            return "Unknown error";
        }

        StringBuilder builder = new StringBuilder();

        appendIfPresent(builder, ex.getMessage());

        if (ex instanceof ClientException clientException && clientException.getCause() != null) {
            ErrorResponse clientError = buildClientErrorResponse(clientException.getCause().getMessage());
            appendIfPresent(builder, clientError != null ? clientError.getErrorMessageDetail() : null);
        }

        appendCauseMessage(builder, ex);

        String clean = builder.toString().replaceAll("null", "").replaceAll("\\s+", " ").trim();
        if (!clean.isEmpty()) {
            return clean;
        }

        String fallback = ex.getClass().getSimpleName();
        if ("Exception".equals(fallback) && ex.getStackTrace() != null && ex.getStackTrace().length > 0) {
            fallback += " at " + ex.getStackTrace()[0];
        }
        return fallback;
    }

    private void appendCauseMessage(StringBuilder builder, Exception ex) {
        if (ex.getCause() == null || !hasText(ex.getCause().getMessage())) {
            return;
        }

        ErrorResponse errorResponse = buildClientErrorResponse(ex.getCause().getMessage());

        if (errorResponse != null) {
            String message = hasText(errorResponse.getErrorMessageDetail())
                    ? errorResponse.getErrorMessageDetail()
                    : errorResponse.getErrorMessage();
            String prefix = hasText(errorResponse.getErrorCode()) ? errorResponse.getErrorCode() : "Cause";
            appendIfPresent(builder, hasText(message) ? prefix + ": " + message.trim() : null);
        } else {
            String cleaned = ex.getCause().getMessage()
                    .replaceAll("\\{[^}]*\\}", "")
                    .replaceAll("\\d{3}\\s*:\\s*\".*", "")
                    .trim();
            if (!cleaned.isEmpty()) {
                appendWithSeparator(builder, "Cause: " + cleaned);
            } else {
                Matcher m = Pattern.compile("^(\\d{3})").matcher(ex.getCause().getMessage());
                if (m.find()) {
                    appendWithSeparator(builder, "Cause: HTTP " + m.group(1));
                }
            }
        }
    }

    private void appendIfPresent(StringBuilder builder, String message) {
        if (hasText(message)) {
            appendWithSeparator(builder, message.trim());
        }
    }

    private void appendWithSeparator(StringBuilder builder, String message) {
        if (builder.length() > 0) {
            builder.append(" | ");
        }
        builder.append(message);
    }

    private boolean hasText(String str) {
        return str != null && !str.trim().isEmpty();
    }

    public ErrorResponse buildClientErrorResponse(String cause) {
        try {
            Matcher matcher = Pattern.compile("\\{.*\\}").matcher(cause);
            if (matcher.find()) {
                ErrorResponse errorResponse = (ErrorResponse) ApplicationUtils.convertJsonToObject(
                        matcher.group(), ErrorResponse.class);
                log.warn("Warn Client -> {}", errorResponse);
                return errorResponse;
            } else {
                log.warn("Warn en buildClientErrorResponse -> No JSON found in the string");
            }
        } catch (Exception ex) {
            log.error("Error en buildClientErrorResponse -> {}", ex.getMessage());
        }
        return null;
    }

}
