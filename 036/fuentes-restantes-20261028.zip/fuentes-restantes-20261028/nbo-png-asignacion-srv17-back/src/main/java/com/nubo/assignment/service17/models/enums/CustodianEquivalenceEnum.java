package com.nubo.assignment.service17.models.enums;

import java.util.Arrays;
import java.util.Optional;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum CustodianEquivalenceEnum {

    CITITRUST_COLOMBIA_SF(1L, "CO0700"),
    SANTANDER_CONSUMER(2L, "CO0641"),
    BNP_PARIBAS_SECURITIES_SER_SF(3L, "CO0701");

    private final Long srvExch;
    private final String participantCode;

    public static Optional<CustodianEquivalenceEnum> fromSrvExch(Long srvExch) {
        return Arrays.stream(values())
                .filter(value -> value.srvExch.equals(srvExch))
                .findFirst();
    }
}
