package com.nubo.assignment.service17.models.domain;

import java.time.LocalDate;

import com.nubo.assignment.service17.client.operations.cmd.models.response.ParticipantBankAccountOutDto;
import com.nubo.assignment.service17.models.entity.ParticipantEntity;
import com.nubo.assignment.service17.models.entity.SideEntity;
import com.nubo.assignment.service17.models.entity.TypeEntity;

public record TradeSide(
        Long tradeId,
        Long matchId,
        LocalDate matchDate,
        SideEntity sideEntity,
        ParticipantEntity participantEntity,
        TypeEntity sourceQuoteType,
        Boolean assignmentMark,
        String affiliate,
        ParticipantBankAccountOutDto participantBankAccountOutDto,
        String marketId) {
}
