package com.nubo.assignment.service17.repository;

import com.nubo.assignment.service17.models.entity.InvestorAccountEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InvestorAccountRepository extends JpaRepository<InvestorAccountEntity,Long> {
    InvestorAccountEntity findByAccountNumber(String accountNumber);
}
