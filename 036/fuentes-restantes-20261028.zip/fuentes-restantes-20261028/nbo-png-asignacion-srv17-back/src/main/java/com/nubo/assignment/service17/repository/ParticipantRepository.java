package com.nubo.assignment.service17.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nubo.assignment.service17.models.entity.ParticipantEntity;

public interface ParticipantRepository extends JpaRepository<ParticipantEntity, Long> {

    Optional<ParticipantEntity> findByCode(String code);

    Optional<ParticipantEntity> findFirstByCodeAndCustodianTrueAndEnabledTrueOrderByIdAsc(String code);
}
