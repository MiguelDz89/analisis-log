package com.nubo.assignment.service17.exception.error;

import lombok.Getter;

@Getter
public enum ErrorCode {

    UNEXPECTED("An unexpected error occurred"),
    SYSTEM_NOT_FOUND("System Not  Found"),
    TRADE_NOT_FOUND("Trade Not Found "),
    INVESTOR_ACCOUNT_NOT_FOUND("Inventor Account Not Found"),
    ERROR_KAFKA_CONSUMER_NUBO("Error Consumer Kafka Nubo"),
    ERROR_KAFKA_PRODUCER_NUBO("Error Producer Kafka Nubo"),
    ERROR_DESERIALIZER_JSON("Error Deserializer Json"),
    VALIDATION_ERROR("Validation Error"),
    ERROR_SERIALIZER_JSON("Error Serializer Json"),
    CLIENT_OPERATION_FRACTIONATION_ERROR("Error Client Operation Fractionation"),
    CLIENT_OPERATION_RULES_ERROR("Error Client Operation Rules"),
    CLIENT_OPERATION_ACCOUNT_VALIDATION_ERROR("Error Client Operation Account Validation");

    private final String message;

    ErrorCode(String message) {
        this.message = message;
    }

    public String getName() {
        return this.name();
    }

}
