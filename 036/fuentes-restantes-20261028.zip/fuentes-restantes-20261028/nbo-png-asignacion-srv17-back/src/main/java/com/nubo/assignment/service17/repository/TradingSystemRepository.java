package com.nubo.assignment.service17.repository;

import com.nubo.assignment.service17.models.entity.TradingSystemEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TradingSystemRepository extends JpaRepository<TradingSystemEntity, Long> {

    TradingSystemEntity findByDescription(String description);
}