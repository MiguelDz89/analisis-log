package com.nubo.assignment.service17.repository;

import com.nubo.assignment.service17.models.entity.TradeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.time.LocalDate;
import java.util.Optional;

public interface TradeRepository extends JpaRepository<TradeEntity, Long>, JpaSpecificationExecutor<TradeEntity> {

    Optional<TradeEntity> findByMatchIdAndMatchDate(Long matchId, LocalDate matchDate);
}
