package com.nubo.assignment.service17.repository;

import com.nubo.assignment.service17.models.entity.ParticipantAccountEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ParticipantAccountRepository extends JpaRepository<ParticipantAccountEntity,Long> {

}
