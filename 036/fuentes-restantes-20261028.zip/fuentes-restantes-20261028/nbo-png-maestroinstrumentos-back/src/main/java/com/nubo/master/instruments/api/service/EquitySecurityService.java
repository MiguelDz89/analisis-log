package com.nubo.master.instruments.api.service;

import org.springframework.data.domain.Pageable;

import com.nubo.master.instruments.api.models.dto.request.EquitySecurityInDto;
import com.nubo.master.instruments.api.models.dto.request.EquitySecurityUpdateInDto;
import com.nubo.master.instruments.api.models.dto.response.EquitySecurityOutDto;
import com.nubo.master.instruments.api.models.dto.response.PageResponseOutDto;

public interface EquitySecurityService {

    PageResponseOutDto<EquitySecurityOutDto> findAllEquitySecurity(Pageable pageable);

    EquitySecurityOutDto findEquitySecurity(Long securityId);

    EquitySecurityOutDto createEquitySecurity(EquitySecurityInDto equitySecurityInDto);

    EquitySecurityOutDto updateEquitySecurity(EquitySecurityUpdateInDto equitySecurityUpdateInDto, Long securityId);

    void deleteEquitySecurity(Long securityId);

}
