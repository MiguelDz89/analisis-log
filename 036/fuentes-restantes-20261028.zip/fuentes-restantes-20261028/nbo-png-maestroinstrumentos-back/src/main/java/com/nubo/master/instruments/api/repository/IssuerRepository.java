package com.nubo.master.instruments.api.repository;

import com.nubo.master.instruments.api.models.entity.IssuerEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface IssuerRepository extends JpaRepository<IssuerEntity, Long>,
        JpaSpecificationExecutor<IssuerEntity> {
}
