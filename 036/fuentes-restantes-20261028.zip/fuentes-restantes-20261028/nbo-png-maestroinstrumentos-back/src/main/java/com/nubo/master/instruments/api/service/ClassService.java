package com.nubo.master.instruments.api.service;

import java.util.List;

import org.springframework.data.domain.Pageable;

import com.nubo.master.instruments.api.models.dto.response.ClassOutDto;
import com.nubo.master.instruments.api.models.dto.response.PageResponseOutDto;

public interface ClassService {

    PageResponseOutDto<ClassOutDto> findAllClasses(Pageable pageable);

    ClassOutDto findClassById(String classId);

    List<ClassOutDto> findClassesByCategory(String category);

}
