package com.nubo.master.instruments.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nubo.master.instruments.api.models.entity.DepositoryEntity;

public interface DepositoryRepository extends JpaRepository<DepositoryEntity, String> {
    List<DepositoryEntity> findByDescriptionContainingIgnoreCase(String description);

    List<DepositoryEntity> findAllByCountryId(Long countryId);
}
