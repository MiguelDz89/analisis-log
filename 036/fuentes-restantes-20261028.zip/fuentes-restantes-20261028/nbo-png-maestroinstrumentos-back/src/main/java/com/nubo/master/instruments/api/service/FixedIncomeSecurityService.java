package com.nubo.master.instruments.api.service;

import com.nubo.master.instruments.api.models.dto.request.ParamsFixedIncomeSecurityInDto;
import com.nubo.master.instruments.api.models.dto.request.ParamsPageInDto;
import com.nubo.master.instruments.api.models.dto.response.FixedIncomeSecurityOutDto;
import com.nubo.master.instruments.api.models.dto.response.PageResponseOutDto;
import com.nubo.master.instruments.api.models.dto.response.SecurityTitleOutDto;

public interface FixedIncomeSecurityService {

    FixedIncomeSecurityOutDto findFixedIncomeSecurityBySecurityId(Long securityId);

    PageResponseOutDto<SecurityTitleOutDto> searchFixedIncomeSecurity(
            ParamsPageInDto paramsPageInDto, ParamsFixedIncomeSecurityInDto paramsFixedIncomeSecurityInDto);

}
