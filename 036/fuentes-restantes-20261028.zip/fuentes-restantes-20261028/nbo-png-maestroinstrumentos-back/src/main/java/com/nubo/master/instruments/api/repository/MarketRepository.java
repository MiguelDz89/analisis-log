package com.nubo.master.instruments.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nubo.master.instruments.api.models.entity.MarketEntity;

public interface MarketRepository extends JpaRepository<MarketEntity, String> {
    List<MarketEntity> findByDescriptionContainingIgnoreCase(String category);

    List<MarketEntity> findByDescriptionContainingIgnoreCaseOrIdContainingIgnoreCase(String type, String typeId);
}
