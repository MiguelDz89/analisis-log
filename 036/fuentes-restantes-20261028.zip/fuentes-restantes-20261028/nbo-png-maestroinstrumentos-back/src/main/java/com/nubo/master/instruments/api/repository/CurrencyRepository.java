package com.nubo.master.instruments.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nubo.master.instruments.api.models.entity.CurrencyEntity;

public interface CurrencyRepository extends JpaRepository<CurrencyEntity, Long> {
}
