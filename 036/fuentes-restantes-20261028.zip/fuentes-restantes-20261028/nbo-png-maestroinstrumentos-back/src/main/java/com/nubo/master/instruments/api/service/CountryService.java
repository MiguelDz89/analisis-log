package com.nubo.master.instruments.api.service;


import com.nubo.master.instruments.api.models.dto.response.CountryOutDto;

import java.util.List;

public interface CountryService {

    List<CountryOutDto> findCountries();

}
