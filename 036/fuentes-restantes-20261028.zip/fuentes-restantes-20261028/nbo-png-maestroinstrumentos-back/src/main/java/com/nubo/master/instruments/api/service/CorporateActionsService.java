package com.nubo.master.instruments.api.service;

import com.nubo.master.instruments.api.models.dto.request.CorporateActionsParamsInDto;
import com.nubo.master.instruments.api.models.dto.request.ParamsPageInDto;
import com.nubo.master.instruments.api.models.dto.response.CorporateActionsOutDto;
import com.nubo.master.instruments.api.models.dto.response.PageResponseOutDto;

public interface CorporateActionsService {

    PageResponseOutDto<CorporateActionsOutDto> searchCorporateActions(ParamsPageInDto paramsPageInDto,
                                                                      CorporateActionsParamsInDto corporateActionsParamsInDto);

    CorporateActionsOutDto findCorporateActionsDetail(Long corporateActionId);

}
