package com.nubo.master.instruments.api.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.nubo.master.instruments.api.models.entity.StatusEntity;

public interface StatusRepository extends JpaRepository<StatusEntity, Long>
{

    Page<StatusEntity> findByCategoryIgnoreCase(Pageable pageable, String category);

}
