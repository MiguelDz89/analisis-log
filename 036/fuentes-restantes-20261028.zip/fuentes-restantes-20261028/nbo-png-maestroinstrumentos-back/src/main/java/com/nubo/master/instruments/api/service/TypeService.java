package com.nubo.master.instruments.api.service;

import com.nubo.master.instruments.api.models.dto.response.TypeOutDto;

import java.util.List;

public interface TypeService {

    List<TypeOutDto> findAllType(String category);

    List<TypeOutDto> findTypeCorporateActions();

}
