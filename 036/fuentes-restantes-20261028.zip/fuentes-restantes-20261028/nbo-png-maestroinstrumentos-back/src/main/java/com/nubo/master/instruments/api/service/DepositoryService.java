package com.nubo.master.instruments.api.service;

import java.util.List;

import org.springframework.data.domain.Pageable;

import com.nubo.master.instruments.api.models.dto.response.DepositoryOutDto;
import com.nubo.master.instruments.api.models.dto.response.PageResponseOutDto;

public interface DepositoryService {

    PageResponseOutDto<DepositoryOutDto> findAllDepositories(Pageable pageable);

    DepositoryOutDto findDepositoryById(String depositoryId);

    List<DepositoryOutDto> findDepositoriesByCountry(Long countryId);

}
