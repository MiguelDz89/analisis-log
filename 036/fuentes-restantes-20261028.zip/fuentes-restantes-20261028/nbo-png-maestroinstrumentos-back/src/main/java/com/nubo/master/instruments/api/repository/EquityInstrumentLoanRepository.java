package com.nubo.master.instruments.api.repository;

import com.nubo.master.instruments.api.models.entity.SecurityTitleEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface EquityInstrumentLoanRepository
        extends JpaRepository<SecurityTitleEntity, Long> {

    @Query("""
        SELECT DISTINCT st FROM SecurityTitleEntity st
        JOIN FETCH st.currency
        JOIN FETCH st.status
        JOIN FETCH st.country
        JOIN FETCH st.market
        JOIN FETCH st.depository
        LEFT JOIN FETCH st.isinNumbers
        WHERE UPPER(st.mnemonic) = UPPER(:mnemonic)
    """)
    Optional<SecurityTitleEntity> findByMnemonic(String mnemonic);

    @Query("""
        SELECT st FROM SecurityTitleEntity st
        JOIN FETCH st.currency
        JOIN FETCH st.status
        JOIN FETCH st.country
        JOIN FETCH st.market
        JOIN FETCH st.depository
    """)
    Page<SecurityTitleEntity> findAllPaged(Pageable pageable);

    @Query("""
        SELECT DISTINCT st FROM SecurityTitleEntity st
        JOIN FETCH st.currency
        JOIN FETCH st.status
        JOIN FETCH st.country
        JOIN FETCH st.market
        JOIN FETCH st.depository
        LEFT JOIN FETCH st.isinNumbers
        WHERE UPPER(st.mnemonic) LIKE UPPER(CONCAT(:prefix, '%'))
          AND LENGTH(:prefix) >= 2
    """)
    List<SecurityTitleEntity> findByMnemonicPrefix(String prefix);
}
