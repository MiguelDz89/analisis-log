package com.nubo.master.instruments.api.repository;

import com.nubo.master.instruments.api.models.entity.SecurityTitleSuspendedHistoryEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface SecurityTitleSuspendedHistoryRepository extends JpaRepository<SecurityTitleSuspendedHistoryEntity, Long>,
        JpaSpecificationExecutor<SecurityTitleSuspendedHistoryEntity> {
}
