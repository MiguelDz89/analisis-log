package com.nubo.master.instruments.api.service;

import com.nubo.master.instruments.api.models.dto.response.EquityInstrumentOutDto;
import com.nubo.master.instruments.api.models.dto.response.EquityInstrumentSimpleOutDto;
import com.nubo.master.instruments.api.models.dto.response.PageResponseOutDto;
import org.springframework.data.domain.Pageable;

public interface EquityInstrumentService {

    PageResponseOutDto<EquityInstrumentOutDto> findAllEquityInstruments(Pageable pageable);

    EquityInstrumentOutDto findEquityInstrumentById(Long securityId);

    PageResponseOutDto<EquityInstrumentOutDto> findEquityInstrumentsWithFilters(
            Pageable pageable,
            Long depositoryId,
            String issuerCode,
            Long statusId);

    PageResponseOutDto<EquityInstrumentOutDto> findAllEquityInstrumentsDynamic(
            Pageable pageable,
            String fieldName, String fieldValue, String operation,
            String mnemonic, String isinCode, String issuerCode,
            Long depositoryId, Long statusId, Long marketId);

    PageResponseOutDto<EquityInstrumentSimpleOutDto> findEquityInstrumentsByMnemonicStartingWith(
            String mnemonic, Pageable pageable);

    PageResponseOutDto<EquityInstrumentSimpleOutDto> findEquityInstrumentsByIsinStartingWith(
            String isin, Pageable pageable);

    PageResponseOutDto<String> findEquityInstrumentsByIssuerCodeStartingWith(
            String issuerCode, Pageable pageable);
}
