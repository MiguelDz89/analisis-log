package com.nubo.master.instruments.api.service;

import org.springframework.data.domain.Pageable;

import com.nubo.master.instruments.api.models.dto.response.CfiOutDto;
import com.nubo.master.instruments.api.models.dto.response.PageResponseOutDto;

public interface CfiService {

    PageResponseOutDto<CfiOutDto> findAllCfis(Pageable pageable);

    CfiOutDto findCfiById(String cfiId);

}
