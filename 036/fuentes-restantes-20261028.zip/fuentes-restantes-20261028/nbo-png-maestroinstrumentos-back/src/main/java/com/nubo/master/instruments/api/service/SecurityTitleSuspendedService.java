package com.nubo.master.instruments.api.service;

import com.nubo.master.instruments.api.models.dto.request.NoSuspendedSecurityTitleInDto;
import com.nubo.master.instruments.api.models.dto.request.SuspendedSecurityTitleInDto;
import com.nubo.master.instruments.api.models.dto.response.SecurityTitleSuspendedHistoryOutDto;

public interface SecurityTitleSuspendedService {

    SecurityTitleSuspendedHistoryOutDto suspendedSecurityTitle(SuspendedSecurityTitleInDto suspendedSecurityTitleInDto);

    SecurityTitleSuspendedHistoryOutDto noSuspendedSecurityTitle(NoSuspendedSecurityTitleInDto noSuspendedSecurityTitleInDto);

}
