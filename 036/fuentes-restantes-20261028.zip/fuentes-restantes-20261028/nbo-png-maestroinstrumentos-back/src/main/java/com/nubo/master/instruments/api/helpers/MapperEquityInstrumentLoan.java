package com.nubo.master.instruments.api.helpers;

import com.nubo.master.instruments.api.models.dto.response.EquityInstrumentLoanDepositoryOutDto;
import com.nubo.master.instruments.api.models.dto.response.EquityInstrumentLoanOutDto;
import com.nubo.master.instruments.api.models.dto.response.RiskModelLoanOutDto;
import com.nubo.master.instruments.api.models.entity.DataRiesgoDiaEntity;
import com.nubo.master.instruments.api.models.entity.ISINNumberEntity;
import com.nubo.master.instruments.api.models.entity.SecurityTitleEntity;

public class MapperEquityInstrumentLoan {

    private MapperEquityInstrumentLoan() {}

    public static EquityInstrumentLoanOutDto toDto(SecurityTitleEntity entity) {

        String description = null;

        if (entity.getIsinNumbers() != null && !entity.getIsinNumbers().isEmpty()) {
            description = entity.getIsinNumbers()
                    .stream()
                    .filter(i -> i.getIsinNumber() != null
                            && i.getIsinNumber().equals(entity.getIsin()))
                    .map(ISINNumberEntity::getDescription)
                    .findFirst()
                    .orElse(
                            entity.getIsinNumbers().get(0).getDescription()
                    );
        }

        return EquityInstrumentLoanOutDto.builder()
                .mnemonic(entity.getMnemonic())
                .isin(entity.getIsin())
                .description(description)
                .status(entity.getStatus().getDescription())
                .currency(entity.getCurrency().getCode())
                .country(entity.getCountry().getCode())
                .marketCode(entity.getMarket().getCode())
                .depository(toDepositoryDto(entity))
                .build();
    }

    private static EquityInstrumentLoanDepositoryOutDto toDepositoryDto(SecurityTitleEntity entity) {

        if (entity.getDepository() == null) {
            return null;
        }

        return EquityInstrumentLoanDepositoryOutDto.builder()
                .depositoryId(entity.getDepository().getId())
                .code(entity.getDepository().getCode())
                .description(entity.getDepository().getDescription())
                .build();
    }

    public static RiskModelLoanOutDto toRiskModelDto(DataRiesgoDiaEntity entity) {
        if (entity == null) {
            return null;
        }
        return RiskModelLoanOutDto.builder()
                .referenceAveragePrice(entity.getAveragePrice())
                .averageAmount(entity.getAverageAmount())
                .concentrationRisk(entity.getConcentrationRisk())
                .build();
    }
}
