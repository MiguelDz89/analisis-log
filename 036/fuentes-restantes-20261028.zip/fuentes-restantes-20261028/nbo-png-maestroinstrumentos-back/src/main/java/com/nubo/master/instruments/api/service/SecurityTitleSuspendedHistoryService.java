package com.nubo.master.instruments.api.service;

import com.nubo.master.instruments.api.models.dto.request.ParamsPageInDto;
import com.nubo.master.instruments.api.models.dto.response.PageResponseOutDto;
import com.nubo.master.instruments.api.models.dto.response.SecurityTitleSuspendedHistoryOutDto;

public interface SecurityTitleSuspendedHistoryService {

    PageResponseOutDto<SecurityTitleSuspendedHistoryOutDto> findSecurityTitleSuspendedHistory(
            ParamsPageInDto paramsPageInDto, Long securityId);

}
