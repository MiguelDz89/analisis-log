package com.nubo.master.instruments.api.repository;

import com.nubo.master.instruments.api.models.entity.CountryEntity;
import com.nubo.master.instruments.api.models.entity.DataRiesgoDiaEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface DataRiesgoDiaRepository extends JpaRepository<DataRiesgoDiaEntity, String> {

    @Query("SELECT r FROM DataRiesgoDiaEntity r WHERE r.mnemonic IN :mnemonics")
    List<DataRiesgoDiaEntity> findDataRiesgoByMnemonics(List<String> mnemonics);
}
