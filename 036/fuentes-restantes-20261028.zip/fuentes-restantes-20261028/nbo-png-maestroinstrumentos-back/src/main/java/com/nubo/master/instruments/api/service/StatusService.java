package com.nubo.master.instruments.api.service;

import org.springframework.data.domain.Pageable;

import com.nubo.master.instruments.api.models.dto.response.PageResponseOutDto;
import com.nubo.master.instruments.api.models.dto.response.StatusOutDto;

public interface StatusService
{

    PageResponseOutDto<StatusOutDto> findAllInstrumentsStatus(Pageable pageable);

}
