package com.nubo.master.instruments.api.service;

import java.util.List;

import org.springframework.data.domain.Pageable;

import com.nubo.master.instruments.api.models.dto.response.MarketOutDto;
import com.nubo.master.instruments.api.models.dto.response.PageResponseOutDto;

public interface MarketService {

    PageResponseOutDto<MarketOutDto> findAllMarkets(Pageable pageable);

    MarketOutDto findMarketById(String marketId);

    List<MarketOutDto> findMarketsByCategory(String category);

    List<MarketOutDto> findMarketsByType(String marketType);

}
