package com.nubo.master.instruments.api.helpers;

import com.nubo.master.instruments.api.models.dto.response.CfiOutDto;
import com.nubo.master.instruments.api.models.dto.response.ClassOutDto;
import com.nubo.master.instruments.api.models.dto.response.CorporateActionsOutDto;
import com.nubo.master.instruments.api.models.dto.response.CountryOutDto;
import com.nubo.master.instruments.api.models.dto.response.CurrencyOutDto;
import com.nubo.master.instruments.api.models.dto.response.DepositoryOutDto;
import com.nubo.master.instruments.api.models.dto.response.EquityInstrumentOutDto;
import com.nubo.master.instruments.api.models.dto.response.EquityInstrumentSimpleOutDto;
import com.nubo.master.instruments.api.models.dto.response.EquitySecurityOutDto;
import com.nubo.master.instruments.api.models.dto.response.FixedIncomeSecurityOutDto;
import com.nubo.master.instruments.api.models.dto.response.GicsOutDto;
import com.nubo.master.instruments.api.models.dto.response.IsinNumberOutDto;
import com.nubo.master.instruments.api.models.dto.response.IssuerOutDto;
import com.nubo.master.instruments.api.models.dto.response.MarketOutDto;
import com.nubo.master.instruments.api.models.dto.response.PageResponseOutDto;
import com.nubo.master.instruments.api.models.dto.response.SecurityTitleOutDto;
import com.nubo.master.instruments.api.models.dto.response.SecurityTitleSuspendedHistoryOutDto;
import com.nubo.master.instruments.api.models.dto.response.SegmentOutDto;
import com.nubo.master.instruments.api.models.dto.response.StatusOutDto;
import com.nubo.master.instruments.api.models.dto.response.TypeOutDto;
import com.nubo.master.instruments.api.models.entity.CfiEntity;
import com.nubo.master.instruments.api.models.entity.ClassEntity;
import com.nubo.master.instruments.api.models.entity.CorporateActionsEntity;
import com.nubo.master.instruments.api.models.entity.CountryEntity;
import com.nubo.master.instruments.api.models.entity.CurrencyEntity;
import com.nubo.master.instruments.api.models.entity.DepositoryEntity;
import com.nubo.master.instruments.api.models.entity.EquitySecurityEntity;
import com.nubo.master.instruments.api.models.entity.FixedIncomeSecurityEntity;
import com.nubo.master.instruments.api.models.entity.GicsEntity;
import com.nubo.master.instruments.api.models.entity.ISINNumberEntity;
import com.nubo.master.instruments.api.models.entity.IssuerEntity;
import com.nubo.master.instruments.api.models.entity.MarketEntity;
import com.nubo.master.instruments.api.models.entity.SecurityTitleEntity;
import com.nubo.master.instruments.api.models.entity.SecurityTitleSuspendedHistoryEntity;
import com.nubo.master.instruments.api.models.entity.SegmentEntity;
import com.nubo.master.instruments.api.models.entity.StatusEntity;
import com.nubo.master.instruments.api.models.entity.TypeEntity;
import com.nubo.master.instruments.api.models.enums.RepoSimultaneousBusinessEnum;
import org.springframework.util.ObjectUtils;

import java.util.Comparator;
import java.util.stream.Collectors;

public final class MapperUtil {

    private MapperUtil() {
    }

    public static CountryOutDto countryEntityToCountryOutDto(CountryEntity countryEntity) {
        if (countryEntity == null) return null;
        return CountryOutDto.builder()
                .id(countryEntity.getId())
                .code(countryEntity.getCode())
                .name(countryEntity.getName())
                .currency(ObjectUtils.isEmpty(countryEntity.getCurrency()) ? null
                        : currencyEntityToCurrencyOutDto(countryEntity.getCurrency()))
                .timeZone(countryEntity.getTimeZone())
                .build();
    }

    public static CurrencyOutDto currencyEntityToCurrencyOutDto(CurrencyEntity currencyEntity) {
        if (currencyEntity == null) return null;
        return CurrencyOutDto.builder()
                .id(currencyEntity.getId())
                .code(currencyEntity.getCode())
                .name(currencyEntity.getName())
                .build();
    }

    public static EquitySecurityOutDto equitySecurityEntityToEquitySecurityOutDto(
            EquitySecurityEntity equitySecurityEntity) {
        if (equitySecurityEntity == null) return null;
        return EquitySecurityOutDto.builder()
                .securityId(equitySecurityEntity.getSecurityId())
                .parent(equitySecurityEntity.getParent())
                .amountIssued(equitySecurityEntity.getAmountIssued())
                .nominalPrice(equitySecurityEntity.getNominalPrice())
                .nominalPriceDate(equitySecurityEntity.getNominalPriceDate())
                .negotiate(equitySecurityEntity.getNegotiate())
                .dateEquityValue(equitySecurityEntity.getDateEquityValue())
                .equityValue(equitySecurityEntity.getEquityValue())
                .dateFaceValue(equitySecurityEntity.getDateFaceValue())
                .faceValue(equitySecurityEntity.getFaceValue())
                .numberOutstanding(equitySecurityEntity.getNumberOutstanding())
                .submission(equitySecurityEntity.getSubmission())
                .liquidity(equitySecurityEntity.getLiquidity())
                .specialRights(equitySecurityEntity.getSpecialRights())
                .exdividendDate(equitySecurityEntity.getExdividendDate())
                .build();
    }

    public static IssuerOutDto issuerEntityToIssuerOutDto(IssuerEntity issuerEntity) {
        if (issuerEntity == null) return null;
        return IssuerOutDto.builder()
                .id(issuerEntity.getId())
                .code(issuerEntity.getCode())
                .name(issuerEntity.getName())
                .shortName(issuerEntity.getShortName())
                .type(ObjectUtils.isEmpty(issuerEntity.getType()) ? null
                        : typeEntityToTypeOutDto(issuerEntity.getType()))
                .country(ObjectUtils.isEmpty(issuerEntity.getCountry()) ? null
                        : countryEntityToCountryOutDto(issuerEntity.getCountry()))
                .gics(ObjectUtils.isEmpty(issuerEntity.getGics()) ? null
                        : gicsEntityToGicsOutDto(issuerEntity.getGics()))
                .dateEntry(issuerEntity.getDateEntry())
                .countryOrigin(ObjectUtils.isEmpty(issuerEntity.getCountryOrigin()) ? null
                        : countryEntityToCountryOutDto(issuerEntity.getCountryOrigin()))
                .cusip(issuerEntity.getCusip())
                .taxCode(issuerEntity.getTaxCode())
                .status(ObjectUtils.isEmpty(issuerEntity.getStatus()) ? null
                        : statusEntityToStatusOutDto(issuerEntity.getStatus()))
                .withdrawalDate(issuerEntity.getWithdrawalDate())
                .mainMarket(issuerEntity.getMainMarket())
                .regulatorCode(issuerEntity.getRegulatorCode())
                .depository(ObjectUtils.isEmpty(issuerEntity.getDepository()) ? null
                        : depositoryEntityToDepositoryOutDto(issuerEntity.getDepository()))
                .dvlCode(issuerEntity.getDvlCode())
                .creditRating(issuerEntity.getCreditRating())
                .build();
    }

    public static IssuerOutDto issuerEntityToIssuerOutDtoDetail(IssuerEntity issuerEntity) {
        if (issuerEntity == null) return null;
        return IssuerOutDto.builder()
                .id(issuerEntity.getId())
                .code(issuerEntity.getCode())
                .name(issuerEntity.getName())
                .build();
    }

    public static StatusOutDto statusEntityToStatusOutDto(StatusEntity statusEntity) {
        if (statusEntity == null) return null;
        return StatusOutDto.builder()
                .id(statusEntity.getId())
                .description(statusEntity.getDescription())
                .category(statusEntity.getCategory())
                .build();
    }

    public static TypeOutDto typeEntityToTypeOutDto(TypeEntity typeEntity) {
        if (typeEntity == null) return null;
        return TypeOutDto.builder()
                .id(typeEntity.getId())
                .description(typeEntity.getDescription())
                .category(typeEntity.getCategory())
                .detail(typeEntity.getDetail())
                .build();
    }

    public static GicsOutDto gicsEntityToGicsOutDto(GicsEntity gicsEntity) {
        if (gicsEntity == null) return null;
        return GicsOutDto.builder()
                .id(gicsEntity.getId())
                .description(gicsEntity.getDescription())
                .build();
    }

    public static CfiOutDto cfiEntityToCfiOutDto(CfiEntity cfiEntity) {
        if (cfiEntity == null) return null;
        return CfiOutDto.builder()
                .id(cfiEntity.getId())
                .description(cfiEntity.getDescription())
                .build();
    }

    public static ClassOutDto classEntityToClassOutDto(ClassEntity classEntity) {
        if (classEntity == null) return null;
        return ClassOutDto.builder()
                .id(classEntity.getId())
                .description(classEntity.getDescription())
                .category(classEntity.getCategory())
                .build();
    }

    public static MarketOutDto marketEntityToMarketOutDto(MarketEntity marketEntity) {
        if (marketEntity == null) return null;
        return MarketOutDto.builder()
                .id(marketEntity.getId())
                .description(marketEntity.getDescription())
                .category(marketEntity.getCategory())
                .build();
    }

    public static EquityInstrumentOutDto securityTitleEntityToEquityInstrumentOutDto(
            SecurityTitleEntity securityTitleEntity) {
        if (securityTitleEntity == null) return null;

        EquitySecurityEntity latestEquitySecurityEntity = securityTitleEntity.getEquitySecurities()
                .stream().max(Comparator.comparing(EquitySecurityEntity::getLastModifyDate))
                .orElse(null);

        return EquityInstrumentOutDto.builder()
                .securityId(securityTitleEntity.getSecurityId())
                .mnemonic(securityTitleEntity.getMnemonic())
                .isinCode(securityTitleEntity.getIsin())
                .description(buildEquityInstrumentDescription(securityTitleEntity))
                .repoSimultaneousBusiness(getRepoSimultaneousBusiness(
                        latestEquitySecurityEntity))
                .listingDate(securityTitleEntity.getListingDate())
                .delistingDate(securityTitleEntity.getDelistingDate())
                .settlementPeriod(securityTitleEntity.getSettlementPeriod())
                .regulatorSpeciesCode(securityTitleEntity.getRegulatoryCode())
                .issuerCode(securityTitleEntity.getIssuer() != null
                        ? securityTitleEntity.getIssuer().getCode()
                        : null)
                .nominalPrice(
                        latestEquitySecurityEntity != null
                                ? latestEquitySecurityEntity.getNominalPrice()
                                : null)
                .nominalPriceDate(
                        latestEquitySecurityEntity != null
                                ? latestEquitySecurityEntity.getNominalPriceDate()
                                : null)
                .baseInstrument(securityTitleEntity.getIssuer() != null
                        ? securityTitleEntity.getIssuer().getShortName()
                        : null)
                .marketType(securityTitleEntity.getSegment() != null
                        ? securityTitleEntity.getSegment().getDescription()
                        : null)
                .cfi(securityTitleEntity.getCfi() != null
                        ? cfiEntityToCfiOutDto(securityTitleEntity.getCfi())
                        : null)
                .instrumentClass(securityTitleEntity.getClassEntity() != null
                        ? classEntityToClassOutDto(securityTitleEntity.getClassEntity())
                        : null)
                .country(securityTitleEntity.getCountry() != null
                        ? countryEntityToCountryOutDto(securityTitleEntity.getCountry())
                        : null)
                .currency(securityTitleEntity.getCurrency() != null
                        ? currencyEntityToCurrencyOutDto(securityTitleEntity.getCurrency())
                        : null)
                .depository(securityTitleEntity.getDepository() != null
                        ? depositoryEntityToDepositoryOutDto(
                        securityTitleEntity.getDepository())
                        : null)
                .issuer(securityTitleEntity.getIssuer() != null
                        ? issuerEntityToIssuerOutDto(securityTitleEntity.getIssuer())
                        : null)
                .market(securityTitleEntity.getMarket() != null
                        ? marketEntityToMarketOutDto(securityTitleEntity.getMarket())
                        : null)
                .status(securityTitleEntity.getStatus() != null
                        ? statusEntityToStatusOutDto(securityTitleEntity.getStatus())
                        : null)
                .tradesOnLoan(latestEquitySecurityEntity != null
                        ? latestEquitySecurityEntity.getTradesOnLoan() : null)
                .tradesOnRepo(latestEquitySecurityEntity != null
                        ? latestEquitySecurityEntity.getTradesOnRepo() : null)
                .suspendedNegotiation(!ObjectUtils.isEmpty(securityTitleEntity.getSuspendedNegotiation()) && securityTitleEntity.getSuspendedNegotiation())
                .suspendedEffectiveDate(securityTitleEntity.getSuspendedEffectiveDate())
                .suspendedProcessType(typeEntityToTypeOutDto(securityTitleEntity.getSuspendedProcessType()))
                .build();
    }

    public static EquityInstrumentSimpleOutDto securityTitleEntityToEquityInstrumentSimpleOutDto(
            SecurityTitleEntity securityTitleEntity) {
        if (securityTitleEntity == null) return null;
        return EquityInstrumentSimpleOutDto.builder()
                .securityId(securityTitleEntity.getSecurityId())
                .mnemonic(securityTitleEntity.getMnemonic())
                .isinCode(securityTitleEntity.getIsin())
                .issuerCode(
                        securityTitleEntity.getIssuer() != null
                                ? securityTitleEntity.getIssuer().getCode()
                                : null)
                .build();
    }

    public static SecurityTitleOutDto securityTitleEntityToSecurityTitleOutDto(SecurityTitleEntity securityTitleEntity) {
        if (securityTitleEntity == null) return null;
        return SecurityTitleOutDto.builder()
                .id(securityTitleEntity.getSecurityId())
                .mnemonic(securityTitleEntity.getMnemonic())
                .build();
    }

    public static DepositoryOutDto depositoryEntityToDepositoryOutDto(DepositoryEntity depositoryEntity) {
        if (depositoryEntity == null) return null;
        return DepositoryOutDto.builder()
                .id(depositoryEntity.getId())
                .description(depositoryEntity.getDescription())
                .build();
    }

    private static String buildEquityInstrumentDescription(SecurityTitleEntity securityTitleEntity) {
        StringBuilder description = new StringBuilder();

        if (!ObjectUtils.isEmpty(securityTitleEntity.getClassEntity())) {
            description.append(securityTitleEntity.getClassEntity().getDescription());
        }

        if (!ObjectUtils.isEmpty(securityTitleEntity.getIssuer())) {
            if (description.length() > 0) {
                description.append(" ");
            }
            description.append(securityTitleEntity.getIssuer().getShortName());
        }

        if (!ObjectUtils.isEmpty(securityTitleEntity.getCurrency())) {
            if (description.length() > 0) {
                description.append(" ");
            }
            description.append(securityTitleEntity.getCurrency().getName());
        }

        if (!ObjectUtils.isEmpty(securityTitleEntity.getSegment())) {
            if (description.length() > 0) {
                description.append(" - ");
            }
            description.append(securityTitleEntity.getSegment().getDescription());
        }

        return description.toString();
    }

    private static String getRepoSimultaneousBusiness(EquitySecurityEntity equitySecurityEntity) {
        if (equitySecurityEntity == null || equitySecurityEntity.getNegotiate() == null) {
            return RepoSimultaneousBusinessEnum.INDEFINIDO.getValue();
        }
        return equitySecurityEntity.getNegotiate() ? RepoSimultaneousBusinessEnum.YES.getValue()
                : RepoSimultaneousBusinessEnum.NO.getValue();
    }

    public static EquityInstrumentSimpleOutDto equityInstrumentOutDtoToEquityInstrumentSimpleOutDto(
            EquityInstrumentOutDto equityInstrumentOutDto) {
        return EquityInstrumentSimpleOutDto.builder()
                .securityId(equityInstrumentOutDto.getSecurityId())
                .mnemonic(equityInstrumentOutDto.getMnemonic())
                .isinCode(equityInstrumentOutDto.getIsinCode())
                .issuerCode(equityInstrumentOutDto.getIssuerCode())
                .build();
    }

    public static PageResponseOutDto<EquityInstrumentSimpleOutDto> mapPageResponse(
            PageResponseOutDto<EquityInstrumentOutDto> allInstruments) {
        PageResponseOutDto<EquityInstrumentSimpleOutDto> simpleOutDto = new PageResponseOutDto<>();
        simpleOutDto.setContent(allInstruments.getContent().stream()
                .map(MapperUtil::equityInstrumentOutDtoToEquityInstrumentSimpleOutDto)
                .collect(Collectors.toList()));
        simpleOutDto.setPageSize(allInstruments.getPageSize());
        simpleOutDto.setPageNumber(allInstruments.getPageNumber());
        simpleOutDto.setTotalElements(allInstruments.getTotalElements());
        simpleOutDto.setTotalPages(allInstruments.getTotalPages());
        return simpleOutDto;
    }

    public static IsinNumberOutDto isinNumberEntityToIsinNumberOutDto(ISINNumberEntity isinNumberEntity) {
        if (isinNumberEntity == null) return null;
        return IsinNumberOutDto.builder()
                .id(isinNumberEntity.getId())
                .isinNumber(isinNumberEntity.getIsinNumber())
                .build();
    }

    public static CorporateActionsOutDto corporateActionsEntityToCorporateActionsOutDtoPageable(CorporateActionsEntity corporateActionsEntity) {
        if (ObjectUtils.isEmpty(corporateActionsEntity)) return null;
        return CorporateActionsOutDto.builder()
                .id(corporateActionsEntity.getId())
                .paymentDate(corporateActionsEntity.getPaymentDate())
                .country(countryEntityToCountryOutDto(corporateActionsEntity.getCountry()))
                .issuer(issuerEntityToIssuerOutDto(corporateActionsEntity.getIssuer()))
                .type(typeEntityToTypeOutDto(corporateActionsEntity.getType()))
                .build();
    }

    public static CorporateActionsOutDto corporateActionsEntityToCorporateActionsOutDtoDetail(CorporateActionsEntity corporateActionsEntity) {
        if (ObjectUtils.isEmpty(corporateActionsEntity)) return null;
        return CorporateActionsOutDto.builder()
                .id(corporateActionsEntity.getId())
                .securityTitle(securityTitleEntityToSecurityTitleOutDto(corporateActionsEntity.getSecurityTitle()))
                .isinNumber(isinNumberEntityToIsinNumberOutDto(corporateActionsEntity.getIsinNumber()))
                .currency(currencyEntityToCurrencyOutDto(corporateActionsEntity.getCurrency()))
                .type(typeEntityToTypeOutDto(corporateActionsEntity.getType()))
                .meetingDate(corporateActionsEntity.getMeetingDate())
                .eventStartDate(corporateActionsEntity.getEventStartDate())
                .eventEndDate(corporateActionsEntity.getEventEndDate())
                .cutOffDate(corporateActionsEntity.getCutOffDate())
                .recordDate(corporateActionsEntity.getRecordDate())
                .paymentDate(corporateActionsEntity.getPaymentDate())
                .adjustedFactor(corporateActionsEntity.getAdjustedFactor())
                .paymentFactor(corporateActionsEntity.getPaymentFactor())
                .paymentCurrency(currencyEntityToCurrencyOutDto(corporateActionsEntity.getPaymentCurrency()))
                .totalAmount(corporateActionsEntity.getTotalAmount())
                .eventDescription(corporateActionsEntity.getEventDescription())
                .issuer(issuerEntityToIssuerOutDto(corporateActionsEntity.getIssuer()))
                .build();
    }

    public static SegmentOutDto segmentEntityToSegmentOutDto(SegmentEntity segmentEntity) {
        if (segmentEntity == null) return null;
        return SegmentOutDto.builder()
                .id(segmentEntity.getId())
                .description(segmentEntity.getDescription())
                .build();
    }

    public static SecurityTitleSuspendedHistoryOutDto securityTitleSuspendedHistoryEntityToSecurityTitleSuspendedHistoryOutDto(
            SecurityTitleSuspendedHistoryEntity securityTitleSuspendedHistoryEntity) {
        if (securityTitleSuspendedHistoryEntity == null) return null;
        return SecurityTitleSuspendedHistoryOutDto.builder()
                .id(securityTitleSuspendedHistoryEntity.getId())
                .securityTitle(securityTitleEntityToSecurityTitleOutDto(securityTitleSuspendedHistoryEntity.getSecurityTitle()))
                .actionType(typeEntityToTypeOutDto(securityTitleSuspendedHistoryEntity.getActionType()))
                .processType(typeEntityToTypeOutDto(securityTitleSuspendedHistoryEntity.getProcessType()))
                .effectiveDate(securityTitleSuspendedHistoryEntity.getEffectiveDate())
                .description(securityTitleSuspendedHistoryEntity.getDescription())
                .lastModifyUser(securityTitleSuspendedHistoryEntity.getLastModifyUser())
                .lastModifyDate(securityTitleSuspendedHistoryEntity.getLastModifyDate())
                .build();
    }

    public static SecurityTitleOutDto securityTitleEntityToFixedIncomeSecurityDetailOutDto(SecurityTitleEntity securityTitleEntity) {
        return SecurityTitleOutDto.builder()
                .id(securityTitleEntity.getSecurityId())
                .issuer(issuerEntityToIssuerOutDto(securityTitleEntity.getIssuer()))
                .isin(securityTitleEntity.getIsin())
                .instrumentClass(classEntityToClassOutDto(securityTitleEntity.getClassEntity()))
                .mnemonic(securityTitleEntity.getMnemonic())
                .depository(depositoryEntityToDepositoryOutDto(securityTitleEntity.getDepository()))
                .cfi(cfiEntityToCfiOutDto(securityTitleEntity.getCfi()))
                .currency(currencyEntityToCurrencyOutDto(securityTitleEntity.getCurrency()))
                .status(statusEntityToStatusOutDto(securityTitleEntity.getStatus()))
                .country(countryEntityToCountryOutDto(securityTitleEntity.getCountry()))
                .segment(segmentEntityToSegmentOutDto(securityTitleEntity.getSegment()))
                .build();
    }

    public static SecurityTitleOutDto fixedIncomeSecurityEntityToSecurityTitleOutDto(FixedIncomeSecurityEntity fixedIncomeSecurityEntity) {
        if (fixedIncomeSecurityEntity == null) return null;
        return SecurityTitleOutDto.builder()
                .securityId(fixedIncomeSecurityEntity.getSecurityId())
                .mnemonic(fixedIncomeSecurityEntity.getSecurityTitle().getMnemonic())
                .isin(fixedIncomeSecurityEntity.getSecurityTitle().getIsin())
                .issuer(issuerEntityToIssuerOutDto(fixedIncomeSecurityEntity.getSecurityTitle().getIssuer()))
                .depository(depositoryEntityToDepositoryOutDto(fixedIncomeSecurityEntity.getSecurityTitle().getDepository()))
                .status(statusEntityToStatusOutDto(fixedIncomeSecurityEntity.getSecurityTitle().getStatus()))
                .build();
    }

    public static FixedIncomeSecurityOutDto fixedIncomeSecurityEntityToFixedIncomeSecurityOutDto(FixedIncomeSecurityEntity fixedIncomeSecurityEntity) {
        if (fixedIncomeSecurityEntity == null) return null;
        return FixedIncomeSecurityOutDto.builder()
                .security(securityTitleEntityToFixedIncomeSecurityDetailOutDto(fixedIncomeSecurityEntity.getSecurityTitle()))
                .maturityDate(fixedIncomeSecurityEntity.getMaturityDate())
                .description(fixedIncomeSecurityEntity.getDescription())
                .firstCuponDate(fixedIncomeSecurityEntity.getFirstCuponDate())
                .couponFrequency(fixedIncomeSecurityEntity.getCouponFrequency())
                .initialParValue(fixedIncomeSecurityEntity.getInitialParValue())
                .nominalValue(fixedIncomeSecurityEntity.getNominalValue())
                .couponInterest(fixedIncomeSecurityEntity.getCouponInterest())
                .minimumUnit(fixedIncomeSecurityEntity.getMinimumUnit())
                .issueDate(fixedIncomeSecurityEntity.getIssueDate())
                .rateUsageMethod(fixedIncomeSecurityEntity.getRateUsageMethod())
                .rateType(typeEntityToTypeOutDto(fixedIncomeSecurityEntity.getRateType()))
                .rateValue(fixedIncomeSecurityEntity.getRateValue())
                .spread(fixedIncomeSecurityEntity.getSpread())
                .periodicityType(typeEntityToTypeOutDto(fixedIncomeSecurityEntity.getPeriodicityType()))
                .paymentType(typeEntityToTypeOutDto(fixedIncomeSecurityEntity.getPaymentType()))
                .fractionationMultiple(fixedIncomeSecurityEntity.getFractionationMultiple())
                .liquidationType(typeEntityToTypeOutDto(fixedIncomeSecurityEntity.getLiquidationType()))
                .build();
    }

}
