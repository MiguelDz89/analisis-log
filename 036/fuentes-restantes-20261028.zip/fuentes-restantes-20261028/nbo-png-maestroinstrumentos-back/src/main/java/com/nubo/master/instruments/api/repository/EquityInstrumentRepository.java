package com.nubo.master.instruments.api.repository;

import com.nubo.master.instruments.api.models.entity.SecurityTitleEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EquityInstrumentRepository extends JpaRepository<SecurityTitleEntity, Long>,
        JpaSpecificationExecutor<SecurityTitleEntity> {

    @Query("SELECT st FROM SecurityTitleEntity st " +
            "LEFT JOIN EquitySecurityEntity ese ON st.securityId = ese.securityId " +
            "LEFT JOIN FETCH st.issuer " +
            "LEFT JOIN FETCH st.market " +
            "LEFT JOIN FETCH st.cfi " +
            "LEFT JOIN FETCH st.status " +
            "LEFT JOIN FETCH st.depository " +
            "WHERE st.id = :securityId")
    Optional<SecurityTitleEntity> findByIdWithAssociations(@Param("securityId") Long securityId);

    @Query("SELECT st FROM SecurityTitleEntity st " +
            "INNER JOIN EquitySecurityEntity ese ON st.securityId = ese.securityId " +
            "LEFT JOIN FETCH st.market " +
            "LEFT JOIN FETCH st.cfi " +
            "LEFT JOIN FETCH st.status " +
            "LEFT JOIN FETCH st.depository " +
            "ORDER BY st.mnemonic ASC")
    Page<SecurityTitleEntity> findAllEquityInstruments(Pageable pageable);

    @Query("SELECT st FROM SecurityTitleEntity st " +
            "INNER JOIN EquitySecurityEntity ese ON st.securityId = ese.securityId " +
            "WHERE UPPER(st.mnemonic) LIKE CONCAT('%', UPPER(:mnemonic), '%') " +
            "ORDER BY st.mnemonic ASC")
    Page<SecurityTitleEntity> findByMnemonicContainsWithIgnoreCase(
            @Param("mnemonic") String mnemonic, Pageable pageable);

    @Query("SELECT st FROM SecurityTitleEntity st " +
            "INNER JOIN EquitySecurityEntity ese ON st.securityId = ese.securityId " +
            "WHERE UPPER(st.isin) LIKE CONCAT('%', UPPER(:isin), '%') " +
            "ORDER BY st.isin ASC")
    Page<SecurityTitleEntity> findByIsinCodeContainsWithIgnoreCase(
            @Param("isin") String isin, Pageable pageable);

    @Query("SELECT DISTINCT i.code FROM SecurityTitleEntity st " +
            "LEFT JOIN st.issuer i " +
            "WHERE UPPER(i.code) LIKE CONCAT('%', UPPER(:issuerCode), '%') " +
            "ORDER BY i.code ASC")
    List<String> findDistinctIssuerCodesByIssuerCodeContainsIgnoreCase(
            @Param("issuerCode") String issuerCode);

    @Query(value = """
             SELECT DISTINCT s
              FROM SecurityTitleEntity s
              LEFT JOIN FETCH s.issuer i
              LEFT JOIN FETCH s.equitySecurities es
              LEFT JOIN FETCH s.market m
              LEFT JOIN FETCH s.status st
              LEFT JOIN FETCH s.depository d
              LEFT JOIN FETCH s.segment seg
              LEFT JOIN FETCH s.cfi c
              LEFT JOIN FETCH s.classEntity ce
              LEFT JOIN FETCH s.country co
              LEFT JOIN FETCH s.currency cur
              WHERE (:mnemonic IS NULL OR s.mnemonic = :mnemonic)
              AND (:isinCode IS NULL OR s.isin = :isinCode)
              AND (:issuerCode IS NULL OR i.code = :issuerCode)
              AND (:depositoryId IS NULL OR s.depository.id = :depositoryId)
              AND (:statusId IS NULL OR s.status.id = :statusId)
              AND (:marketId IS NULL OR s.market.id = :marketId)
            """,
            countQuery = """
                            SELECT count(DISTINCT s)
                     FROM SecurityTitleEntity s
                     LEFT JOIN s.issuer i
                     WHERE (:mnemonic IS NULL OR s.mnemonic = :mnemonic)
                     AND (:isinCode IS NULL OR s.isin = :isinCode)
                     AND (:issuerCode IS NULL OR i.code = :issuerCode)
                     AND (:depositoryId IS NULL OR s.depository.id = :depositoryId)
                     AND (:statusId IS NULL OR s.status.id = :statusId)
                     AND (:marketId IS NULL OR s.market.id = :marketId)
                    """
    )
    Page<SecurityTitleEntity> findAllByByFilter(
            @Param("mnemonic") String mnemonic,
            @Param("isinCode") String isinCode,
            @Param("issuerCode") String issuerCode,
            @Param("depositoryId") Long depositoryId,
            @Param("statusId") Long statusId,
            @Param("marketId") Long marketId,
            Pageable pageable);

}
