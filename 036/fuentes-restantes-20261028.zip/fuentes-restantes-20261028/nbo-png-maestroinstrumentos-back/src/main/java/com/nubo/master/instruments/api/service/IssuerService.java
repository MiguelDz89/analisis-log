package com.nubo.master.instruments.api.service;

import com.nubo.master.instruments.api.models.dto.request.IssuerInDto;
import com.nubo.master.instruments.api.models.dto.request.IssuerUpdateInDto;
import com.nubo.master.instruments.api.models.dto.response.IssuerOutDto;
import com.nubo.master.instruments.api.models.dto.response.PageResponseOutDto;
import org.springframework.data.domain.Pageable;

public interface IssuerService {

    PageResponseOutDto<IssuerOutDto> findAllIssuer(Pageable pageable);

    IssuerOutDto findIssuerById(Long issuerId);

    PageResponseOutDto<IssuerOutDto> searchIssuer(Pageable pageable, String issuerCode, String text);

    IssuerOutDto createIssuer(IssuerInDto issuerInDto);

    IssuerOutDto updateIssuer(Long issuerId, IssuerUpdateInDto issuerUpdateInDto);
}
