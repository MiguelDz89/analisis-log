package com.nubo.master.instruments.api.helpers;

import org.springframework.data.jpa.domain.Specification;

import com.nubo.master.instruments.api.models.dto.request.EquityInstrumentFilterRequestDto;
import com.nubo.master.instruments.api.models.entity.SecurityTitleEntity;
import com.nubo.master.instruments.api.models.enums.SearchOperationEnum;

import jakarta.persistence.criteria.Path;

public class EquityInstrumentSpecificationFactory {

    private EquityInstrumentSpecificationFactory() {
        throw new IllegalStateException("Utility class");
    }

    public static Specification<SecurityTitleEntity> createStandardFilter(EquityInstrumentFilterRequestDto filter) {
        return EquityInstrumentSpecificationBuilder.builder()
                .withMnemonic(filter.getMnemonic())
                .withIsinCode(filter.getIsinCode())
                .withIssuerCode(filter.getIssuerCode())
                .withDepositoryId(filter.getDepositoryId())
                .withStatusId(filter.getStatusId())
                .withIssuerId(filter.getIssuerId())
                .withMarketId(filter.getMarketId())
                .withCountryId(filter.getCountryId())
                .withClassId(filter.getClassId())
                .withSegmentId(filter.getSegmentId())
                .withSecurityId(filter.getSecurityId())
                .build();
    }

    public static Specification<SecurityTitleEntity> createDynamicFilter(
            String fieldName, String fieldValue, SearchOperationEnum operation) {

        return (root, query, cb) -> {
            try {
                Path<?> fieldPath = MapperEquityInstrumentDynamicSearch.getEquityInstrumentFieldPath(root, fieldName);
                if (fieldPath != null) {
                    return MapperEquityInstrumentDynamicSearch.buildEquityInstrumentFieldPredicate(cb, fieldPath,
                            fieldValue, operation);
                }
                return cb.conjunction();
            } catch (Exception e) {
                return cb.conjunction();
            }
        };
    }

    public static Specification<SecurityTitleEntity> createCombinedFilter(
            EquityInstrumentFilterRequestDto filter,
            String fieldName, String fieldValue, SearchOperationEnum operation) {

        return EquityInstrumentSpecificationBuilder.builder()
                .withMnemonic(filter.getMnemonic())
                .withIsinCode(filter.getIsinCode())
                .withIssuerCode(filter.getIssuerCode())
                .withDepositoryId(filter.getDepositoryId())
                .withStatusId(filter.getStatusId())
                .withIssuerId(filter.getIssuerId())
                .withMarketId(filter.getMarketId())
                .withCountryId(filter.getCountryId())
                .withClassId(filter.getClassId())
                .withSegmentId(filter.getSegmentId())
                .withSecurityId(filter.getSecurityId())
                .withDynamicFilter(fieldName, fieldValue, operation)
                .build();
    }

    public static Specification<SecurityTitleEntity> createDepositoryStatusFilter(Long depositoryId, Long statusId) {
        return EquityInstrumentSpecificationBuilder.builder()
                .withDepositoryId(depositoryId)
                .withStatusId(statusId)
                .build();
    }

    public static Specification<SecurityTitleEntity> createMnemonicFilter(String mnemonic) {
        return EquityInstrumentSpecificationBuilder.builder()
                .withMnemonic(mnemonic)
                .build();
    }

    public static Specification<SecurityTitleEntity> createIssuerFilter(String issuerCode) {
        return EquityInstrumentSpecificationBuilder.builder()
                .withIssuerCode(issuerCode)
                .build();
    }

    public static Specification<SecurityTitleEntity> createIsinFilter(String isinCode) {
        return EquityInstrumentSpecificationBuilder.builder()
                .withIsinCode(isinCode)
                .build();
    }
}
