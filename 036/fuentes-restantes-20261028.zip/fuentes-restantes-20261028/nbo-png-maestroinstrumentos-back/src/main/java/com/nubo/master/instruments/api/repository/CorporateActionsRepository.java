package com.nubo.master.instruments.api.repository;

import com.nubo.master.instruments.api.models.entity.CorporateActionsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface CorporateActionsRepository extends JpaRepository<CorporateActionsEntity, Long>,
        JpaSpecificationExecutor<CorporateActionsEntity> {
}
