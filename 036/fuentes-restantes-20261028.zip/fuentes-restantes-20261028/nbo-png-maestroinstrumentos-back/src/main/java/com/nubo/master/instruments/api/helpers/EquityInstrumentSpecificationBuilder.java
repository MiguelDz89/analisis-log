package com.nubo.master.instruments.api.helpers;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import com.nubo.master.instruments.api.models.entity.SecurityTitleEntity;
import com.nubo.master.instruments.api.models.enums.SearchOperationEnum;

import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;

public class EquityInstrumentSpecificationBuilder
{

    private Specification<SecurityTitleEntity> spec;

    private EquityInstrumentSpecificationBuilder()
    {
        this.spec = Specification.anyOf();
    }

    public static EquityInstrumentSpecificationBuilder builder()
    {
        return new EquityInstrumentSpecificationBuilder();
    }

    public EquityInstrumentSpecificationBuilder withMnemonic(String mnemonic)
    {
        if (StringUtils.hasText(mnemonic))
        {
            spec = spec.and(
                    (root, query, cb) -> cb.like(cb.lower(root.get("mnemonic")), "%" + mnemonic.toLowerCase() + "%"));
        }
        return this;
    }

    public EquityInstrumentSpecificationBuilder withIsinCode(String isinCode)
    {
        if (StringUtils.hasText(isinCode))
        {
            spec = spec.and(
                    (root, query, cb) -> cb.like(cb.lower(root.get("isin")), "%" + isinCode.toLowerCase() + "%"));
        }
        return this;
    }

    public EquityInstrumentSpecificationBuilder withIssuerCode(String issuerCode)
    {
        if (StringUtils.hasText(issuerCode))
        {
            spec = spec.and((root, query, cb) -> cb.like(cb.lower(root.get("equityCode")),
                    "%" + issuerCode.toLowerCase() + "%"));
        }
        return this;
    }

    public EquityInstrumentSpecificationBuilder withDepositoryId(Long depositoryId)
    {
        if (depositoryId != null)
        {
            spec = spec.and((root, query, cb) ->
            {
                Join<Object, Object> depositoryJoin = root.join("depository", JoinType.LEFT);
                return cb.equal(depositoryJoin.get("id"), depositoryId);
            });
        }
        return this;
    }

    public EquityInstrumentSpecificationBuilder withStatusId(Long statusId)
    {
        if (statusId != null)
        {
            spec = spec.and((root, query, cb) ->
            {
                Join<Object, Object> statusJoin = root.join("status", JoinType.LEFT);
                return cb.equal(statusJoin.get("id"), statusId);
            });
        }
        return this;
    }

    public EquityInstrumentSpecificationBuilder withIssuerId(Long issuerId)
    {
        if (issuerId != null)
        {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("issuerId"), issuerId));
        }
        return this;
    }

    public EquityInstrumentSpecificationBuilder withMarketId(Long marketId)
    {
        if (marketId != null)
        {
            spec = spec.and((root, query, cb) ->
            {
                Join<Object, Object> marketJoin = root.join("market", JoinType.LEFT);
                return cb.equal(marketJoin.get("id"), marketId);
            });
        }
        return this;
    }

    public EquityInstrumentSpecificationBuilder withCountryId(Long countryId)
    {
        if (countryId != null)
        {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("countryId"), countryId));
        }
        return this;
    }

    public EquityInstrumentSpecificationBuilder withClassId(Long classId)
    {
        if (classId != null)
        {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("classId"), classId));
        }
        return this;
    }

    public EquityInstrumentSpecificationBuilder withSegmentId(Long segmentId)
    {
        if (segmentId != null)
        {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("segmentId"), segmentId));
        }
        return this;
    }

    public EquityInstrumentSpecificationBuilder withSecurityId(Long securityId)
    {
        if (securityId != null)
        {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("id"), securityId));
        }
        return this;
    }

    public EquityInstrumentSpecificationBuilder withDynamicFilter(
            String fieldName, String fieldValue, SearchOperationEnum operation)
    {
        if (StringUtils.hasText(fieldName) && StringUtils.hasText(fieldValue) && operation != null)
        {
            spec = spec.and(EquityInstrumentSpecificationFactory.createDynamicFilter(fieldName, fieldValue, operation));
        }
        return this;
    }

    public EquityInstrumentSpecificationBuilder withOnlyEquityInstruments()
    {
        spec = spec.and((root, query, cb) ->
        {
            if (query != null)
            {
                var subquery = query.subquery(Long.class);
                var equityRoot = subquery
                        .from(com.nubo.master.instruments.api.models.entity.EquitySecurityEntity.class);
                subquery.select(equityRoot.get("securityId"))
                        .where(cb.equal(equityRoot.get("securityId"), root.get("id")));

                return cb.exists(subquery);
            }
            return cb.conjunction();
        });
        return this;
    }

    public EquityInstrumentSpecificationBuilder withActiveStatus()
    {
        spec = spec.and((root, query, cb) ->
        {
            Join<Object, Object> statusJoin = root.join("status", JoinType.LEFT);
            return cb.equal(cb.upper(statusJoin.get("description")), "ACTIVO");
        });
        return this;
    }

    public Specification<SecurityTitleEntity> build()
    {
        return withOnlyEquityInstruments().spec;
    }
}
