package com.nubo.master.instruments.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nubo.master.instruments.api.models.entity.ClassEntity;

public interface ClassRepository extends JpaRepository<ClassEntity, String> {
    List<ClassEntity> findByCategoryIgnoreCase(String category);
}
