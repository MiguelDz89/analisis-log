package com.nubo.master.instruments.api.service;

import com.nubo.master.instruments.api.models.dto.response.EquityInstrumentLoanOutDto;
import com.nubo.master.instruments.api.models.dto.response.PageResponseOutDto;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface EquityInstrumentLoanService {

    EquityInstrumentLoanOutDto getByMnemonic(String mnemonic, Boolean includeRiskModel);

    PageResponseOutDto<EquityInstrumentLoanOutDto> list(Pageable pageable, Boolean includeRiskModel);

    List<EquityInstrumentLoanOutDto> getByPrefix(String prefix, Boolean includeRiskModel);

}
