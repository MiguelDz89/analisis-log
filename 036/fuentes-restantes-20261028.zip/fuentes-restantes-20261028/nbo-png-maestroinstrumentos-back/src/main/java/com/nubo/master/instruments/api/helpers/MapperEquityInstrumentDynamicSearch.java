package com.nubo.master.instruments.api.helpers;

import com.nubo.master.instruments.api.models.entity.SecurityTitleEntity;
import com.nubo.master.instruments.api.models.enums.SearchOperationEnum;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

public class MapperEquityInstrumentDynamicSearch {

    private MapperEquityInstrumentDynamicSearch() {
        throw new IllegalStateException("Utility class");
    }

    public static Path<?> getEquityInstrumentFieldPath(Root<SecurityTitleEntity> root, String fieldName) {
        if (fieldName == null || fieldName.trim().isEmpty()) {
            return null;
        }

        return switch (fieldName.toLowerCase()) {

            case "mnemonic" -> root.get("mnemonic");
            case "isin" -> root.get("isin");
            case "description" -> root.get("description");
            case "listingdate" -> root.get("listingDate");
            case "delistingdate" -> root.get("delistingDate");
            case "settlementperiod" -> root.get("settlementPeriod");
            case "nominalprice" -> root.get("nominalPrice");
            case "nominalpricedate" -> root.get("nominalPriceDate");
            case "regulatorspeciescode" -> root.get("regulatorSpeciesCode");

            case "issuercode" -> {
                Join<Object, Object> issuerJoin = root.join("issuer", JoinType.LEFT);
                yield issuerJoin.get("code");
            }
            case "issuername" -> {
                Join<Object, Object> issuerJoin = root.join("issuer", JoinType.LEFT);
                yield issuerJoin.get("name");
            }
            case "depositoryname" -> {
                Join<Object, Object> depositoryJoin = root.join("depository", JoinType.LEFT);
                yield depositoryJoin.get("name");
            }
            case "statusdescription" -> {
                Join<Object, Object> statusJoin = root.join("status", JoinType.LEFT);
                yield statusJoin.get("description");
            }
            case "countryname" -> {
                Join<Object, Object> countryJoin = root.join("country", JoinType.LEFT);
                yield countryJoin.get("name");
            }
            case "marketname" -> {
                Join<Object, Object> marketJoin = root.join("market", JoinType.LEFT);
                yield marketJoin.get("name");
            }
            case "currencycode" -> {
                Join<Object, Object> currencyJoin = root.join("currency", JoinType.LEFT);
                yield currencyJoin.get("code");
            }
            case "cficode" -> {
                Join<Object, Object> cfiJoin = root.join("cfi", JoinType.LEFT);
                yield cfiJoin.get("code");
            }

            case "classdescription" -> root.get("classId");
            case "segmentname" -> root.get("segmentId");

            default -> null;
        };
    }

    public static Predicate buildEquityInstrumentFieldPredicate(
            CriteriaBuilder cb, Path<?> fieldPath, String fieldValue, SearchOperationEnum operation) {

        if (fieldPath == null || fieldValue == null || operation == null) {
            return cb.conjunction();
        }

        return switch (operation) {
            case EQUALS -> cb.equal(cb.lower(fieldPath.as(String.class)), fieldValue.toLowerCase());

            case CONTAINS -> cb.like(cb.lower(fieldPath.as(String.class)),
                    "%" + fieldValue.toLowerCase() + "%");

            case STARTS_WITH -> cb.like(cb.lower(fieldPath.as(String.class)),
                    fieldValue.toLowerCase() + "%");

            case ENDS_WITH -> cb.like(cb.lower(fieldPath.as(String.class)),
                    "%" + fieldValue.toLowerCase());

            case GREATER_THAN -> {
                if (isNumericField(fieldPath)) {
                    yield cb.greaterThan(fieldPath.as(String.class), fieldValue);
                } else {
                    yield cb.greaterThan(cb.lower(fieldPath.as(String.class)), fieldValue.toLowerCase());
                }
            }

            case LESS_THAN -> {
                if (isNumericField(fieldPath)) {
                    yield cb.lessThan(fieldPath.as(String.class), fieldValue);
                } else {
                    yield cb.lessThan(cb.lower(fieldPath.as(String.class)), fieldValue.toLowerCase());
                }
            }

            case NOT_EQUALS -> cb.notEqual(cb.lower(fieldPath.as(String.class)), fieldValue.toLowerCase());

            default -> cb.conjunction();
        };
    }

    private static boolean isNumericField(Path<?> fieldPath) {
        Class<?> fieldType = fieldPath.getJavaType();
        return Number.class.isAssignableFrom(fieldType) ||
                fieldType.isPrimitive() && (fieldType == int.class ||
                        fieldType == long.class ||
                        fieldType == double.class ||
                        fieldType == float.class);
    }
}
