package com.nubo.master.instruments.api.service;

import com.nubo.master.instruments.api.models.dto.response.EquityInstrumentLoanOutDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

public interface RiskModelService {

    void addRiskModelByMultipleMnemonic (Boolean includeRiskModel, List<EquityInstrumentLoanOutDto> dtoList);
    void addRiskModelByMnemonic (Boolean includeRiskModel, String mnemonic, EquityInstrumentLoanOutDto dto);

}
