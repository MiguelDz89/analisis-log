package com.nubo.master.instruments.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nubo.master.instruments.api.models.entity.TypeEntity;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface TypeRepository extends JpaRepository<TypeEntity, Long> {

    @Query("""
            SELECT t FROM TypeEntity t 
            WHERE t.category = :category 
            ORDER BY t.id ASC
            """)
    List<TypeEntity> findByGuaranteeLimit(String category);

    List<TypeEntity> findByCategoryIgnoreCase(String category);

}
