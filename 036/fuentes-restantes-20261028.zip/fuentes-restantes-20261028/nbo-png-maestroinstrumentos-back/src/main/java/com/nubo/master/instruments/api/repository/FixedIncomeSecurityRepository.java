package com.nubo.master.instruments.api.repository;

import com.nubo.master.instruments.api.models.entity.FixedIncomeSecurityEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.Optional;

public interface FixedIncomeSecurityRepository
        extends JpaRepository<FixedIncomeSecurityEntity, Long>,
        JpaSpecificationExecutor<FixedIncomeSecurityEntity> {

    Optional<FixedIncomeSecurityEntity>
    findTopBySecurityTitle_SecurityIdOrderByLastModifyDateDesc(Long securityId);
}
