package com.nubo.master.holidays.rate.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MasterHolidayApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(MasterHolidayApiApplication.class, args);
    }

}
