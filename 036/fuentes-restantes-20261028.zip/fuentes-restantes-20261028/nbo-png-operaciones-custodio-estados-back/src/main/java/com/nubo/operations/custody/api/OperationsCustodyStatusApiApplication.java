package com.nubo.operations.custody.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OperationsCustodyStatusApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(OperationsCustodyStatusApiApplication.class, args);
	}

}
