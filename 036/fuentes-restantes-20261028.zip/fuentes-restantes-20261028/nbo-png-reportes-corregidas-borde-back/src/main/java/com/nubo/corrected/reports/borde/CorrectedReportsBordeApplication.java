package com.nubo.corrected.reports.borde;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CorrectedReportsBordeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CorrectedReportsBordeApplication.class, args);
	}

}
