package com.nubo.persistence.assignment.vericlear;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersistenceAssignmentVericlearApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersistenceAssignmentVericlearApplication.class, args);
	}

}
