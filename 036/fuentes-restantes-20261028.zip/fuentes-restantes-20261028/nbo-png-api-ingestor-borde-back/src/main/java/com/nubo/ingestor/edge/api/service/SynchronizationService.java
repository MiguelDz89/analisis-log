package com.nubo.ingestor.edge.api.service;

import com.nubo.ingestor.edge.api.models.dto.response.SynchronizeOutDto;

public interface SynchronizationService {

    SynchronizeOutDto synchronizeDataReference(Integer size);
}
