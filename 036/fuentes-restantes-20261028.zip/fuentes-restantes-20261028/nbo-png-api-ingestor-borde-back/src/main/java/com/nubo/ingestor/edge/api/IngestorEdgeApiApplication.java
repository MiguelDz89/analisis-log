package com.nubo.ingestor.edge.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IngestorEdgeApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(IngestorEdgeApiApplication.class, args);
	}

}
