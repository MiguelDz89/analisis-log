package com.nubo.report.downloader.helpers;

import java.io.InputStream;
import java.util.Arrays;
import java.util.Map;
import java.util.Optional;

import com.nubo.report.downloader.service.impl.FileDownloadServiceImpl;

public class FileDownloadHelper {

    public enum ProtocolStrategy {
        FTP("ftp"),
        SFTP("sftp"),
        RELATIVE("relative");
        
        private final String protocol;
        
        ProtocolStrategy(String protocol) {
            this.protocol = protocol;
        }
        
        public static Optional<ProtocolStrategy> fromProtocol(String protocol) {
            return Arrays.stream(values())
                .filter(strategy -> strategy.protocol.equals(protocol))
                .findFirst();
        }
        
        public InputStream download(FileDownloadServiceImpl service, String extractedPath) {
            return switch (this) {
                case FTP -> service.downloadFromFtp(extractedPath);
                case SFTP -> service.downloadFromSftp(extractedPath);
                case RELATIVE -> service.downloadFromBothServers(extractedPath);
            };
        }
        
        public String extractPath(FileDownloadServiceImpl service, String fullUri) {
            return switch (this) {
                case FTP -> service.extractFtpPath(fullUri);
                case SFTP -> service.extractSftpPath(fullUri);
                case RELATIVE -> fullUri;
            };
        }
    }

    public static final Map<String, String> CONTENT_TYPE_MAP = Map.of(
        "csv", "text/csv",
        "txt", "text/plain",
        "pdf", "application/pdf",
        "zip", "application/zip",
        "dat", "application/octet-stream",
        "xml", "application/xml",
        "json", "application/json"
    );

    private FileDownloadHelper() {
        // Utility class - no instances allowed
    }
}