package com.nubo.report.downloader.repository;

import com.nubo.report.downloader.models.entity.ParticipantEntity;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ParticipantRepository extends JpaRepository<ParticipantEntity, Long> {
}
