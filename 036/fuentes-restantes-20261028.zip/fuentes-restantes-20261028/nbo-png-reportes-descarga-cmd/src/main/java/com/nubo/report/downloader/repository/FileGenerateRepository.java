package com.nubo.report.downloader.repository;

import com.nubo.report.downloader.models.entity.FileGenerateEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FileGenerateRepository extends JpaRepository<FileGenerateEntity, Long> {
}
