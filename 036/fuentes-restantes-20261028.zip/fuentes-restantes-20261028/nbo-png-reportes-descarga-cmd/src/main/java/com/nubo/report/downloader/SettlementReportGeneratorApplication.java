package com.nubo.report.downloader;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SettlementReportGeneratorApplication {

	public static void main(String[] args) {
		SpringApplication.run(SettlementReportGeneratorApplication.class, args);
	}

}
