package com.nubo.report.downloader.service;

import org.springframework.http.ResponseEntity;

import com.nubo.report.downloader.models.dto.FileDownloadResult;
import com.nubo.report.downloader.models.dto.FileDownloadResponse;

public interface FileDownloadService {

    ResponseEntity<FileDownloadResponse> downloadFile(String filePath);

    ResponseEntity<FileDownloadResult> getFileInfo(String filePath);

    ResponseEntity<byte[]> downloadFileById(Long fileId);

    ResponseEntity<FileDownloadResult> getFileInfoById(Long fileId);

    ResponseEntity<byte[]> downloadFileAsByteArray(Long fileId);

}