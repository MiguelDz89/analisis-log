package com.nubo.report.downloader.helpers;

import java.io.IOException;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.util.List;

import com.nubo.report.downloader.models.dto.request.SettlementReportOutDto;
import com.nubo.report.downloader.models.enums.SettlementFieldEnum;

public class FixedWidthCsvGeneratorUtil {

    public static String writeFixedWidthFile(List<SettlementReportOutDto> data, String filePath) throws IOException {
        StringWriter writer = new StringWriter();
        for (SettlementReportOutDto dto : data) {
            StringBuilder line = new StringBuilder();
            for (SettlementFieldEnum field : SettlementFieldEnum.values()) {
                Object value = getFieldValue(dto, field.getFieldName());
                line.append(fixedWidth(value, field.getLength(), field.getType()));
            }
            writer.write(line.toString());
            writer.write(System.lineSeparator());
        }
        return writer.toString();
    }

    private static Object getFieldValue(SettlementReportOutDto dto, String fieldName) {
        try {
            String methodName = "get" + Character.toUpperCase(fieldName.charAt(0)) + fieldName.substring(1);
            Method method = dto.getClass().getMethod(methodName);
            return method.invoke(dto);
        } catch (Exception e) {
            return "";
        }
    }

    private static String fixedWidth(Object value, int width, char type) {

    String str = value == null ? "" : value.toString();

    if (type == 'N') {
        
        if (str.length() > width) {
            str = str.substring(0, width);
            
            if (str.endsWith(".")) {
                str = str.substring(0, str.length() - 1);
                
                if (str.length() < width) {
                    str = String.format("%" + width + "s", str).replace(' ', '0');
                }
            }
        }

        if (str.length() < width) {
            str = String.format("%" + width + "s", str).replace(' ', '0');
        }

        return str;

    } else {

        if (str.length() > width) {
            str = str.substring(0, width);
        }

        return String.format("%-" + width + "s", str);
    }
    
    }

}