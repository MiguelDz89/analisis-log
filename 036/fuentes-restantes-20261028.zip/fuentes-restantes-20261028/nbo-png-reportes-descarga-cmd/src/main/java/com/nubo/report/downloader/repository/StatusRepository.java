package com.nubo.report.downloader.repository;

import com.nubo.report.downloader.models.entity.StatusEntity;
import org.springframework.data.jpa.repository.JpaRepository;


public interface StatusRepository extends JpaRepository<StatusEntity, Long> {
}
