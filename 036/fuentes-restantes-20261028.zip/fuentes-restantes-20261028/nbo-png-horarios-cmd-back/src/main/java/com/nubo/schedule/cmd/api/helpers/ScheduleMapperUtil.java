package com.nubo.schedule.cmd.api.helpers;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import com.nubo.schedule.cmd.api.models.dto.response.ScheduleDto;
import com.nubo.schedule.cmd.api.models.entity.ScheduleEntity;

public class ScheduleMapperUtil
{

    public static ScheduleDto toDto(ScheduleEntity entity)
    {
        if (entity == null)
            return null;
        return ScheduleDto.builder()
                .id(entity.getId())
                .description(entity.getDescription())
                .openingTime(entity.getOpeningTime())
                .closingTime(entity.getClosingTime())
                .startDate(entity.getStartDate())
                .endDate(entity.getEndDate())
                .frequency(entity.getFrequency())
                .module(entity.getModule() != null ? ModuleMapperUtil.toDto(entity.getModule()) : null)
                .automatic(entity.getAutomatic())
                .process(entity.getProcess() != null ? ProcessMapperUtil.toDto(entity.getProcess()) : null)
                .build();
    }

    public static List<ScheduleDto> toDtoList(List<ScheduleEntity> entities)
    {
        if (entities == null || entities.isEmpty())
        {
            return Collections.emptyList();
        }
        return entities.stream()
                .map(ScheduleMapperUtil::toDto)
                .collect(Collectors.toList());
    }
}
