package com.nubo.schedule.cmd.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nubo.schedule.cmd.api.models.entity.MicroserviceEntity;

public interface MicroserviceRepository extends JpaRepository<MicroserviceEntity, Integer>
{
    List<MicroserviceEntity> findByNameContainingIgnoreCase(String name);
}
