package com.nubo.schedule.cmd.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nubo.schedule.cmd.api.models.entity.SubmoduleEntity;

public interface SubmoduleRepository extends JpaRepository<SubmoduleEntity, Integer>
{
    List<SubmoduleEntity> findBySubmoduleDeletedFalse();

    List<SubmoduleEntity> findByModuleIdAndSubmoduleDeletedFalse(Integer moduleId);

    List<SubmoduleEntity> findByNameContainingIgnoreCaseAndSubmoduleDeletedFalse(String name);

    List<SubmoduleEntity> findByModuleIdAndNameContainingIgnoreCaseAndSubmoduleDeletedFalse(
            Integer moduleId, String name);
}
