package com.nubo.schedule.cmd.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nubo.schedule.cmd.api.models.entity.TypeEntity;

public interface TypeRepository extends JpaRepository<TypeEntity, Long>
{
}
