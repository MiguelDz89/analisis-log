package com.nubo.schedule.cmd.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nubo.schedule.cmd.api.models.entity.ScheduleEntity;

public interface ScheduleRepository extends JpaRepository<ScheduleEntity, Long>
{

    List<ScheduleEntity> findByUserNuboId(Long userNuboId);

    boolean existsByProcessIdAndStatusIdAndCountryId(Long processId, Long statusId, Long countryId);

    boolean existsByScreenActionIdAndStatusIdAndCountryId(Long screenActionId, Long statusId, Long countryId);

    boolean existsByDescriptionAndIdNot(String description, Long id);

}
