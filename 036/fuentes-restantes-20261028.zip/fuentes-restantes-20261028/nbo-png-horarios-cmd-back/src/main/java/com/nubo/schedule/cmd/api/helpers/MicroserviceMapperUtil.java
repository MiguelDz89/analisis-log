package com.nubo.schedule.cmd.api.helpers;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import com.nubo.schedule.cmd.api.models.dto.response.MicroserviceDto;
import com.nubo.schedule.cmd.api.models.entity.MicroserviceEntity;

public class MicroserviceMapperUtil
{

    public static MicroserviceDto toDto(MicroserviceEntity entity)
    {
        if (entity == null)
            return null;
        return MicroserviceDto.builder()
                .id(entity.getId())
                .name(entity.getName())
                .build();
    }

    public static List<MicroserviceDto> toDtoList(List<MicroserviceEntity> entities)
    {
        if (entities == null || entities.isEmpty())
        {
            return Collections.emptyList();
        }
        return entities.stream()
                .map(MicroserviceMapperUtil::toDto)
                .collect(Collectors.toList());
    }
}
