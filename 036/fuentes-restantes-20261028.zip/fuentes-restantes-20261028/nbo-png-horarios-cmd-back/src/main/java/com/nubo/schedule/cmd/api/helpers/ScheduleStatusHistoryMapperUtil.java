package com.nubo.schedule.cmd.api.helpers;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import com.nubo.schedule.cmd.api.models.dto.response.ScheduleStatusHistoryDto;
import com.nubo.schedule.cmd.api.models.entity.ScheduleStatusHistoryEntity;

public class ScheduleStatusHistoryMapperUtil
{

    public static ScheduleStatusHistoryDto toDto(ScheduleStatusHistoryEntity entity)
    {
        if (entity == null)
            return null;
        return ScheduleStatusHistoryDto.builder()
                .scheduleId(entity.getScheduleId())
                .time(entity.getTime())
                .detail(entity.getDetail())
                .build();
    }

    public static List<ScheduleStatusHistoryDto> toDtoList(List<ScheduleStatusHistoryEntity> entities)
    {
        if (entities == null || entities.isEmpty())
        {
            return Collections.emptyList();
        }
        return entities.stream()
                .map(ScheduleStatusHistoryMapperUtil::toDto)
                .collect(Collectors.toList());
    }
}
