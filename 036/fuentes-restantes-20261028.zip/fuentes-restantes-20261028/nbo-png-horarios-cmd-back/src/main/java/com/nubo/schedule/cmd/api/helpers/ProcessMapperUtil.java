package com.nubo.schedule.cmd.api.helpers;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import com.nubo.schedule.cmd.api.models.dto.response.ProcessDto;
import com.nubo.schedule.cmd.api.models.entity.ProcessEntity;

public class ProcessMapperUtil
{

    public static ProcessDto toDto(ProcessEntity entity)
    {
        if (entity == null)
            return null;
        return ProcessDto.builder()
                .id(entity.getId())
                .description(entity.getDescription())
                .build();
    }

    public static List<ProcessDto> toDtoList(List<ProcessEntity> entities)
    {
        if (entities == null || entities.isEmpty())
        {
            return Collections.emptyList();
        }
        return entities.stream()
                .map(ProcessMapperUtil::toDto)
                .collect(Collectors.toList());
    }
}
