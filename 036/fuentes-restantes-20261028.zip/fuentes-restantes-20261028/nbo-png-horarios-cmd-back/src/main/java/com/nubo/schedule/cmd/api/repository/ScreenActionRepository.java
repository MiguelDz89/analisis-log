package com.nubo.schedule.cmd.api.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nubo.schedule.cmd.api.models.entity.ScreenActionEntity;

@Repository
public interface ScreenActionRepository extends JpaRepository<ScreenActionEntity, Long>
{
    Optional<ScreenActionEntity> findById(Long id);
}
