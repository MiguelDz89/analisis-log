package com.nubo.schedule.cmd.api.service;

import java.util.List;

import com.nubo.schedule.cmd.api.models.dto.request.JobsResultRequestDto;
import com.nubo.schedule.cmd.api.models.dto.request.ScheduleRequestDto;
import com.nubo.schedule.cmd.api.models.dto.request.ScheduleUpdateRequestDto;
import com.nubo.schedule.cmd.api.models.dto.response.ScheduleDto;

public interface ScheduleService
{

    List<ScheduleDto> createOrUpdate(ScheduleRequestDto request);

    ScheduleDto updateSchedule(ScheduleUpdateRequestDto request);

    List<ScheduleDto> getAllByUser(Long userId);

    void processScheduleEvent(JobsResultRequestDto message);

}
