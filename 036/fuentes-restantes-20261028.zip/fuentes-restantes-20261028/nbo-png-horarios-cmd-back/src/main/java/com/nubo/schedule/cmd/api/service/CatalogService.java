package com.nubo.schedule.cmd.api.service;

import java.util.List;

import com.nubo.schedule.cmd.api.models.dto.response.CatalogItemDto;

public interface CatalogService
{

    List<CatalogItemDto> getModules(String search);

    List<CatalogItemDto> getSubmodules(Long moduleId, String search);

    List<CatalogItemDto> getProcesses(String search);

    List<CatalogItemDto> getMicroservices(String search);

    List<CatalogItemDto> getCountries();

    List<CatalogItemDto> getFrequencies();

    List<CatalogItemDto> getSchedulesByCountry(String countryCode);

    List<CatalogItemDto> getTimezones();
}
