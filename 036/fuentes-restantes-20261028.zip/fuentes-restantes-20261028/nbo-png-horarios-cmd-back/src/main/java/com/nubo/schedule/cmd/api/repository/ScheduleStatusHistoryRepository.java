package com.nubo.schedule.cmd.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.nubo.schedule.cmd.api.models.entity.ScheduleStatusHistoryEntity;

public interface ScheduleStatusHistoryRepository
        extends JpaRepository<ScheduleStatusHistoryEntity, ScheduleStatusHistoryEntity.ScheduleStatusHistoryId>
{

    @Query("SELECT ssh FROM ScheduleStatusHistoryEntity ssh WHERE ssh.scheduleId IN " +
            "(SELECT s.id FROM ScheduleEntity s WHERE s.userNubo.id = :userNuboId)")
    List<ScheduleStatusHistoryEntity> findByScheduleUserNuboId(@Param("userNuboId") Long userNuboId);
}
