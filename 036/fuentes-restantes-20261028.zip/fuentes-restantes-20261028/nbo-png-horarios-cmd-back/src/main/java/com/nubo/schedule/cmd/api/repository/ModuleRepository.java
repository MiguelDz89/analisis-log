package com.nubo.schedule.cmd.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nubo.schedule.cmd.api.models.entity.ModuleEntity;

public interface ModuleRepository extends JpaRepository<ModuleEntity, Integer>
{
    List<ModuleEntity> findByModuleDeletedFalse();

    List<ModuleEntity> findByNameContainingIgnoreCaseAndModuleDeletedFalse(String name);
}
