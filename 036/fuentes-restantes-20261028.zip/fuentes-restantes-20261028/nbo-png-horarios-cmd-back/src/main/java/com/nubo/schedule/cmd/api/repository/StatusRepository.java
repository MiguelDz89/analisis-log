package com.nubo.schedule.cmd.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nubo.schedule.cmd.api.models.entity.StatusEntity;

public interface StatusRepository extends JpaRepository<StatusEntity, Long>
{
}
