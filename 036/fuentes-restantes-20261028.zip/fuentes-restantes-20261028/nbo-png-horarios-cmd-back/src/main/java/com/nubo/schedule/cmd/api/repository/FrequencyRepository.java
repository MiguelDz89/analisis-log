package com.nubo.schedule.cmd.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nubo.schedule.cmd.api.models.entity.FrequencyEntity;

public interface FrequencyRepository extends JpaRepository<FrequencyEntity, Long>
{
}
