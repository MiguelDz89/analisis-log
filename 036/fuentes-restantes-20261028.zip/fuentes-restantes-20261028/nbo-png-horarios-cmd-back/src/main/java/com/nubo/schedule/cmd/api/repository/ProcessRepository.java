package com.nubo.schedule.cmd.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nubo.schedule.cmd.api.models.entity.ProcessEntity;

public interface ProcessRepository extends JpaRepository<ProcessEntity, Long>
{
    List<ProcessEntity> findByDescriptionContainingIgnoreCase(String description);
}
