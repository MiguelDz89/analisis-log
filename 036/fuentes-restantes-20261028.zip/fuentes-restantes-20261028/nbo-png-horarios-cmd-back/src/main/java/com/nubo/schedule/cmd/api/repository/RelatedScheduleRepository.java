package com.nubo.schedule.cmd.api.repository;

import com.nubo.schedule.cmd.api.models.entity.RelatedScheduleEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RelatedScheduleRepository extends JpaRepository<RelatedScheduleEntity, Long> {
    List<RelatedScheduleEntity> findByScheduleId(Long scheduleId);

}
