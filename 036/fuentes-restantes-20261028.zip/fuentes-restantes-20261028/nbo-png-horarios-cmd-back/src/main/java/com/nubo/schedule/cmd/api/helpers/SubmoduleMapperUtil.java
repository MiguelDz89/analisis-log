package com.nubo.schedule.cmd.api.helpers;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import com.nubo.schedule.cmd.api.models.dto.response.SubmoduleDto;
import com.nubo.schedule.cmd.api.models.entity.SubmoduleEntity;

public class SubmoduleMapperUtil
{

    public static SubmoduleDto toDto(SubmoduleEntity entity)
    {
        if (entity == null)
            return null;
        return SubmoduleDto.builder()
                .id(entity.getId())
                .description(entity.getDescription())
                .name(entity.getName())
                .collapsible(entity.getCollapsible())
                .orderItem(entity.getOrderItem())
                .module(entity.getModule() != null ? ModuleMapperUtil.toDto(entity.getModule()) : null)
                .build();
    }

    public static List<SubmoduleDto> toDtoList(List<SubmoduleEntity> entities)
    {
        if (entities == null || entities.isEmpty())
        {
            return Collections.emptyList();
        }
        return entities.stream()
                .map(SubmoduleMapperUtil::toDto)
                .collect(Collectors.toList());
    }
}
