package com.nubo.schedule.cmd.api.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nubo.schedule.cmd.api.models.entity.CountryEntity;

public interface CountryRepository extends JpaRepository<CountryEntity, Long>
{
    Optional<CountryEntity> findByCode(String code);
}
