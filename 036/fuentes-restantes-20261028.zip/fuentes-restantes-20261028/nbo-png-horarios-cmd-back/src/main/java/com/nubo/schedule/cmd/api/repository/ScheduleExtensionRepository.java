package com.nubo.schedule.cmd.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nubo.schedule.cmd.api.models.entity.ScheduleExtensionEntity;

public interface ScheduleExtensionRepository extends JpaRepository<ScheduleExtensionEntity, Long>
{
    List<ScheduleExtensionEntity> findByScheduleId(Long scheduleId);
}
