package com.nubo.schedule.cmd.api.service;

import java.util.List;

import com.nubo.schedule.cmd.api.models.dto.response.ScheduleStatusHistoryDto;

public interface ScheduleStatusHistoryService
{

    List<ScheduleStatusHistoryDto> getAllByUser(Long userId);

}
