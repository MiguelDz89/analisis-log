package com.nubo.schedule.cmd.api.exception;

import java.util.List;

import org.springframework.http.HttpStatus;

import com.nubo.schedule.cmd.api.exception.error.ErrorCode;

import lombok.Getter;

@Getter
public class SchedulePermissionException extends RuntimeException
{

    private final ErrorCode errorCode;
    private final HttpStatus httpStatus;
    private final List<String> validationErrors;

    public SchedulePermissionException(ErrorCode errorCode)
    {
        super(errorCode.getMessage());
        this.errorCode = errorCode;
        this.httpStatus = HttpStatus.BAD_REQUEST;
        this.validationErrors = null;
    }

    public SchedulePermissionException(ErrorCode errorCode, List<String> validationErrors)
    {
        super(errorCode.getMessage());
        this.errorCode = errorCode;
        this.httpStatus = HttpStatus.BAD_REQUEST;
        this.validationErrors = validationErrors;
    }
}
