package com.nubo.issuer.sync.service;

import com.nubo.issuer.sync.models.entity.CountryEntity;
import com.nubo.issuer.sync.models.entity.DepositoryEntity;
import com.nubo.issuer.sync.models.entity.GicsEntity;
import com.nubo.issuer.sync.models.entity.IssuerEntity;
import com.nubo.issuer.sync.models.entity.StatusEntity;
import com.nubo.issuer.sync.models.entity.TypeEntity;

import java.util.Optional;

public interface BatchCacheService {

    TypeEntity validateTypeEntity(String issuerType);

    DepositoryEntity validateDepositoryEntity(String depositCode);

    StatusEntity findStatusEntityFromMapping(String externalStatusCode);

    CountryEntity validateCountryEntity(String countryCode);

    GicsEntity validateSectorAndSubsectorEntity(String sector, String subSector);
}
