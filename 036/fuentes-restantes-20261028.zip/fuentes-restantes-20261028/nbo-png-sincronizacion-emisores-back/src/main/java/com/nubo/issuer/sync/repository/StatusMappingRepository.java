package com.nubo.issuer.sync.repository;

import com.nubo.issuer.sync.models.entity.StatusMappingEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface StatusMappingRepository extends JpaRepository<StatusMappingEntity, Long> {

    Optional<StatusMappingEntity> findByExternalSystemAndExternalCodeAndCategory(
            String externalSystem,
            String externalCode,
            String category
    );
}
