package com.nubo.issuer.sync.repository;

import com.nubo.issuer.sync.models.entity.TypeEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;


public interface TypeRepository extends JpaRepository<TypeEntity, Long> {

}
