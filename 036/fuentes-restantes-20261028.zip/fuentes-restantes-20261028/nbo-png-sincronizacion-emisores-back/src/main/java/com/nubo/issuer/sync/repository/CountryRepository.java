package com.nubo.issuer.sync.repository;

import com.nubo.issuer.sync.models.entity.CountryEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CountryRepository extends JpaRepository<CountryEntity, Long> {
    Optional<CountryEntity> findByCode(String countryCode);
}
