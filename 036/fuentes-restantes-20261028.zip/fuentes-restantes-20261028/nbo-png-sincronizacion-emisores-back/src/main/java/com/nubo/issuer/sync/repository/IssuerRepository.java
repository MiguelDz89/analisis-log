package com.nubo.issuer.sync.repository;

import com.nubo.issuer.sync.models.entity.IssuerEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface IssuerRepository extends JpaRepository<IssuerEntity, Long> {
    Optional<IssuerEntity> findByCode(String code);

    List<IssuerEntity> findByCodeIn(Collection<String> codes);
}
