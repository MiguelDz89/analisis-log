package com.nubo.issuer.sync.repository;

import com.nubo.issuer.sync.models.entity.DepositoryEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface DepositoryRepository  extends JpaRepository<DepositoryEntity, Long> {
    Optional<DepositoryEntity> findByDescription(String description);
}
