package com.nubo.issuer.sync.repository;

import com.nubo.issuer.sync.models.entity.DepositoryMappingEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface DepositoryMappingRepository extends JpaRepository<DepositoryMappingEntity, Long> {

    Optional<DepositoryMappingEntity>
    findByExternalSystemAndExternalCodeAndCategory(
            String externalSystem,
            String externalCode,
            String category
    );
}
