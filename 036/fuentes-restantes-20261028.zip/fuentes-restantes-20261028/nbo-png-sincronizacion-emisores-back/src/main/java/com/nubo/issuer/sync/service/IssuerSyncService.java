package com.nubo.issuer.sync.service;

import com.nubo.issuer.sync.models.dto.request.IssuerInDto;

import java.util.List;

public interface IssuerSyncService {

    void sendBatchToDataBase(List<IssuerInDto> issuerInDtoList);


}
