package com.nubo.issuer.sync.repository;

import com.nubo.issuer.sync.models.entity.StatusEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StatusRepository extends JpaRepository<StatusEntity, Long> {

}
