package com.nubo.issuer.sync.repository;

import com.nubo.issuer.sync.models.entity.GicsEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface GicsRepository extends JpaRepository<GicsEntity, Long> {
    Optional<GicsEntity> findById(Long id);
}
