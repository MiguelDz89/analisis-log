package com.nubo.issuer.sync;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IssuerSyncApplication {

	public static void main(String[] args) {
		SpringApplication.run(IssuerSyncApplication.class, args);
	}

}
