package com.nubo.transformation.corrections.api.helpers;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class OperacionCorregidaContext {

    private List<String> operationNumbers;
    private Integer sellDepositorCodeMapped;
    private Integer buyDepositorCodeMapped;
    private String deposit;

}