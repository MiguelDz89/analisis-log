package com.nubo.transformation.corrections.api.repository;

import com.nubo.transformation.corrections.api.models.entity.InvestorAccountEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InvestorAccountRepository extends JpaRepository<InvestorAccountEntity, Long> {
}
