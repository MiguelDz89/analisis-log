package com.nubo.transformation.corrections.api.helpers;

import com.nubo.transformation.corrections.api.exception.ServiceException;
import com.nubo.transformation.corrections.api.exception.error.ErrorCode;
import com.nubo.transformation.corrections.api.models.dto.request.TradeCorrectionInDto;
import com.nubo.transformation.corrections.api.models.dto.response.OperacionCorregidaOutDto;
import com.nubo.transformation.corrections.api.models.entity.ParticipantEntity;
import com.nubo.transformation.corrections.api.models.entity.SettlementEntity;
import com.nubo.transformation.corrections.api.models.entity.TradeEntity;
import com.nubo.transformation.corrections.api.models.enums.CorrectionsEnum;
import com.nubo.transformation.corrections.api.models.enums.SideEnum;

import lombok.experimental.UtilityClass;

import java.math.BigDecimal;
import java.math.MathContext;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@UtilityClass
public class OperacionCorregidaOutMapper {

    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyyMMdd");

    public List<OperacionCorregidaOutDto> mapToOperacionCorregidaDtos(TradeCorrectionInDto kafkaCorrection,
                                                                      TradeEntity trade,
                                                                      List<SettlementEntity> settlementsOpuesta,
                                                                      SettlementEntity settlementCorregido,
                                                                      SideEnum currentSide,
                                                                      OperacionCorregidaContext context) {

        List<OperacionCorregidaOutDto> result = new ArrayList<>();

        boolean fraccionar = SideEnum.BUY.equals(currentSide) && settlementsOpuesta.size() > 1;

        BigDecimal totalFraction = settlementCorregido.getFractionQuantity();
        BigDecimal totalAmount = settlementCorregido.getSettlementAmount();

        BigDecimal totalFraccionesOpuestas = settlementsOpuesta.stream()
                .map(SettlementEntity::getFractionQuantity)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        for (int i = 0; i < settlementsOpuesta.size(); i++) {
            SettlementEntity puntaOpuesta = settlementsOpuesta.get(i);
            String operationNumber = context.getOperationNumbers().get(i);

            String cuentaVendedor = kafkaCorrection.getInvestorAccount() != null
                    ? kafkaCorrection.getInvestorAccount().getAccountNumber()
                    : null;

            String cuentaComprador = puntaOpuesta.getInvestorAccount() != null
                    ? puntaOpuesta.getInvestorAccount().getAccountNumber()
                    : null;

            if (SideEnum.SELL.equals(currentSide)) {
                String tmp = cuentaVendedor;
                cuentaVendedor = cuentaComprador;
                cuentaComprador = tmp;
            }

            String isinCode = trade.getSecurityTitle() != null
                    ? trade.getSecurityTitle().getIsin()
                    : null;

            if (isinCode == null) {
                throw new ServiceException(
                        ErrorCode.SECURITY_TITLE_NOT_FOUND,
                        new RuntimeException("El equityCode del SecurityTitle no puede ser nulo")
                );
            }

            BigDecimal proporcion = BigDecimal.ZERO;
            if (fraccionar && totalFraccionesOpuestas.compareTo(BigDecimal.ZERO) > 0) {
                proporcion = puntaOpuesta.getFractionQuantity().divide(totalFraccionesOpuestas, MathContext.DECIMAL64);
            }

            BigDecimal unitValue = fraccionar
                    ? totalFraction.multiply(proporcion, MathContext.DECIMAL64)
                    : BigDecimal.valueOf(kafkaCorrection.getFractionQuantity());

            BigDecimal cashValue = fraccionar
                    ? totalAmount.multiply(proporcion, MathContext.DECIMAL64)
                    : BigDecimal.valueOf(kafkaCorrection.getSettlementAmount());

            Integer sellCustodianCode = toIntId(puntaOpuesta.getCustodian());
            if (sellCustodianCode == null) {
                sellCustodianCode = toIntId(puntaOpuesta.getDirectDepositor());
            }

            Integer buyCustodianCode = toIntId(trade.getCustodianBuy());
            if (buyCustodianCode == null) {
                buyCustodianCode = toIntId(trade.getParticipantBuy());
            }

            OperacionCorregidaOutDto dto = OperacionCorregidaOutDto.builder()
                    .operationIndicator(CorrectionsEnum.OPERATION_INDICATOR.getValue())
                    .plazaCode(CorrectionsEnum.PLAZA_CODE.getValue())
                    .operationMode(CorrectionsEnum.OPERATION_MODE.getValue())
                    .operationRegistrationDate(trade.getMatchDate() != null ? trade.getMatchDate().format(DATE_FORMAT) : null)
                    .operationNumber(operationNumber)
                    .processType(CorrectionsEnum.PROCESS_TYPE.getValue())
                    .countedSettlementType(CorrectionsEnum.COUNTED_SETTLEMENT_TYPE.getValue())
                    .termSettlementType(CorrectionsEnum.TERM_SETTLEMENT_TYPE.getValue())
                    .countedSettlementDate(trade.getClearingDate() != null ? trade.getClearingDate().format(DATE_FORMAT) : null)
                    .termSettlementDate(trade.getClearingDate() != null ? trade.getClearingDate().format(DATE_FORMAT) : null)
                    .sellDepositorCode(context.getSellDepositorCodeMapped())//
                    .sellCustodianCode(sellCustodianCode)
                    .sellInvestorAccount(cuentaVendedor)
                    .sellCud(Integer.toString(CorrectionsEnum.SELL_CUD.getValue()))
                    .buyDepositorCode(context.getBuyDepositorCodeMapped())//
                    .buyCustodianCode(buyCustodianCode)
                    .buyInvestorAccount(cuentaComprador)
                    .buyCud(Integer.toString(CorrectionsEnum.BUY_CUD.getValue()))
                    .isin(isinCode)
                    .deposit(context.getDeposit())
                    .unitValue(unitValue)
                    .cashValue(cashValue)
                    .currencyCode(CorrectionsEnum.CURRENCY_CODE.getValue())
                    .buySettlementIndicator(CorrectionsEnum.BUY_SETTLEMENT_INDICATOR.getValue())
                    .sellSettlementIndicator(CorrectionsEnum.SELL_SETTLEMENT_INDICATOR.getValue())
                    .referencePlazaCode(CorrectionsEnum.REFERENCE_PLAZA_CODE.getValue())
                    .referenceOperationMode(CorrectionsEnum.REFERENCE_OPERATION_MODE.getValue())
                    .referenceOperationRegistrationDate(LocalDate.now().format(DATE_FORMAT))
                    .referenceOperationNumber(trade.getMatchId() != null ? trade.getMatchId().toString() : null)
                    .build();

            result.add(dto);
        }

        return result;

    }

    private static Integer toIntId(ParticipantEntity participant) {
        return participant != null && participant.getId() != null
                ? participant.getId().intValue()
                : null;
    }

}
