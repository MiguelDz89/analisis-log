package com.nubo.transformation.corrections.api.repository;

import com.nubo.transformation.corrections.api.models.entity.DirectDepositoryEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface DirectDepositoryRepository extends JpaRepository<DirectDepositoryEntity, Long> {
    @Query("""
           select d.directDepositoryNumber
           from DirectDepositoryEntity d
           where d.participant.id = :participantId
             and d.depository.id = :depositoryId
           """)
    Optional<String> findDirectDepositoryNumberByParticipantIdAndDepositoryId(
            @Param("participantId") Long participantId,
            @Param("depositoryId") String depositoryId
    );
}
