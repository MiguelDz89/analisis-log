package com.nubo.transformation.corrections.api.repository;

import com.nubo.transformation.corrections.api.models.entity.ParticipantCodeEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ParticipantCodeRepository extends JpaRepository<ParticipantCodeEntity, Long> {

    Optional<ParticipantCodeEntity> findByNuamCode(String nuamCode);
}
