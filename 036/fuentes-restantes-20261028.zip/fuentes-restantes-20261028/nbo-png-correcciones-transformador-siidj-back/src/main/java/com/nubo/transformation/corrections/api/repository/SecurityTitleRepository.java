package com.nubo.transformation.corrections.api.repository;

import com.nubo.transformation.corrections.api.models.entity.SecurityTitleEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SecurityTitleRepository extends JpaRepository<SecurityTitleEntity, Long> {
}
