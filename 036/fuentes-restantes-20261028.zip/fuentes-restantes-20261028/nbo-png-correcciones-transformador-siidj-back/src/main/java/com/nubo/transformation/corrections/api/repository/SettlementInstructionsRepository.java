package com.nubo.transformation.corrections.api.repository;

import com.nubo.transformation.corrections.api.models.entity.SettlementInstructionsEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SettlementInstructionsRepository extends JpaRepository<SettlementInstructionsEntity, Long> {
}
