package com.nubo.transformation.corrections.api.service;

import com.nubo.transformation.corrections.api.models.dto.request.FractionEventKafkaInDto;

public interface TransformationCorrectionService {
    void processCorrections(FractionEventKafkaInDto kafkaMessage);
}
