package com.nubo.transformation.corrections.api.repository;

import com.nubo.transformation.corrections.api.models.entity.DailyOperationCounterEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;

public interface DailyOperationCounterRepository extends JpaRepository<DailyOperationCounterEntity, LocalDate> {

    @Query(value = """
        INSERT INTO daily_operation_counter(operation_date, counter)
        VALUES (CURRENT_DATE, 1)
        ON CONFLICT (operation_date) DO UPDATE
            SET counter = daily_operation_counter.counter + 1
        RETURNING counter
        """, nativeQuery = true)
    Integer getNextDailyCounter();

    @Query(value = """
        INSERT INTO daily_operation_counter(operation_date, counter)
        VALUES (CURRENT_DATE, :increment)
        ON CONFLICT (operation_date) DO UPDATE
            SET counter = daily_operation_counter.counter + :increment
        RETURNING counter
        """, nativeQuery = true)
    Integer incrementAndGetCounter(@Param("increment") int increment);
}

