package com.nubo.transformation.corrections.api.repository;

import com.nubo.transformation.corrections.api.models.entity.SettlementEntity;
import com.nubo.transformation.corrections.api.models.entity.SettlementKey;
import com.nubo.transformation.corrections.api.models.entity.StatusEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface SettlementRepository extends JpaRepository<SettlementEntity, SettlementKey> {

    List<SettlementEntity> findByTradeIdAndSideId(Long tradeId, String sideId);
    List<SettlementEntity> findByTradeIdAndFractionAndSideId(Long tradeId, Integer fraction, String sideId);

    @Modifying
    @Transactional
    @Query("""
            UPDATE SettlementEntity s
            SET s.status = :status, s.lastModifyUser = :user, s.lastModifyDate = :date,
                    s.lastModifyApplication = :app, s.lastModifyIp = :ip
            WHERE s.trade.id = :tradeId
            AND s.fraction = :fraction
            AND s.side.id = :sideId
            """)
    int updateStatus(
            @Param("status") StatusEntity status,
            @Param("tradeId") Long tradeId,
            @Param("fraction") Integer fraction,
            @Param("sideId") String sideId,
            @Param("user") String user,
            @Param("date") LocalDateTime date,
            @Param("app") String app,
            @Param("ip") String ip
    );
}
