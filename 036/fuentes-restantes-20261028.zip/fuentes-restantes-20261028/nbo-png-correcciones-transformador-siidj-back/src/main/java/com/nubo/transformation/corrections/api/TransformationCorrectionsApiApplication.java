package com.nubo.transformation.corrections.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransformationCorrectionsApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransformationCorrectionsApiApplication.class, args);
	}

}
