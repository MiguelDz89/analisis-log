package com.nubo.transformation.corrections.api.repository;

import com.nubo.transformation.corrections.api.models.entity.IsinNumberEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface IsinNumberRepository extends JpaRepository<IsinNumberEntity, Long> {
    Optional<IsinNumberEntity> findByIsinNumber(String isinNumber);
}
