package com.nubo.transformation.corrections.api.repository;

import com.nubo.transformation.corrections.api.models.entity.DepositoryMappingEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface DepositoryMappingRepository extends JpaRepository<DepositoryMappingEntity, Long> {
    Optional<DepositoryMappingEntity> findByExternalSystemAndDepository_Id(String externalSystem, String depositoryId);

}
