package com.nubo.siidj.correction.sender.service;

import com.nubo.siidj.correction.sender.models.dto.request.SendingCorrection;

import java.util.List;

public interface ProcessMessageService {

    void sendMessageToKafkaRegional(SendingCorrection sendingCorrection);
}
