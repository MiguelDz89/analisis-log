package com.nubo.siidj.correction.sender.helpers;

import com.nuamx.bus.message.common.Currency;
import com.nuamx.bus.message.common.Date;
import com.nubo.siidj.correction.sender.application.util.ApplicationUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class MapperUtil {
    private MapperUtil() {}

    public static Date stringToDate(String string){
        if (string == null || string.equals("0") || string.equals("00000000") ) {
            return Date.newBuilder()
                    .setYear(0)
                    .setMonth(0)
                    .setDay(0)
                    .build();
        }
        LocalDate localDate = ApplicationUtils.convertStringToLocalDate(string);
        return Date.newBuilder()
                .setYear(localDate.getYear())
                .setMonth(localDate.getMonthValue())
                .setDay(localDate.getDayOfMonth())
                .build();
    }

    public static Currency fromCode(Integer code){
        Currency currency = Currency.forNumber(code);
        return currency != null ? currency :Currency.UNRECOGNIZED;
    }

}
