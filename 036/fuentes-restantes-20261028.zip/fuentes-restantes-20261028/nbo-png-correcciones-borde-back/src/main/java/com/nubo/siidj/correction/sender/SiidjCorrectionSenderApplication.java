package com.nubo.siidj.correction.sender;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"com.nubo.siidj.correction.sender", "com.nuamx.bus.*"})
public class SiidjCorrectionSenderApplication {

	public static void main(String[] args) {
		SpringApplication.run(SiidjCorrectionSenderApplication.class, args);
	}

}
