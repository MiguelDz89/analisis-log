# Proyectos restantes: fuentes originales

Fecha: 28/10/2026. Comparación con los 30 proyectos entregados en los tres lotes anteriores.

Pendientes identificados: 40. Proyectos Java incluidos: 39. Archivos copiados: 4078. Java: 3466.

Una subcarpeta por proyecto, conservando rutas originales. Se incluyen Java de src/main, recursos y configuraciones de producción, pom.xml y auxiliares de compilación/configuración disponibles. Sin src/test, target, binarios, herramientas ni perfiles de rendimiento. Los archivos copiados son idénticos al original; se verificó cada SHA-256.

El proyecto nbo-png-pruebas-automatizacion se lista pero se excluye del código entregado porque corresponde a automatización de pruebas. Los directorios query-scan, query-snapshot y la copia se conservan por separado.

| # | Proyecto | Java | Archivos | Estado |
|---:|---|---:|---:|---|
| 1 | nbo-png-asignacion-srv17-back | 84 | 100 | Incluido |
| 2 | nbo-png-operaciones-custodio-traslados-back | 157 | 173 | Incluido |
| 3 | nbo-png-carga-modelo-riesgos-back | 60 | 76 | Incluido |
| 4 | query-scan-d9f8a67 | 37 | 53 | Incluido |
| 5 | query-snapshot2-fix-packing | 37 | 53 | Incluido |
| 6 | query-scan-76b5d6b | 51 | 67 | Incluido |
| 7 | nbo-png-sincronizacion-participantes-back | 61 | 78 | Incluido |
| 8 | nbo-png-maestroterceros-back | 147 | 163 | Incluido |
| 9 | query-snapshot2-origin-feat-empaqAutomatico | 23 | 39 | Incluido |
| 10 | nbo-png-sincronizacion-cuentas-participantes-back | 70 | 87 | Incluido |
| 11 | nbo-png-consulta-parametros-back | 78 | 94 | Incluido |
| 12 | nbo-png-horarios-query-back | 155 | 171 | Incluido |
| 13 | nbo-png-validacion-horarios-manual-back | 123 | 139 | Incluido |
| 14 | nbo-png-horarios-cmd-back | 108 | 124 | Incluido |
| 15 | nbo-png-cmd-validacion-cierre-back | 86 | 102 | Incluido |
| 16 | nbo-png-adm-garantias-back | 103 | 119 | Incluido |
| 17 | nbo-png-maestro-feriados-back | 47 | 63 | Incluido |
| 18 | nbo-png-sincronizacion-emisores-back | 46 | 62 | Incluido |
| 19 | nbo-png-maestroinstrumentos-back | 177 | 194 | Incluido |
| 20 | nbo-png-api-ingestor-borde-back | 35 | 51 | Incluido |
| 21 | nbo-png-maestroparticipante-back | 160 | 176 | Incluido |
| 22 | nbo-png-operaciones-custodio-estados-back | 142 | 158 | Incluido |
| 23 | nbo-png-pruebas-automatizacion | 0 | 0 | Excluido: automatización de pruebas; sin fuentes Java de producción |
| 24 | nbo-png-reportes-corregidas-borde-back | 55 | 71 | Incluido |
| 25 | nbo-png-reportes-corregidas-cmd-back | 92 | 108 | Incluido |
| 26 | nbo-png-operaciones-consulta-folios-back | 48 | 64 | Incluido |
| 27 | nbo-png-operaciones-custodio-acciones-back - copia | 133 | 149 | Incluido |
| 28 | nbo-png-reportes-descarga-cmd | 46 | 62 | Incluido |
| 29 | nbo-png-operaciones-espec-reglas-back | 81 | 97 | Incluido |
| 30 | nbo-png-operaciones-espec-estados-back | 38 | 54 | Incluido |
| 31 | nbo-png-operaciones-espec-calculos-back | 53 | 69 | Incluido |
| 32 | nbo-png-operaciones-espec-fracciones-back | 148 | 164 | Incluido |
| 33 | nbo-png-operaciones-espec-back | 257 | 273 | Incluido |
| 34 | nbo-png-mantenedor-modulos-cmd-back | 86 | 102 | Incluido |
| 35 | nbo-png-mantenedor-modulos-query-back | 66 | 82 | Incluido |
| 36 | nbo-png-correcciones-transformador-siidj-back | 102 | 118 | Incluido |
| 37 | bin-ti-lib | 16 | 18 | Incluido |
| 38 | nbo-png-correcciones-borde-back | 15 | 31 | Incluido |
| 39 | nbo-png-operaciones-back | 182 | 198 | Incluido |
| 40 | nbo-png-persistencia-asignacion-vericlear-back | 61 | 76 | Incluido |
