/*
 * Copyright (c) NUAM EXCHANGE. All rights reserved.
 *
 * All  rights to this product are owned  by NUAM EXCHANGE  and  may  only  be
 * used under the terms of its associated license document. You may NOT  copy,
 * modify,  sublicense,  or  distribute  this  source  file or portions of  it
 * unless previously authorized in  writing by  NUAM EXCHANGE. In  any  event,
 * this notice and the above copyright must always be included verbatim   with
 * this file.
 */
package com.nuamx.bus.utils.testing;

import java.util.ArrayList;
import java.util.List;

import com.google.protobuf.Message;

import io.confluent.kafka.schemaregistry.SchemaProvider;
import io.confluent.kafka.schemaregistry.client.SchemaRegistryClient;
import io.confluent.kafka.schemaregistry.testutil.MockSchemaRegistry;
import io.confluent.kafka.serializers.protobuf.KafkaProtobufDeserializer;
import io.confluent.kafka.serializers.protobuf.KafkaProtobufSerializer;

/**
 * Clase de utilidades para pruebas de Kafka con Avro. 
 * Encapsula los tradicionales {@link KafkaAvroSerializer} y {@link KafkaAvroDeserializer}
 * colocando un {@link MockSchemaRegistry} en reemplazo de uno real. 
 * Works like a charm!
 * 
 * @author Jonathan Makuc - jmakuc@bithaus.cl - Dic 2024
 */
public class TestKafkaProtobufSerdes   {

    private static List<SchemaProvider> schemaProviders = 
            new ArrayList<SchemaProvider>() {{
                add(new io.confluent.kafka.schemaregistry.protobuf.ProtobufSchemaProvider());
            }};
    
    private static final SchemaRegistryClient REGISTRY = MockSchemaRegistry.getClientForScope("PROTOBUF", schemaProviders);
    

    public static SchemaRegistryClient getRegistry() {
        return REGISTRY;
    }

    public static class TestKafkaProtobufSerializer<T extends Message> extends KafkaProtobufSerializer<T> {
        public TestKafkaProtobufSerializer() {
            super(REGISTRY);
        }
    }
 

    public static class TestKafkaProtobufDeserializer<T extends Message> extends KafkaProtobufDeserializer<T> {
        public TestKafkaProtobufDeserializer() {
            super(REGISTRY);
        }
    }    
}
