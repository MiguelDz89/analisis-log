/*
 * Copyright (c) NUAM EXCHANGE. All rights reserved.
 *
 * All  rights to this product are owned  by NUAM EXCHANGE  and  may  only  be
 * used under the terms of its associated license document. You may NOT  copy,
 * modify,  sublicense,  or  distribute  this  source  file or portions of  it
 * unless previously authorized in  writing by  NUAM EXCHANGE. In  any  event,
 * this notice and the above copyright must always be included verbatim   with
 * this file.
 */

package com.nuamx.bus.utils.time;

import java.util.concurrent.atomic.AtomicLong;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Tarea Programada utilizada por {@link TradingTimer}.
 *
 * @version 1.0
 * @since 1.0
 * @see TradingTimer
 * @author jmakuc
 * @author Javier Sepúlveda
 */

@Data
@NoArgsConstructor
public class TradingTimerEntry implements Runnable, Comparable<TradingTimerEntry> {

  // Atributos //

  // Serializador de tareas.
  private static final AtomicLong serializer = new AtomicLong(0);
  // Serial de la tarea.
  public final long serial = serializer.incrementAndGet();

  // Estados de la tarea.

  // Tarea sin ejecutar.
  public static final int VIRGIN = 0;
  // Tarea programada.
  public static final int SCHEDULED = 1;
  // Tarea ejecutada.
  public static final int EXECUTED = 2;
  // Tarea cancelada.
  public static final int CANCELLED = 3;

  // Estado de la tarea.
  private int state = VIRGIN;
  // Tiempo de ejecución de la tarea.
  private long nextExecutionTime = 0;
  // Tiempo de ejecución de la tarea.
  private long lastExecutionTime = 0;
  // Periodo de ejecución de la tarea.
  private long period = 0;
  // Tarea a ejecutar.
  private Runnable task = null;

  // Constructores Custom //

  /**
   * Constructor de la tarea programada.
   *
   * @param task              Tarea a ejecutar.
   * @param nextExecutionTime Tiempo de ejecución de la siguiente tarea.
   */

  public TradingTimerEntry(Runnable task, long nextExecutionTime) {
    this.task = task;
    this.nextExecutionTime = nextExecutionTime;
  }

  /**
   * Constructor solo con tarea a ejecutar.
   *
   * @param task tarea a ejecutar
   */
  public TradingTimerEntry(Runnable task) {

    this.task = task;
  }

  // Getter & Setters Customs //

  /**
   * Retorna el estado de la tarea como string.
   *
   * @return estado de la tarea como string.
   */
  public String getStateString() {

    switch (state) {

      case CANCELLED:
        return "CANCELLED";
      case EXECUTED:
        return "EXECUTED";
      case SCHEDULED:
        return "SCHEDULED";
      case VIRGIN:
        return "VIRGIN";
    }

    return "UNKONWN";
  }

  /**
   * Actualiza el estado de la tarea
   *
   * @param newScheduleTime nuevo timestamp de gatillamiento
   * @param newPeriod       nuevo periodo de gatillamiento
   * @param newState        nuevo estado de la tarea
   */
  synchronized void updateState(long newScheduleTime, long newPeriod, int newState) {

    this.nextExecutionTime = newScheduleTime;
    this.period = newPeriod;
    this.state = newState;
  }

  // Métodos //

  /**
   * Ejecuta la tarea programada.
   *
   */

  public void run() {

    // Ejecuta la tarea.
    task.run();
  }

  /**
   * Cancela la ejecución de la tarea. No la remueve de la cola de espera,
   * solo la marca como cancelada. Cuando el TradingTimer decida que es
   * tiempo de ejecutarla la omitirá al estar cancelada.
   *
   * @return TRUE si el estado al cancel era SCHEDULED.
   *
   */

  public synchronized boolean cancel() {

    // Manejo de excepciones
    boolean result = (state == SCHEDULED);
    state = CANCELLED;
    return result;
  }

  /**
   * Comparacion para ordenamiento en base al tiempo de gatillamiento.
   *
   * @param other tarea a comparar
   * @return -1 si el tiempo de ejecucion de esta tarea es mas cercano que
   *         la otra.
   */
  public int compareTo(TradingTimerEntry other) {

    if (this.getNextExecutionTime() > other.getNextExecutionTime())
      return 1;
    else if (this.getNextExecutionTime() < other.getNextExecutionTime())
      return -1;

    if (this.serial < other.serial)
      return -1;
    else if (this.serial > other.serial)
      return 1;

    return 0;
  }

}
