/*
 * Copyright (c) NUAM EXCHANGE. All rights reserved.
 *
 * All  rights to this product are owned  by NUAM EXCHANGE  and  may  only  be
 * used under the terms of its associated license document. You may NOT  copy,
 * modify,  sublicense,  or  distribute  this  source  file or portions of  it
 * unless previously authorized in  writing by  NUAM EXCHANGE. In  any  event,
 * this notice and the above copyright must always be included verbatim   with
 * this file.
 */
package com.nuamx.bus;

import java.time.Duration;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Future;
import java.util.concurrent.Semaphore;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerGroupMetadata;
import org.apache.kafka.clients.consumer.ConsumerRebalanceListener;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.TopicPartition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.KafkaTemplate;

import com.google.protobuf.Message;
import com.nuamx.bus.message.simple.SimpleStringMessage;
import com.nuamx.bus.utils.NuamMessageUtils;

import jakarta.annotation.PostConstruct;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

/**
 * Aplicación de prueba Hola Mundo
 * 
 * Antes de ejecutar el programa se deben realizar los siguientes pasos:
 * 
 * 1. Tener un cluster de Kafka corriendo. Podría ser local vía docker o en un servidor remoto.
 * 
 * 2. Crear el tópico: 
 *    kafka-topics --create --topic el-topico --bootstrap-server localhost:9092 --partitions 2 --replication-factor 1
 *    
 *    Para borrar: kafka-topics --delete --topic el-topico --bootstrap-server localhost:9092 
 * DISCLAIMER
 * Actualmente la conexión está configurada para auto-registrar los schemas. 
 * Esto puede (queremos) cambiar en el futuro cercano.
 *      
 * @author Jonathan Makuc - jmakuc@bithaus.cl - Dic 2024
 */
// @SpringBootApplication(scanBasePackages = {"com.nuamx.bus.kafka"})
@SpringBootApplication
@Slf4j
public class NuamSampleBusApp {

    static {
        // Configuración de propiedades del sistema
        
        System.setProperty("spring.kafka.nuam.bootstrap-servers", "localhost:9092"); 
        System.setProperty("spring.kafka.nuam.properties.schema.registry.url", "http://localhost:8081"); 
        System.setProperty("spring.kafka.nuam.properties.allow.auto.create.topics", "false"); 
        // Producer
        System.setProperty("spring.kafka.nuam.producer.properties.key.serializer", "org.apache.kafka.common.serialization.StringSerializer"); 
        System.setProperty("spring.kafka.nuam.producer.properties.value.serializer", "io.confluent.kafka.serializers.protobuf.KafkaProtobufSerializer"); 
        System.setProperty("spring.kafka.nuam.producer.properties.interceptor.classes", "com.nuamx.bus.kafka.NuamProducerInterceptor"); 
        System.setProperty("spring.kafka.nuam.producer.properties.value.subject.name.strategy", "io.confluent.kafka.serializers.subject.RecordNameStrategy"); 
        System.setProperty("spring.kafka.nuam.producer.properties.reference.subject.name.strategy", "io.confluent.kafka.serializers.subject.QualifiedReferenceSubjectNameStrategy"); 
        System.setProperty("spring.kafka.nuam.producer.properties.auto.register.schemas", "true"); 
        // Consumer
        System.setProperty("spring.kafka.nuam.consumer.properties.use.latest.version", "true"); 
        System.setProperty("spring.kafka.nuam.consumer.properties.auto.offset.reset", "earliest"); 
        System.setProperty("spring.kafka.nuam.consumer.properties.enable.auto.commit", "false"); 
        System.setProperty("spring.kafka.nuam.consumer.properties.key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer"); 
        System.setProperty("spring.kafka.nuam.consumer.properties.value.deserializer", "io.confluent.kafka.serializers.protobuf.KafkaProtobufDeserializer"); 
        System.setProperty("spring.kafka.nuam.consumer.properties.value.subject.name.strategy", "io.confluent.kafka.serializers.subject.RecordNameStrategy"); 
        System.setProperty("spring.kafka.nuam.consumer.properties.reference.subject.name.strategy", "io.confluent.kafka.serializers.subject.QualifiedReferenceSubjectNameStrategy"); 
        System.setProperty("spring.kafka.nuam.consumer.properties.derive.type", "true"); 
        System.setProperty("spring.kafka.nuam.consumer.properties.interceptor.classes", "com.nuamx.bus.kafka.NuamConsumerInterceptor"); 
    }

    public static void main(String[] args) {
        // para que cada ejecución sea un cliente diferente y no tengamos que esperar rebalanceo
        // Si queremos replicar el funcionamiento normal, quitar el currentTimeMillis.
        // System.setProperty("spring.kafka.nuam.consumer.properties.group.id", "nuam-test" + System.currentTimeMillis()); 
        System.setProperty("spring.kafka.nuam.consumer.properties.group.id", "nuam-test"); 

        SpringApplication.run(NuamSampleBusApp.class, args);        
    }

    @Autowired
    private KafkaTemplate<String, Message> kafkaTemplate;

    @Autowired
    private ConsumerFactory<String, Message> consumerFactory;

    @SneakyThrows
    @PostConstruct
    public void init() {

        log.info("Iniciando");

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            log.info("Apagando la aplicación...");
            kafkaTemplate.destroy();    
        }));
        
        Producer<String, Message> producer = kafkaTemplate.getProducerFactory().createProducer();

        // Uso del mensaje generado. Una vez creado, no se puede modificar. 
        SimpleStringMessage message = com.nuamx.bus.message.simple.SimpleStringMessage.newBuilder()            
            .setData("Hola Mundo")            
            .build();

        // En un caso de negocio real, esto debería ser el timestamp del evento original
        long timestamp = System.currentTimeMillis();
    
        // Usar el utilitario para que se setee la llave y el timestamp a partir de los atributos del mensaje
        ProducerRecord<String, Message> producerRecord = NuamMessageUtils.createProducerRecord("el-topico", "la-llave", timestamp, message);
        Future<RecordMetadata> future = producer.send(producerRecord); 

        // Forzar el commit al broker
        producer.flush();

        RecordMetadata metadata = future.get();

        log.info("Mensaje enviado: topic={} partition={} offset={} timestamp={}", 
            metadata.topic(), metadata.partition(), metadata.offset(), metadata.timestamp());


            
        Consumer<String, Message> consumer = this.consumerFactory.createConsumer(); 
        consumer.subscribe(List.of("el-topico"), new ConsumerRebalanceListener() {
            @Override
            public void onPartitionsRevoked(Collection<TopicPartition> partitions) {
                log.info("Revoked partitions: {}", partitions);
            }

            @Override
            public void onPartitionsAssigned(Collection<TopicPartition> partitions) {
                log.info("Assigned partitions: {}", partitions);
            }
        });

        ConsumerGroupMetadata cgm = consumer.groupMetadata();

        log.info("Consumer group: {}", cgm.groupId());

        ConsumerRecords<String, Message> polledRecords = consumer.poll(Duration.ofSeconds(4));
   
        for(ConsumerRecord<String, Message> record : polledRecords) {
            log.info("Mensaje recibido: topic={} partition={} tipo={} offset={} key={} value={}", 
                record.topic(), record.partition(), record.value().getClass(), record.offset(), record.key(), record.value());
        }

        // controlar el commit al broker es bueno.
        consumer.commitSync();

        log.info("Fin de la aplicación");
    }
}
