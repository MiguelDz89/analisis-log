/*
 * Copyright (c) NUAM EXCHANGE. All rights reserved.
 *
 * All  rights to this product are owned  by NUAM EXCHANGE  and  may  only  be
 * used under the terms of its associated license document. You may NOT  copy,
 * modify,  sublicense,  or  distribute  this  source  file or portions of  it
 * unless previously authorized in  writing by  NUAM EXCHANGE. In  any  event,
 * this notice and the above copyright must always be included verbatim   with
 * this file.
 */
package com.nuamx.bus.utils;

import java.time.LocalDate;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.ProducerRecord;

import com.google.protobuf.Descriptors.FieldDescriptor;
import com.google.protobuf.Message;
import com.google.protobuf.util.Timestamps;
import com.nuamx.bus.message.NuamMessage;
import com.nuamx.bus.message.NuamMessageInterface;
import com.nuamx.bus.message.common.Country;
import com.nuamx.bus.message.common.Metadata;
import com.nuamx.bus.message.common.SourceSystem;

import lombok.extern.slf4j.Slf4j;

/**
 * Utilitarios para el manejo de mensajes
 * 
 * @author Jonathan Makuc - jmakuc@bithaus.cl - Dic 2024
 */
@Slf4j
public class NuamMessageUtils {

    /**
     * Crea un objeto Metadata a partir de un ConsumerRecord
     * 
     * @param record
     * @return
     */
    public static com.nuamx.bus.message.common.Metadata enhanceMetadataWith(ConsumerRecord<?, Message> record) {

        if (record == null || record.value() == null) {
            return null;
        }

        if(!record.value().getClass().isAssignableFrom(NuamMessageInterface.class)) {
            log.warn("Recibido mensaje que no implementa NuamMessageInterface, descartando: " + record.value().getClass());
            return null;
        }

        NuamMessageInterface message = (NuamMessageInterface) record.value();

        com.nuamx.bus.message.common.Metadata metadata = message.getBase().getMetadata();

        return com.nuamx.bus.message.common.Metadata.newBuilder(metadata)
                .setPartition(record.partition())
                .setOffset(record.offset())
                .build();
        
    }

    /**
     * Crea un ProducerRecord a partir de un mensaje NuamMessageInterface.
     * @param topic Tópico en el bus
     * @param key Llave de particionamiento
     * @param timestampMillis Timestamp en milisegundos a setear en el tópico
     * @param message Mensaje a enviar al bus
     * @return ProducerRecord con el mensaje y metadatos
     */
    public static ProducerRecord<String, Message> createProducerRecord(String topic, String key, Long timestampMillis, NuamMessageInterface message) {

        if(topic == null || topic.isEmpty()) {
            throw new RuntimeException("Tópico de salida es requerido"); 
        }

        if(timestampMillis == null) {
            timestampMillis = System.currentTimeMillis();
        }

        // tendremos particionado propio? Por ahora nop. 
        Integer partition = null;

        if(!NuamMessageInterface.class.isAssignableFrom(message.getClass())) {
            throw new RuntimeException("Solo se pueden enviar mensajes que implementen NuamMessageInterface. Revisa tu especificación Protobuf y el generador de código.");            
        }

        FieldDescriptor baseField = message.getDescriptorForType().findFieldByName("base");
        Message baseMessage = (Message) message.getField(baseField);

        Message updatedBase = baseMessage.toBuilder()
            .setField(baseMessage.getDescriptorForType().findFieldByName("metadata"),
            com.nuamx.bus.message.common.Metadata.newBuilder()
                .setTopic(topic)
                .setKey(key)
                .setTimestamp(timestampMillis)
                .setBusTime(Timestamps.fromMillis(timestampMillis))
                .build())
            .build();

        Message enriched = message.toBuilder().setField(baseField, updatedBase).build();


        return new ProducerRecord<>(topic, partition, timestampMillis, key, enriched);

    }


    public static ProducerRecord<String, Message> createProducerRecord(String topic, NuamMessageInterface message) {

        if(message.getBase() != null && message.getBase().getMetadata() != null) {

            if(topic == null || topic.isEmpty()) {

                if(message.getBase().getMetadata().getTopic() == null || message.getBase().getMetadata().getTopic().isEmpty()) {
                    throw new RuntimeException("Tópico de salida es requerido"); 
                } else {
                    topic = message.getBase().getMetadata().getTopic();
                }                
            }

            if(message.getBase().getMetadata().getKey() == null || message.getBase().getMetadata().getKey().isEmpty()) {
                throw new RuntimeException("Llave de particionamiento es requerida");        
            }

            if(!message.getBase().getMetadata().hasTimestamp()) {
                throw new RuntimeException("Timestamp es requerido");
            }
    
        }

        Long timestamp = message.getBase().getMetadata().getTimestamp();
        String key = message.getBase().getMetadata().getKey();

        // tendremos particionado propio? Por ahora nop. 
        Integer partition = null;

        if(!NuamMessageInterface.class.isAssignableFrom(message.getClass())) {
            throw new RuntimeException("Solo se pueden enviar mensajes que implementen NuamMessageInterface. Revisa tu especificación Protobuf y el generador de código.");            
        }

        FieldDescriptor baseField = message.getDescriptorForType().findFieldByName("base");
        NuamMessage baseMessage = (NuamMessage) message.getField(baseField);

        Metadata metadata = baseMessage.getMetadata().toBuilder()
            .setTopic(topic)
            .setBusTime(Timestamps.fromMillis(timestamp))
            .build();

        baseMessage.toBuilder().setMetadata(metadata);

        Message enriched = message.toBuilder().setField(baseField, baseMessage).build();


        return new ProducerRecord<>(topic, partition, timestamp, key, enriched);

    }


    public static String generateUniqueTradeId(Country country, SourceSystem sourceSystem, LocalDate date, String tradeId) {
        return country + "-" + sourceSystem + "-" + date + "-" + tradeId;
    }    

    /**
     * Crea un ProducerRecord a partir de un mensaje NuamMessageInterface cuyos metadatos 
     * han sido setados previamente. Si no hay topico, llave o timestamp; se lanzará una
     * RuntimeException.
     * @param message Mensaje a enviar al bus
     * @return ProducerRecord con el mensaje y metadatos
     * @throws RuntimeException si el mensaje no tiene metadatos o si no se han seteado
     */
    // public static ProducerRecord<String, Message> createProducerRecord(NuamMessageInterface message) {

    //     if(message.getBase() == null)
    //         throw new RuntimeException("Mensaje no tiene campos base. Todos los producer records deben ser generados usando NuamMessageUtils.");

    //     if(message.getBase().getMetadata() == null)
    //         throw new RuntimeException("Mensaje no tiene metadatos. Todos los producer records deben ser generados usando NuamMessageUtils.");

    //     com.nuamx.bus.message.common.Metadata metadata = message.getBase().getMetadata();

    //     if(metadata.getTopic() == null)
    //         throw new RuntimeException("Tópico de salida es requerido"); 

    //     if(metadata.getKey() == null)
    //         throw new RuntimeException("Llave de particionamiento es requerida");        

    //     return createProducerRecord(message.getBase().getMetadata().getTopic(), message.getBase().getMetadata().getKey(), message.getBase().getMetadata().getTimestamp(), message);
    // }
}
