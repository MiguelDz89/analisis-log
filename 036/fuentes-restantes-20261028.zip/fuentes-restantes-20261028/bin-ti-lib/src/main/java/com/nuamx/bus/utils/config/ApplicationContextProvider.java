package com.nuamx.bus.utils.config;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.core.env.ConfigurableEnvironment;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class ApplicationContextProvider implements ApplicationContextAware {

    private static GenericApplicationContext context;

    @SneakyThrows
    @Override
    public void setApplicationContext(ApplicationContext applicationContext) {

        if(applicationContext == null)
            throw new RuntimeException("ApplicationContextProvider.setApplicationContext: ApplicationContext is null");

        if(context != null) {
            
            log.warn("ApplicationContextProvider.setApplicationContext: ApplicationContextProvider already set, ignoring new context");
            return;
        }
            

        if(applicationContext instanceof GenericApplicationContext)
            context = (GenericApplicationContext) applicationContext;
        else 
            context = new GenericApplicationContext(applicationContext);
    }

    public static GenericApplicationContext getGenericApplicationContext() {
        return context;
    }

    public static void setGenericApplicationContext(ApplicationContext applicationContext) {
        log.info("ApplicationContextProvider.setGenericApplicationContext: Setting ApplicationContextProvider context: " + applicationContext);

        if(applicationContext instanceof GenericApplicationContext)
            context = (GenericApplicationContext) applicationContext;
        else 
            context = new GenericApplicationContext(applicationContext);
    }

    public static ConfigurableEnvironment getEnvironment() {
        return (ConfigurableEnvironment) context.getEnvironment();
    }    
}