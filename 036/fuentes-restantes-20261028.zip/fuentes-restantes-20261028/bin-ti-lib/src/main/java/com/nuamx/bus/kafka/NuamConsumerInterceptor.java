/*
 * Copyright (c) NUAM EXCHANGE. All rights reserved.
 *
 * All  rights to this product are owned  by NUAM EXCHANGE  and  may  only  be
 * used under the terms of its associated license document. You may NOT  copy,
 * modify,  sublicense,  or  distribute  this  source  file or portions of  it
 * unless previously authorized in  writing by  NUAM EXCHANGE. In  any  event,
 * this notice and the above copyright must always be included verbatim   with
 * this file.
 */
package com.nuamx.bus.kafka;

import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerInterceptor;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.common.TopicPartition;

import com.google.protobuf.Message;

import lombok.extern.slf4j.Slf4j;

/**
 * Interceptor en la recepción de mensajes desde el tópico
 * 
 * @author Jonathan Makuc - jmakuc@bithaus.cl - Dic 2024
 */
@Slf4j
public class NuamConsumerInterceptor implements ConsumerInterceptor<String, Message> {

  @Override
  public void configure(Map<String, ?> configs) {
    
    log.info("Init OK");
  }

  @Override
  public ConsumerRecords<String, Message> onConsume(ConsumerRecords<String, Message> records) {

    return records;
  }

  @Override
  public void onCommit(Map<TopicPartition, OffsetAndMetadata> offsets) {
    
  }

  @Override
  public void close() {
    
  }

}