package com.nuamx.bus.utils.config;

/**
 * Interfaz que permite identificar las clases que son configuraciones 
 * aun cuando no tengan @Configuration anotado.
 * Utilizado para la carga de configuraciones dinamicas.
 */
public interface ConfigurationInterface {

}
