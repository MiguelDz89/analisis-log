package com.nuamx.bus.utils.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.PropertiesPropertySource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ConfigurationUtils {

    @SuppressWarnings("unchecked")
    public static <T extends ConfigurationInterface> T createConfigurationBeanFromProperties(String configuracionClassname, String propertiesFilename) 
        throws ClassNotFoundException, FileNotFoundException, IOException {

        Class<T> configClass = (Class<T>) Class.forName(configuracionClassname); 

        return createConfigurationBeanFromProperties(configClass, propertiesFilename);

    }

    public static <T extends ConfigurationInterface> T createConfigurationBeanFromProperties(Class<T> configClass, String propertiesFilename) 
        throws ClassNotFoundException, FileNotFoundException, IOException {
        

        GenericApplicationContext applicationContext = ApplicationContextProvider.getGenericApplicationContext();
        ConfigurableEnvironment configurableEnvironment = ApplicationContextProvider.getEnvironment();

        File propertiesFile = new File(propertiesFilename);

        if(!propertiesFile.exists()){
            throw new FileNotFoundException("Properties file not found: " + propertiesFilename);
        }

        Properties properties = new Properties();
        properties.load(new FileInputStream(propertiesFile));

        String propertySourceName = "tmp-" + System.currentTimeMillis();

        // Add properties to the environment
        PropertiesPropertySource propertySource = new PropertiesPropertySource(propertySourceName, properties);
        configurableEnvironment.getPropertySources().addFirst(propertySource);            

        // Config class registration
        DefaultListableBeanFactory beanFactory = (DefaultListableBeanFactory) applicationContext.getAutowireCapableBeanFactory();
        BeanDefinition beanDefinition = BeanDefinitionBuilder.genericBeanDefinition(configClass).getBeanDefinition();
        beanFactory.registerBeanDefinition(configClass.getName(), beanDefinition);

        // New Instance with properties loaded into
        T config = applicationContext.getBean(configClass);    

        configurableEnvironment.getPropertySources().remove(propertySourceName);
        beanFactory.removeBeanDefinition(configClass.getName());

        return config;

    }

    
}
