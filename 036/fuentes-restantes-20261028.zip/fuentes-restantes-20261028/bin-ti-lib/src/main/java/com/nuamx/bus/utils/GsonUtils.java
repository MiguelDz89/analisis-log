/*
 * Copyright (c) NUAM EXCHANGE. All rights reserved.
 *
 * All  rights to this product are owned  by NUAM EXCHANGE  and  may  only  be
 * used under the terms of its associated license document. You may NOT  copy,
 * modify,  sublicense,  or  distribute  this  source  file or portions of  it
 * unless previously authorized in  writing by  NUAM EXCHANGE. In  any  event,
 * this notice and the above copyright must always be included verbatim   with
 * this file.
 */
package com.nuamx.bus.utils;

import java.io.IOException;
import java.time.Instant;
import java.time.LocalDate;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

/**
 * Utilitario para centralizar la configuración de Gson.
 * Resuelve:
 * - Los problemas de acceso en Java 17 a LocalDate y Instant.
 * 
 * 
 * @author Jonathan Makuc - jmakuc@bithaus.cl - Dic 2024
 */
public class GsonUtils {

    private static GsonBuilder GSON_BUILDER = new GsonBuilder()
        .serializeNulls()
        .registerTypeAdapter(LocalDate.class, new Gson_LocalDateTypeAdapter())  
        .registerTypeAdapter(Instant.class, new Gson_InstantTypeAdapter());

    private static Gson GSON = GSON_BUILDER.create();

    private static Gson GSON_PRETTY_PRINT = GSON_BUILDER.setPrettyPrinting().create();


    /**
     * Obtiene la instancia singleton de Gson.
     * @return Gson.
     */
    public static Gson getGson() {
        return GSON;
    }

    /**
     * Obtiene la instancia singleton de Gson con pretty print.
     * @return Gson con pretty print.
     */
    public static Gson getGsonPrettyPrint() {
        return GSON_PRETTY_PRINT;
    }


    /**
     * TypeAdapter que ayuda a Gson a acceder a los campos de Instant.
     */
    public static class Gson_InstantTypeAdapter extends TypeAdapter < Instant >
    {
        @Override
        public void write ( JsonWriter jsonWriter , Instant instant ) throws IOException
        {
            jsonWriter.value( instant.toString() );  // Writes in standard ISO 8601 format.
        }

        @Override
        public Instant read ( JsonReader jsonReader ) throws IOException
        {
            return Instant.parse( jsonReader.nextString() );   // Parses standard ISO 8601 format.
        }
    }    
    

    /**
     * TypeAdapter que ayuda a Gson a acceder a los campos de LocalDate.
     */
    public static class Gson_LocalDateTypeAdapter extends TypeAdapter<LocalDate> {
    @Override
    public void write(JsonWriter jsonWriter, LocalDate localDate) throws IOException {
        jsonWriter.value(localDate.toString());  // Writes in standard ISO 8601 format.
    }

    @Override
    public LocalDate read(JsonReader jsonReader) throws IOException {
        return LocalDate.parse(jsonReader.nextString());  // Parses standard ISO 8601 format.
    }
}    
}
