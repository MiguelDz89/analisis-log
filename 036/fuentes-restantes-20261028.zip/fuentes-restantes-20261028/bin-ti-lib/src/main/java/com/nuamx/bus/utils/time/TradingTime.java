/*
 * Copyright (c) NUAM EXCHANGE. All rights reserved.
 *
 * All  rights to this product are owned  by NUAM EXCHANGE  and  may  only  be
 * used under the terms of its associated license document. You may NOT  copy,
 * modify,  sublicense,  or  distribute  this  source  file or portions of  it
 * unless previously authorized in  writing by  NUAM EXCHANGE. In  any  event,
 * this notice and the above copyright must always be included verbatim   with
 * this file.
 */


package com.nuamx.bus.utils.time;

import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import lombok.extern.slf4j.Slf4j;

/**
 * Clase Utilitaria de hora.
 * Permite la centralizacion de la hora en nanosegundos para simulacion de
 * cambios
 * horarios en pruebas de sistema.
 * Al setearse un nuevo "tiempo actual", el objeto guarda el nanotime del
 * seteo y lo utiliza para calcular el delta que ha ocurrido desde el seteo y
 * una consulta, entregando el tiempo simulado.
 * Si no se setea tiempo forzado, obtiene la hora del sistema operativo.
 *
 * @version 1.0
 * @since 1.0
 * @author jmakuc
 * @author Javier Sepúlveda
 */

@Slf4j
public class TradingTime {

  // Atributos //

  // Tiempo forzado.
  private static long startTime = 0;
  // Nanosegundos de cuando fue seteado el tiempo forzado.
  private static long startTimeSetTime = 0;
  // Ultimo timestamp en nanosegundos entregado
  private static long lastNanoTime = 0;
  // Update lock para evitar problemas de concurrencia.
  private static final Object updateLock = new Object();
  // Hashset de callbacks para ser llamados en cada actualizacion de tiempo.
  private static HashSet<Runnable> onTimeUpdateCallbacks = new HashSet<Runnable>();

  // Getter & Setter Custom //

  /**
   * Setea el tiempo actual en nanosegundos
   *
   * @param newTime  tiempo actual
   * @param timeUnit unidad de tiempo de la nueva hora del sistema
   * @return tiempo actual en nanosegundos
   */
  public static synchronized long setTime(long newTime, TimeUnit timeUnit) {

    synchronized (updateLock) {

      startTime = TimeUnit.NANOSECONDS.convert(newTime, timeUnit);

      startTimeSetTime = System.nanoTime();

      lastNanoTime = 0;

      Iterator<Runnable> callbacks = onTimeUpdateCallbacks.iterator();

      while (callbacks.hasNext())
        callbacks.next().run();

      log.info("Trading Time updated: " + getDate());

      return startTime;
    }
  }

  /**
   * Obtiene el tiempo actual en nanosegundos. Si no se ha seteado tiempo
   * forzado, obtiene el tiempo del sistema operativo.
   *
   * @return tiempo actual en nanosegundos
   */
  public static long getTimeNanos() {

    if (startTime == 0) {

      startTime = System.currentTimeMillis() * 1000000l;
      startTimeSetTime = System.nanoTime();
    }

    long delta = System.nanoTime() - startTimeSetTime;

    long returnValue = startTime + delta;

    synchronized (updateLock) {

      if (returnValue <= lastNanoTime) {

        returnValue = lastNanoTime + 1;
      }

      lastNanoTime = returnValue;
    }

    return returnValue;
  }

  /**
   * Obtiene el tiempo actual en milisegundos. Si no se ha seteado tiempo
   * forzado, obtiene el tiempo del sistema opertivo.
   *
   * @return tiempo actual en milisegundos
   */
  public static long getTimeMilis() {

    return getTimeNanos() / 1000000l;
  }

  /**
   * Obtiene el tiempo actual en milisegundos. Si no se ha seteado tiempo
   * forzado, obtiene el tiempo del sistema opertivo.
   *
   * @return tiempo actual en milisegundos
   */
  public static Date getDate() {

    return new Date(getTimeMilis());
  }

  /**
   * Retorna un objeto Date a partir de un timestamp en nanosegundos
   *
   * @param nanoTime timestamp en nanosegundos
   * @return Nuevo objeto Date
   */
  public static Date getDate(long nanoTime) {

    return new Date(TimeUnit.NANOSECONDS.toMillis(nanoTime));
  }

  /**
   * Obtiene el tiempo actual en nanosegundos considerando un delta de tiempo.
   * Si no se ha seteado tiempo
   * forzado, obtiene el tiempo del sistema operativo.
   *
   * @param delta         delta de tiempo
   * @param deltaTimeUnit unidad de tiempo del delta
   * @return timestamp en nano segundos de ahora + delta.
   */
  public static long getTimeNano(long delta, TimeUnit deltaTimeUnit) {

    long deltaNanos = deltaTimeUnit.toNanos(delta);
    return TradingTime.getTimeNanos() + deltaNanos;
  }

  // Métodos //

  /**
   * Agrega un objeto 'callback' que es invocado cuando se actualiza la hora
   * forzadamente
   *
   * @param runnable
   */
  public static void addOnTimeUpdateCallback(Runnable runnable) {

    onTimeUpdateCallbacks.add(runnable);
  }

}
