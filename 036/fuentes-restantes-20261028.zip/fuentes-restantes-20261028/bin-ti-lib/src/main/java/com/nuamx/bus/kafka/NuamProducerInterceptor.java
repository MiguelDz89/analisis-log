/*
 * Copyright (c) NUAM EXCHANGE. All rights reserved.
 *
 * All  rights to this product are owned  by NUAM EXCHANGE  and  may  only  be
 * used under the terms of its associated license document. You may NOT  copy,
 * modify,  sublicense,  or  distribute  this  source  file or portions of  it
 * unless previously authorized in  writing by  NUAM EXCHANGE. In  any  event,
 * this notice and the above copyright must always be included verbatim   with
 * this file.
 */
package com.nuamx.bus.kafka;

import java.time.Instant;
import java.util.Map;

import org.apache.kafka.clients.producer.ProducerInterceptor;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

import com.google.protobuf.Descriptors.FieldDescriptor;
import com.google.protobuf.Descriptors.Descriptor;
import com.google.protobuf.Message;
import com.google.protobuf.Timestamp;
import com.google.protobuf.util.Timestamps;
import com.nuamx.bus.message.NuamMessageInterface;
import com.nuamx.bus.message.common.Metadata;

import lombok.extern.slf4j.Slf4j;

/**
 * Interceptor en la producción de mensajes hacia el tópico
 * 
 * @author Jonathan Makuc - jmakuc@bithaus.cl - Dic 2024
 */
@Slf4j
public class NuamProducerInterceptor implements ProducerInterceptor<String, Message> {

  // Constantes para los nombres de campos
  private static final String METADATA_FIELD_NAME = "metadata";
  private static final String BUS_TIME_FIELD_NAME = "busTime";

  @Override
  public void configure(Map<String, ?> configs) {
    log.info("Init OK");     
  }

  /**
   * Actualiza los metadatos del mensaje antes de ser enviado
   */
  @Override
  public ProducerRecord<String, Message> onSend(ProducerRecord<String, Message> record) {
    
    if(record.value() == null)
      return record;
    
    if(!NuamMessageInterface.class.isAssignableFrom(record.value().getClass())) {
      throw new RuntimeException("Mensajes que pasan por el bus DEBEN imeplementar NuamMessageInterface. Revisa tu especificación Protobuf y el generador de código.");
    }
    
    NuamMessageInterface message = (NuamMessageInterface) record.value();

    if(message.getBase() == null)
      throw new RuntimeException("Mensaje no tiene campos base. Todos los producer records deben ser generados usando NuamMessageUtils.");

    Metadata metadata = message.getBase().getMetadata();

    if(metadata == null)
      throw new RuntimeException("Mensaje no tiene metadatos. Todos los producer records deben ser generados usando NuamMessageUtils.");

    if(metadata.getBusTime() == null || metadata.getTopic() == null || metadata.getKey() == null)
      throw new RuntimeException("Mensaje no tiene metadatos completos. Todos los producer records deben ser generados usando NuamMessageUtils.");

    return record;
    
  }

  @Override
  public void onAcknowledgement(RecordMetadata metadata, Exception exception) {
    // Sería interesante hacer algo aquí?
  }

  @Override
  public void close() {
    // Bye bye!
  }

}
