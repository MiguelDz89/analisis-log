/*
 * Copyright (c) NUAM EXCHANGE. All rights reserved.
 *
 * All  rights to this product are owned  by NUAM EXCHANGE  and  may  only  be
 * used under the terms of its associated license document. You may NOT  copy,
 * modify,  sublicense,  or  distribute  this  source  file or portions of  it
 * unless previously authorized in  writing by  NUAM EXCHANGE. In  any  event,
 * this notice and the above copyright must always be included verbatim   with
 * this file.
 */
package com.nuamx.bus.utils.testing;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Lazy;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaAdmin;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

import com.google.protobuf.Message;
import com.nuamx.bus.kafka.NuamConsumerInterceptor;
import com.nuamx.bus.kafka.NuamProducerInterceptor;
import com.nuamx.bus.utils.testing.TestKafkaProtobufSerdes.TestKafkaProtobufDeserializer;
import com.nuamx.bus.utils.testing.TestKafkaProtobufSerdes.TestKafkaProtobufSerializer;

import io.confluent.kafka.serializers.AbstractKafkaSchemaSerDeConfig;
import io.confluent.kafka.serializers.protobuf.KafkaProtobufDeserializerConfig;
import io.confluent.kafka.serializers.protobuf.KafkaProtobufSerializerConfig;
import io.confluent.kafka.serializers.subject.QualifiedReferenceSubjectNameStrategy;
import io.confluent.kafka.serializers.subject.RecordNameStrategy;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

/**
 * Clase de configuración de Kafka para pruebas
 * Modo de uso: agregar las siguientes anotaciones a la clase de prueba unitaria donde
 * se quiere utilizar el cluster Kafka y el schema registry de pruebas. 
 * 
 * <pre>
 * @SpringBootTest(
 *     webEnvironment = SpringBootTest.WebEnvironment.NONE,
 *     classes = { TestKafkaConfig.class },
 *     properties = {
 *         "spring.kafka.schema.registry.url=mock://local",
 *         "logging.level.org.apache.kafka.common.metrics=WARN",
 *         "logging.level.org.apache.kafka.clients.consumer.internals.Fetcher=WARN",
 *         "logging.level.kafka.server=WARN",
 *         "logging.level.org.apache.kafka.image=WARN",
 *         "logging.level.org.apache.kafka.controller=WARN",
 *         "logging.level.state.change.logger=WARN",
 *     }
 * )
 * @EmbeddedKafka(
 *     topics = "test-topic", kraft = true
 * )
 * </pre>
 * 
 * 
 * @author Jonathan Makuc - jmakuc@bithaus.cl - Dic 2024
 */
@Lazy
@Data
@Slf4j
@SuppressWarnings("rawtypes")
public class TestKafkaConfig {


    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;
    private String schemaRegistryUrl = "mock://local";
    
    private Class<? extends Serializer> keySerializer = StringSerializer.class;   
    private Class<? extends Serializer> valueSerializer = TestKafkaProtobufSerializer.class;


    private Class<? extends Deserializer> keyDeserializer = StringDeserializer.class;
    private Class<? extends Deserializer> valueDeserializer = TestKafkaProtobufDeserializer.class;
 

    @Bean
    public Map<String, Object> producerConfigs() {

        if(bootstrapServers == null)
            throw new IllegalArgumentException("bootstrapServers is required");

        if(schemaRegistryUrl == null)
            throw new IllegalArgumentException("schemaRegistryUrl is required");

        Map<String, Object> configProps = new HashMap<>();
        configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, this.bootstrapServers);
        configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, this.keySerializer.getName());
        configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, this.valueSerializer.getName());
        configProps.put("schema.registry.url", this.schemaRegistryUrl);

        // NOTA DE DESARROLLADOR
        // En fase de pruebas si registramos los schemas automaticamente,
        // de lo contrario habría que replicar el registro recursivo que realiza serializer
        // En AVRO se puede solo registrar el json pero en protobuf cada tipo de mensaje/objeto
        // se registra como un schema distinto.

        configProps.put("auto.register.schemas", "true");
        configProps.put("value.subject.name.strategy", RecordNameStrategy.class.getName());
        configProps.put(KafkaProtobufSerializerConfig.REFERENCE_SUBJECT_NAME_STRATEGY_CONFIG, QualifiedReferenceSubjectNameStrategy.class.getName());
        configProps.put(ProducerConfig.INTERCEPTOR_CLASSES_CONFIG, NuamProducerInterceptor.class.getName());        

        return configProps;
    }        

    @Bean
    public Map<String, Object> consumerConfigs() {

        if(bootstrapServers == null)
            throw new IllegalArgumentException("bootstrapServers is required");

        if(schemaRegistryUrl == null)
            throw new IllegalArgumentException("schemaRegistryUrl is required");

        Map<String, Object> configProps = new HashMap<>();
        configProps.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, this.bootstrapServers);
        configProps.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, this.keyDeserializer.getName());
        configProps.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, this.valueDeserializer.getName());
        configProps.put(ConsumerConfig.GROUP_ID_CONFIG, "test-group");
        configProps.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        configProps.put("schema.registry.url", this.schemaRegistryUrl);
        configProps.put("auto.register.schemas", "true");
        configProps.put("use.latest.version", "true");
        configProps.put("value.subject.name.strategy", RecordNameStrategy.class.getName());
        configProps.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        configProps.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, 1);
        configProps.put(KafkaProtobufDeserializerConfig.DERIVE_TYPE_CONFIG, true);
        configProps.put(ConsumerConfig.INTERCEPTOR_CLASSES_CONFIG, NuamConsumerInterceptor.class.getName());
        
        return configProps;
    }       
 
    @Bean
    public KafkaTemplate<String, Message> kafkaTemplate() {
        KafkaTemplate<String,Message> template = new KafkaTemplate<String, Message>(producerFactory());
        template.setConsumerFactory(consumerFactory());
        template.setKafkaAdmin(kafkaAdmin());
        return template;
    }

    @Bean
    public KafkaAdmin kafkaAdmin() {

        Map<String, Object> configs = new HashMap<>();
        configs.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, this.bootstrapServers);
        return new KafkaAdmin(configs);
    }

    @Bean
    public ProducerFactory<String, Message> producerFactory() {
        return new DefaultKafkaProducerFactory<>(this.producerConfigs());
    }        

    @Bean
    public ConsumerFactory<String, Message> consumerFactory() {
        return new DefaultKafkaConsumerFactory<>(this.consumerConfigs());
    }    

 

}
