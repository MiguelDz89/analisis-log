package com.nuamx.bus.utils;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

import com.google.protobuf.Timestamp;
import com.nuamx.bus.message.common.Currency;
import com.nuamx.bus.message.common.Decimal;
import com.nuamx.bus.message.common.ExecInst;
import com.nuamx.bus.message.common.ExecType;
import com.nuamx.bus.message.common.MarketEventType;
import com.nuamx.bus.message.common.OrderSide;
import com.nuamx.bus.message.common.OrderStatus;
import com.nuamx.bus.message.common.SettlementType;
import com.nuamx.bus.message.common.TimeInForce;

public class NuamTranslationUtils {

  public static com.nuamx.bus.message.common.Date toDate(LocalDate dateToConvert) {
    if (dateToConvert == null) {
      return null;
    }
    return com.nuamx.bus.message.common.Date.newBuilder()
        .setYear(dateToConvert.getYear())
        .setMonth(dateToConvert.getMonthValue())
        .setDay(dateToConvert.getDayOfMonth())
        .build();
  }

  public static com.nuamx.bus.message.common.Date toDate(Date dateToConvert) {
    if (dateToConvert == null) {
      return null;
    }

    LocalDate localDate = dateToConvert.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    return com.nuamx.bus.message.common.Date.newBuilder()
        .setYear(localDate.getYear())
        .setMonth(localDate.getMonthValue())
        .setDay(localDate.getDayOfMonth())
        .build();
  }

  public static com.nuamx.bus.message.common.Date toDate(LocalDateTime dateToConvert) {
    if (dateToConvert == null) {
      return null;
    }
    return com.nuamx.bus.message.common.Date.newBuilder()
        .setYear(dateToConvert.getYear())
        .setMonth(dateToConvert.getMonthValue())
        .setDay(dateToConvert.getDayOfMonth())
        .build();
  }

  public static Timestamp toTimestamp(LocalDateTime dateToConvert) {
    if (dateToConvert == null) {
      return null;
    }
    return Timestamp.newBuilder()
        .setSeconds(dateToConvert.atZone(ZoneId.systemDefault()).toInstant().getEpochSecond())
        .setNanos(dateToConvert.getNano())
        .build();
  }

  public static Instant toInstant(Timestamp timestamp) {
    if (timestamp == null) {
      return null;
    }
    return Instant.ofEpochSecond(timestamp.getSeconds(), timestamp.getNanos());
  }

  public static LocalDateTime toLocalDateTime(Timestamp timestamp) {
    if (timestamp == null) {
      return null;
    }
    return LocalDateTime.ofInstant(
        Instant.ofEpochSecond(timestamp.getSeconds(), timestamp.getNanos()), ZoneId.systemDefault());
  }

  public static Timestamp toTimestamp(Instant instant) {
    if (instant == null) {
      return null;
    }
    return Timestamp.newBuilder()
        .setSeconds(instant.getEpochSecond())
        .setNanos(instant.getNano())
        .build();
  }

  public static Currency toCurrency(String currency) {
    if (currency == null) {
      return null;
    }
    switch (currency) {

      case "CLP":
        return Currency.CURRENCY_CLP;
      case "COP":
        return Currency.CURRENCY_COP;
      case "PEN":
        return Currency.CURRENCY_PEN;
      case "DOP":
        return Currency.CURRENCY_DOP;
      case "CRC":
        return Currency.CURRENCY_CRC;
      case "USD":
        return Currency.CURRENCY_USD;
      case "EUR":
        return Currency.CURRENCY_EUR;
    }

    return Currency.CURRENCY_UNSPECIFIED;
  }

  public static Decimal toDecimal(BigDecimal value) {
    if (value == null) {
      return null;
    }
    return Decimal.newBuilder()
        .setValue(value.toString())
        .build();
  }

  public static LocalDate toLocalDate(com.nuamx.bus.message.common.Date date) {
    if (date == null) {
      return null;
    }
    return LocalDate.of(date.getYear(), date.getMonth(), date.getDay());
  }

  public static MarketEventType marketEventTypeFromFixValue(String fixValue) {
    if (fixValue == null) {
      return null;
    }
    
    switch (fixValue) {
      case "1":
        return MarketEventType.MARKET_EVENT_TYPE_MARKET_EVENT;
      case "2":
        return MarketEventType.MARKET_EVENT_TYPE_SYMBOL_NEWS;
      case "3":
        return MarketEventType.MARKET_EVENT_TYPE_SYMBOL_SUSPENSION;
      case "4":
        return MarketEventType.MARKET_EVENT_TYPE_ALARM;
      case "5":
        return MarketEventType.MARKET_EVENT_TYPE_CROSS_ORDER;
      case "6":
        return MarketEventType.MARKET_EVENT_TYPE_SYMBOL_RESUME;
      case "7":
        return MarketEventType.MARKET_EVENT_TYPE_LOCAL_NEWS;
      case "8":
        return MarketEventType.MARKET_EVENT_TYPE_MARKET_NEWS;
      case "9999":
        return MarketEventType.MARKET_EVENT_TYPE_OTHER;
      default:
        return null;
    }
  }  

  public static SettlementType settlementTypeFromFixValue(String fixValue) {
    if (fixValue == null) {
      return null;
    }
    
    switch (fixValue) {
      case "0":
        return SettlementType.SETTLEMENT_TYPE_T_PLUS_0;
      case "1":
        return SettlementType.SETTLEMENT_TYPE_T_PLUS_1;
      case "2":
        return SettlementType.SETTLEMENT_TYPE_T_PLUS_2;
      case "3":
        return SettlementType.SETTLEMENT_TYPE_T_PLUS_3;
      case "4":
        return SettlementType.SETTLEMENT_TYPE_T_PLUS_4;
      case "5":
        return SettlementType.SETTLEMENT_TYPE_T_PLUS_5;
      default:
        return SettlementType.SETTLEMENT_TYPE_UNSPECIFIED;
      }
  }

  public static ExecType execTypeFromFixValue(String fixValue) {
    if (fixValue == null) {
      return null;
    }
    
    switch (fixValue) {
      case "0":
        return ExecType.EXEC_TYPE_NEW;
      case "3":
        return ExecType.EXEC_TYPE_DONE_FOR_DAY;
      case "4":
        return ExecType.EXEC_TYPE_CANCELED;
      case "5":
        return ExecType.EXEC_TYPE_REPLACED;
      case "6":
        return ExecType.EXEC_TYPE_PENDING_CANCEL;
      case "7":
        return ExecType.EXEC_TYPE_STOPPED;
      case "8":
        return ExecType.EXEC_TYPE_REJECTED;
      case "9":
        return ExecType.EXEC_TYPE_SUSPENDED;
      case "A":
        return ExecType.EXEC_TYPE_PENDING_NEW;
      case "B":
        return ExecType.EXEC_TYPE_CALCULATED;
      case "C":
        return ExecType.EXEC_TYPE_EXPIRED;
      case "D":
        return ExecType.EXEC_TYPE_RESTATED;
      case "E":
        return ExecType.EXEC_TYPE_PENDING_REPLACE;
      case "F":
        return ExecType.EXEC_TYPE_TRADE_ADD;
      case "G":
        return ExecType.EXEC_TYPE_TRADE_CORRECT;
      case "H":
        return ExecType.EXEC_TYPE_TRADE_CANCEL;
      case "I":
        return ExecType.EXEC_TYPE_ORDER_STATUS;        
    }
    return ExecType.EXEC_TYPE_UNSPECIFIED;
  }

  public static OrderStatus orderStatusFromFixValue(Character fixValue) {
    if (fixValue == null) {
      return null;
    }
    
    switch (fixValue) {
      case '0':
        return OrderStatus.ORDER_STATUS_NEW;
      case '1':
        return OrderStatus.ORDER_STATUS_PARTIALLY_FILLED;
      case '2':
        return OrderStatus.ORDER_STATUS_FILLED;
      case '3':
        return OrderStatus.ORDER_STATUS_DONE_FOR_DAY;
      case '4':
        return OrderStatus.ORDER_STATUS_CANCELLED;
      case '5':
        return OrderStatus.ORDER_STATUS_REPLACED;
      case '6':
        return OrderStatus.ORDER_STATUS_PENDING_CANCEL;
      case '7':
        return OrderStatus.ORDER_STATUS_STOPPED;
      case '8':
        return OrderStatus.ORDER_STATUS_REJECTED;
      case '9':
        return OrderStatus.ORDER_STATUS_SUSPENDED;
      case 'A':
        return OrderStatus.ORDER_STATUS_PENDING_NEW;
      case 'B':
        return OrderStatus.ORDER_STATUS_CALCULATED;
      case 'C':
        return OrderStatus.ORDER_STATUS_EXPIRED;
      case 'D':
        return OrderStatus.ORDER_STATUS_ACCEPTED_FOR_BIDDING;
      case 'E':
        return OrderStatus.ORDER_STATUS_PENDING_REPLACE;        
    }
    return OrderStatus.ORDER_STATUS_UNSPECIFIED;
  }


  public static OrderSide orderSideFromFixValue(Character fixValue) {
    if (fixValue == null) {
      return null;
    }
    
    switch (fixValue) {
      case '1':
        return OrderSide.ORDER_SIDE_BUY;
      case '2':
        return OrderSide.ORDER_SIDE_SELL;
      case '3':
        return OrderSide.ORDER_SIDE_BUY_MINUS;
      case '4':
        return OrderSide.ORDER_SIDE_SELL_PLUS;
      case '5':
        return OrderSide.ORDER_SIDE_SELL_SHORT;
      case '6':
        return OrderSide.ORDER_SIDE_SELL_SHORT_EXEMPT;
    }
    return OrderSide.ORDER_SIDE_UNSPECIFIED;
  }

  public static TimeInForce timeInForceFromFixValue(Character fixValue) {
    if (fixValue == null) {
      return null;
    }
    
    switch (fixValue) {
      case '0':
        return TimeInForce.TIME_IN_FORCE_DAY;
      case '1':
        return TimeInForce.TIME_IN_FORCE_GOOD_TILL_CANCEL;
      case '2':
        return TimeInForce.TIME_IN_FORCE_AT_THE_OPENING;
      case '3':
        return TimeInForce.TIME_IN_FORCE_IMMEDIATE_OR_CANCEL;
      case '4':
        return TimeInForce.TIME_IN_FORCE_FILL_OR_KILL;
      case '5':
        return TimeInForce.TIME_IN_FORCE_GOOD_TILL_CROSSING;
      case '6':
        return TimeInForce.TIME_IN_FORCE_GOOD_TILL_DATE;
    }
    return TimeInForce.TIME_IN_FORCE_UNSPECIFIED;
  }

  public static ExecInst execInstFromFixValue(Character fixValue) {
    if (fixValue == null) {
      return null;
    }
    
    switch (fixValue) {
      case '0':
        return ExecInst.EXEC_INST_STAY_ON_OFFER_SIDE;
      case '1':
        return ExecInst.EXEC_INST_NOT_HELD;
      case '2':
        return ExecInst.EXEC_INST_WORK;
      case '3':
        return ExecInst.EXEC_INST_GO_ALONG;
      case '4':
        return ExecInst.EXEC_INST_OVER_THE_DAY;
      case '5':
        return ExecInst.EXEC_INST_HELD;
      case '6':
        return ExecInst.EXEC_INST_PARTICIPATE_DONT_INITIATE;
      case '7':
        return ExecInst.EXEC_INST_STRICT_SCALE;
      case '8':
        return ExecInst.EXEC_INST_TRY_TO_SCALE;
      case '9':
        return ExecInst.EXEC_INST_STAY_ON_BID_SIDE;
      case 'A':
        return ExecInst.EXEC_INST_NO_CROSS;
      case 'B':
        return ExecInst.EXEC_INST_OK_TO_CROSS;
      case 'C':
        return ExecInst.EXEC_INST_CALL_FIRST;
      case 'D':
        return ExecInst.EXEC_INST_PERCENT_OF_VOLUME;
      case 'E':
        return ExecInst.EXEC_INST_DO_NOT_INCREASE;
      case 'F':
        return ExecInst.EXEC_INST_DO_NOT_REDUCE;
      case 'G':
        return ExecInst.EXEC_INST_ALL_OR_NONE;
      case 'H':
        return ExecInst.EXEC_INST_REINSTATE_ON_SYSTEM_FAILURE;
      case 'I':
        return ExecInst.EXEC_INST_INSTITUTIONS_ONLY;
      case 'J':
        return ExecInst.EXEC_INST_REINSTATE_ON_TRADING_HALT;
      case 'K':
        return ExecInst.EXEC_INST_CANCEL_ON_TRADING_HALT;
      case 'L':
        return ExecInst.EXEC_INST_LAST_PEG;
      case 'M':
        return ExecInst.EXEC_INST_MID_PRICE_PEG;
      case 'N':
        return ExecInst.EXEC_INST_NON_NEGOTIABLE;
      case 'O':
        return ExecInst.EXEC_INST_OPENING_PEG;
      case 'P':
        return ExecInst.EXEC_INST_MARKET_PEG;
      case 'Q':
        return ExecInst.EXEC_INST_CANCEL_ON_SYSTEM_FAILURE;        
    }
    return
        ExecInst.EXEC_INST_UNSPECIFIED;
  }

}
