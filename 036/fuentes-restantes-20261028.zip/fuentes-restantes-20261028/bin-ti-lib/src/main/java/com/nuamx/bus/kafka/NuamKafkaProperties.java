package com.nuamx.bus.kafka;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.kafka.clients.CommonClientConfigs;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties.Admin;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties.Consumer;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties.Jaas;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties.Listener;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties.Producer;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties.Retry;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties.Security;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties.Ssl;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties.Streams;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties.Template;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.ssl.SslBundles;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.CollectionUtils;

import lombok.Data;

/**
 * Clase de configuración Kafka para nuam.
 * Obtiene los valores desde las propiedades con prefijo "spring.kafka.nuam" 
 * y funciona igual que {@link org.springframework.boot.autoconfigure.kafka.KafkaProperties}.
 * 
 * <br>
 * <br>
 * Se crea con el objetivo de no mezclar las propiedades de Kafka de nuam con las propiedades
 * de Kafka de otras integraciones. 
 * <br>
 * 
 * @see org.springframework.boot.autoconfigure.kafka.KafkaProperties
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "spring.kafka.nuam")
public class NuamKafkaProperties {

  /**
   * CONTENIDO COPIADO DE org.springframework.boot.autoconfigure.kafka.KafkaProperties
   */




	/**
	 * List of host:port pairs to use for establishing the initial connections to the
	 * Kafka cluster. Applies to all components unless overridden.
	 */
	private List<String> bootstrapServers = new ArrayList<>();

	/**
	 * ID to pass to the server when making requests. Used for server-side logging.
	 */
	private String clientId;

	/**
	 * Additional properties, common to producers and consumers, used to configure the
	 * client.
	 */
	private final Map<String, String> properties = new HashMap<>();

	private final Consumer consumer = new Consumer();

	private final Producer producer = new Producer();

	private final Admin admin = new Admin();

	private final Streams streams = new Streams();

	private final Listener listener = new Listener();

	private final Ssl ssl = new Ssl();

	private final Jaas jaas = new Jaas();

	private final Template template = new Template();

	private final Security security = new Security();

	private final Retry retry = new Retry();  



	private Map<String, Object> buildCommonProperties(SslBundles sslBundles) {
		Map<String, Object> properties = new HashMap<>();
		if (this.bootstrapServers != null) {
			properties.put(CommonClientConfigs.BOOTSTRAP_SERVERS_CONFIG, this.bootstrapServers);
		}
		if (this.clientId != null) {
			properties.put(CommonClientConfigs.CLIENT_ID_CONFIG, this.clientId);
		}
		properties.putAll(this.ssl.buildProperties(sslBundles));
		properties.putAll(this.security.buildProperties());
		if (!CollectionUtils.isEmpty(this.properties)) {
			properties.putAll(this.properties);
		}
		return properties;
	}

	/**
	 * Create an initial map of consumer properties from the state of this instance.
	 * <p>
	 * This allows you to add additional properties, if necessary, and override the
	 * default {@code kafkaConsumerFactory} bean.
	 * @param sslBundles bundles providing SSL trust material
	 * @return the consumer properties initialized with the customizations defined on this
	 * instance
	 */
	public Map<String, Object> buildConsumerProperties(SslBundles sslBundles) {
		Map<String, Object> properties = buildCommonProperties(sslBundles);
		properties.putAll(this.consumer.buildProperties(sslBundles));
		return properties;
	}

	/**
	 * Create an initial map of producer properties from the state of this instance.
	 * <p>
	 * This allows you to add additional properties, if necessary, and override the
	 * default {@code kafkaProducerFactory} bean.
	 * @param sslBundles bundles providing SSL trust material
	 * @return the producer properties initialized with the customizations defined on this
	 * instance
	 */
	public Map<String, Object> buildProducerProperties(SslBundles sslBundles) {
		Map<String, Object> properties = buildCommonProperties(sslBundles);
		properties.putAll(this.producer.buildProperties(sslBundles));
		return properties;
	}

	/**
	 * Create an initial map of admin properties from the state of this instance.
	 * <p>
	 * This allows you to add additional properties, if necessary, and override the
	 * default {@code kafkaAdmin} bean.
	 * @param sslBundles bundles providing SSL trust material
	 * @return the admin properties initialized with the customizations defined on this
	 * instance
	 */
	public Map<String, Object> buildAdminProperties(SslBundles sslBundles) {
		Map<String, Object> properties = buildCommonProperties(sslBundles);
		properties.putAll(this.admin.buildProperties(sslBundles));
		return properties;
	}

	/**
	 * Create an initial map of streams properties from the state of this instance.
	 * <p>
	 * This allows you to add additional properties, if necessary.
	 * @param sslBundles bundles providing SSL trust material
	 * @return the streams properties initialized with the customizations defined on this
	 * instance
	 */
	public Map<String, Object> buildStreamsProperties(SslBundles sslBundles) {
		Map<String, Object> properties = buildCommonProperties(sslBundles);
		properties.putAll(this.streams.buildProperties(sslBundles));
		return properties;
	}  
}
