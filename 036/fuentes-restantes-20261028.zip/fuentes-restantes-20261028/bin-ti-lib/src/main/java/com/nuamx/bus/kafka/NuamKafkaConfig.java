/*
 * Copyright (c) NUAM EXCHANGE. All rights reserved.
 *
 * All  rights to this product are owned  by NUAM EXCHANGE  and  may  only  be
 * used under the terms of its associated license document. You may NOT  copy,
 * modify,  sublicense,  or  distribute  this  source  file or portions of  it
 * unless previously authorized in  writing by  NUAM EXCHANGE. In  any  event,
 * this notice and the above copyright must always be included verbatim   with
 * this file.
 */

package com.nuamx.bus.kafka;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaAdmin;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;

import com.google.protobuf.Message;

import io.confluent.kafka.schemaregistry.client.CachedSchemaRegistryClient;
import io.confluent.kafka.schemaregistry.client.SchemaRegistryClient;
import io.confluent.kafka.serializers.protobuf.KafkaProtobufDeserializer;
import io.confluent.kafka.serializers.protobuf.KafkaProtobufDeserializerConfig;
import io.confluent.kafka.serializers.protobuf.KafkaProtobufSerializer;
import io.confluent.kafka.serializers.protobuf.KafkaProtobufSerializerConfig;
import io.confluent.kafka.serializers.subject.QualifiedReferenceSubjectNameStrategy;
import io.confluent.kafka.serializers.subject.RecordNameStrategy;
import jakarta.annotation.PostConstruct;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

/**
 * Inicialización de Kafka para nuam en base a las propiedades en {@link NuamKafkaProperties} 
 * las cuales son leídas desde las propiedades con prefijo "spring.kafka.nuam".
 * <br>
 * <br>
 * 
 * <b>Siempre debe utilizarse esta clase para inicializar el entorno Springboot con Kafka.</b>
 * <br>
 * <br>
 * Responsable de:
 * <ul>
 *  <li>Proveer Beans para {@link KafkaTemplate}, {@link KafkaListenerContainerFactory},
 *  {@link ProducerFactory} y {@link ConsumerFactory} para mensajes de nuam.</li>
 *  <li>Configurar los serializadores y deserializadores</li>
 *  <li>Setear las configuracicones base estrictas para productores y consumidores</li>
 * </ul>
 * <br>
 * <br>
 * 
 * @author Jonathan Makuc - jmakuc@bithaus.cl - Dic 2024
 */
@Slf4j
@Data
@Configuration
@SuppressWarnings("rawtypes")
public class NuamKafkaConfig {

    @Autowired
    private NuamKafkaProperties kafkaProperties;
    
    /**
     * NOTA DE DESARROLLADOR
     * 
     * Esta clase configura las opciones forzadas de la conexión con el cluster Kafka. 
     * Detalles de seguridad y opciones avanzadas se dejan libres para ser configuradas
     * vía application.properties / application.yml.
     * 
     * Importante destacar que la clase de configuración es personalizada {@link NuamKafkaProperties}
     * para no interferir con las otras configuraciones Kafka que puedan existir en la aplicación.
     * 
     * PREFIJO PROPIEDADES: spring.kafka.nuam
     * 
     * - Mejorar la configuración del container factory
     */




    /**
     * 
     * 
     *                  **********    ATENCION   **********
     * 
     *  Si se hacen modificaciones a este proyecto, también debe modificarse la versión 
     *            Java 8 para que no haya incompatibilidades. 
     * 
     *              https://github.com/nuamx/bin-ti-bus-lib-java8
     * 
     * 
     *      DE VERDAD, NO TE OLVIDES DE MODIFICAR EL OTRO PROYECTO TAMBIÉN!
     * 
     * 
     */







    private Class<? extends Serializer> keySerializer = StringSerializer.class;
    private Class<? extends Serializer> valueSerializer = KafkaProtobufSerializer.class;

    private Class<? extends Deserializer> keyDeserializer = StringDeserializer.class;
    private Class<? extends Deserializer> valueDeserializer = KafkaProtobufDeserializer.class;
 
    @PostConstruct
    public void postConstruct() {

        log.info("Bootstrap servers: {}", kafkaProperties.getBootstrapServers());
        log.info("Schema registry URL: {}", kafkaProperties.getProperties().get("schema.registry.url"));        
    }

    @Bean
    KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<String, Message>> kafkaListenerContainerFactory(NuamKafkaProperties kafkaProperties) {
        ConcurrentKafkaListenerContainerFactory<String, Message> factory =
                                new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory(kafkaProperties));

        // TODO: ver la configuración de concurrency, polltimeout, etc

        return factory;
    }    

    /**
     * Producer factory para mensajes de nuam
     */
    @Lazy
    @Bean
    public ProducerFactory<String, Message> producerFactory(NuamKafkaProperties kafkaProperties) {

        Map<String, Object> config = new HashMap<>(kafkaProperties.buildConsumerProperties(null));
        config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, this.keySerializer.getName());
        config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, this.valueSerializer.getName());
        config.put("allow.auto.create.topics", "false");

        /**
         * NOTA DE DESARROLLADOR
         * Abril 2025 - jmakuc
         * En protobuf no se puede solo registrar el schema del mensaje, sino que
         * también los de los objetos que contiene.
         * Así, es complicado hacer al registro en las pruebas y por el momento
         * se decidió dejar que se autoregistre. Contacta a jmakuc@bithaus.cl para más info. 
         * Se podría dejar así en producción (aunque no me gusta) dado que el equipo bus controla
         * el proyecto de mensajes y eso disminuye el riesgo de que se registren
         * schemas no deseados. (Igual podría pasar si alguien llega con el primer
         * mensaje en un tópico y hay colisión de nombres)
         * 
         */

        // config.put("auto.register.schemas", "false");
        config.put("value.subject.name.strategy", RecordNameStrategy.class.getName());
        config.put(KafkaProtobufSerializerConfig.REFERENCE_SUBJECT_NAME_STRATEGY_CONFIG, QualifiedReferenceSubjectNameStrategy.class.getName());
        config.put(ProducerConfig.INTERCEPTOR_CLASSES_CONFIG, NuamProducerInterceptor.class.getName());        

        return new DefaultKafkaProducerFactory<>(config);
    
    }

    @Lazy
    @Bean
    public ConsumerFactory<String, Message> consumerFactory(NuamKafkaProperties kafkaProperties) {

        Map<String, Object> consumerConfig = new HashMap<>(kafkaProperties.buildConsumerProperties(null));
        consumerConfig.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, this.keyDeserializer.getName());
        consumerConfig.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, this.valueDeserializer.getName());
        consumerConfig.put("allow.auto.create.topics", "false");
        consumerConfig.put("auto.register.schemas", "false");
        consumerConfig.put("use.latest.version", "true");
        consumerConfig.put("value.subject.name.strategy", RecordNameStrategy.class.getName());
        consumerConfig.put(KafkaProtobufDeserializerConfig.DERIVE_TYPE_CONFIG, true);
        consumerConfig.put(ConsumerConfig.INTERCEPTOR_CLASSES_CONFIG, NuamConsumerInterceptor.class.getName());

        return new DefaultKafkaConsumerFactory<>(consumerConfig);
    }

    @Lazy
    @Bean
    public KafkaTemplate<String, Message> kafkaTemplate(NuamKafkaProperties kafkaProperties) {
        KafkaTemplate<String, Message> template = new KafkaTemplate<>(producerFactory(kafkaProperties));
        template.setConsumerFactory(consumerFactory(kafkaProperties));            
        return template;
    }

    @Lazy
    @Bean
    public KafkaAdmin kafkaAdmin(NuamKafkaProperties kafkaProperties) {
        Map<String, Object> config = new HashMap<>(kafkaProperties.buildAdminProperties(null));
        config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, this.keySerializer.getName());
        config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, this.valueSerializer.getName());
        config.put("allow.auto.create.topics", "false");
        return new KafkaAdmin(config);
    }
 

    @Lazy
    @Bean
    public SchemaRegistryClient schemaRegistryClient() {

        String schemaRegistryUrl = kafkaProperties.getProperties().get("schema.registry.url");

        if (schemaRegistryUrl == null || schemaRegistryUrl.isEmpty()) {
            throw new IllegalArgumentException("Schema registry URL not found in properties");
        }
        
        log.info("Schema registry URL: {}", schemaRegistryUrl);
        return new CachedSchemaRegistryClient(schemaRegistryUrl, 100); 
    }

}
