/*
 * Copyright (c) NUAM EXCHANGE. All rights reserved.
 *
 * All  rights to this product are owned  by NUAM EXCHANGE  and  may  only  be
 * used under the terms of its associated license document. You may NOT  copy,
 * modify,  sublicense,  or  distribute  this  source  file or portions of  it
 * unless previously authorized in  writing by  NUAM EXCHANGE. In  any  event,
 * this notice and the above copyright must always be included verbatim   with
 * this file.
 */

 package com.nuamx.bus.utils.time;

import java.util.HashMap;
import java.util.TreeSet;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.Semaphore;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

/**
 *
 *
 * /**
 * Calendarizador de tareas cuyo tiempo de referencia es entregado por
 * {@link TradingTime}.
 * Implementa correctamente el gatillamiento de eventos por modificaciones
 * a la hora en TradingTime.
 *
 * @version 1.0
 * @since 1.0
 * @author jmakuc
 * @author Javier Sepúlveda
 * @see TradingTime
 * @see TradingTimerEntry
 */

@Slf4j
@Getter
@Setter
@ToString
public class TradingTimer extends Thread {

  // Atributos //

  // N° De Hilos para la ejecución de tareas
  public static int DEFAULT_WORKING_THREADS = 4;
  // Cola de tareas
  private TreeSet<TradingTimerEntry> queue = new TreeSet<TradingTimerEntry>();
  // Mapa de tareas
  private HashMap<Runnable, TradingTimerEntry> taskEntryMap = new HashMap<Runnable, TradingTimerEntry>();
  // Contador de instancias
  private static AtomicInteger instanceCount = new AtomicInteger(0);
  // Acepta nuevas tareas
  private boolean acceptNewTasks = true;
  // Lock de la cola
  private Semaphore queueLock = new Semaphore(1);
  // Lock de la cola vacía
  private Semaphore emptyLock = new Semaphore(0);
  // Pool de hilos
  private ThreadPoolExecutor threadPool = null;
  // Serializador de hilos
  private static final AtomicLong threadPoolSerializer = new AtomicLong(0);

  // Constructores Custom //

  /**
   * Constructor sin argumentos.
   */
  public TradingTimer() {

    this(DEFAULT_WORKING_THREADS);
  }

  /**
   * Constructor con las hebras internas
   *
   * @param workingThreads cantidad de hebras internas ejecutoras de tareas
   */
  public TradingTimer(int workingThreads) {

    this("TradingTimer" + instanceCount.incrementAndGet(), false, workingThreads);
  }

  /**
   * Constructor con el nombre y las hebras
   *
   * @param name           nombre del timer
   * @param workingThreads cantidad de hebras ejecutoras de tareas
   */
  public TradingTimer(String name, int workingThreads) {

    this(name, false, workingThreads);

  }

  /**
   * Constructor
   *
   * @param isDaemon       convierte a la hebra principal del timer en daemon
   * @param workingThreads cantidad de hebras ejecutoras de tareas
   */
  public TradingTimer(boolean isDaemon, int workingThreads) {

    this("TradingTimer" + instanceCount.incrementAndGet(), false, workingThreads);
  }

  /**
   * Constructor
   *
   * @param name           nombre del timer
   * @param isDaemon       convierte a la hebra principal del timer en daemon
   * @param workingThreads cantidad de hebras ejecutoras de tareas
   * @param autoStart      iniciar el timer al instanciar
   */
  public TradingTimer(String name, boolean isDaemon, int workingThreads, boolean autoStart) {

    this.setName(name);
    this.setDaemon(isDaemon);

    this.threadPool = new ScheduledThreadPoolExecutor(workingThreads, new TradingTimeRejectedExecutionHandler());

    log.info(String.format("Initialized with %s worker threads", workingThreads));

    if (autoStart) {
      this.start();
    }

    // enganche para despertar al timer en caso que se fuerza un cambio de hora

    TradingTime.addOnTimeUpdateCallback(new Runnable() {

      public void run() {
        emptyLock.release();
      }
    });

  }

  /**
   * Constructor
   *
   * @param name           nombre del timer
   * @param isDaemon       convierte a la hebra principal del timer en daemon
   * @param workingThreads cantidad de hebras ejecutoras de tareas
   */
  public TradingTimer(String name, boolean isDaemon, int workingThreads) {

    this(name, isDaemon, workingThreads, true);
  }

  // Getter & Setters Customs //

  /**
   * Entradas calendarizadas en este timer
   */
  public TradingTimerEntry[] getScheduledEntries() {

    return queue.toArray(new TradingTimerEntry[0]);
  }

  // Métodos //

  /**
   * Inicia el timer
   */
  @Override
  public void start() {
    // Logger
    log.info("Timer starting...");
    super.start();
  }

  /**
   * Calendariza o recalendariza la ejecución de la una tarea en un tiempo
   * determinado en el futuro (timestamp real).
   *
   * @param task         tarea a ejecutar
   * @param scheduleTime timestamp en el futuro.
   * @param timeUnit     unidad de tiempo utilizada
   */
  public void scheduleOnTime(Runnable task, long scheduleTime, TimeUnit timeUnit) {

    scheduleOnTimePeriod(task, scheduleTime, 0, timeUnit);
  }

  /**
   * Calendariza o recalendariza la ejecución de la una tarea en un tiempo
   * determinado en el futuro (timestamp real), ejecutandola periodicamente
   * luego de la primera llamada.
   *
   * @param task         tarea a ejecutar
   * @param scheduleTime timestamp en el futuro.
   * @param period       periodo de ejecucion luego de la primera llamada
   * @param timeUnit     unidad de tiempo utilizada
   */
  public void scheduleOnTimePeriod(Runnable task, long scheduleTime, long period, TimeUnit timeUnit) {

    long scheduleTimeNano = TimeUnit.NANOSECONDS.convert(scheduleTime, timeUnit);
    long periodNano = TimeUnit.NANOSECONDS.convert(period, timeUnit);

    schedule(task, scheduleTimeNano, periodNano);
  }

  /**
   * Calendariza o recalendariza la ejecución de la una tarea en delay
   * nanosegundos en el futuro
   *
   * @param task     tarea a ejecutar
   * @param delay    tiempo a esperar para la primera llamada
   * @param timeUnit unidad de tiempo utilizada
   */
  public void scheduleDelayed(Runnable task, long delay, TimeUnit timeUnit) {

    scheduleDelayedPeriod(task, delay, 0, timeUnit);
  }

  /**
   * Calendariza o recalendariza la ejecución de la una tarea en delay
   * nanosegundos en el futuro, ejecutandola periódicamente luego de la
   * primera llamada
   *
   * @param task     tarea a ejecutar
   * @param delay    tiempo a esperar para la primera llamada
   * @param period   periodo de ejecucion luego de la primera llamada
   * @param timeUnit unidad de tiempo utilizada
   */
  public void scheduleDelayedPeriod(final Runnable task, long delay, long period, TimeUnit timeUnit) {

    // especial que pasa directo al thread pool:
    if (delay == 0 && period == 0) {

      // threadPool.execute(new TaskRunner(task));
      // return;
    }

    long delayNano = TimeUnit.NANOSECONDS.convert(delay, timeUnit);
    long periodNano = TimeUnit.NANOSECONDS.convert(period, timeUnit);

    schedule(task, TradingTime.getTimeNanos() + delayNano, periodNano);
  }

  /**
   * Cancela la ejecución de una tarea
   *
   * @param task tarea a cancelar
   * @return True si la tarea se encontró en la cola de tareas calendarizadas
   *         y fue removida.
   */
  public boolean cancel(Runnable task) {

    queueLock.acquireUninterruptibly();

    TradingTimerEntry entry = taskEntryMap.get(task);

    if (entry == null) {

      queueLock.release();
      return false;
    }

    boolean result = queue.remove(entry);
    entry.setState(TradingTimerEntry.CANCELLED);

    queueLock.release();

    // Logger

    if (result)
      log.info("Task Cancelled: " + task.getClass().getSimpleName());
    else
      log.debug(String.format("Task %s not found in queue...", task.getClass().getSimpleName()));

    return result;
  }

  /**
   * Cierra el servicio descartando todas las tareas a realizar.<br>
   * No interfiere con las tareas que pudieran encontrarse en ejecución.
   */
  public void shutdown() {

    acceptNewTasks = false;
    log.info(this.getName() + " shutdown");
  }

  /**
   * Elimina todas las tareas por ejecutar de la cola.
   */
  public void clear() {

    queueLock.acquireUninterruptibly();

    queue.clear();

    queueLock.release();

    log.info(this.getName() + " cleared");
  }

  /**
   * Calendarización de una tarea
   *
   * @param task             tarea a calendarizar
   * @param scheduleNanoTime tiempo de gatillamiento inicial
   * @param period           periodo de gatillamiento
   */
  private void schedule(Runnable task, long scheduleNanoTime, long period) {

    if (task == null)
      throw new RuntimeException("Task cannot be null");

    if (scheduleNanoTime <= 0)
      throw new IllegalArgumentException("Scheduletime must be positive");

    if (period < 0)
      throw new IllegalArgumentException("Period must be zero or positive");

    TradingTimerEntry entry = new TradingTimerEntry(task);
    entry.setNextExecutionTime(scheduleNanoTime);
    entry.setPeriod(period);

    queueLock.acquireUninterruptibly();

    if (entry.getState() != TradingTimerEntry.VIRGIN &&
        entry.getState() != TradingTimerEntry.SCHEDULED)
      throw new IllegalArgumentException("Task has already been completed");

    TradingTimerEntry oldEntry = taskEntryMap.get(task);

    if (oldEntry != null)
      queue.remove(oldEntry);

    taskEntryMap.put(task, entry);

    queue.add(entry);
    entry.updateState(scheduleNanoTime, period, TradingTimerEntry.SCHEDULED);

    // Cambio de debug to info
    if (log.isDebugEnabled() && period < 1) {
      log.info(
          String.format("Task [%s] scheduled to be trigger @ %s", entry.serial, TradingTime.getDate(scheduleNanoTime)));
    }

    else {
      log.info(String.format("Task [%s] scheduled to be trigger @ %s, period: %s milis", entry.serial,
          TradingTime.getDate(scheduleNanoTime), TimeUnit.MILLISECONDS.convert(period, TimeUnit.NANOSECONDS)));

    }

    queueLock.release();

    emptyLock.release();

  }

  /**
   * Ciclo de búsqueda de tareas vencidas a ejecutar
   */

  @Override
  public void run() {

    long delta = 0;

    while (acceptNewTasks) {

      queueLock.acquireUninterruptibly();

      if (queue.isEmpty()) {

        queueLock.release();
        emptyLock.acquireUninterruptibly();
      } else {

        TradingTimerEntry[] tasks = queue.headSet(new DummyNowTask(), true).toArray(new TradingTimerEntry[] {});

        int triggeredTasks = 0;

        for (TradingTimerEntry current : tasks) {

          if (!queue.remove(current))
            log.error("Could not remove element from task queue: " + current);

          if (current.getPeriod() > 0) {
            current.updateState(TradingTime.getTimeNanos() + current.getPeriod(), current.getPeriod(),
                TradingTimerEntry.SCHEDULED);
            queue.add(current);
            continue;
          } else {
            current.setState(TradingTimerEntry.EXECUTED);
            threadPool.execute(new TaskRunner(current));
          }

          triggeredTasks++;

        }

        if (log.isDebugEnabled())
          log.debug(String.format("%s triggered tasks", triggeredTasks));

        if (!queue.isEmpty()) {

          delta = queue.first().getNextExecutionTime() - TradingTime.getTimeNanos();

          delta = (long) delta;
        } else {

          delta = Long.MAX_VALUE;
        }

        queueLock.release();

        if (delta < 0)
          continue;

        try {

          if (log.isDebugEnabled())
            log.debug(String.format("Nothing to do. Sleeping %s milis",
                TimeUnit.MILLISECONDS.convert(delta, TimeUnit.NANOSECONDS)));

          emptyLock.tryAcquire(delta, TimeUnit.NANOSECONDS);
        } catch (Exception e) {

          // espera interrumpida sin significado.
          // si se ha llamado a shutdown, entonces el ciclo se
          // rompera en el while general
        }

      }

    }
  }
  // Clases internas //

  /**
   * Utilizada para obtener la rama del árbol que es menor
   * para determinar que tareas deben ser ejecutadas.
   *
   * @version 1.0
   * @since 1.0
   * @see TradingTimerEntry
   * @see Runnable
   * @see TaskRunner
   */

  private class DummyNowTask extends TradingTimerEntry {

    /**
     * Constructor de la clase.
     *
     * @see TradingTimerEntry#TradingTimerEntry(Runnable)
     * @see TradingTime#getTimeNanos()
     */

    public DummyNowTask() {

      super(new Runnable() {

        public void run() {

        }
      }, TradingTime.getTimeNanos());
    }
  }

  /**
   * Clase interna para ejecutar las tareas.
   *
   * @version 1.0
   * @since 1.0
   * @see Runnable
   * @see TaskRunner
   *
   *
   */

  private class TaskRunner implements Runnable {

    // Atributos //
    private Runnable task;

    // Constructor //

    /**
     * Constructor de la clase.
     *
     * @param task Tarea a ejecutar.
     * @see Runnable
     *
     */

    public TaskRunner(Runnable task) {
      this.task = task;
    }

    // Métodos //

    /**
     * Método que ejecuta la tarea.
     *
     * @see Runnable#run()
     *
     */

    public void run() {
      try {
        log.info("Task Triggered: " + task);
        task.run();
      } catch (Exception e2) {
        log.error("Task did not catch exception " + e2, e2);
      }
    }

  }

  /**
   * clase Factory que nombra del pool de hebras de acuerdo al nombre del time,
   * serializador de hilos.
   *
   * @version 1.0
   * @since 1.0
   * @see ThreadFactory
   * @see TradingTimer
   *
   */

  class TradingTimerThreadFactory implements ThreadFactory {

    /**
     * Método que crea un nuevo hilo.
     *
     * @param r Tarea a ejecutar.
     * @return Hilo creado.
     * @see ThreadFactory#newThread(Runnable)
     * @see TaskRunner
     *
     */

    public Thread newThread(Runnable r) {

      Thread t = new Thread(r);
      t.setName(getName() + "-ThreadPool-" +
          threadPoolSerializer.incrementAndGet());

      if (log.isDebugEnabled())
        log.debug("Thread created: " + t.getName());

      return t;
    }
  }

  /**
   * Clase interna para manejar las tareas rechazadas.
   *
   * @version 1.0
   * @since 1.0
   * @see RejectedExecutionHandler
   * @see ThreadPoolExecutor
   * @see TaskRunner
   *
   */

  class TradingTimeRejectedExecutionHandler implements RejectedExecutionHandler {

    /**
     * Método que se ejecuta cuando una tarea es rechazada por el pool de hilos.
     *
     * @param r        Tarea rechazada.
     * @param executor Pool de hilos.
     * @see RejectedExecutionHandler#rejectedExecution(Runnable, ThreadPoolExecutor)
     * @see TaskRunner
     *
     */

    public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {

      if (r instanceof TaskRunner) {

        TaskRunner runner = (TaskRunner) r;

        log.warn(String.format("%s task execution rejected by timer's thread pool", runner.task));

      }
    }

  }
}
