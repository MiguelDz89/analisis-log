package com.nubo.risk.model.load.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
public class RiskModelLoadApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RiskModelLoadApiApplication.class, args);
	}

}
