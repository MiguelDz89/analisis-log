package com.nubo.masterparticipant.api.helpers;

import com.nubo.masterparticipant.api.models.dto.response.ParticipantLoanOutDto;
import com.nubo.masterparticipant.api.models.dto.response.ParticipantLoanTaxStatusOutDto;
import com.nubo.masterparticipant.api.models.dto.response.ParticipantLoanTypeOutDto;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class MapperParticipantLoan {

    public ParticipantLoanOutDto toDto(Object[] row) {
        if (row == null) {
            return null;
        }

        return ParticipantLoanOutDto.builder()
                .id(((Number) row[0]).longValue())
                .code((String) row[1])
                .name((String) row[2])
                .shortname((String) row[3])
                .participanttypes((String) row[4])
                .country((String) row[5])
                .shortcountry((String) row[6])
                .status((String) row[7])
                .custodian((Boolean) row[8])
                .documentnumber((String) row[9])
                .marginaccount(charToString(row[10]))
                .typeentity(charToString(row[11]))
                .taxcode((String) row[12])
                .otcLoanRelationship((Boolean) row[13])
                .taxStatus(buildTaxStatus(row))
                .type(buildType(row))
                .documentType((String) row[18])
                .equity((BigDecimal) row[19])
                .build();
    }

    private ParticipantLoanTaxStatusOutDto buildTaxStatus(Object[] row) {
        if (row[14] == null) {
            return null;
        }

        return ParticipantLoanTaxStatusOutDto.builder()
                .taxStatusId(((Number) row[14]).longValue())
                .description((String) row[15])
                .build();
    }

    private ParticipantLoanTypeOutDto buildType(Object[] row) {
        if (row[16] == null) {
            return null;
        }

        return ParticipantLoanTypeOutDto.builder()
                .typeId(((Number) row[16]).longValue())
                .description((String) row[17])
                .build();
    }

    private String charToString(Object value) {
        return value == null ? null : value.toString();
    }

}

