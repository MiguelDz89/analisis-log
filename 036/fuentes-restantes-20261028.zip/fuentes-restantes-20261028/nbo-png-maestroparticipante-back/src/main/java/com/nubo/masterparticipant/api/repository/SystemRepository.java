package com.nubo.masterparticipant.api.repository;

import com.nubo.masterparticipant.api.models.entity.CityEntity;
import com.nubo.masterparticipant.api.models.entity.SystemEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SystemRepository extends JpaRepository<SystemEntity, Long> {
}
