package com.nubo.masterparticipant.api.service;

import com.nubo.masterparticipant.api.models.dto.response.DirectDepositorOutDto;

import java.util.List;

public interface ParticipantEquivalenceService {

    DirectDepositorOutDto findParticipantEquivalence(Long participantId, String participantCode);

    List<DirectDepositorOutDto> findParticipantEquivalences(Long participantId, String participantCode, Long depositoryId);
}
