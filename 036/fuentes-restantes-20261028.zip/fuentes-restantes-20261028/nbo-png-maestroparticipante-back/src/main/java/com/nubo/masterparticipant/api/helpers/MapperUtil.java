package com.nubo.masterparticipant.api.helpers;

import com.nubo.masterparticipant.api.models.dto.response.BankOutDto;
import com.nubo.masterparticipant.api.models.dto.response.CityOutDto;
import com.nubo.masterparticipant.api.models.dto.response.CountryOutDto;
import com.nubo.masterparticipant.api.models.dto.response.CurrencyOutDto;
import com.nubo.masterparticipant.api.models.dto.response.DepartmentOutDto;
import com.nubo.masterparticipant.api.models.dto.response.DepositoryOutDto;
import com.nubo.masterparticipant.api.models.dto.response.DirectDepositorOutDto;
import com.nubo.masterparticipant.api.models.dto.response.EnterpriseGroupOutDto;
import com.nubo.masterparticipant.api.models.dto.response.GicsOutDto;
import com.nubo.masterparticipant.api.models.dto.response.IdentificationTypeOutDto;
import com.nubo.masterparticipant.api.models.dto.response.InvestorOutDto;
import com.nubo.masterparticipant.api.models.dto.response.ParticipantAccountOutDto;
import com.nubo.masterparticipant.api.models.dto.response.ParticipantAssociatedAccountOutDto;
import com.nubo.masterparticipant.api.models.dto.response.ParticipantAuthorizationOutDto;
import com.nubo.masterparticipant.api.models.dto.response.ParticipantBankAccountFilterOutDto;
import com.nubo.masterparticipant.api.models.dto.response.ParticipantBankAccountOutDto;
import com.nubo.masterparticipant.api.models.dto.response.ParticipantFilterOutDto;
import com.nubo.masterparticipant.api.models.dto.response.ParticipantInvestorOutDto;
import com.nubo.masterparticipant.api.models.dto.response.ParticipantOutDto;
import com.nubo.masterparticipant.api.models.dto.response.ParticipantSuspendedHistoryOutDto;
import com.nubo.masterparticipant.api.models.dto.response.StatusOutDto;
import com.nubo.masterparticipant.api.models.dto.response.SystemOutDto;
import com.nubo.masterparticipant.api.models.dto.response.TaxStatusOutDto;
import com.nubo.masterparticipant.api.models.dto.response.TypeOutDto;
import com.nubo.masterparticipant.api.models.entity.BankEntity;
import com.nubo.masterparticipant.api.models.entity.CityEntity;
import com.nubo.masterparticipant.api.models.entity.CountryEntity;
import com.nubo.masterparticipant.api.models.entity.CurrencyEntity;
import com.nubo.masterparticipant.api.models.entity.DepartmentEntity;
import com.nubo.masterparticipant.api.models.entity.DepositoryEntity;
import com.nubo.masterparticipant.api.models.entity.DirectDepositoryEntity;
import com.nubo.masterparticipant.api.models.entity.EnterpriseGroupEntity;
import com.nubo.masterparticipant.api.models.entity.GicsEntity;
import com.nubo.masterparticipant.api.models.entity.IdentificationTypeEntity;
import com.nubo.masterparticipant.api.models.entity.InvestorEntity;
import com.nubo.masterparticipant.api.models.entity.ParticipantAccountEntity;
import com.nubo.masterparticipant.api.models.entity.ParticipantAuthorizationEntity;
import com.nubo.masterparticipant.api.models.entity.ParticipantBankAccountEntity;
import com.nubo.masterparticipant.api.models.entity.ParticipantEntity;
import com.nubo.masterparticipant.api.models.entity.ParticipantInvestorEntity;
import com.nubo.masterparticipant.api.models.entity.ParticipantSuspendedHistoryEntity;
import com.nubo.masterparticipant.api.models.entity.StatusEntity;
import com.nubo.masterparticipant.api.models.entity.SystemEntity;
import com.nubo.masterparticipant.api.models.entity.TaxStatusEntity;
import com.nubo.masterparticipant.api.models.entity.TypeEntity;
import org.springframework.util.ObjectUtils;

import java.util.Optional;

public class MapperUtil {

    private MapperUtil() {
    }

    public static ParticipantOutDto participantEntityToParticipantOutDto(ParticipantEntity participantEntity) {
        return ParticipantOutDto.builder()
                .id(participantEntity.getId())
                .enterpriseGroup(ObjectUtils.isEmpty(participantEntity.getEnterpriseGroup())
                        ? null : enterpriseGroupEntityToEnterpriseGroupOutDto(participantEntity.getEnterpriseGroup()))
                .code(participantEntity.getCode())
                .documentNumber(participantEntity.getDocumentNumber())
                .identificationType(ObjectUtils.isEmpty(participantEntity.getIdentificationType())
                        ? null : identificationTypeEntityToIdentificationTypeOutDto(participantEntity.getIdentificationType()))
                .name(participantEntity.getName())
                .shortName(participantEntity.getShortName())
                .type(ObjectUtils.isEmpty(participantEntity.getType()) ? null : typeEntityToTypeOutDto(participantEntity.getType()))
                .country(ObjectUtils.isEmpty(participantEntity.getCountry()) ? null : countryEntityToCountryOutDto(participantEntity.getCountry()))
                .registrationDate(participantEntity.getRegistrationDate())
                .taxCode(participantEntity.getTaxCode())
                .department(ObjectUtils.isEmpty(participantEntity.getDepartment())
                        ? null : departmentEntityToDepartmentOutDto(participantEntity.getDepartment()))
                .mainAddress(participantEntity.getMainAddress())
                .webPage(participantEntity.getWebPage())
                .phoneNumber(participantEntity.getPhoneNumber())
                .status(ObjectUtils.isEmpty(participantEntity.getStatus()) ? null : statusEntityToStatusOutDto(participantEntity.getStatus()))
                .taxStatus(ObjectUtils.isEmpty(participantEntity.getTaxStatus()) ? null : taxStatusEntityToTaxStatusOutDto(participantEntity.getTaxStatus()))
                .typeEntity(ObjectUtils.isEmpty(participantEntity.getEntityType()) ? null : typeEntityToTypeOutDto(participantEntity.getEntityType()))
                .directAllocation(participantEntity.getDirectAllocation())
                .marketMaker(participantEntity.getMarketMaker())
                .custodian(participantEntity.getCustodian())
                .city(ObjectUtils.isEmpty(participantEntity.getCity()) ? null : cityEntityToCityOutDto(participantEntity.getCity()))
                .canceledStatus(participantEntity.getCanceledStatus())
                .registeredSystem(ObjectUtils.isEmpty(participantEntity.getRegisteredSystem())
                        ? null : systemEntityToSystemOutDto(participantEntity.getRegisteredSystem()))
                .dcvRvOpersAuth(Optional.ofNullable(participantEntity.getDcvRvOpersAuth()).orElse(false))
                .dcvRvSettlementAuth(Optional.ofNullable(participantEntity.getDcvRvSettlementAuth()).orElse(false))
                .directOperatorAgreements(Optional.ofNullable(participantEntity.getDirectOperatorAgreements()).orElse(false))
                .otcLoanRelationship(Optional.ofNullable(participantEntity.getOtcLoanRelationship()).orElse(false))
                .otcIndicator("")//booleno SI,NO
                .suspendedNegotiation(!ObjectUtils.isEmpty(participantEntity.getSuspendedNegotiation()) && participantEntity.getSuspendedNegotiation())
                .masterAccount(participantAccountEntityToParticipantAccountDetailOutDto(participantEntity.getMasterAccount()))
                .ownAccount(participantAccountEntityToParticipantAccountDetailOutDto(participantEntity.getOwnAccount()))
                .equity(participantEntity.getEquity())
                .currency(currencyEntityToCurrencyOutDto(participantEntity.getCurrency()))
                .build();
    }

    public static ParticipantFilterOutDto participantEntityToParticipantFilterOutDto(ParticipantEntity participantEntity) {
        return ParticipantFilterOutDto.builder()
                .id(participantEntity.getId())
                .code(participantEntity.getCode())
                .documentNumber(participantEntity.getDocumentNumber())
                .name(participantEntity.getName())
                .shortName(participantEntity.getShortName())
                .build();
    }

    public static DirectDepositorOutDto directDepositoryEntityToDirectDepositorOutDto(DirectDepositoryEntity directDepositoryEntity) {
        if (ObjectUtils.isEmpty(directDepositoryEntity)) return null;
        return DirectDepositorOutDto.builder()
                .depository(depositoryEntityToDepositoryOutDto(directDepositoryEntity.getDepository()))
                .id(directDepositoryEntity.getId())
                .nuamCode(directDepositoryEntity.getParticipant().getCode())
                .directDepositorNumber(directDepositoryEntity.getDirectDepositoryNumber())
                //TODO se agregan campos con autorización de Frank y Hector, para solucion de Big RTBOF-11326
                .crccNegotiatorCode(directDepositoryEntity.getCrccNegotiatorCode())
                .crccCompensatorCode(directDepositoryEntity.getCrccCompensatorCode())
                .crccCustodianCode(directDepositoryEntity.getCrccCustodianCode())
                .build();
    }

    public static CountryOutDto countryEntityToCountryOutDto(CountryEntity countryEntity) {
        return CountryOutDto.builder()
                .id(countryEntity.getId())
                .code(countryEntity.getCode())
                .name(countryEntity.getName())
                .currency(ObjectUtils.isEmpty(countryEntity.getCurrency()) ? null : currencyEntityToCurrencyOutDto(countryEntity.getCurrency()))
                .timeZone(countryEntity.getTimeZone())
                .build();
    }

    public static CurrencyOutDto currencyEntityToCurrencyOutDto(CurrencyEntity currencyEntity) {
        if (currencyEntity == null) return null;
        return CurrencyOutDto.builder()
                .id(currencyEntity.getId())
                .code(currencyEntity.getCode())
                .name(currencyEntity.getName())
                .build();
    }

    public static ParticipantAccountOutDto participantAccountEntityToParticipantAccountOutDto(
            ParticipantAccountEntity participantAccountEntity) {
        if (participantAccountEntity == null) return null;

        return ParticipantAccountOutDto.builder()
                .id(participantAccountEntity.getId())
                .participant(ObjectUtils.isEmpty(participantAccountEntity.getParticipant())
                        ? null : MapperUtil.participantEntityToParticipantOutDto(participantAccountEntity.getParticipant()))
                .accountNumber(participantAccountEntity.getAccountNumber())
                .status(ObjectUtils.isEmpty(participantAccountEntity.getStatus())
                        ? null : MapperUtil.statusEntityToStatusOutDto(participantAccountEntity.getStatus()))
                .originType(ObjectUtils.isEmpty(participantAccountEntity.getOriginType())
                        ? null : MapperUtil.typeEntityToTypeOutDto(participantAccountEntity.getOriginType()))
                .type(ObjectUtils.isEmpty(participantAccountEntity.getType())
                        ? null : MapperUtil.typeEntityToTypeOutDto(participantAccountEntity.getType()))
                .depository(ObjectUtils.isEmpty(participantAccountEntity.getDepository())
                        ? null : MapperUtil.depositoryEntityToDepositoryOutDto(participantAccountEntity.getDepository()))
                .country(ObjectUtils.isEmpty(participantAccountEntity.getCountry())
                        ? null : MapperUtil.countryEntityToCountryOutDto(participantAccountEntity.getCountry()))
                .entityCode(participantAccountEntity.getEntityCode())
                .swiftCode(participantAccountEntity.getSwiftCode())
                .principal(participantAccountEntity.getPrincipal())
                .branchCode(participantAccountEntity.getBranchCode())
                .portfolio(participantAccountEntity.getPortfolio())
                .accountConcept(participantAccountEntity.getAccountConcept())
                .nitClearingEntity(participantAccountEntity.getNitClearingEntity())
                .build();
    }

    public static ParticipantAccountOutDto participantAccountEntityToParticipantAccountDetailOutDto(
            ParticipantAccountEntity participantAccountEntity) {
        if (participantAccountEntity == null) return null;

        return ParticipantAccountOutDto.builder()
                .id(participantAccountEntity.getId())
                .accountNumber(participantAccountEntity.getAccountNumber())
                .status(ObjectUtils.isEmpty(participantAccountEntity.getStatus())
                        ? null : MapperUtil.statusEntityToStatusOutDto(participantAccountEntity.getStatus()))
                .originType(ObjectUtils.isEmpty(participantAccountEntity.getOriginType())
                        ? null : MapperUtil.typeEntityToTypeOutDto(participantAccountEntity.getOriginType()))
                .type(ObjectUtils.isEmpty(participantAccountEntity.getType())
                        ? null : MapperUtil.typeEntityToTypeOutDto(participantAccountEntity.getType()))
                .depository(ObjectUtils.isEmpty(participantAccountEntity.getDepository())
                        ? null : MapperUtil.depositoryEntityToDepositoryOutDto(participantAccountEntity.getDepository()))
                .country(ObjectUtils.isEmpty(participantAccountEntity.getCountry())
                        ? null : MapperUtil.countryEntityToCountryOutDto(participantAccountEntity.getCountry()))
                .build();
    }

    public static ParticipantBankAccountFilterOutDto participantBankAccountEntityToParticipantBankAccountFilterOutDto(
            ParticipantBankAccountEntity participantBankAccountEntity) {
        if (participantBankAccountEntity == null) return null;

        return ParticipantBankAccountFilterOutDto.builder()
                .id(participantBankAccountEntity.getId())
                .bankAccount(participantBankAccountEntity.getBankAccount())
                .status(ObjectUtils.isEmpty(participantBankAccountEntity.getStatus())
                        ? null : statusEntityToStatusOutDto(participantBankAccountEntity.getStatus()))
                .type(ObjectUtils.isEmpty(participantBankAccountEntity.getType())
                        ? null : typeEntityToTypeOutDto(participantBankAccountEntity.getType()))
                .build();
    }


    public static ParticipantAssociatedAccountOutDto participantAccountEntityToParticipantAssociatedAccountOutDto(
            ParticipantAccountEntity participantAccountEntity) {
        if (participantAccountEntity == null) return null;

        return ParticipantAssociatedAccountOutDto.builder()
                .participantAccountId(participantAccountEntity.getId())
                .participantBankAccountId(null)

                .participantId(participantAccountEntity.getParticipant() != null
                        ? participantAccountEntity.getParticipant().getId() : null)

                .participant(ObjectUtils.isEmpty(participantAccountEntity.getParticipant())
                        ? null : participantEntityToParticipantOutDto(participantAccountEntity.getParticipant()))
                .status(ObjectUtils.isEmpty(participantAccountEntity.getStatus())
                        ? null : statusEntityToStatusOutDto(participantAccountEntity.getStatus()))
                .type(ObjectUtils.isEmpty(participantAccountEntity.getTypeAccount())
                        ? null : typeEntityToTypeOutDto(participantAccountEntity.getTypeAccount()))
                .originType(ObjectUtils.isEmpty(participantAccountEntity.getOriginType())
                        ? null : typeEntityToTypeOutDto(participantAccountEntity.getOriginType()))
                .depository(ObjectUtils.isEmpty(participantAccountEntity.getDepository())
                        ? null : depositoryEntityToDepositoryOutDto(participantAccountEntity.getDepository()))
                .bank(null)
                .country(ObjectUtils.isEmpty(participantAccountEntity.getCountry())
                        ? null : countryEntityToCountryOutDto(participantAccountEntity.getCountry()))

                .accountNumber(participantAccountEntity.getAccountNumber())
                .bankAccount(null)
                .entityCode(participantAccountEntity.getEntityCode())
                .swiftCode(participantAccountEntity.getSwiftCode())
                .principal(participantAccountEntity.getPrincipal())
                .branchCode(participantAccountEntity.getBranchCode())
                .portfolio(participantAccountEntity.getPortfolio())
                .concept(participantAccountEntity.getAccountConcept())
                .nitClearingEntity(participantAccountEntity.getNitClearingEntity())

                .build();
    }

    public static ParticipantAssociatedAccountOutDto participantBankAccountEntityToParticipantAssociatedAccountOutDto(
            ParticipantBankAccountEntity participantBankAccountEntity) {
        if (participantBankAccountEntity == null) return null;

        return ParticipantAssociatedAccountOutDto.builder()
                .participantAccountId(null)
                .participantBankAccountId(participantBankAccountEntity.getId())

                .participantId(participantBankAccountEntity.getParticipant() != null
                        ? participantBankAccountEntity.getParticipant().getId() : null)

                .participant(ObjectUtils.isEmpty(participantBankAccountEntity.getParticipant())
                        ? null : participantEntityToParticipantOutDto(participantBankAccountEntity.getParticipant()))
                .status(ObjectUtils.isEmpty(participantBankAccountEntity.getStatus())
                        ? null : statusEntityToStatusOutDto(participantBankAccountEntity.getStatus()))
                .type(ObjectUtils.isEmpty(participantBankAccountEntity.getType())
                        ? null : typeEntityToTypeOutDto(participantBankAccountEntity.getType()))
                .originType(null)
                .depository(ObjectUtils.isEmpty(participantBankAccountEntity.getDepository())
                        ? null : depositoryEntityToDepositoryOutDto(participantBankAccountEntity.getDepository()))
                .bank(ObjectUtils.isEmpty(participantBankAccountEntity.getBank())
                        ? null : bankEntityToBankOutDto(participantBankAccountEntity.getBank()))
                .country(ObjectUtils.isEmpty(participantBankAccountEntity.getCountry())
                        ? null : countryEntityToCountryOutDto(participantBankAccountEntity.getCountry()))
                .currency(ObjectUtils.isEmpty(participantBankAccountEntity.getCurrency())
                        ? null : currencyEntityToCurrencyOutDto(participantBankAccountEntity.getCurrency()))

                .accountNumber(participantBankAccountEntity.getBankAccount())
                .bankAccount(participantBankAccountEntity.getBankAccount())
                .entityCode(participantBankAccountEntity.getEntityCode())
                .swiftCode(participantBankAccountEntity.getSwiftCode())
                .principal(participantBankAccountEntity.getPrincipal())
                .branchCode(participantBankAccountEntity.getBranchCode())
                .portfolio(participantBankAccountEntity.getPortfolio())
                .concept(participantBankAccountEntity.getAccountConcept())
                .nitClearingEntity(participantBankAccountEntity.getNitClearingEntity())

                .build();
    }


    public static ParticipantInvestorOutDto participantInvestorEntityToParticipantInvestorOutDto(
            ParticipantInvestorEntity participantInvestorEntity) {
        return ParticipantInvestorOutDto.builder()
                .participant(participantEntityToParticipantOutDto(participantInvestorEntity.getParticipant()))
                .investor(investorEntityToInvestorOutDto(participantInvestorEntity.getInvestor()))
                .build();
    }

    public static InvestorOutDto investorEntityToInvestorOutDto(InvestorEntity investorEntity) {
        return InvestorOutDto.builder()
                .id(investorEntity.getId())
                .code(investorEntity.getCode())
                .firstName(investorEntity.getFirstName())
                .lastName(investorEntity.getLastName())
                .companyName(investorEntity.getCompanyName())
                .type(ObjectUtils.isEmpty(investorEntity.getType())
                        ? null : typeEntityToTypeOutDto(investorEntity.getType()))
                .status(ObjectUtils.isEmpty(investorEntity.getStatus())
                        ? null : statusEntityToStatusOutDto(investorEntity.getStatus()))
                .country(ObjectUtils.isEmpty(investorEntity.getCountry()) ?
                        null : countryEntityToCountryOutDto(investorEntity.getCountry()))
                .department(ObjectUtils.isEmpty(investorEntity.getDepartment())
                        ? null : departmentEntityToDepartmentOutDto(investorEntity.getDepartment()))
                .city(ObjectUtils.isEmpty(investorEntity.getCity())
                        ? null : cityEntityToCityOutDto(investorEntity.getCity()))
                .documentNumber(investorEntity.getDocumentNumber())
                .documentType(investorEntity.getDocumentType())
                .nationality(investorEntity.getNationality())
                .address(investorEntity.getAddress())
                .phoneNumber(investorEntity.getPhoneNumber())
                .email(investorEntity.getEmail())
                .clearinghouseCode(investorEntity.getClearinghouseCode())
                .gics(ObjectUtils.isEmpty(investorEntity.getGics())
                        ? null : gicsEntityToGicsOutDto(investorEntity.getGics()))
                .moneyLaunderingFlag(investorEntity.getMoneyLaunderingFlag())
                .taxStatus(ObjectUtils.isEmpty(investorEntity.getTaxStatus())
                        ? null : taxStatusEntityToTaxStatusOutDto(investorEntity.getTaxStatus()))
                .build();
    }

    public static StatusOutDto statusEntityToStatusOutDto(StatusEntity statusEntity) {
        return StatusOutDto.builder()
                .id(statusEntity.getId())
                .description(statusEntity.getDescription())
                .category(statusEntity.getCategory())
                .build();
    }

    public static TypeOutDto typeEntityToTypeOutDto(TypeEntity typeEntity) {
        if (typeEntity == null) return null;
        return TypeOutDto.builder()
                .id(typeEntity.getId())
                .description(typeEntity.getDescription())
                .category(typeEntity.getCategory())
                .detail(typeEntity.getDetail())
                .build();
    }

    public static DepartmentOutDto departmentEntityToDepartmentOutDto(DepartmentEntity departmentEntity) {
        return DepartmentOutDto.builder()
                .id(departmentEntity.getId())
                .description(departmentEntity.getDescription())
                .country(ObjectUtils.isEmpty(departmentEntity.getCountry())
                        ? null : countryEntityToCountryOutDto(departmentEntity.getCountry()))
                .build();
    }

    public static CityOutDto cityEntityToCityOutDto(CityEntity cityEntity) {
        return CityOutDto.builder()
                .id(cityEntity.getId())
                .country(ObjectUtils.isEmpty(cityEntity.getCountry()) ? null : countryEntityToCountryOutDto(cityEntity.getCountry()))
                .code(safeParseInteger(cityEntity.getCode()))
                .description(cityEntity.getDescription())
                .build();
    }

    public static GicsOutDto gicsEntityToGicsOutDto(GicsEntity gicsEntity) {
        return GicsOutDto.builder()
                .id(gicsEntity.getId())
                .description(gicsEntity.getDescription())
                .build();
    }

    public static TaxStatusOutDto taxStatusEntityToTaxStatusOutDto(TaxStatusEntity taxStatusEntity) {
        return TaxStatusOutDto.builder()
                .id(taxStatusEntity.getId())
                .description(taxStatusEntity.getDescription())
                .build();
    }

    public static IdentificationTypeOutDto identificationTypeEntityToIdentificationTypeOutDto(
            IdentificationTypeEntity identificationTypeEntity) {
        return IdentificationTypeOutDto.builder()
                .id(identificationTypeEntity.getId())
                .description(identificationTypeEntity.getDescription())
                .build();
    }

    public static DepositoryOutDto depositoryEntityToDepositoryOutDto(DepositoryEntity depositoryEntity) {
        return DepositoryOutDto.builder()
                .id(depositoryEntity.getId())
                .description(depositoryEntity.getDescription())
                .build();
    }

    public static EnterpriseGroupOutDto enterpriseGroupEntityToEnterpriseGroupOutDto(EnterpriseGroupEntity enterpriseGroupEntity) {
        return EnterpriseGroupOutDto.builder()
                .id(enterpriseGroupEntity.getId())
                .code(enterpriseGroupEntity.getCode())
                .name(enterpriseGroupEntity.getName())
                .detail(enterpriseGroupEntity.getDetail())
                .canceled(enterpriseGroupEntity.getCanceled())
                .status(ObjectUtils.isEmpty(enterpriseGroupEntity.getStatus())
                        ? null : statusEntityToStatusOutDto(enterpriseGroupEntity.getStatus()))
                .build();
    }

    public static SystemOutDto systemEntityToSystemOutDto(SystemEntity systemEntity) {
        if (systemEntity == null) return null;
        return SystemOutDto.builder()
                .id(systemEntity.getId())
                .code(systemEntity.getCode())
                .description(systemEntity.getDescription())
                .category(systemEntity.getCategory())
                .build();
    }

    public static BankOutDto bankEntityToBankOutDto(BankEntity bankEntity) {
        if (bankEntity == null) return null;
        return BankOutDto.builder()
                .id(bankEntity.getId())
                .country(ObjectUtils.isEmpty(bankEntity.getCountry()) ? null : countryEntityToCountryOutDto(bankEntity.getCountry()))
                .bankCode(bankEntity.getBankCode())
                .bankName(bankEntity.getBankName())
                .build();
    }

    public static ParticipantBankAccountOutDto participantBankAccountEntityToOutDto(
            ParticipantBankAccountEntity participantBankAccountEntity) {
        if (participantBankAccountEntity == null) return null;
        return ParticipantBankAccountOutDto.builder()
                .id(participantBankAccountEntity.getId())
                .participant(ObjectUtils.isEmpty(participantBankAccountEntity.getParticipant())
                        ? null : MapperUtil.participantEntityToParticipantOutDto(participantBankAccountEntity.getParticipant()))
                .bankAccount(participantBankAccountEntity.getBankAccount())
                .status(ObjectUtils.isEmpty(participantBankAccountEntity.getStatus())
                        ? null : MapperUtil.statusEntityToStatusOutDto(participantBankAccountEntity.getStatus()))
                .type(ObjectUtils.isEmpty(participantBankAccountEntity.getType())
                        ? null : MapperUtil.typeEntityToTypeOutDto(participantBankAccountEntity.getType()))
                .bank(ObjectUtils.isEmpty(participantBankAccountEntity.getBank())
                        ? null : MapperUtil.bankEntityToBankOutDto(participantBankAccountEntity.getBank()))
                .country(ObjectUtils.isEmpty(participantBankAccountEntity.getCountry())
                        ? null : MapperUtil.countryEntityToCountryOutDto(participantBankAccountEntity.getCountry()))
                .entityCode(participantBankAccountEntity.getEntityCode())
                .swiftCode(participantBankAccountEntity.getSwiftCode())
                .principal(participantBankAccountEntity.getPrincipal())
                .branchCode(participantBankAccountEntity.getBranchCode())
                .portfolio(participantBankAccountEntity.getPortfolio())
                .accountConcept(participantBankAccountEntity.getAccountConcept())
                .nitClearingEntity(participantBankAccountEntity.getNitClearingEntity())
                .build();
    }

    public static ParticipantAuthorizationOutDto participantAuthorizationEntityToParticipantAuthorizationOutDto(
            ParticipantAuthorizationEntity participantAuthorizationEntity) {
        if (participantAuthorizationEntity == null) return null;
        return ParticipantAuthorizationOutDto.builder()
                .participant(ObjectUtils.isEmpty(participantAuthorizationEntity.getParticipant())
                        ? null : MapperUtil.participantEntityToParticipantOutDto(participantAuthorizationEntity.getParticipant()))
                .authorizedParticipant(ObjectUtils.isEmpty(participantAuthorizationEntity.getAuthorizedParticipant())
                        ? null : MapperUtil.participantEntityToParticipantOutDto(participantAuthorizationEntity.getAuthorizedParticipant()))
                .type(ObjectUtils.isEmpty(participantAuthorizationEntity.getType())
                        ? null : MapperUtil.typeEntityToTypeOutDto(participantAuthorizationEntity.getType()))
                .build();
    }

    public static ParticipantSuspendedHistoryOutDto participantSuspendedHistoryEntityToParticipantSuspendedHistoryOutDto(
            ParticipantSuspendedHistoryEntity participantSuspendedHistoryEntity) {
        if (participantSuspendedHistoryEntity == null) return null;
        return ParticipantSuspendedHistoryOutDto.builder()
                .id(participantSuspendedHistoryEntity.getId())
                .participant(participantEntityToParticipantBlockOutDto(participantSuspendedHistoryEntity.getParticipant()))
                .actionType(typeEntityToTypeOutDto(participantSuspendedHistoryEntity.getActionType()))
                .processType(typeEntityToTypeOutDto(participantSuspendedHistoryEntity.getProcessType()))
                .effectiveDate(participantSuspendedHistoryEntity.getEffectiveDate())
                .description(participantSuspendedHistoryEntity.getDescription())
                .lastModifyUser(participantSuspendedHistoryEntity.getLastModifyUser())
                .lastModifyDate(participantSuspendedHistoryEntity.getLastModifyDate())
                .build();
    }

    public static ParticipantOutDto participantEntityToParticipantBlockOutDto(ParticipantEntity participantEntity) {
        return ParticipantOutDto.builder()
                .id(participantEntity.getId())
                .code(participantEntity.getCode())
                .documentNumber(participantEntity.getDocumentNumber())
                .identificationType(ObjectUtils.isEmpty(participantEntity.getIdentificationType())
                        ? null : identificationTypeEntityToIdentificationTypeOutDto(participantEntity.getIdentificationType()))
                .name(participantEntity.getName())
                .status(ObjectUtils.isEmpty(participantEntity.getStatus()) ? null : statusEntityToStatusOutDto(participantEntity.getStatus()))
                .build();
    }

    private static Integer safeParseInteger(String value) {
        if (value == null) return null;
        try {
            return Integer.valueOf(value.trim());
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    public static com.nubo.masterparticipant.api.models.dto.response.ParticipantShortOutDto participantEntityToParticipantShortOutDto(ParticipantEntity participantEntity) {
        return com.nubo.masterparticipant.api.models.dto.response.ParticipantShortOutDto.builder()
                .id(participantEntity.getId())
                .code(participantEntity.getCode())
                .name(participantEntity.getName())
                .build();
    }
}
