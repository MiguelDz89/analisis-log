package com.nubo.masterparticipant.api.service;

import com.nubo.masterparticipant.api.models.dto.response.PageResponseOutDto;
import com.nubo.masterparticipant.api.models.dto.response.ParticipantAuthorizationOutDto;


public interface ParticipantAuthorizationService {

    PageResponseOutDto<ParticipantAuthorizationOutDto> findAllParticipantAuthorization(
            int page,
            int size,
            String sort,
            String order,
            boolean all,
            Long participantId,
            Long authorizedParticipantId,
            Long typeId
    );

}
