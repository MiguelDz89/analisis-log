package com.nubo.masterparticipant.api.models.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "\"PARTICIPANT\"", schema = "\"NUANBODB\"")
public class ParticipantEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "\"PARTICIPANT_ID\"", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "\"ENTERPRISE_GROUP_ID\"")
    private EnterpriseGroupEntity enterpriseGroup;

    @Column(name = "\"CODE\"", length = 6)
    private String code;

    @Column(name = "\"DOCUMENT_NUMBER\"", length = 20)
    private String documentNumber;

    @ManyToOne
    @JoinColumn(name = "\"IDENTIFICATION_TYPE_ID\"", nullable = false)
    private IdentificationTypeEntity identificationType;

    @Column(name = "\"NAME\"", length = 100)
    private String name;

    @Column(name = "\"SHORT_NAME\"", length = 50)
    private String shortName;

    @ManyToOne
    @JoinColumn(name = "\"TYPE_ID\"", nullable = false)
    private TypeEntity type;

    @ManyToOne
    @JoinColumn(name = "\"COUNTRY_ID\"", nullable = false)
    private CountryEntity country;

    @Column(name = "\"REGISTRATION_DATE\"")
    private LocalDate registrationDate;

    @Column(name = "\"TAX_CODE\"", length = 20)
    private String taxCode;

    @ManyToOne
    @JoinColumn(name = "\"DEPARTMENT_ID\"")
    private DepartmentEntity department;

    @Column(name = "\"MAIN_ADDRESS\"", length = 100)
    private String mainAddress;

    @Column(name = "\"WEB_PAGE\"", length = 100)
    private String webPage;

    @Column(name = "\"PHONE_NUMBER\"", length = 20)
    private String phoneNumber;

    @ManyToOne
    @JoinColumn(name = "\"STATUS_ID\"", nullable = false)
    private StatusEntity status;

    @ManyToOne
    @JoinColumn(name = "\"TAX_STATUS_ID\"", nullable = false)
    private TaxStatusEntity taxStatus;

    @ManyToOne
    @JoinColumn(name = "\"ENTITY_TYPE_ID\"", nullable = false)
    private TypeEntity entityType;

    @Column(name = "\"DIRECT_ALLOCATION\"", length = 1)
    private String directAllocation;

    @Column(name = "\"MARKET_MAKER\"", length = 1)
    private String marketMaker;

    @Column(name = "\"CUSTODIAN\"", nullable = true)
    private Boolean custodian;

    @ManyToOne
    @JoinColumn(name = "\"CITY_ID\"", nullable = true)
    private CityEntity city;

    @Column(name = "\"CANCELED_STATUS\"")
    private Boolean canceledStatus;

    @ManyToOne
    @JoinColumn(name = "\"REGISTERED_SYSTEM_ID\"")
    private SystemEntity registeredSystem;

    @Column(name = "\"DCV_RV_OPERS_AUTH\"")
    private Boolean dcvRvOpersAuth;

    @Column(name = "\"DCV_RV_SETTLEMENT_AUTH\"")
    private Boolean dcvRvSettlementAuth;

    @Column(name = "\"DIRECT_OPERATOR_AGREEMENTS\"")
    private Boolean directOperatorAgreements;

    @Column(name = "\"OTC_LOAN_RELATIONSHIP\"")
    private Boolean otcLoanRelationship;

    @Column(name = "\"SUSPENDED_NEGOTIATION\"")
    private Boolean suspendedNegotiation;

    @Column(name = "\"SUSPENDED_EFFECTIVE_DATE\"")
    private LocalDate suspendedEffectiveDate;

    @ManyToOne
    @JoinColumn(name = "\"SUSPENDED_PROCESS_TYPE_ID\"")
    private TypeEntity suspendedProcessType;

    @ManyToOne
    @JoinColumn(name = "\"MASTER_ACCOUNT_ID\"")
    private ParticipantAccountEntity masterAccount;

    @ManyToOne
    @JoinColumn(name = "\"OWN_ACCOUNT_ID\"")
    private ParticipantAccountEntity ownAccount;

    @Column(name = "\"EQUITY\"", precision = 16, scale = 4)
    private BigDecimal equity;

    @ManyToOne
    @JoinColumn(name = "\"CURRENCY_ID\"")
    private CurrencyEntity currency;

    @Column(name = "\"LAST_MODIFY_USER\"", length = 250)
    private String lastModifyUser;

    @Column(name = "\"LAST_MODIFY_APPLIC\"", length = 250)
    private String lastModifyApplication;

    @Column(name = "\"LAST_MODIFY_DATE\"")
    private LocalDateTime lastModifyDate;

    @Column(name = "\"LAST_MODIFY_IP\"", length = 50)
    private String lastModifyIp;

}