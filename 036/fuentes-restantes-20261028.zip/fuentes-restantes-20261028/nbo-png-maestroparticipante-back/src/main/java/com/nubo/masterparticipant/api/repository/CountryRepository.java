package com.nubo.masterparticipant.api.repository;

import com.nubo.masterparticipant.api.models.entity.CountryEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CountryRepository extends JpaRepository<CountryEntity, Long> {

    Optional<CountryEntity> findByCode(String code);

    List<CountryEntity> findByCodeInOrderByNameAsc(List<String> codes);
}
