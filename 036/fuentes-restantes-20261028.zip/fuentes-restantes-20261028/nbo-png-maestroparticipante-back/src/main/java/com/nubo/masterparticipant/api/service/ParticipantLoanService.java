package com.nubo.masterparticipant.api.service;

import com.nubo.masterparticipant.api.models.dto.response.PageResponseOutDto;
import com.nubo.masterparticipant.api.models.dto.response.ParticipantLoanOutDto;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ParticipantLoanService {

    ParticipantLoanOutDto getById(Long id, Long[] types, String countryCode);

    ParticipantLoanOutDto getByCode(String code, Long[] types, String countryCode);

    List<ParticipantLoanOutDto> getByCodePrefix(String prefix, Long[] types, String countryCode);

    PageResponseOutDto<ParticipantLoanOutDto> getAll(Pageable pageable, Long[] types, String countryCode);

    List<ParticipantLoanOutDto> getByShortnamePrefix(String prefix, Long[] types, String countryCode);

}
