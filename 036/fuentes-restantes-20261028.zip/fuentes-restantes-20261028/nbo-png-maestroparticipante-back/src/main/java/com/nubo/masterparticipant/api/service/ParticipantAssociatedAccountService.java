package com.nubo.masterparticipant.api.service;

import com.nubo.masterparticipant.api.models.dto.response.PageResponseOutDto;
import com.nubo.masterparticipant.api.models.dto.response.ParticipantAssociatedAccountOutDto;
import com.nubo.masterparticipant.api.models.dto.response.ParticipantBankAccountFilterOutDto;
import com.nubo.masterparticipant.api.models.enums.AccountSourceEnum;

public interface ParticipantAssociatedAccountService {

    PageResponseOutDto<ParticipantAssociatedAccountOutDto> findAccountsAssociatedByParticipant(
            Long participantId,
            AccountSourceEnum source,
            int page,
            int size,
            String sort,
            String order,
            boolean all,
            String depositoryId,
            Long accountTypeId,
            String accountNumber,
            Long currencyId,
            String currencyName
    );

    PageResponseOutDto<ParticipantBankAccountFilterOutDto> searchParticipantBankAccounts(
            Long participantId,
            String account,
            Long typeId,
            Long statusId,
            int page,
            int size,
            String sort,
            String order,
            boolean all
    );
}
