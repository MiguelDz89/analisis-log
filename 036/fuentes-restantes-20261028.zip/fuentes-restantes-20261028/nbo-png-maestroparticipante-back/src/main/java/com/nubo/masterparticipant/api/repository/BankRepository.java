package com.nubo.masterparticipant.api.repository;

import com.nubo.masterparticipant.api.models.entity.BankEntity;
import org.springframework.data.jpa.repository.JpaRepository;


public interface BankRepository extends JpaRepository<BankEntity, Long> {
}
