package com.nubo.masterparticipant.api.repository;

import com.nubo.masterparticipant.api.models.entity.DirectDepositoryEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface DirectDepositoryRepository extends JpaRepository<DirectDepositoryEntity, Long> ,
        JpaSpecificationExecutor<DirectDepositoryEntity> {

    @Query("SELECT d FROM DirectDepositoryEntity d WHERE d.participant.id = :participantId")
    List<DirectDepositoryEntity> findByParticipantId(Long participantId);

}
