package com.nubo.masterparticipant.api.service;

import org.springframework.stereotype.Repository;

import com.nubo.masterparticipant.api.models.dto.request.ParticipantInvestorInDto;
import com.nubo.masterparticipant.api.models.dto.response.PageResponseOutDto;
import com.nubo.masterparticipant.api.models.dto.response.ParticipantInvestorOutDto;

@Repository
public interface ParticipantInvestorService {

    PageResponseOutDto<ParticipantInvestorOutDto> findAllParticipantInvestor(
            int page, int size, String sort, String order, boolean all, Long participantId, Long investorId);

    ParticipantInvestorOutDto createParticipantInvestor(ParticipantInvestorInDto participantInvestorInDto);
}
