package com.nubo.masterparticipant.api.repository;

import com.nubo.masterparticipant.api.models.entity.ParticipantBankAccountEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface ParticipantBankAccountRepository extends JpaRepository<ParticipantBankAccountEntity, Long>,
        JpaSpecificationExecutor<ParticipantBankAccountEntity> {


}