package com.nubo.masterparticipant.api.repository;

import com.nubo.masterparticipant.api.models.entity.TypeEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TypeRepository extends JpaRepository<TypeEntity, Long> {

    List<TypeEntity> findByCategoryIgnoreCase(String category);
}
