package com.nubo.masterparticipant.api.service;

import com.nubo.masterparticipant.api.models.dto.response.PageResponseOutDto;
import com.nubo.masterparticipant.api.models.dto.response.ParticipantBankAccountOutDto;
import org.springframework.data.domain.Pageable;

public interface ParticipantBankAccountService {

    PageResponseOutDto<ParticipantBankAccountOutDto> findAllParticipantBankAccount(Pageable pageable,
                                                                                          Long bankId,
                                                                                          Long typeId,
                                                                                          String bankAccount,
                                                                                          Long countryId,
                                                                                          Long statusId,
                                                                                          Boolean principal);

    ParticipantBankAccountOutDto findParticipantBankAccountById(Long id);
}
