package com.nubo.masterparticipant.api.repository;

import com.nubo.masterparticipant.api.models.entity.ParticipantEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ParticipantLoanRepository extends JpaRepository<ParticipantEntity, Long> {

        // ---------- BASE SELECT ----------
        String BASE_SELECT = """
        SELECT
            p."PARTICIPANT_ID",
            p."CODE",
            p."NAME",
            p."SHORT_NAME",
            t."DESCRIPTION",
            c."NAME",
            c."CODE",
            s."DESCRIPTION",
            p."CUSTODIAN",
            p."DOCUMENT_NUMBER",
            p."MARGIN_ACCOUNT",
            p."TYPE_ENTITY",
            p."TAX_CODE",
            p."OTC_LOAN_RELATIONSHIP",
            
            
            ts."TAX_STATUS_ID",
            ts."DESCRIPTION",
        
            t."TYPE_ID",
            t."DESCRIPTION" AS TYPE_DESCRIPTION,
           
            it."CODE" AS IDENTIFICATION_TYPE_CODE,
            
            p."EQUITY" AS EQUITY
                        
        FROM "NUANBODB"."PARTICIPANT" p
        INNER JOIN "NUANBODB"."TYPE" t ON p."TYPE_ID" = t."TYPE_ID"
        INNER JOIN "NUANBODB"."COUNTRY" c ON p."COUNTRY_ID" = c."COUNTRY_ID"
        INNER JOIN "NUANBODB"."STATUS" s ON p."STATUS_ID" = s."STATUS_ID"
        INNER JOIN "NUANBODB"."TAX_STATUS" ts ON ts."TAX_STATUS_ID" = p."TAX_STATUS_ID"
        INNER JOIN "NUANBODB"."IDENTIFICATION_TYPE" it ON it."IDENTIFICATION_TYPE_ID" = p."IDENTIFICATION_TYPE_ID"
        WHERE p."OTC_LOAN_RELATIONSHIP" = TRUE
        """;

        // FIND BY ID
        @Query(value = BASE_SELECT + """
        AND p."PARTICIPANT_ID" = :id
        AND (:countryCode IS NULL OR p."COUNTRY_ID" = :countryCode)
        """, nativeQuery = true)
        List<Object[]> findLoanById(@Param("id") Long id, @Param("countryCode") Long countryCode);

        @Query(value = BASE_SELECT + """
        AND p."PARTICIPANT_ID" = :id
        AND t."TYPE_ID" IN (:types)
        AND (:countryCode IS NULL OR p."COUNTRY_ID" = :countryCode)
        """, nativeQuery = true)
        List<Object[]> findLoanByIdAndTypes(@Param("id") Long id, @Param("types") List<Long> types, @Param("countryCode") Long countryCode);


        // FIND BY CODE
        @Query(value = BASE_SELECT + """
        AND p."CODE" = :code
        AND (:countryCode IS NULL OR p."COUNTRY_ID" = :countryCode)
        """, nativeQuery = true)
        List<Object[]> findLoanByCode(@Param("code") String code, @Param("countryCode") Long countryCode);

        @Query(value = BASE_SELECT + """
        AND p."CODE" = :code
        AND t."TYPE_ID" IN (:types)
        AND (:countryCode IS NULL OR p."COUNTRY_ID" = :countryCode)
        """, nativeQuery = true)
        List<Object[]> findLoanByCodeAndTypes(@Param("code") String code, @Param("types") List<Long> types, @Param("countryCode") Long countryCode);

        // FIND BY CODE PREFIX
        @Query(value = BASE_SELECT + """
        AND p."CODE" LIKE CONCAT(:prefix, '%')
        AND (:countryCode IS NULL OR p."COUNTRY_ID" = :countryCode)
        """, nativeQuery = true)
        List<Object[]> findByCodePrefix(@Param("prefix") String prefix, @Param("countryCode") Long countryCode);

        @Query(value = BASE_SELECT + """
        AND p."CODE" LIKE CONCAT(:prefix, '%')
        AND t."TYPE_ID" IN (:types)
        AND (:countryCode IS NULL OR p."COUNTRY_ID" = :countryCode)
        """, nativeQuery = true)
        List<Object[]> findByCodePrefixAndTypes(@Param("prefix") String prefix, @Param("types") List<Long> types, @Param("countryCode") Long countryCode);

        // FIND BY SHORTNAME PREFIX
        @Query(value = BASE_SELECT + """
        AND p."SHORT_NAME" LIKE CONCAT(:prefix, '%')
        AND (:countryCode IS NULL OR p."COUNTRY_ID" = :countryCode)
        """, nativeQuery = true)
        List<Object[]> findByShortnamePrefix(@Param("prefix") String prefix, @Param("countryCode") Long countryCode);

        @Query(value = BASE_SELECT + """
        AND p."SHORT_NAME" LIKE CONCAT(:prefix, '%')
        AND t."TYPE_ID" IN (:types)
        AND (:countryCode IS NULL OR p."COUNTRY_ID" = :countryCode)
        """, nativeQuery = true)
        List<Object[]> findByShortnamePrefixAndTypes(@Param("prefix") String prefix, @Param("types") List<Long> types, @Param("countryCode") Long countryCode);

        // LIST PAGINATED
        @Query(value = BASE_SELECT + """
        AND (:countryCode IS NULL OR p."COUNTRY_ID" = :countryCode)
        ORDER BY p."PARTICIPANT_ID"
        LIMIT :size OFFSET :offset
        """, nativeQuery = true)
        List<Object[]> findAllLoanParticipants(
                @Param("size") int size,
                @Param("offset") int offset,
                @Param("countryCode") Long countryCode
        );

        @Query(value = BASE_SELECT + """
        AND t."TYPE_ID" IN (:types)
        AND (:countryCode IS NULL OR p."COUNTRY_ID" = :countryCode)
        ORDER BY p."PARTICIPANT_ID"
        LIMIT :size OFFSET :offset
        """, nativeQuery = true)
        List<Object[]> findAllLoanParticipantsAndTypes(
                @Param("size") int size,
                @Param("offset") int offset,
                @Param("types") List<Long> types,
                @Param("countryCode") Long countryCode
        );

        // COUNT
        @Query(value = """
        SELECT COUNT(*)
        FROM "NUANBODB"."PARTICIPANT" p
        WHERE p."OTC_LOAN_RELATIONSHIP" = TRUE
        AND (:countryCode IS NULL OR p."COUNTRY_ID" = :countryCode)
        """, nativeQuery = true)
        long countLoanParticipants(@Param("countryCode") Long countryCode);

        @Query(value = """
        SELECT COUNT(*)
        FROM "NUANBODB"."PARTICIPANT" p
        INNER JOIN "NUANBODB"."TYPE" t ON p."TYPE_ID" = t."TYPE_ID"
        WHERE p."OTC_LOAN_RELATIONSHIP" = TRUE
        AND t."TYPE_ID" IN (:types)
        AND (:countryCode IS NULL OR p."COUNTRY_ID" = :countryCode)
        """, nativeQuery = true)
        long countLoanParticipantsByTypes(@Param("types") List<Long> types, @Param("countryCode") Long countryCode);
    }
