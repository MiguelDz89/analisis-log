package com.nubo.masterparticipant.api.service;

import com.nubo.masterparticipant.api.models.dto.request.ParamsPageInDto;
import com.nubo.masterparticipant.api.models.dto.response.PageResponseOutDto;
import com.nubo.masterparticipant.api.models.dto.response.ParticipantSuspendedHistoryOutDto;

public interface ParticipantSuspendedHistoryService {

    PageResponseOutDto<ParticipantSuspendedHistoryOutDto> findParticipantSuspendedHistory(
            ParamsPageInDto paramsPageInDto, Long participantId);

}
