package com.nubo.masterparticipant.api.repository;

import com.nubo.masterparticipant.api.models.entity.CityEntity;
import com.nubo.masterparticipant.api.models.entity.EnterpriseGroupEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EnterpriseGroupRepository extends JpaRepository<EnterpriseGroupEntity, Long> {
}
