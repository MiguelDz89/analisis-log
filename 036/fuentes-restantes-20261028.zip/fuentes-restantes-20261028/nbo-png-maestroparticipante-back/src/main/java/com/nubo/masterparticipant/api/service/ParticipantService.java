package com.nubo.masterparticipant.api.service;

import com.nubo.masterparticipant.api.models.dto.request.ParticipantDetailUpdateInDto;
import com.nubo.masterparticipant.api.models.dto.request.ParticipantInDto;
import com.nubo.masterparticipant.api.models.dto.request.ParticipantUpdateInDto;
import com.nubo.masterparticipant.api.models.dto.response.PageResponseOutDto;
import com.nubo.masterparticipant.api.models.dto.response.ParticipantFilterOutDto;
import com.nubo.masterparticipant.api.models.dto.response.ParticipantOutDto;
import com.nubo.masterparticipant.api.models.dto.response.ParticipantShortOutDto;

import java.util.List;

public interface ParticipantService {

    PageResponseOutDto<ParticipantOutDto> findAllParticipant(
            int page, int size, String sort, String order, boolean all,
            String code, String name, String documentNumber, Long typeId, Long statusId);

    ParticipantOutDto findParticipantById(Long participantId);

    List<ParticipantOutDto> getParticipantByTrade(Long tradeId, int page, int size);

    PageResponseOutDto<ParticipantOutDto> searchParticipant(
            String text, int page, int size, String sort, String order, boolean all);

    ParticipantOutDto createParticipant(ParticipantInDto participantInDto);

    ParticipantOutDto updateParticipant(Long participantId, ParticipantUpdateInDto participantInDto);

    ParticipantOutDto updateDirectAllocation(Long participantId, String directAllocation);

    ParticipantOutDto updateParticipantDetail(Long participantId, ParticipantDetailUpdateInDto participantDetailUpdateInDto);

    PageResponseOutDto<ParticipantFilterOutDto> searchByCode(
            String code, int page, int size, String sort, String order, boolean all);

    PageResponseOutDto<ParticipantFilterOutDto> searchByName(
            String name, int page, int size, String sort, String order, boolean all);

    PageResponseOutDto<ParticipantFilterOutDto> listIdentifications(
            String documentNumber, int page, int size, String sort, String order, boolean all);

    PageResponseOutDto<ParticipantShortOutDto> findAllParticipantShort(
            int page, int size, String sort, String order, boolean all,
            String code, String name, String documentNumber, Long typeId, Long statusId, Long countryId);

}
