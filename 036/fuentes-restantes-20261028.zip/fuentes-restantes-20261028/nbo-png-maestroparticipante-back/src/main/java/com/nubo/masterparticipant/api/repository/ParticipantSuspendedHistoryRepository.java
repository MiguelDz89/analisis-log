package com.nubo.masterparticipant.api.repository;

import com.nubo.masterparticipant.api.models.entity.ParticipantSuspendedHistoryEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface ParticipantSuspendedHistoryRepository extends JpaRepository<ParticipantSuspendedHistoryEntity, Long>,
        JpaSpecificationExecutor<ParticipantSuspendedHistoryEntity> {
}
