package com.nubo.masterparticipant.api.repository;

import com.nubo.masterparticipant.api.models.entity.ParticipantAuthorizationEntity;
import com.nubo.masterparticipant.api.models.entity.ParticipantAuthorizationKey;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface ParticipantAuthorizationRepository extends JpaRepository<ParticipantAuthorizationEntity, ParticipantAuthorizationKey>,
        JpaSpecificationExecutor<ParticipantAuthorizationEntity> {
}


