package com.nubo.masterparticipant.api.repository;

import com.nubo.masterparticipant.api.models.dto.response.ParticipantFilterOutDto;
import com.nubo.masterparticipant.api.models.entity.ParticipantEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ParticipantRepository extends JpaRepository<ParticipantEntity, Long>,
        JpaSpecificationExecutor<ParticipantEntity> {

    @Query("SELECT p FROM ParticipantEntity p WHERE p.id IN " +
            "(SELECT t.participantIdBuy FROM TradeEntity t WHERE t.id = :tradeId) " +
            "OR p.id IN (SELECT t.participantIdSell FROM TradeEntity t WHERE t.id = :tradeId)")
    Page<ParticipantEntity> findParticipantsByTradeId(@Param("tradeId") Long tradeId, Pageable pageable);


    @Query("""
            select new com.nubo.masterparticipant.api.models.dto.response.ParticipantFilterOutDto(
                 p.id,
                 p.code,
                 p.name,
                 p.documentNumber,
                 p.shortName
            )
            from ParticipantEntity p
                where (:code is null or lower(p.code) like :code)
            """)
    Page<ParticipantFilterOutDto> findByCodeLike(String code, Pageable pageable);

    @Query("""
            select new com.nubo.masterparticipant.api.models.dto.response.ParticipantFilterOutDto(
                 p.id,
                 p.code,
                 p.name,
                 p.documentNumber,
                 p.shortName
            )
            from ParticipantEntity p
                where (:name is null or lower(p.name) like :name)
            """)
    Page<ParticipantFilterOutDto> findByNameLike(String name, Pageable pageable);

    @Query("""
            select new com.nubo.masterparticipant.api.models.dto.response.ParticipantFilterOutDto(
                 p.id,
                 p.code,
                 p.name,
                 p.documentNumber,
                 p.shortName
            )
            from ParticipantEntity p
                where (:doc is null or lower(p.documentNumber) like :doc)
                order by p.documentNumber asc
            """)
    Page<ParticipantFilterOutDto> findByDocumentNumberLikePageable(String doc, Pageable pageable);

}
