package com.nubo.masterparticipant.api.service;

import com.nubo.masterparticipant.api.models.dto.request.NoSuspendedParticipantInDto;
import com.nubo.masterparticipant.api.models.dto.request.SuspendedParticipantInDto;
import com.nubo.masterparticipant.api.models.dto.response.ParticipantSuspendedHistoryOutDto;

public interface ParticipantSuspendedService {

    ParticipantSuspendedHistoryOutDto suspendedParticipant(SuspendedParticipantInDto suspendedParticipantInDto);

    ParticipantSuspendedHistoryOutDto noSuspendedParticipant(NoSuspendedParticipantInDto noSuspendedParticipantInDto);

}
