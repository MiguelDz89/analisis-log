package com.nubo.masterparticipant.api.repository;

import com.nubo.masterparticipant.api.models.dto.response.ParticipantBankAccountFilterOutDto;
import com.nubo.masterparticipant.api.models.entity.ParticipantAccountEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ParticipantAccountRepository extends JpaRepository<ParticipantAccountEntity, Long>,
        JpaSpecificationExecutor<ParticipantAccountEntity> {

    @Query("SELECT DISTINCT pa FROM SettlementEntity s " +
            "JOIN ParticipantAccountEntity pa ON s.participantAccountId = pa.id " +
            "WHERE s.tradeId = :tradeId")
    Page<ParticipantAccountEntity> findParticipantAccountsByTradeId(@Param("tradeId") Long tradeId, Pageable pageable);

    @Query("""
        select new com.nubo.masterparticipant.api.models.dto.response.ParticipantBankAccountFilterOutDto(
            pba.id,
            pba.accountNumber,
            new com.nubo.masterparticipant.api.models.dto.response.StatusOutDto(
                s.id, s.description, s.category
            ),
            new com.nubo.masterparticipant.api.models.dto.response.TypeOutDto(
                t.id, t.description, t.category, t.detail
            )
        )
        from ParticipantAccountEntity pba
            join pba.participant p
            join p.identificationType it
            join pba.status s
            join pba.type t
        where (:participantId is null or p.id = :participantId)
          and (:account is null or lower(pba.accountNumber) like :account)
          and (:typeId is null or t.id = :typeId)
          and (:statusId is null or s.id = :statusId)
        """)
        //where (:code is null or lower(p.code) like :code)
    Page<ParticipantBankAccountFilterOutDto> findBankAccountsForFilter(
            @Param("participantId") Long participantId,
            @Param("account") String account,
            @Param("typeId") Long typeId,
            @Param("statusId") Long statusId,
            Pageable pageable
    );

}
