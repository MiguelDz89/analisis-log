package com.nubo.masterparticipant.api.repository;

import com.nubo.masterparticipant.api.models.entity.ParticipantAccountEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

public interface AccountLookupRepository extends Repository<ParticipantAccountEntity, Long>,
        JpaSpecificationExecutor<ParticipantAccountEntity> {

    @Query(
            value = """
            select q.account
            from (
                select pa."ACCOUNT_NUMBER" as account
                from "NUANBODB"."PARTICIPANT_ACCOUNT" pa
                where (:account is null or lower(pa."ACCOUNT_NUMBER") like lower(concat('%', :account, '%')))
                union
                select pba."BANK_ACCOUNT" as account
                from "NUANBODB"."PARTICIPANT_BANK_ACCOUNT" pba
                where (:account is null or lower(pba."BANK_ACCOUNT") like lower(concat('%', :account, '%')))
            ) q
            order by q.account
            """,
            countQuery = """
            select count(*) from (
                select pa."ACCOUNT_NUMBER" as account
                from "NUANBODB"."PARTICIPANT_ACCOUNT" pa
                where (:account is null or lower(pa."ACCOUNT_NUMBER") like lower(concat('%', :account, '%')))
                union
                select pba."BANK_ACCOUNT" as account
                from "NUANBODB"."PARTICIPANT_BANK_ACCOUNT" pba
                where (:account is null or lower(pba."BANK_ACCOUNT") like lower(concat('%', :account, '%')))
            ) c
            """,
            nativeQuery = true
    )
    Page<String> findAccountsForFilter(@Param("account") String account, Pageable pageable);
}
