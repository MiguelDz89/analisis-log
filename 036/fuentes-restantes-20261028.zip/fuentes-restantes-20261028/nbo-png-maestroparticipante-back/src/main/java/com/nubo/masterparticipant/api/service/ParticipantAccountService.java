package com.nubo.masterparticipant.api.service;

import com.nubo.masterparticipant.api.models.dto.request.ParamsPageInDto;
import com.nubo.masterparticipant.api.models.dto.request.ParticipantAccountInDto;
import com.nubo.masterparticipant.api.models.dto.request.ParticipantAccountUpdateInDto;
import com.nubo.masterparticipant.api.models.dto.response.PageResponseOutDto;
import com.nubo.masterparticipant.api.models.dto.response.ParticipantAccountOutDto;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ParticipantAccountService {

    PageResponseOutDto<ParticipantAccountOutDto> findAllParticipantAccount(Pageable pageable, String depositId,
                                                                           Long accountTypeId, String accountNumber, Long currencyId, Long statusId);

    ParticipantAccountOutDto findParticipantAccountById(Long participantAccountId);

    PageResponseOutDto<ParticipantAccountOutDto> findParticipantAccount(ParamsPageInDto paramsPageInDto, Long participantId, String text);

    List<ParticipantAccountOutDto> getParticipantAccountsByTrade(Long tradeId, Pageable pageable);

    ParticipantAccountOutDto createParticipantAccount(ParticipantAccountInDto participantAccountInDto);

    ParticipantAccountOutDto updateParticipantAccount(Long participantAccountId,
                                                      ParticipantAccountUpdateInDto participantAccountUpdateInDto);

}
