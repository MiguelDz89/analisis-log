package com.nubo.participants.synchronization.repository;

import com.nubo.participants.synchronization.models.entity.ParticipantEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ParticipantRepository extends JpaRepository<ParticipantEntity, Long> {
    Optional<ParticipantEntity> findFirstByCode(String code);
}
