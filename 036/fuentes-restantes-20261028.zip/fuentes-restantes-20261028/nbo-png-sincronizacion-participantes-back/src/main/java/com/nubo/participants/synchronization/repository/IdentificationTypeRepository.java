package com.nubo.participants.synchronization.repository;

import com.nubo.participants.synchronization.models.entity.IdentificationTypeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface IdentificationTypeRepository extends JpaRepository<IdentificationTypeEntity, Long> {

    @Query("""
            SELECT i FROM IdentificationTypeEntity i
            JOIN i.country c
            WHERE i.code = :code
            AND c.code = :countryCode
            """)
    Optional<IdentificationTypeEntity> findByCodeAndCountryCode(String code, String countryCode);
}
