package com.nubo.participants.synchronization.repository;

import com.nubo.participants.synchronization.models.entity.TypeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface TypeRepository extends JpaRepository<TypeEntity, Long> {

    Optional<TypeEntity> findByDescription(String description);

    @Query("""
            SELECT t FROM TypeEntity t
            WHERE LOWER(t.description) = LOWER(:description)
            AND t.category = :category
            ORDER BY t.id ASC
            """)
    Optional<TypeEntity> findDescriptionIgnoreCaseAndCategory(@Param("description") String description,
                                                              @Param("category") String category);
}

