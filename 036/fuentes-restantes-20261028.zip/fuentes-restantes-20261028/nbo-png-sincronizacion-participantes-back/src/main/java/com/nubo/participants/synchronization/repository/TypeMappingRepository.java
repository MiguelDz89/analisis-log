package com.nubo.participants.synchronization.repository;

import com.nubo.participants.synchronization.models.entity.TypeMappingEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface TypeMappingRepository extends JpaRepository<TypeMappingEntity, Long> {

    @Query("""
            SELECT tm FROM TypeMappingEntity tm
            WHERE tm.externalSystem = :externalSystem
            AND tm.externalCode = :externalCode
            AND tm.category = :category
            """)
    Optional<TypeMappingEntity> findByExternalSystemAndExternalCodeAndCategory(
            @Param("externalSystem") String externalSystem,
            @Param("externalCode") String externalCode,
            @Param("category") String category);

}
