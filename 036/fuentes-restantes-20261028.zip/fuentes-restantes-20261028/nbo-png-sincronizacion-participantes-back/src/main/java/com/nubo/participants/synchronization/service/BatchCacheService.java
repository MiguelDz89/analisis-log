package com.nubo.participants.synchronization.service;

import com.nubo.participants.synchronization.models.entity.*;

public interface BatchCacheService {

    TypeEntity findTypeEntityDescription(String typeDescription);

    TypeEntity findTypeEntityById(Long typeId);

    CountryEntity findCountryEntityByCode(String countryCode);

    StatusEntity findStatusEntityByDescription(String statusDescription);

    TaxStatusEntity findTaxStatusEntityByDescription(String taxStatusDescription);

    DepartmentEntity findDepartmentEntityById(String departmentId);

    CurrencyEntity findCurrencyEntityByCode(String currencyCode);

    IdentificationTypeEntity findIdentificationTypeByCodeAndCountry(String countryCode);

     TypeMappingEntity findTypeMappingByExternalCodeAndCategory(String externalCode, String category);

}
