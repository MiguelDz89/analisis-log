package com.nubo.participants.synchronization.service;

import com.nubo.participants.synchronization.models.dto.request.DataReferenceParticipantInDto;

public interface SynchronizationService {

    void synchronizeDataReferenceAndParticipants(DataReferenceParticipantInDto dataReferenceParticipantInDto);

}
