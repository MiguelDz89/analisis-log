package com.nubo.participants.synchronization.repository;

import com.nubo.participants.synchronization.models.entity.CountryEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface CountryRepository extends JpaRepository<CountryEntity, Long> {

    @Query("SELECT c FROM CountryEntity c WHERE c.code =:code")
    Optional<CountryEntity> findCountryByCode(String code);

    Optional<CountryEntity> findByCodeIgnoreCase(String code);

}
