package com.nubo.participants.synchronization.service;

import com.nubo.participants.synchronization.models.domain.ParticipantResult;
import com.nubo.participants.synchronization.models.dto.request.DataReferenceParticipantInDto;

public interface ParticipantNuboService {

    ParticipantResult createUpdateParticipant(DataReferenceParticipantInDto dataReferenceParticipantInDto);
}
