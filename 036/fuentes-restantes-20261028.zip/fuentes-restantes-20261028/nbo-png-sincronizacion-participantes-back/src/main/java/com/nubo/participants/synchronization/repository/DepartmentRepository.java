package com.nubo.participants.synchronization.repository;

import com.nubo.participants.synchronization.models.entity.DepartmentEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepartmentRepository extends JpaRepository<DepartmentEntity, String> {
}
