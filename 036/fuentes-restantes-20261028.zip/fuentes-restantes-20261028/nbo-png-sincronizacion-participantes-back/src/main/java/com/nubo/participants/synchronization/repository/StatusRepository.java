package com.nubo.participants.synchronization.repository;

import com.nubo.participants.synchronization.models.entity.StatusEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface StatusRepository extends JpaRepository<StatusEntity, Integer> {

    Optional<StatusEntity> findByDescription(String description);

    Optional<StatusEntity> findFirstByDescriptionIgnoreCaseAndCategoryIgnoreCase(String description, String category);

}

