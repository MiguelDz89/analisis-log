package com.nubo.participants.synchronization.repository;

import com.nubo.participants.synchronization.models.entity.TaxStatusEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface TaxStatusRepository extends JpaRepository<TaxStatusEntity, Long> {
    Optional<TaxStatusEntity> findByDescriptionIgnoreCase(String description);
}
