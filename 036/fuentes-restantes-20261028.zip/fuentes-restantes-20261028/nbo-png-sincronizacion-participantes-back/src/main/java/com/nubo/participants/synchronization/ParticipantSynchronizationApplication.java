package com.nubo.participants.synchronization;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParticipantSynchronizationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParticipantSynchronizationApplication.class, args);
	}

}
