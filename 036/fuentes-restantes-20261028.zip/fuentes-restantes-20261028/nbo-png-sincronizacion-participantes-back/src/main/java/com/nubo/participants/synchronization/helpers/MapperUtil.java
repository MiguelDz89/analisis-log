package com.nubo.participants.synchronization.helpers;

public final class MapperUtil {

    private MapperUtil() {
    }

}
