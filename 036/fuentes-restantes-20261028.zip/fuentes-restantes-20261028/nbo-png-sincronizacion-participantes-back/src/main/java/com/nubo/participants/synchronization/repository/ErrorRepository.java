package com.nubo.participants.synchronization.repository;

import com.nubo.participants.synchronization.models.entity.ErrorEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface ErrorRepository extends JpaRepository<ErrorEntity, Long> {

    @Query("SELECT e FROM ErrorEntity e WHERE e.code =:code")
    Optional<ErrorEntity> findErrorByCode(Integer code);
}