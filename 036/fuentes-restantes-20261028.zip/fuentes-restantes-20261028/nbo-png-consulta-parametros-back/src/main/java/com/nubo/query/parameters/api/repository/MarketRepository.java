package com.nubo.query.parameters.api.repository;

import com.nubo.query.parameters.api.models.entity.MarketEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MarketRepository extends JpaRepository<MarketEntity, String> {

    List<MarketEntity> findByCategory(String category);
}
