package com.nubo.query.parameters.api.repository;

import com.nubo.query.parameters.api.models.entity.TypeEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TypeRepository extends JpaRepository<TypeEntity, Long> {

    List<TypeEntity> findByCategory(String category);
}
