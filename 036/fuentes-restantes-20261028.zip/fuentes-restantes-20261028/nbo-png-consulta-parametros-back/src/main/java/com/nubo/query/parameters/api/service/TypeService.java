package com.nubo.query.parameters.api.service;

import com.nubo.query.parameters.api.models.dto.SelectOutDto;
import com.nubo.query.parameters.api.models.dto.TypeOutDto;

import java.util.List;

public interface TypeService {

    List<TypeOutDto> getTypeByCategory(String category);

    List<SelectOutDto> getOperationTypes();

}
