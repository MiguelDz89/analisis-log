package com.nubo.query.parameters.api.service;

import com.nubo.query.parameters.api.models.dto.SelectOutDto;
import com.nubo.query.parameters.api.models.dto.StatusOutDto;

import java.util.List;

public interface StatusService {
    List<StatusOutDto> getStatusByCategory(String category);

    List<SelectOutDto> getCustodianStatus();
}
