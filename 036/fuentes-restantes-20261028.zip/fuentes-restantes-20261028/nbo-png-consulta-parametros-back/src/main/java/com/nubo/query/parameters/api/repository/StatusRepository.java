package com.nubo.query.parameters.api.repository;

import com.nubo.query.parameters.api.models.entity.StatusEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface StatusRepository extends JpaRepository<StatusEntity, Integer> {

   List<StatusEntity> findByCategory(String category);

}
