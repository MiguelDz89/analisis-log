package com.nubo.query.parameters.api.service;

import java.util.List;

import com.nubo.query.parameters.api.models.dto.IdentificationTypeOutDto;

public interface IdentificationTypeService {

    List<IdentificationTypeOutDto> findAllIdentificationType();
}
