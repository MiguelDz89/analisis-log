package com.nubo.query.parameters.api.service;

import com.nubo.query.parameters.api.models.dto.MarketOutDto;

import java.util.List;

public interface MarketService {


    List<MarketOutDto> getMarketByCategory(String category);
}
