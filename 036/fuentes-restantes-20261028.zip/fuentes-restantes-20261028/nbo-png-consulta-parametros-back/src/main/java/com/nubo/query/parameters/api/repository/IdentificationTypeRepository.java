package com.nubo.query.parameters.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.nubo.query.parameters.api.models.entity.IdentificationTypeEntity;

public interface IdentificationTypeRepository extends JpaRepository<IdentificationTypeEntity, Long> {
}
