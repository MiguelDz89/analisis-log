package com.nubo.query.parameters.api.service;

import com.nubo.query.parameters.api.models.dto.PageResponseOutDto;
import com.nubo.query.parameters.api.models.dto.ParticipantOutDto;

public interface ParticipantsService {

    PageResponseOutDto<ParticipantOutDto> getParticipants(String search, int page, int size);

    PageResponseOutDto<ParticipantOutDto> getCustodians(String search, int page, int size);


}
