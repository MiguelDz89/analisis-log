package com.nubo.query.parameters.api.helpers;


import com.nubo.query.parameters.api.models.dto.SettlementSearchOutDto;
import com.nubo.query.parameters.api.models.dto.SideOutDto;
import com.nubo.query.parameters.api.models.entity.SettlementEntity;

public final class SettlementSearchMapper {

    private SettlementSearchMapper() {}

    public static SettlementSearchOutDto toDto(SettlementEntity s) {

        var trade = s.getTrade();

        return SettlementSearchOutDto.builder()
                .tradeId(trade.getId())
                .fraction(s.getFraction())

                .matchDate(trade.getMatchDate())
                .clearingDate(trade.getClearingDate())

                .market(trade.getMarket() != null ? trade.getMarket().getDescription() : null)
                .tradeType(trade.getType() != null ? trade.getType().getDescription() : null)
                .side(
                        s.getSide() != null
                                ? SideOutDto.builder()
                                .id(s.getSide().getId())
                                .description(s.getSide().getDescription())
                                .build()
                                : null
                )

                .symbol(
                        trade.getSecurityTitle() != null
                                ? trade.getSecurityTitle().getMnemonic()
                                : null
                )
                .isin(
                        trade.getSecurityTitle() != null
                                ? trade.getSecurityTitle().getIsin()
                                : null
                )

                .fractionQuantity(s.getFractionQuantity())
                .price(trade.getPrice())
                .fractionVolume(s.getFractionVolume())

                .participantCode(
                        s.getInvestorAccount() != null &&
                                s.getInvestorAccount().getParticipant() != null
                                ? s.getInvestorAccount().getParticipant().getCode()
                                : null
                )
                .participantName(
                        s.getInvestorAccount() != null &&
                                s.getInvestorAccount().getParticipant() != null
                                ? s.getInvestorAccount().getParticipant().getName()
                                : null
                )

                .investorDocumentType(
                        s.getInvestor() != null &&
                                s.getInvestor().getIdentificationType() != null
                                ? s.getInvestor().getIdentificationType().getDescription()
                                : null
                )
                .investorDocumentNumber(
                        s.getInvestor() != null
                                ? s.getInvestor().getDocumentNumber()
                                : null
                )
                .investorName(
                        s.getInvestor() != null
                                ? s.getInvestor().getCompanyName()
                                : null
                )
                .investorAccount(
                        s.getInvestorAccount() != null
                                ? s.getInvestorAccount().getAccountNumber()
                                : null
                )

                .custodianId(
                        s.getCustodian() != null ? s.getCustodian().getId() : null
                )
                .custodianName(
                        s.getCustodian() != null ? s.getCustodian().getName() : null
                )
                .custodianStatus(
                        s.getCustodianStatus() != null
                                ? s.getCustodianStatus().getDescription()
                                : null
                )

                .cashAccount(s.getCashAccount())
                .rejectionReason(s.getRejectionReason())

                .build();
    }
}
