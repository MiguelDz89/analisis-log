package com.nubo.query.parameters.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.nubo.query.parameters.api.models.entity.ParticipantEntity;

public interface ParticipantRepository
        extends JpaRepository<ParticipantEntity, Long>, JpaSpecificationExecutor<ParticipantEntity> {
}
