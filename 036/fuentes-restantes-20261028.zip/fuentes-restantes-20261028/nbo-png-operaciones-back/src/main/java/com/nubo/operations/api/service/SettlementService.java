package com.nubo.operations.api.service;

import org.springframework.data.domain.Pageable;

import com.nubo.operations.api.models.dto.request.SettlementCommissionUpdateInDto;
import com.nubo.operations.api.models.dto.request.SettlementUpdateInDto;
import com.nubo.operations.api.models.dto.response.PageResponseOutDto;
import com.nubo.operations.api.models.dto.response.SettlementOutDto;
import com.nubo.operations.api.models.entity.SettlementKey;

public interface SettlementService {

    PageResponseOutDto<SettlementOutDto> findAllSettlements(Pageable pageable, Long tradeId, String sideId, String investorDocumentNumber);

    PageResponseOutDto<SettlementOutDto> findAllSettlements(int page, int size, String sort, String order, boolean all, Long tradeId, String sideId, String investorDocumentNumber);

    PageResponseOutDto<SettlementOutDto> findAllSettlementsDynamic(
            Pageable pageable,
            Long tradeId,
            String sideId,
            String investorDocumentNumber,
            String fieldName,
            String fieldValue,
            String operation);

    SettlementOutDto findSettlementById(SettlementKey settlementKey);

    SettlementOutDto updateSettlement(SettlementKey settlementKey, SettlementUpdateInDto settlementUpdateInDto);

    PageResponseOutDto<SettlementOutDto> findAllSettlementsByTrade(Pageable pageable, Long tradeId);

    PageResponseOutDto<SettlementOutDto> findAllSettlementsByTrade(int page, int size, String sort, String order, boolean all, Long tradeId);

    SettlementOutDto updateSettlementCommission(SettlementKey settlementKey,
                                                SettlementCommissionUpdateInDto settlementCommissionUpdateInDto);
}