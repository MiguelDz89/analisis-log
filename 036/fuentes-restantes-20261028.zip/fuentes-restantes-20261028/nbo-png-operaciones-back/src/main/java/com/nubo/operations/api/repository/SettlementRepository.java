package com.nubo.operations.api.repository;

import com.nubo.operations.api.models.entity.SettlementEntity;
import com.nubo.operations.api.models.entity.SettlementKey;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface SettlementRepository extends JpaRepository<SettlementEntity, SettlementKey>,
        JpaSpecificationExecutor<SettlementEntity> {

    void deleteByTradeIdAndSideId(Long tradeId, String sideId);

    List<SettlementEntity> findAllByTradeId(Long tradeId);

    @Query("SELECT s FROM SettlementEntity s JOIN s.trade t JOIN s.side si " +
            "WHERE t.id  = :tradeId AND s.fraction = :fraction AND si.id = :sideId")
    Optional<SettlementEntity> findByTradeIdAndFractionAndSideId(Long tradeId, Integer fraction, String sideId);

    @Query("SELECT s FROM SettlementEntity s JOIN s.trade t JOIN s.side si " +
            "WHERE t.id  = :tradeId AND si.id = :sideId")
    List<SettlementEntity> findByTradeIdAndSideId(Long tradeId, String sideId);

}
