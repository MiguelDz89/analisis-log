package com.nubo.operations.api.service;

import com.nubo.operations.api.models.dto.request.TradeEquityInDto;
import com.nubo.operations.api.models.dto.request.TradeEquityUpdateInDto;
import com.nubo.operations.api.models.dto.response.PageResponseOutDto;
import com.nubo.operations.api.models.dto.response.TradeEquityOutDto;
import org.springframework.data.domain.Pageable;

public interface TradeEquityService {

    PageResponseOutDto<TradeEquityOutDto> findAllTradeEquity(Pageable pageable);

    PageResponseOutDto<TradeEquityOutDto> findAllTradeEquity(int page, int size, String sort, String order, boolean all);

    TradeEquityOutDto findTradeEquityById(Long tradeId);

    TradeEquityOutDto createTradeEquity(TradeEquityInDto tradeEquityInDto);

    TradeEquityOutDto updateTradeEquity(Long tradeId, TradeEquityUpdateInDto tradeEquityUpdateInDto);
}
