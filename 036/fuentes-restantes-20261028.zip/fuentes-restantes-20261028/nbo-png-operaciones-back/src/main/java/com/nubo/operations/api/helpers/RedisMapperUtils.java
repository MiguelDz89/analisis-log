package com.nubo.operations.api.helpers;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

import org.springframework.stereotype.Component;

@Component
public class RedisMapperUtils {

    private RedisMapperUtils() {
    }

    public static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    public static final DateTimeFormatter DATETIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    public static class FilterContext {
        public final String redisFieldName;
        public final String fieldValue;
        public final boolean isNumericField;
        public final boolean isDateField;

        public FilterContext(String redisFieldName, String fieldValue, boolean isNumericField, boolean isDateField) {
            this.redisFieldName = redisFieldName;
            this.fieldValue = fieldValue;
            this.isNumericField = isNumericField;
            this.isDateField = isDateField;
        }
    }

    public static final Map<String, Function<FilterContext, String>> FILTER_STRATEGIES = Map.ofEntries(
        Map.entry("equals", RedisMapperUtils::buildEqualsFilter),
        Map.entry("contains", RedisMapperUtils::buildContainsFilter),
        Map.entry("greater_than", RedisMapperUtils::buildGreaterThanFilter),
        Map.entry("less_than", RedisMapperUtils::buildLessThanFilter),
        Map.entry("greater_than_or_equal", RedisMapperUtils::buildGreaterThanOrEqualFilter),
        Map.entry("less_than_or_equal", RedisMapperUtils::buildLessThanOrEqualFilter),
        Map.entry("starts_with", RedisMapperUtils::buildStartsWithFilter),
        Map.entry("ends_with", RedisMapperUtils::buildEndsWithFilter),
        Map.entry("not_equals", RedisMapperUtils::buildNotEqualsFilter),
        Map.entry("in", RedisMapperUtils::buildInFilter),
        Map.entry("not_in", RedisMapperUtils::buildNotInFilter),
        Map.entry("is_empty", RedisMapperUtils::buildIsEmptyFilter),
        Map.entry("is_not_empty", RedisMapperUtils::buildIsNotEmptyFilter),
        Map.entry("not_contains", RedisMapperUtils::buildNotContainsFilter)
    );

    public static String parseString(Object value) {
        return value != null ? value.toString() : null;
    }

    public static Long parseLong(Object value) {
        try {
            return value != null && !value.toString().isEmpty() ? Long.valueOf(value.toString()) : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public static Integer parseInt(Object value) {
        try {
            return value != null && !value.toString().isEmpty() ? Integer.valueOf(value.toString()) : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public static Boolean parseBoolean(Object value) {
        try {
            return value != null && !value.toString().isEmpty() ? Boolean.valueOf(value.toString()) : Boolean.FALSE;
        } catch (Exception e) {
            return Boolean.FALSE;
        }
    }

    public static BigDecimal parseBigDecimal(Object value) {
        try {
            return value != null && !value.toString().isEmpty() ? new BigDecimal(value.toString()) : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public static BigInteger parseBigInteger(Object value) {
        try {
            return value != null && !value.toString().isEmpty() ? new BigInteger(value.toString()) : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public static LocalDate parseLocalDate(Object value) {
        try {
            return value != null && !value.toString().isEmpty() ? LocalDate.parse(value.toString(), DATE_FORMATTER) : null;
        } catch (Exception e) {
            return null;
        }
    }

    public static LocalDateTime parseLocalDateTime(Object value) {
        try {
            return value != null && !value.toString().isEmpty()
                    ? LocalDateTime.parse(value.toString(), DATETIME_FORMATTER)
                    : null;
        } catch (Exception e) {
            return null;
        }
    }

    public static OffsetDateTime parseOffsetDateTime(Object value) {
        try {
            return value != null && !value.toString().isEmpty()
                    ? OffsetDateTime.parse(value.toString())
                    : null;
        } catch (Exception e) {
            return null;
        }
    }

    public static String buildEqualsFilter(FilterContext ctx, Set<String> tagFields) {
        if (ctx.isNumericField) {
            return "@" + ctx.redisFieldName + ":[" + ctx.fieldValue + " " + ctx.fieldValue + "]";
        } else if (ctx.isDateField) {
            String[] dateParts = ctx.fieldValue.split("-");
            if (dateParts.length == 3) {
                return "(@" + ctx.redisFieldName + ":*" + dateParts[0] + "*) " +
                       "(@" + ctx.redisFieldName + ":*" + dateParts[1] + "*) " +
                       "(@" + ctx.redisFieldName + ":*" + dateParts[2] + "*)";
            } else {
                return "@" + ctx.redisFieldName + ":*" + ctx.fieldValue + "*";
            }
        } else if (tagFields.contains(ctx.redisFieldName)) {
            return "@" + ctx.redisFieldName + ":{" + escapeTagValue(ctx.fieldValue) + "}";
        } else {
            return "@" + ctx.redisFieldName + ":" + escapeValue(ctx.fieldValue);
        }
    }

    public static String buildEqualsFilter(FilterContext ctx) {
        return buildEqualsFilter(ctx, Set.of());
    }

    public static String buildContainsFilter(FilterContext ctx, Set<String> tagFields) {
        if (ctx.isNumericField) {
            return "@" + ctx.redisFieldName + ":[" + ctx.fieldValue + " " + ctx.fieldValue + "]";
        } else if (tagFields.contains(ctx.redisFieldName)) {
            return "@" + ctx.redisFieldName + ":{*" + escapeTagValue(ctx.fieldValue) + "*}";
        } else {
            return "@" + ctx.redisFieldName + ":*" + ctx.fieldValue + "*";
        }
    }

    public static String buildContainsFilter(FilterContext ctx) {
        return buildContainsFilter(ctx, Set.of());
    }

    public static String buildNotContainsFilter(FilterContext ctx, Set<String> tagFields) {
        if (ctx.isNumericField) {
            return "-@" + ctx.redisFieldName + ":[" + ctx.fieldValue + " " + ctx.fieldValue + "]";
        } else if (tagFields.contains(ctx.redisFieldName)) {
            return "-@" + ctx.redisFieldName + ":{*" + escapeTagValue(ctx.fieldValue) + "*}";
        } else {
            return "-@" + ctx.redisFieldName + ":*" + ctx.fieldValue + "*";
        }
    }

    public static String buildNotContainsFilter(FilterContext ctx) {
        return buildNotContainsFilter(ctx, Set.of());
    }

    public static String buildGreaterThanFilter(FilterContext ctx) {
        return "@" + ctx.redisFieldName + ":[(" + ctx.fieldValue + " +inf]";
    }

    public static String buildLessThanFilter(FilterContext ctx) {
        return "@" + ctx.redisFieldName + ":[-inf (" + ctx.fieldValue + "]";
    }

    public static String buildGreaterThanOrEqualFilter(FilterContext ctx) {
        return "@" + ctx.redisFieldName + ":[" + ctx.fieldValue + " +inf]";
    }

    public static String buildLessThanOrEqualFilter(FilterContext ctx) {
        return "@" + ctx.redisFieldName + ":[-inf " + ctx.fieldValue + "]";
    }

    public static String buildStartsWithFilter(FilterContext ctx, Set<String> tagFields) {
        if (ctx.isNumericField) {
            return "@" + ctx.redisFieldName + ":[" + ctx.fieldValue + " " + ctx.fieldValue + "]";
        } else if (tagFields.contains(ctx.redisFieldName)) {
            return "@" + ctx.redisFieldName + ":{" + escapeTagValue(ctx.fieldValue) + "*}";
        } else {
            return "@" + ctx.redisFieldName + ":" + ctx.fieldValue + "*";
        }
    }

    public static String buildStartsWithFilter(FilterContext ctx) {
        return buildStartsWithFilter(ctx, Set.of());
    }

    public static String buildEndsWithFilter(FilterContext ctx, Set<String> tagFields) {
        if (ctx.isNumericField) {
            return "@" + ctx.redisFieldName + ":[" + ctx.fieldValue + " " + ctx.fieldValue + "]";
        } else if (tagFields.contains(ctx.redisFieldName)) {
            return "@" + ctx.redisFieldName + ":{*" + escapeTagValue(ctx.fieldValue) + "}";
        } else {
            return "@" + ctx.redisFieldName + ":*" + ctx.fieldValue;
        }
    }

    public static String buildEndsWithFilter(FilterContext ctx) {
        return buildEndsWithFilter(ctx, Set.of());
    }

    public static String buildNotEqualsFilter(FilterContext ctx, Set<String> tagFields) {
        if (ctx.isNumericField) {
            return "-@" + ctx.redisFieldName + ":[" + ctx.fieldValue + " " + ctx.fieldValue + "]";
        } else if (tagFields.contains(ctx.redisFieldName)) {
            return "-@" + ctx.redisFieldName + ":{" + escapeTagValue(ctx.fieldValue) + "}";
        } else {
            return "-@" + ctx.redisFieldName + ":" + escapeValue(ctx.fieldValue);
        }
    }

    public static String buildNotEqualsFilter(FilterContext ctx) {
        return buildNotEqualsFilter(ctx, Set.of());
    }

    public static String buildInFilter(FilterContext ctx, Set<String> tagFields) {
        String[] values = ctx.fieldValue.split(",");
        if (ctx.isNumericField) {
            List<String> inFilters = new ArrayList<>();
            for (String value : values) {
                inFilters.add("@" + ctx.redisFieldName + ":[" + value.trim() + " " + value.trim() + "]");
            }
            return "(" + String.join(" | ", inFilters) + ")";
        } else if (tagFields.contains(ctx.redisFieldName)) {
            List<String> escapedValues = new ArrayList<>();
            for (String value : values) {
                escapedValues.add(escapeTagValue(value.trim()));
            }
            return "@" + ctx.redisFieldName + ":{" + String.join("|", escapedValues) + "}";
        } else {
            List<String> inFilters = new ArrayList<>();
            for (String value : values) {
                inFilters.add("@" + ctx.redisFieldName + ":" + escapeValue(value.trim()));
            }
            return "(" + String.join(" | ", inFilters) + ")";
        }
    }

    public static String buildInFilter(FilterContext ctx) {
        return buildInFilter(ctx, Set.of());
    }

    public static String buildNotInFilter(FilterContext ctx, Set<String> tagFields) {
        String[] notValues = ctx.fieldValue.split(",");
        if (ctx.isNumericField) {
            List<String> notInFilters = new ArrayList<>();
            for (String value : notValues) {
                notInFilters.add("@" + ctx.redisFieldName + ":[" + value.trim() + " " + value.trim() + "]");
            }
            return "-(" + String.join(" | ", notInFilters) + ")";
        } else if (tagFields.contains(ctx.redisFieldName)) {
            List<String> escapedValues = new ArrayList<>();
            for (String value : notValues) {
                escapedValues.add(escapeTagValue(value.trim()));
            }
            return "-@" + ctx.redisFieldName + ":{" + String.join("|", escapedValues) + "}";
        } else {
            List<String> notInFilters = new ArrayList<>();
            for (String value : notValues) {
                notInFilters.add("@" + ctx.redisFieldName + ":" + escapeValue(value.trim()));
            }
            return "-(" + String.join(" | ", notInFilters) + ")";
        }
    }

    public static String buildNotInFilter(FilterContext ctx) {
        return buildNotInFilter(ctx, Set.of());
    }

    public static String buildIsEmptyFilter(FilterContext ctx, Set<String> tagFields) {
        if (tagFields.contains(ctx.redisFieldName)) {
            return "@" + ctx.redisFieldName + ":{null}";
        } else {
            return "@" + ctx.redisFieldName + ":\"null\"";
        }
    }

    public static String buildIsEmptyFilter(FilterContext ctx) {
        return buildIsEmptyFilter(ctx, Set.of());
    }

    public static String buildIsNotEmptyFilter(FilterContext ctx, Set<String> tagFields) {
        if (tagFields.contains(ctx.redisFieldName)) {
            return "-@" + ctx.redisFieldName + ":{null}";
        } else {
            return "-@" + ctx.redisFieldName + ":\"null\"";
        }
    }

    public static String buildIsNotEmptyFilter(FilterContext ctx) {
        return buildIsNotEmptyFilter(ctx, Set.of());
    }

    public static String escapeTagValue(String value) {
        return value.replace(",", "\\,")
                    .replace(".", "\\.")
                    .replace("<", "\\<")
                    .replace(">", "\\>")
                    .replace("{", "\\{")
                    .replace("}", "\\}")
                    .replace("[", "\\[")
                    .replace("]", "\\]")
                    .replace("\"", "\\\"")
                    .replace("'", "\\'")
                    .replace(":", "\\:")
                    .replace(";", "\\;")
                    .replace("!", "\\!")
                    .replace("@", "\\@")
                    .replace("#", "\\#")
                    .replace("$", "\\$")
                    .replace("%", "\\%")
                    .replace("^", "\\^")
                    .replace("&", "\\&")
                    .replace("*", "\\*")
                    .replace("(", "\\(")
                    .replace(")", "\\)")
                    .replace("-", "\\-")
                    .replace("+", "\\+")
                    .replace("=", "\\=")
                    .replace("~", "\\~");
    }

    public static String escapeValue(String value) {
        return "\"" + value.replace("\"", "\\\"") + "\"";
    }
}
