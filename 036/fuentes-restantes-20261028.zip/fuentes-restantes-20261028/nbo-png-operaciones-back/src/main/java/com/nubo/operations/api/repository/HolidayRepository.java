package com.nubo.operations.api.repository;

import com.nubo.operations.api.models.entity.HolidayEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface HolidayRepository extends JpaRepository<HolidayEntity, Long> {

    @Query("SELECT h FROM HolidayEntity h JOIN h.country c WHERE c.id = :countryId")
    List<HolidayEntity> findByCountryId(Long countryId);

}
