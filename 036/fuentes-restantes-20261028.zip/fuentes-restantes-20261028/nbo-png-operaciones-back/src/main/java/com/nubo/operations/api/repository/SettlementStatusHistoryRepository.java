package com.nubo.operations.api.repository;

import com.nubo.operations.api.models.entity.SettlementStatusHistoryEntity;
import com.nubo.operations.api.models.entity.SettlementStatusHistoryKey;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;

public interface SettlementStatusHistoryRepository extends JpaRepository<SettlementStatusHistoryEntity, SettlementStatusHistoryKey>,
        JpaSpecificationExecutor<SettlementStatusHistoryEntity> {

    List<SettlementStatusHistoryEntity> findAllByTradeId(Long tradeId);

    void deleteByTradeIdAndSideId(Long tradeId, String sideId);

}
