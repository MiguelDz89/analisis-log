package com.nubo.operations.api.service;

import org.springframework.data.domain.Pageable;

import com.nubo.operations.api.models.domain.TradeParams;
import com.nubo.operations.api.models.dto.request.TradeInDto;
import com.nubo.operations.api.models.dto.request.TradeUpdateInDto;
import com.nubo.operations.api.models.dto.response.PageResponseOutDto;
import com.nubo.operations.api.models.dto.response.TradeOutDto;

public interface TradeService {

    PageResponseOutDto<TradeOutDto> findAllTrades(Pageable pageable, TradeParams tradeParams);

    PageResponseOutDto<Long> findAllTradeIds(Pageable pageable, Long matchId);

    TradeOutDto findTradeById(Long tradeId);

    TradeOutDto createTrade(TradeInDto tradeInDto);

    TradeOutDto updateTrade(Long tradeId, TradeUpdateInDto tradeUpdateInDto);

    PageResponseOutDto<TradeOutDto> findAllTradesDynamic(
            Pageable pageable,
            String fieldName,
            String fieldValue,
            String operation,
            TradeParams tradeParams);

    long countAllTrades();

}
