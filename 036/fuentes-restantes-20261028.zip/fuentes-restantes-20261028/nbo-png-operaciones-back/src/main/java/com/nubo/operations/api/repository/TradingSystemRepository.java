package com.nubo.operations.api.repository;

import com.nubo.operations.api.models.entity.TradingSystemEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TradingSystemRepository extends JpaRepository<TradingSystemEntity, Long> {
}
