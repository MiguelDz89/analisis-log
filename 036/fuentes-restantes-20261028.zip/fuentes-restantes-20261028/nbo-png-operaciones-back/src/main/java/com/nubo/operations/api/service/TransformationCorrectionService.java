package com.nubo.operations.api.service;

import java.util.List;

import com.nubo.operations.api.client.operation.fractionation.models.dto.request.AssignmentInDto;
import com.nubo.operations.api.client.operation.fractionation.models.dto.request.FractionInDto;
import com.nubo.operations.api.models.dto.response.SettlementOutDto;

public interface TransformationCorrectionService {

    void sendEventUpdate(Long tradeId, String sideId,
            List<AssignmentInDto> assignmentInDtoList, List<SettlementOutDto> response,
            List<SettlementOutDto> previous);

    void sendEventCreate(Long tradeId, String sideId,
            List<FractionInDto> fractionInDtoList, List<SettlementOutDto> response);

}
