package com.nubo.operations.api.repository;

import com.nubo.operations.api.models.entity.InvestorEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InvestorRepository extends JpaRepository<InvestorEntity, Long> {
}
