package com.nubo.operations.api.helpers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.nubo.operations.api.models.entity.SettlementEntity;
import com.nubo.operations.api.models.enums.SearchOperationEnum;

import jakarta.persistence.criteria.Path;

public class SettlementSpecificationBuilder {
    
    private static final String TRADE_FIELD = "trade";
    private static final String CUSTODIAN_FIELD = "custodian";
    private static final String INVESTOR_FIELD = "investor";
    private static final String ID_FIELD = "id";
    private static final String NAME_FIELD = "name";
    private static final String CODE_FIELD = "code";
    
    private final List<Specification<SettlementEntity>> specifications = new ArrayList<>();

    public static SettlementSpecificationBuilder builder() {
        return new SettlementSpecificationBuilder();
    }

    public SettlementSpecificationBuilder withTradeId(Long tradeId) {
        if (tradeId != null) {
            specifications.add((root, query, cb) -> 
                cb.equal(root.get(TRADE_FIELD).get(ID_FIELD), tradeId));
        }
        return this;
    }

    public SettlementSpecificationBuilder withSideId(String sideId) {
        if (sideId != null) {
            specifications.add((root, query, cb) -> 
                cb.equal(root.get("side").get(ID_FIELD), sideId));
        }
        return this;
    }

    public SettlementSpecificationBuilder withInvestorDocumentNumber(String investorDocumentNumber) {
        if (investorDocumentNumber != null) {
            specifications.add((root, query, cb) -> 
                cb.equal(root.get(INVESTOR_FIELD).get("documentNumber"), investorDocumentNumber));
        }
        return this;
    }

    public SettlementSpecificationBuilder withFiduciarySpecialist(Boolean fiduciarySpecialist) {
        if (fiduciarySpecialist != null) {
            specifications.add((root, query, cb) -> 
                cb.equal(root.get("fiduciarySpecialist"), fiduciarySpecialist));
        }
        return this;
    }

    public SettlementSpecificationBuilder withReference(String reference) {
        if (reference != null) {
            specifications.add((root, query, cb) -> 
                cb.like(cb.lower(root.get("reference")), "%" + reference.toLowerCase() + "%"));
        }
        return this;
    }

    public SettlementSpecificationBuilder withCustodianId(Long custodianId) {
        if (custodianId != null) {
            specifications.add((root, query, cb) -> 
                cb.equal(root.get(CUSTODIAN_FIELD).get(ID_FIELD), custodianId));
        }
        return this;
    }

    public SettlementSpecificationBuilder withCustodianName(String custodianName) {
        if (custodianName != null) {
            specifications.add((root, query, cb) -> 
                cb.like(cb.lower(root.get(CUSTODIAN_FIELD).get(NAME_FIELD)), "%" + custodianName.toLowerCase() + "%"));
        }
        return this;
    }

    public SettlementSpecificationBuilder withCustodianCode(String custodianCode) {
        if (custodianCode != null) {
            specifications.add((root, query, cb) -> 
                cb.equal(root.get(CUSTODIAN_FIELD).get(CODE_FIELD), custodianCode));
        }
        return this;
    }

    public SettlementSpecificationBuilder withInvestorId(Long investorId) {
        if (investorId != null) {
            specifications.add((root, query, cb) -> 
                cb.equal(root.get(INVESTOR_FIELD).get(ID_FIELD), investorId));
        }
        return this;
    }

    public SettlementSpecificationBuilder withInvestorAccountNumber(String accountNumber) {
        if (accountNumber != null) {
            specifications.add((root, query, cb) -> 
                cb.equal(root.get("investorAccount").get("accountNumber"), accountNumber));
        }
        return this;
    }

    public SettlementSpecificationBuilder withTradeStatusId(Long tradeStatusId) {
        if (tradeStatusId != null) {
            specifications.add((root, query, cb) -> 
                cb.equal(root.get(TRADE_FIELD).get("status").get(ID_FIELD), tradeStatusId));
        }
        return this;
    }

    public SettlementSpecificationBuilder withTradeCanceledStatus(String canceledStatus) {
        if (canceledStatus != null) {
            specifications.add((root, query, cb) -> 
                cb.equal(root.get(TRADE_FIELD).get("canceledStatus"), canceledStatus));
        }
        return this;
    }

    public SettlementSpecificationBuilder withTradeSpecialTradeId(String specialTradeId) {
        if (specialTradeId != null) {
            specifications.add((root, query, cb) -> 
                cb.equal(root.get(TRADE_FIELD).get("specialTradeId"), specialTradeId));
        }
        return this;
    }

    public SettlementSpecificationBuilder withDynamicFilter(String fieldName, String fieldValue, SearchOperationEnum operation) {
        if (fieldName != null && fieldValue != null && operation != null) {
            specifications.add((root, query, cb) -> {
                try {
                    Path<Object> fieldPath = SettlementDynamicSearchMapper.getSettlementFieldPath(root, fieldName);
                    if (fieldPath != null) {
                        return SettlementDynamicSearchMapper.buildSettlementFieldPredicate(cb, fieldPath, fieldValue, operation);
                    }
                    return cb.conjunction(); 
                } catch (Exception e) {
                    return cb.conjunction(); 
                }
            });
        }
        return this;
    }

    public Specification<SettlementEntity> build() {
        if (specifications.isEmpty()) {
            return (root, query, cb) -> cb.conjunction();
        }
        return specifications.stream()
                .reduce(Specification::and)
                .orElse((root, query, cb) -> cb.conjunction());
    }
}
