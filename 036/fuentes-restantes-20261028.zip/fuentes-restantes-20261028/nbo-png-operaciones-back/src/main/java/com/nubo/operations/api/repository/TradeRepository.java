package com.nubo.operations.api.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.nubo.operations.api.models.entity.TradeEntity;

public interface TradeRepository extends JpaRepository<TradeEntity, Long>, JpaSpecificationExecutor<TradeEntity>
{
    @Query("SELECT DISTINCT t.matchId FROM TradeEntity t WHERE (:matchId IS NULL OR CAST(t.matchId AS string) LIKE %:matchId%)")
    Page<Long> findAllMatchIds(Long matchId, Pageable pageable);
}
