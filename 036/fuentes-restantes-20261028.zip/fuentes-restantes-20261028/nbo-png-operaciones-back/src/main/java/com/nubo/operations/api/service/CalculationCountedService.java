package com.nubo.operations.api.service;

import com.nubo.operations.api.models.dto.request.CalculationInDto;
import com.nubo.operations.api.models.dto.request.CalculationIvaInDto;
import com.nubo.operations.api.models.dto.response.CalculationOutDto;

public interface CalculationCountedService {

    CalculationOutDto calculationSettlementWithIva(Long tradeId, CalculationIvaInDto calculationIvaInDto);

    CalculationOutDto calculationSettlementByCountryId(Long tradeId, Long countryId, CalculationInDto calculationInDto);

}
