package com.nubo.operations.api.helpers;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.function.Function;

import com.nubo.operations.api.models.entity.TradeEntity;
import com.nubo.operations.api.models.enums.SearchOperationEnum;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class MapperTradeDynamicSearch {

    private enum ComparisonType {
        GREATER_THAN, GREATER_THAN_OR_EQUAL, LESS_THAN, LESS_THAN_OR_EQUAL
    }

    private static final Map<String, Function<Root<TradeEntity>, Path<?>>> FIELD_PATH_MAPPING = Map.ofEntries(
        Map.entry("id", root -> root.get("id")),
        Map.entry("matchDate", root -> root.get("matchDate")),
        Map.entry("matchId", root -> root.get("matchId")),
        Map.entry("clearingDate", root -> root.get("clearingDate")),
        Map.entry("returnClearingDate", root -> root.get("returnClearingDate")),
        Map.entry("depositoryId", root -> root.get("depository").get("id")),
        Map.entry("depositoryName", root -> root.get("depository").get("description")),
        Map.entry("countryId", root -> root.get("country").get("id")),
        Map.entry("countryName", root -> root.get("country").get("name")),
        Map.entry("countryCode", root -> root.get("country").get("code")),
        Map.entry("typeId", root -> root.get("type").get("id")),
        Map.entry("typeDescription", root -> root.get("type").get("description")),
        Map.entry("marketId", root -> root.get("market").get("id")),
        Map.entry("marketDescription", root -> root.get("market").get("description")),
        Map.entry("issuanceMarketId", root -> root.get("issuanceMarket").get("id")),
        Map.entry("issuanceMarketDescription", root -> root.get("issuanceMarket").get("description")),
        Map.entry("securityTitleId", root -> root.get("securityTitle").get("id")),
        Map.entry("securityTitleIsin", root -> root.get("securityTitle").get("isin")),
        Map.entry("securityTitleMnemonic", root -> root.get("securityTitle").get("mnemonic")),
        Map.entry("participantBuyId", root -> root.get("participantBuy").get("id")),
        Map.entry("participantBuyName", root -> root.get("participantBuy").get("name")),
        Map.entry("participantSellId", root -> root.get("participantSell").get("id")),
        Map.entry("participantSellName", root -> root.get("participantSell").get("name")),
        Map.entry("custodianBuyId", root -> root.get("custodianBuy").get("id")),
        Map.entry("custodianBuyName", root -> root.get("custodianBuy").get("name")),
        Map.entry("custodianSellId", root -> root.get("custodianSell").get("id")),
        Map.entry("custodianSellName", root -> root.get("custodianSell").get("name")),
        Map.entry("assignmentMarkBuy", root -> root.get("assignmentMarkBuy")),
        Map.entry("assignmentMarkSell", root -> root.get("assignmentMarkSell")),
        Map.entry("fractionalMarkBuy", root -> root.get("fractionalMarkBuy")),
        Map.entry("fractionalMarkSell", root -> root.get("fractionalMarkSell")),
        Map.entry("advanceStatus", root -> root.get("advanceStatus")),
        Map.entry("exitIndicatorSettlement", root -> root.get("exitIndicatorSettlement")),
        Map.entry("canceledStatus", root -> root.get("canceledStatus")),
        Map.entry("quantity", root -> root.get("quantity")),
        Map.entry("price", root -> root.get("price")),
        Map.entry("volume", root -> root.get("volume")),
        Map.entry("repurchaseRate", root -> root.get("repurchaseRate")),
        Map.entry("repurchaseAmount", root -> root.get("repurchaseAmount")),
        Map.entry("statusId", root -> root.get("status").get("id")),
        Map.entry("statusDescription", root -> root.get("status").get("description")),
        Map.entry("matchTime", root -> root.get("matchTime")),
        Map.entry("ownPositionSell", root -> root.get("ownPositionSell")),
        Map.entry("ownPositionBuy", root -> root.get("ownPositionBuy")),
        Map.entry("currencyId", root -> root.get("currency").get("id")),
        Map.entry("currencyCode", root -> root.get("currency").get("code")),
        Map.entry("currencyName", root -> root.get("currency").get("name")),
        Map.entry("tradingSystemId", root -> root.get("tradingSystem").get("id")),
        Map.entry("tradingSystemDescription", root -> root.get("tradingSystem").get("description")),
        Map.entry("tradingSessionId", root -> root.get("tradingSession").get("id")),
        Map.entry("tradingSessionDescription", root -> root.get("tradingSession").get("description")),
        Map.entry("repurchaseAgreementDate", root -> root.get("repurchaseAgreementDate")),
        Map.entry("daysToSettlement", root -> root.get("daysToSettlement")),
        Map.entry("repoRate", root -> root.get("repoRate")),
        Map.entry("repoAmount", root -> root.get("repoAmount")),
        Map.entry("fundingAmount", root -> root.get("fundingAmount")),
        Map.entry("netOutFlowTotal", root -> root.get("netOutFlowTotal")),
        Map.entry("outFlowTurnOverValue", root -> root.get("outFlowTurnOverValue")),
        Map.entry("totalNetReturn", root -> root.get("totalNetReturn")),
        Map.entry("returnTurnoverValue", root -> root.get("returnTurnoverValue")),
        Map.entry("deliveryVersusPaymentValue", root -> root.get("deliveryVersusPaymentValue")),
        Map.entry("reallocationIndicator", root -> root.get("reallocationIndicator")),
        Map.entry("businessTypeId", root -> root.get("businessType").get("id")),
        Map.entry("businessTypeDescription", root -> root.get("businessType").get("description")),
        Map.entry("marketTypeId", root -> root.get("marketType").get("id")),
        Map.entry("marketTypeDescription", root -> root.get("marketType").get("description")),
        Map.entry("originTypeId", root -> root.get("originType").get("id")),
        Map.entry("originTypeDescription", root -> root.get("originType").get("description")),
        Map.entry("settlementIndicatorOutgoing", root -> root.get("settlementIndicatorOutgoing")),
        Map.entry("settlementIndicatorReturn", root -> root.get("settlementIndicatorReturn")),
        Map.entry("resettlementIndicatorAdvance", root -> root.get("resettlementIndicatorAdvance")),
        Map.entry("specialTradeId", root -> root.get("specialTradeId")),
        Map.entry("paymentTypeId", root -> root.get("paymentType").get("id")),
        Map.entry("paymentTypeDescription", root -> root.get("paymentType").get("description")),
        Map.entry("settlementTypeId", root -> root.get("settlementType").get("id")),
        Map.entry("settlementTypeDescription", root -> root.get("settlementType").get("description")),
        Map.entry("custodianStatusId", root -> root.get("custodianStatus").get("id")),
        Map.entry("custodianStatusDescription", root -> root.get("custodianStatus").get("description")),
        Map.entry("settlementStatusId", root -> root.get("settlementStatus").get("id")),
        Map.entry("settlementStatusDescription", root -> root.get("settlementStatus").get("description")),
        Map.entry("bloquingStatusId", root -> root.get("bloquingStatus").get("id")),
        Map.entry("bloquingStatusDescription", root -> root.get("bloquingStatus").get("description")),
        Map.entry("salesGuarantee", root -> root.get("salesGuarantee")),
        Map.entry("purchaseGuarantee", root -> root.get("purchaseGuarantee")),
        Map.entry("purchasePaymentIndicator", root -> root.get("purchasePaymentIndicator")),
        Map.entry("returnIndicatorSettlement", root -> root.get("returnIndicatorSettlement"))
    );

    private static final Map<Class<?>, Function<String, Object>> TYPE_PARSERS = Map.of(
        Long.class, Long::valueOf,
        long.class, Long::valueOf,
        Integer.class, Integer::valueOf,
        int.class, Integer::valueOf,
        Boolean.class, Boolean::valueOf,
        boolean.class, Boolean::valueOf,
        LocalDate.class, LocalDate::parse,
        LocalDateTime.class, LocalDateTime::parse,
        BigDecimal.class, BigDecimal::new,
        String.class, value -> value
    );

    @FunctionalInterface
    private interface PredicateBuilder {
        Predicate build(CriteriaBuilder criteriaBuilder, 
                       Path<?> fieldPath, 
                       String fieldValue);
    }

    private static final Map<SearchOperationEnum, PredicateBuilder> OPERATION_BUILDERS = Map.ofEntries(
        Map.entry(SearchOperationEnum.CONTAINS, (cb, path, value) -> {
            if (path.getJavaType() == String.class) {
                return cb.like(cb.lower(path.as(String.class)), "%" + value.toLowerCase() + "%");
            } else {
                return cb.like(cb.concat("", path.as(String.class)), "%" + value + "%");
            }
        }),
        Map.entry(SearchOperationEnum.NOT_CONTAINS, (cb, path, value) -> {
            if (path.getJavaType() == String.class) {
                return cb.notLike(cb.lower(path.as(String.class)), "%" + value.toLowerCase() + "%");
            } else {
                return cb.notLike(cb.concat("", path.as(String.class)), "%" + value + "%");
            }
        }),
        Map.entry(SearchOperationEnum.EQUALS, (cb, path, value) -> {
            Object parsedValue = parseFieldValue(path, value);
            if (path.getJavaType() == String.class) {
                return cb.equal(cb.lower(path.as(String.class)), parsedValue.toString().toLowerCase());
            }
            return cb.equal(path, parsedValue);
        }),
        Map.entry(SearchOperationEnum.NOT_EQUALS, (cb, path, value) -> {
            Object parsedValue = parseFieldValue(path, value);
            if (path.getJavaType() == String.class) {
                return cb.notEqual(cb.lower(path.as(String.class)), parsedValue.toString().toLowerCase());
            }
            return cb.notEqual(path, parsedValue);
        }),
        Map.entry(SearchOperationEnum.STARTS_WITH, (cb, path, value) -> {
            if (path.getJavaType() == String.class) {
                return cb.like(cb.lower(path.as(String.class)), value.toLowerCase() + "%");
            } else {
                return cb.like(cb.concat("", path.as(String.class)), value + "%");
            }
        }),
        Map.entry(SearchOperationEnum.ENDS_WITH, (cb, path, value) -> {
            if (path.getJavaType() == String.class) {
                return cb.like(cb.lower(path.as(String.class)), "%" + value.toLowerCase());
            } else {
                return cb.like(cb.concat("", path.as(String.class)), "%" + value);
            }
        }),
        Map.entry(SearchOperationEnum.GREATER_THAN, (cb, path, value) -> 
            buildComparisonPredicate(cb, path, value, ComparisonType.GREATER_THAN)),
        Map.entry(SearchOperationEnum.GREATER_THAN_OR_EQUAL, (cb, path, value) -> 
            buildComparisonPredicate(cb, path, value, ComparisonType.GREATER_THAN_OR_EQUAL)),
        Map.entry(SearchOperationEnum.LESS_THAN, (cb, path, value) -> 
            buildComparisonPredicate(cb, path, value, ComparisonType.LESS_THAN)),
        Map.entry(SearchOperationEnum.LESS_THAN_OR_EQUAL, (cb, path, value) -> 
            buildComparisonPredicate(cb, path, value, ComparisonType.LESS_THAN_OR_EQUAL)),
        Map.entry(SearchOperationEnum.IS_EMPTY, (cb, path, value) -> 
            cb.or(cb.isNull(path), cb.equal(path.as(String.class), ""))),
        Map.entry(SearchOperationEnum.IS_NOT_EMPTY, (cb, path, value) -> 
            cb.and(cb.isNotNull(path), cb.notEqual(path.as(String.class), ""))),
        Map.entry(SearchOperationEnum.IN, (cb, path, value) -> {
            String[] values = value.split(",");
            CriteriaBuilder.In<Object> inClause = cb.in(path);
            for (String val : values) {
                inClause.value(parseFieldValue(path, val.trim()));
            }
            return inClause;
        }),
        Map.entry(SearchOperationEnum.NOT_IN, (cb, path, value) -> {
            String[] values = value.split(",");
            CriteriaBuilder.In<Object> inClause = cb.in(path);
            for (String val : values) {
                inClause.value(parseFieldValue(path, val.trim()));
            }
            return inClause.not();
        }),
        Map.entry(SearchOperationEnum.IS_ANY_OF, (cb, path, value) -> {
            String[] values = value.split(",");
            CriteriaBuilder.In<Object> inClause = cb.in(path);
            for (String val : values) {
                inClause.value(parseFieldValue(path, val.trim()));
            }
            return inClause;
        })
    );

    public static Path<?> getTradeFieldPath(Root<TradeEntity> root, String fieldName) {
        try {
            Function<Root<TradeEntity>, Path<?>> pathFunction = FIELD_PATH_MAPPING.get(fieldName);
            if (pathFunction != null) {
                return pathFunction.apply(root);
            }
            log.warn("Campo no reconocido: {}", fieldName);
            return null;
        } catch (Exception e) {
            log.error("Error obteniendo ruta del campo {}: {}", fieldName, e.getMessage());
            return null;
        }
    }

    public static Predicate buildTradeFieldPredicate(CriteriaBuilder criteriaBuilder, 
                                                    Path<?> fieldPath, 
                                                    String fieldValue, 
                                                    SearchOperationEnum operation) {
        try {
            PredicateBuilder builder = OPERATION_BUILDERS.get(operation);
            if (builder == null) {
                log.warn("Operación no soportada: {}", operation);
                return null;
            }

            return builder.build(criteriaBuilder, fieldPath, fieldValue);
        } catch (Exception e) {
            log.error("Error construyendo predicado para operación {}: {}", operation, e.getMessage());
            return null;
        }
    }

    public static Object parseFieldValue(Path<?> fieldPath, String value) {
        try {
            Class<?> fieldType = fieldPath.getJavaType();
            Function<String, Object> parser = TYPE_PARSERS.get(fieldType);
            return parser != null ? parser.apply(value) : value;
        } catch (IllegalArgumentException e) {
            log.warn("Error parseando valor {} para tipo {}: {}", value, fieldPath.getJavaType(), e.getMessage());
            return value;
        }
    }

    @SuppressWarnings("unchecked")
    private static Predicate buildComparisonPredicate(CriteriaBuilder criteriaBuilder, 
                                                     Path<?> fieldPath, 
                                                     String fieldValue, 
                                                     ComparisonType comparisonType) {
        try {
            Object parsedValue = parseFieldValue(fieldPath, fieldValue);
            Class<?> fieldType = fieldPath.getJavaType();
            
            if (Number.class.isAssignableFrom(fieldType) || fieldType.isPrimitive()) {
                Path<Number> numberPath = (Path<Number>) fieldPath;
                Number numberValue = (Number) parsedValue;
                
                return switch (comparisonType) {
                    case GREATER_THAN -> criteriaBuilder.gt(numberPath, numberValue);
                    case GREATER_THAN_OR_EQUAL -> criteriaBuilder.ge(numberPath, numberValue);
                    case LESS_THAN -> criteriaBuilder.lt(numberPath, numberValue);
                    case LESS_THAN_OR_EQUAL -> criteriaBuilder.le(numberPath, numberValue);
                };
            } else if (Comparable.class.isAssignableFrom(fieldType)) {
                Path<Comparable<Object>> comparablePath = (Path<Comparable<Object>>) fieldPath;
                Comparable<Object> comparableValue = (Comparable<Object>) parsedValue;
                
                return switch (comparisonType) {
                    case GREATER_THAN -> criteriaBuilder.greaterThan(comparablePath, comparableValue);
                    case GREATER_THAN_OR_EQUAL -> criteriaBuilder.greaterThanOrEqualTo(comparablePath, comparableValue);
                    case LESS_THAN -> criteriaBuilder.lessThan(comparablePath, comparableValue);
                    case LESS_THAN_OR_EQUAL -> criteriaBuilder.lessThanOrEqualTo(comparablePath, comparableValue);
                };
            } else {
                log.warn("Tipo de campo no soportado para comparación: {}", fieldType);
                return null;
            }
        } catch (Exception e) {
            log.error("Error en buildComparisonPredicate para tipo {}: {}", comparisonType, e.getMessage());
            return null;
        }
    }
}
