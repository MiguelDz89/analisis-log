package com.nubo.operations.api.repository;

import com.nubo.operations.api.models.entity.TradeEquityEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TradeEquityRepository extends JpaRepository<TradeEquityEntity, Long> {
}
