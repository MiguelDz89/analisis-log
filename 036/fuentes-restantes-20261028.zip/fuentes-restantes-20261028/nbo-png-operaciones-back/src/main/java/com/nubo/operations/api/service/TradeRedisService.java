package com.nubo.operations.api.service;

import org.springframework.data.domain.Pageable;

import com.nubo.operations.api.models.domain.TradeParams;
import com.nubo.operations.api.models.dto.response.PageResponseOutDto;
import com.nubo.operations.api.models.dto.response.TradeOutDto;

public interface TradeRedisService {


    PageResponseOutDto<TradeOutDto> findAllTradesDynamic(
            Pageable pageable,
            String fieldName,
            String fieldValue,
            String operation,
            TradeParams tradeParams);


    PageResponseOutDto<TradeOutDto> findAllTradesRedisOnly(
            Pageable pageable,
            String fieldName,
            String fieldValue,
            String operation,
            TradeParams tradeParams);
}
