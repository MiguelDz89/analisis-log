package com.nubo.operations.api.service;

public interface ValidateCountedOperationService {

    Boolean validateTypeCountedTradeCorrection(Long tradeId);

    Boolean validateCustodianTradeCorrection(Long tradeId, String sideId);

    Boolean validateDaysAllowedTradeCorrection(Long tradeId);

}