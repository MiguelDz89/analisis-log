package com.nubo.operations.api.helpers;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.function.Function;

import com.nubo.operations.api.models.entity.SettlementEntity;
import com.nubo.operations.api.models.enums.SearchOperationEnum;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SettlementDynamicSearchMapper {

    private static final String TRADE_FIELD = "trade";
    private static final String CUSTODIAN_FIELD = "custodian";
    private static final String INVESTOR_FIELD = "investor";
    private static final String ID_FIELD = "id";
    private static final String NAME_FIELD = "name";
    private static final String CODE_FIELD = "code";

    private enum ComparisonType {
        GREATER_THAN, GREATER_THAN_OR_EQUAL, LESS_THAN, LESS_THAN_OR_EQUAL
    }

    private static final Map<String, Function<Root<SettlementEntity>, Path<?>>> FIELD_PATH_MAPPING = Map.ofEntries(
        Map.entry("tradeId", root -> root.get(TRADE_FIELD).get(ID_FIELD)),
        Map.entry("fraction", root -> root.get("fraction")),
        Map.entry("fiduciarySpecialist", root -> root.get("fiduciarySpecialist")),
        Map.entry("reference", root -> root.get("reference")),
        Map.entry("fractionQuantity", root -> root.get("fractionQuantity")),
        Map.entry("commissionPercentage", root -> root.get("commissionPercentage")),
        Map.entry("commissionAmount", root -> root.get("commissionAmount")),
        Map.entry("valTaxAmount", root -> root.get("valTaxAmount")),
        Map.entry("netAmount", root -> root.get("netAmount")),
        Map.entry("amount", root -> root.get("netAmount")), 
        Map.entry("settlementAmount", root -> root.get("settlementAmount")),
        Map.entry("transferValue", root -> root.get("transferValue")),
        Map.entry("custodianId", root -> root.get(CUSTODIAN_FIELD).get(ID_FIELD)),
        Map.entry("custodianName", root -> root.get(CUSTODIAN_FIELD).get(NAME_FIELD)),
        Map.entry("custodianCode", root -> root.get(CUSTODIAN_FIELD).get(CODE_FIELD)),
        Map.entry("masterAccount", root -> root.get("participantAccount").get("participant").get("masterAccount")),
        Map.entry("investorId", root -> root.get(INVESTOR_FIELD).get(ID_FIELD)),
        Map.entry("investorFirstName", root -> root.get(INVESTOR_FIELD).get("firstName")),
        Map.entry("investorLastName", root -> root.get(INVESTOR_FIELD).get("lastName")),
        Map.entry("investorCompanyName", root -> root.get(INVESTOR_FIELD).get("companyName")),
        Map.entry("investorDocumentNumber", root -> root.get(INVESTOR_FIELD).get("documentNumber")),
        Map.entry("investorAccountNumber", root -> root.get("investorAccount").get("accountNumber")),
        Map.entry("tradeStatusId", root -> root.get(TRADE_FIELD).get("status").get(ID_FIELD)),
        Map.entry("tradeCanceledStatus", root -> root.get(TRADE_FIELD).get("canceledStatus")),
        Map.entry("tradeSpecialTradeId", root -> root.get(TRADE_FIELD).get("specialTradeId")),
        Map.entry("sideId", root -> root.get("side").get(ID_FIELD)),
        Map.entry("statusId", root -> root.get("status").get(ID_FIELD)),
        Map.entry("fractionVolume", root -> root.get("fractionVolume")),
        Map.entry("fundingAmount", root -> root.get("fundingAmount")),
        Map.entry("repoAmount", root -> root.get("repoAmount"))
    );

    private static final Map<Class<?>, Function<String, Object>> TYPE_PARSERS = Map.of(
        Long.class, Long::valueOf,
        long.class, Long::valueOf,
        Integer.class, Integer::valueOf,
        int.class, Integer::valueOf,
        Boolean.class, Boolean::valueOf,
        boolean.class, Boolean::valueOf,
        LocalDate.class, LocalDate::parse,
        LocalDateTime.class, LocalDateTime::parse,
        BigDecimal.class, BigDecimal::new,
        String.class, value -> value
    );

    @FunctionalInterface
    private interface PredicateBuilder {
        Predicate build(CriteriaBuilder criteriaBuilder, 
                       Path<?> fieldPath, 
                       String fieldValue);
    }

    private static final Map<SearchOperationEnum, PredicateBuilder> OPERATION_BUILDERS = Map.ofEntries(
        Map.entry(SearchOperationEnum.CONTAINS, (cb, path, value) -> {
            if (path.getJavaType() == String.class) {
                return cb.like(cb.lower(path.as(String.class)), "%" + value.toLowerCase() + "%");
            } else {
                // Para campos numéricos, usar conversión directa a string con CONCAT
                return cb.like(cb.concat("", path.as(String.class)), "%" + value + "%");
            }
        }),
        Map.entry(SearchOperationEnum.NOT_CONTAINS, (cb, path, value) -> {
            if (path.getJavaType() == String.class) {
                return cb.notLike(cb.lower(path.as(String.class)), "%" + value.toLowerCase() + "%");
            } else {
                // Para campos numéricos, usar conversión directa a string con CONCAT
                return cb.notLike(cb.concat("", path.as(String.class)), "%" + value + "%");
            }
        }),
        Map.entry(SearchOperationEnum.EQUALS, (cb, path, value) -> {
            Object parsedValue = parseFieldValue(path, value);
            if (path.getJavaType() == String.class) {
                return cb.equal(cb.lower(path.as(String.class)), parsedValue.toString().toLowerCase());
            }
            return cb.equal(path, parsedValue);
        }),
        Map.entry(SearchOperationEnum.NOT_EQUALS, (cb, path, value) -> {
            Object parsedValue = parseFieldValue(path, value);
            if (path.getJavaType() == String.class) {
                return cb.notEqual(cb.lower(path.as(String.class)), parsedValue.toString().toLowerCase());
            }
            return cb.notEqual(path, parsedValue);
        }),
        Map.entry(SearchOperationEnum.STARTS_WITH, (cb, path, value) -> {
            if (path.getJavaType() == String.class) {
                return cb.like(cb.lower(path.as(String.class)), value.toLowerCase() + "%");
            } else {
                // Para campos numéricos, usar conversión directa a string con CONCAT
                return cb.like(cb.concat("", path.as(String.class)), value + "%");
            }
        }),
        Map.entry(SearchOperationEnum.ENDS_WITH, (cb, path, value) -> {
            if (path.getJavaType() == String.class) {
                return cb.like(cb.lower(path.as(String.class)), "%" + value.toLowerCase());
            } else {
                // Para campos numéricos, usar conversión directa a string con CONCAT
                return cb.like(cb.concat("", path.as(String.class)), "%" + value);
            }
        }),
        Map.entry(SearchOperationEnum.GREATER_THAN, (cb, path, value) -> 
            buildComparisonPredicate(cb, path, value, ComparisonType.GREATER_THAN)),
        Map.entry(SearchOperationEnum.GREATER_THAN_OR_EQUAL, (cb, path, value) -> 
            buildComparisonPredicate(cb, path, value, ComparisonType.GREATER_THAN_OR_EQUAL)),
        Map.entry(SearchOperationEnum.LESS_THAN, (cb, path, value) -> 
            buildComparisonPredicate(cb, path, value, ComparisonType.LESS_THAN)),
        Map.entry(SearchOperationEnum.LESS_THAN_OR_EQUAL, (cb, path, value) -> 
            buildComparisonPredicate(cb, path, value, ComparisonType.LESS_THAN_OR_EQUAL)),
        Map.entry(SearchOperationEnum.IS_EMPTY, (cb, path, value) -> 
            cb.or(cb.isNull(path), cb.equal(path.as(String.class), ""))),
        Map.entry(SearchOperationEnum.IS_NOT_EMPTY, (cb, path, value) -> 
            cb.and(cb.isNotNull(path), cb.notEqual(path.as(String.class), ""))),
        Map.entry(SearchOperationEnum.IN, (cb, path, value) -> {
            String[] values = value.split(",");
            CriteriaBuilder.In<Object> inClause = cb.in(path);
            for (String val : values) {
                inClause.value(parseFieldValue(path, val.trim()));
            }
            return inClause;
        }),
        Map.entry(SearchOperationEnum.NOT_IN, (cb, path, value) -> {
            String[] values = value.split(",");
            CriteriaBuilder.In<Object> inClause = cb.in(path);
            for (String val : values) {
                inClause.value(parseFieldValue(path, val.trim()));
            }
            return inClause.not();
        }),
        Map.entry(SearchOperationEnum.IS_ANY_OF, (cb, path, value) -> {
            String[] values = value.split(",");
            CriteriaBuilder.In<Object> inClause = cb.in(path);
            for (String val : values) {
                inClause.value(parseFieldValue(path, val.trim()));
            }
            return inClause;
        })
    );

    @SuppressWarnings("unchecked")
    public static Path<Object> getSettlementFieldPath(Root<SettlementEntity> root, String fieldName) {
        try {
            Function<Root<SettlementEntity>, Path<?>> pathFunction = FIELD_PATH_MAPPING.get(fieldName);
            if (pathFunction != null) {
                return (Path<Object>) pathFunction.apply(root);
            }
            log.warn("Campo no reconocido en Settlement: {}", fieldName);
            return null;
        } catch (Exception e) {
            log.error("Error obteniendo ruta del campo {}: {}", fieldName, e.getMessage());
            return null;
        }
    }

    public static Predicate buildSettlementFieldPredicate(CriteriaBuilder criteriaBuilder, 
                                                         Path<?> fieldPath, 
                                                         String fieldValue, 
                                                         SearchOperationEnum operation) {
        try {
            PredicateBuilder builder = OPERATION_BUILDERS.get(operation);
            if (builder == null) {
                log.warn("Operación no soportada: {}", operation);
                return null;
            }

            return builder.build(criteriaBuilder, fieldPath, fieldValue);
        } catch (Exception e) {
            log.error("Error construyendo predicado para operación {}: {}", operation, e.getMessage());
            return null;
        }
    }

    public static Object parseFieldValue(Path<?> fieldPath, String value) {
        try {
            Class<?> fieldType = fieldPath.getJavaType();
            Function<String, Object> parser = TYPE_PARSERS.get(fieldType);
            return parser != null ? parser.apply(value) : value;
        } catch (IllegalArgumentException e) {
            log.warn("Error parseando valor {} para tipo {}: {}", value, fieldPath.getJavaType(), e.getMessage());
            return value;
        }
    }

    @SuppressWarnings("unchecked")
    private static Predicate buildComparisonPredicate(CriteriaBuilder criteriaBuilder, 
                                                     Path<?> fieldPath, 
                                                     String fieldValue, 
                                                     ComparisonType comparisonType) {
        try {
            Object parsedValue = parseFieldValue(fieldPath, fieldValue);
            Class<?> fieldType = fieldPath.getJavaType();
            
            if (Number.class.isAssignableFrom(fieldType) || fieldType.isPrimitive()) {
                Path<Number> numberPath = (Path<Number>) fieldPath;
                Number numberValue = (Number) parsedValue;
                
                return switch (comparisonType) {
                    case GREATER_THAN -> criteriaBuilder.gt(numberPath, numberValue);
                    case GREATER_THAN_OR_EQUAL -> criteriaBuilder.ge(numberPath, numberValue);
                    case LESS_THAN -> criteriaBuilder.lt(numberPath, numberValue);
                    case LESS_THAN_OR_EQUAL -> criteriaBuilder.le(numberPath, numberValue);
                };
            } else if (Comparable.class.isAssignableFrom(fieldType)) {
                Path<Comparable<Object>> comparablePath = (Path<Comparable<Object>>) fieldPath;
                Comparable<Object> comparableValue = (Comparable<Object>) parsedValue;
                
                return switch (comparisonType) {
                    case GREATER_THAN -> criteriaBuilder.greaterThan(comparablePath, comparableValue);
                    case GREATER_THAN_OR_EQUAL -> criteriaBuilder.greaterThanOrEqualTo(comparablePath, comparableValue);
                    case LESS_THAN -> criteriaBuilder.lessThan(comparablePath, comparableValue);
                    case LESS_THAN_OR_EQUAL -> criteriaBuilder.lessThanOrEqualTo(comparablePath, comparableValue);
                };
            } else {
                log.warn("Tipo de campo no soportado para comparación: {}", fieldType);
                return null;
            }
        } catch (Exception e) {
            log.error("Error en buildComparisonPredicate para tipo {}: {}", comparisonType, e.getMessage());
            return null;
        }
    }
}
