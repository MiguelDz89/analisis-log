package com.nubo.operations.api.service;

import com.nubo.operations.api.models.dto.response.AllTradeOutDto;
import com.nubo.operations.api.models.dto.response.CalculationTotalAmountOutDto;

public interface AllTradeService {

    AllTradeOutDto findAllByTradeId(Long tradeId);

    CalculationTotalAmountOutDto calculationTotalAmountByTradeAndSide(Long tradeId, String sideId);

}
