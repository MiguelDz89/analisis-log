package com.nubo.operations.api.helpers;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.nubo.operations.api.models.enums.TypeEnum;
import org.springframework.data.jpa.domain.Specification;

import com.nubo.operations.api.application.properties.PropertiesContext;
import com.nubo.operations.api.models.entity.TradeEntity;
import com.nubo.operations.api.models.enums.SearchOperationEnum;
import com.nubo.operations.api.models.enums.StatusEnum;

import jakarta.persistence.criteria.Path;

public class TradeSpecificationBuilder {
    
    private static final String CLEARING_DATE_FIELD = "clearingDate";
    
    private final List<Specification<TradeEntity>> specifications = new ArrayList<>();

    public static TradeSpecificationBuilder builder() {
        return new TradeSpecificationBuilder();
    }
    
    public TradeSpecificationBuilder withMatchId(Long matchId) {
        if (matchId != null) {
            specifications.add((root, query, cb) -> 
                cb.like(cb.toString(root.get("matchId")), matchId + "%"));
        }
        return this;
    }
    
    public TradeSpecificationBuilder withStatusId(Integer statusId) {
        if (statusId != null) {
            specifications.add((root, query, cb) -> {
                var statusPredicate = cb.equal(root.get("status").get("id"), statusId);
                if (!StatusEnum.UNCOMPLETED.getValue().equals(statusId) &&
                        !StatusEnum.FINISHED.getValue().equals(statusId)) {
                    var datePredicate = cb.greaterThanOrEqualTo(root.get(CLEARING_DATE_FIELD), 
                        PropertiesContext.getClientDatetime().toLocalDate());
                    return cb.and(statusPredicate, datePredicate);
                }
                return statusPredicate;
            });
        }
        return this;
    }
    
    public TradeSpecificationBuilder withCanceledStatus(Boolean canceledStatus) {
        if (canceledStatus != null) {
            specifications.add((root, query, cb) -> 
                cb.equal(root.get("canceledStatus"), canceledStatus));
        }
        return this;
    }
    
    public TradeSpecificationBuilder withParticipantId(Long participantId) {
        if (participantId != null) {
            specifications.add((root, query, cb) -> 
                cb.or(
                    cb.equal(root.get("participantBuy").get("id"), participantId),
                    cb.equal(root.get("participantSell").get("id"), participantId)
                ));
        }
        return this;
    }
    
    public TradeSpecificationBuilder withTypeId(Long typeId) {
        if (typeId != null) {
            specifications.add((root, query, cb) -> 
                cb.equal(root.get("type").get("id"), typeId));
        }
        return this;
    }

    public TradeSpecificationBuilder withCountryIds(List<Long> countryIds) {
        if (countryIds != null && !countryIds.isEmpty()) {
            specifications.add((root, query, cb) ->
                    root.get("country").get("id").in(countryIds)
            );
        }
        return this;
    }
    
    public TradeSpecificationBuilder withCountryId(Long countryId) {
        if (countryId != null) {
            specifications.add((root, query, cb) -> 
                cb.equal(root.get("country").get("id"), countryId));
        }
        return this;
    }
    
    public TradeSpecificationBuilder withMatchDateRange(LocalDate startMatchDate, LocalDate endMatchDate) {
        if (startMatchDate != null && endMatchDate != null) {
            specifications.add((root, query, cb) -> 
                cb.and(
                    cb.greaterThanOrEqualTo(root.get("matchDate"), startMatchDate),
                    cb.lessThanOrEqualTo(root.get("matchDate"), endMatchDate)
                ));
        }
        return this;
    }
    
    public TradeSpecificationBuilder withEndClearingDate(LocalDate endClearingDate) {
        if (endClearingDate != null) {
            specifications.add((root, query, cb) -> 
                cb.lessThanOrEqualTo(root.get(CLEARING_DATE_FIELD), endClearingDate));
        }
        return this;
    }
    
    public TradeSpecificationBuilder withSpecialTradeIdNull() {
        specifications.add((root, query, cb) -> 
            cb.isNull(root.get("specialTradeId").as(Long.class)));
        return this;
    }
    
    public TradeSpecificationBuilder withDynamicFilter(String fieldName, String fieldValue, SearchOperationEnum operation) {
        if (fieldName != null && fieldValue != null && operation != null) {
            specifications.add((root, query, cb) -> {
                try {
                    Path<?> fieldPath = MapperTradeDynamicSearch.getTradeFieldPath(root, fieldName);
                    if (fieldPath != null) {
                        return MapperTradeDynamicSearch.buildTradeFieldPredicate(cb, fieldPath, fieldValue, operation);
                    }
                    return cb.conjunction(); 
                } catch (Exception e) {
                    return cb.conjunction(); 
                }
            });
        }
        return this;
    }

    public Specification<TradeEntity> build() {
        return specifications.stream()
                .reduce(Specification.allOf(), Specification::and);
    }


    public TradeSpecificationBuilder withOnlyOperation(Boolean onlyOperation) {
        if (Boolean.TRUE.equals(onlyOperation)) {
            specifications.add((root, query, cb) -> cb.and(
                    root.get("type").get("id").in(TypeEnum.COUNTED_OPERATION.getValue(), TypeEnum.REPO_OPERATION.getValue()),
                    cb.notEqual(root.get("status").get("id"), StatusEnum.NEGOCIATED.getValue())
            ));
        }
        return this;
    }
}
