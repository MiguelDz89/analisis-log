package com.nubo.operations.api.helpers;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Set;

@Component
@RequiredArgsConstructor
public class DateUtil {

    public Integer countBusinessDays(LocalDate startDate, LocalDate endDate, Set<LocalDate> holidays) {
        Integer businessDays = 0;
        if (startDate.isAfter(endDate)) {
            return 0;
        }
        LocalDate current = startDate;
        while (!current.isAfter(endDate)) {
            if (Boolean.TRUE.equals(isBusinessDay(current, holidays))) {
                businessDays++;
            }
            current = current.plusDays(1);
        }
        return businessDays;
    }

    public LocalDate getNextBusinessDay(LocalDate date, Set<LocalDate> holidays) {
        LocalDate nextDay = date.plusDays(1);
        while (nextDay.getDayOfWeek() == DayOfWeek.SATURDAY
                || nextDay.getDayOfWeek() == DayOfWeek.SUNDAY
                || holidays.contains(nextDay)) {
            nextDay = nextDay.plusDays(1);
        }
        return nextDay;
    }

    private Boolean isBusinessDay(LocalDate date, Set<LocalDate> holidays) {
        if (date.getDayOfWeek() == DayOfWeek.SATURDAY
                || date.getDayOfWeek() == DayOfWeek.SUNDAY) {
            return false;
        }
        return !holidays.contains(date);
    }

}
