package com.nubo.operations.api.helpers;

import org.springframework.data.jpa.domain.Specification;

import com.nubo.operations.api.models.entity.SettlementEntity;
import com.nubo.operations.api.models.enums.SearchOperationEnum;

import jakarta.persistence.criteria.Path;

public class SettlementSpecificationFactory {

    private SettlementSpecificationFactory() {
        throw new IllegalStateException("Utility class");
    }

    public static Specification<SettlementEntity> createStandardFilter(
            Long tradeId, String sideId, String investorDocumentNumber) {

        return SettlementSpecificationBuilder.builder()
                .withTradeId(tradeId)
                .withSideId(sideId)
                .withInvestorDocumentNumber(investorDocumentNumber)
                .build();
    }

    public static Specification<SettlementEntity> createDynamicFilter(
            String fieldName, String fieldValue, SearchOperationEnum operation) {

        return (root, query, cb) -> {
            try {
                Path<Object> fieldPath = SettlementDynamicSearchMapper.getSettlementFieldPath(root, fieldName);
                if (fieldPath != null) {
                    return SettlementDynamicSearchMapper.buildSettlementFieldPredicate(cb, fieldPath, fieldValue, operation);
                }
                return cb.conjunction();
            } catch (Exception e) {
                return cb.conjunction();
            }
        };
    }

    public static Specification<SettlementEntity> createCombinedFilter(
            Long tradeId, String sideId, String investorDocumentNumber,
            String fieldName, String fieldValue, SearchOperationEnum operation) {

        return SettlementSpecificationBuilder.builder()
                .withTradeId(tradeId)
                .withSideId(sideId)
                .withInvestorDocumentNumber(investorDocumentNumber)
                .withDynamicFilter(fieldName, fieldValue, operation)
                .build();
    }

    public static Specification<SettlementEntity> createTradeFilter(Long tradeId) {
        return SettlementSpecificationBuilder.builder()
                .withTradeId(tradeId)
                .build();
    }

    public static Specification<SettlementEntity> createInvestorFilter(Long investorId, String documentNumber) {
        return SettlementSpecificationBuilder.builder()
                .withInvestorId(investorId)
                .withInvestorDocumentNumber(documentNumber)
                .build();
    }

    public static Specification<SettlementEntity> createCustodianFilter(Long custodianId, String custodianCode) {
        return SettlementSpecificationBuilder.builder()
                .withCustodianId(custodianId)
                .withCustodianCode(custodianCode)
                .build();
    }

    public static Specification<SettlementEntity> createAdvancedFilter(
            Long tradeId, String sideId, String investorDocumentNumber,
            Boolean fiduciarySpecialist, String reference, Long custodianId) {

        return SettlementSpecificationBuilder.builder()
                .withTradeId(tradeId)
                .withSideId(sideId)
                .withInvestorDocumentNumber(investorDocumentNumber)
                .withFiduciarySpecialist(fiduciarySpecialist)
                .withReference(reference)
                .withCustodianId(custodianId)
                .build();
    }
}
