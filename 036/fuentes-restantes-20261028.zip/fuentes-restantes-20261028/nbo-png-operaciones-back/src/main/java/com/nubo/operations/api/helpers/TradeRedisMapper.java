package com.nubo.operations.api.helpers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

import org.springframework.stereotype.Component;

import com.nubo.operations.api.models.dto.response.CountryOutDto;
import com.nubo.operations.api.models.dto.response.CurrencyOutDto;
import com.nubo.operations.api.models.dto.response.MarketOutDto;
import com.nubo.operations.api.models.dto.response.ParticipantOutDto;
import com.nubo.operations.api.models.dto.response.SecurityTitleOutDto;
import com.nubo.operations.api.models.dto.response.StatusOutDto;
import com.nubo.operations.api.models.dto.response.TradeOutDto;
import com.nubo.operations.api.models.dto.response.TradingSessionOutDto;
import com.nubo.operations.api.models.dto.response.TradingSystemOutDto;
import com.nubo.operations.api.models.dto.response.TypeOutDto;

import io.redisearch.Document;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class TradeRedisMapper {

    public static final Set<String> NUMERIC_FIELDS = Set.of(
        "tradeid", "matchid", "quantity", "price", "volume",
        "repurchaserate", "repurchaseamount", "daystosettlement", "reporate", "repoamount",
        "fundingamount", "netoutflowtotal", "outflowturnovervalue", "totalnetreturn",
        "returnturnovervalue", "deliveryversuspaymentvalue", "advancestatus",
        "depositoryid", "countryid", "typeid", "marketid", "issuancemarketid",
        "securitytitlecurrencyid", "securitytitlesettlementperiod", "securitytitleparentid",
        "securitytitlecountryid", "securitytitleamountissued", "securitytitlesegmentid",
        "participantbuyid", "participantsellid", "custodianbuyid", "custodiansellid",
        "statusid", "currencyid", "tradingsystemid", "tradingsessionid",
        "businesstypeid", "markettypeid", "origintypeid", "paymenttypeid",
        "settlementtypeid", "custodianstatusid", "settlementstatusid", "bloquingstatusid"
    );

    public static final Set<String> TAG_FIELDS = Set.of(
        "countryname", "countrycode", "countrytimezone", "depositorydescription",
        "typedescription", "typecategory", "marketdescription", "marketcategory",
        "issuancemarketdescription", "issuancemarketcategory", "securitytitleequitycode",
        "securitytitlemnemonic", "securitytitleisin", "securitytitlesettlementperiod",
        "securitytitleparent", "securitytitleregulatorycode", "participantbuycode",
        "participantbuydocumentnumber", "participantbuyname", "participantbuyshortname",
        "participantbuymnemonic", "participantbuytaxcode", "participantbuymainaddress",
        "participantbuywebpage", "participantbuyphonenumber", "participantbuynitclearinghouse",
        "participantbuytypeentity", "participantbuymarginaccount", "participantbuymasteraccount",
        "participantbuydirectallocation", "participantbuymarketmaker", "participantbuyenabled",
        "participantbuycustodian", "participantsellcode", "participantselldocumentnumber",
        "participantsellname", "participantsellshortname", "participantsellmnemonic",
        "participantselltaxcode", "participantsellmainaddress", "participantsellwebpage",
        "participantsellphonenumber", "participantsellnitclearinghouse", "participantselltypeentity",
        "participantsellmarginaccount", "participantsellmasteraccount", "participantselldirectallocation",
        "participantsellmarketmaker", "participantsellenabled", "participantsellcustodian",
        "statusdescription", "statuscategory", "currencycode", "currencyname",
        "tradingsystemdescription", "tradingsessiondescription", "businesstypedescription",
        "businesstypecategory", "markettypedescription", "markettypecategory",
        "origintypedescription", "origintypecategory", "tradelastmodifyuser",
        "tradelastmodifyapplic", "tradelastmodifyip"
    );

    public static final Set<String> DATE_FIELDS = Set.of(
        "matchdate", "clearingdate", "returnclearingdate", "matchtime",
        "repurchaseagreementdate", "securitytitlelistingdate", "securitytitledelistingdate",
        "participantbuyregistrationdate", "participantsellregistrationdate",
        "custodianbuyregistrationdate", "custodiansellregistrationdate",
        "tradelastmodifydate"
    );

    public static final Map<String, Function<RedisMapperUtils.FilterContext, String>> FILTER_STRATEGIES = Map.ofEntries(
        Map.entry("equals", ctx -> RedisMapperUtils.buildEqualsFilter(ctx, TAG_FIELDS)),
        Map.entry("contains", ctx -> RedisMapperUtils.buildContainsFilter(ctx, TAG_FIELDS)),
        Map.entry("greater_than", RedisMapperUtils::buildGreaterThanFilter),
        Map.entry("less_than", RedisMapperUtils::buildLessThanFilter),
        Map.entry("greater_than_or_equal", RedisMapperUtils::buildGreaterThanOrEqualFilter),
        Map.entry("less_than_or_equal", RedisMapperUtils::buildLessThanOrEqualFilter),
        Map.entry("starts_with", ctx -> RedisMapperUtils.buildStartsWithFilter(ctx, TAG_FIELDS)),
        Map.entry("ends_with", ctx -> RedisMapperUtils.buildEndsWithFilter(ctx, TAG_FIELDS)),
        Map.entry("not_equals", ctx -> RedisMapperUtils.buildNotEqualsFilter(ctx, TAG_FIELDS)),
        Map.entry("in", ctx -> RedisMapperUtils.buildInFilter(ctx, TAG_FIELDS)),
        Map.entry("not_in", ctx -> RedisMapperUtils.buildNotInFilter(ctx, TAG_FIELDS)),
        Map.entry("is_empty", ctx -> RedisMapperUtils.buildIsEmptyFilter(ctx, TAG_FIELDS)),
        Map.entry("is_not_empty", ctx -> RedisMapperUtils.buildIsNotEmptyFilter(ctx, TAG_FIELDS)),
        Map.entry("not_contains", ctx -> RedisMapperUtils.buildNotContainsFilter(ctx, TAG_FIELDS))
    );

    public static class FilterContext extends RedisMapperUtils.FilterContext {
        public FilterContext(String redisFieldName, String fieldValue, boolean isNumericField, boolean isDateField) {
            super(redisFieldName, fieldValue, isNumericField, isDateField);
        }
    }

    private static final Map<String, String> FIELD_NAME_TO_REDIS_MAPPING = Map.ofEntries(
    Map.entry("id", "tradeid"),
    Map.entry("tradeId", "tradeid"),
    Map.entry("matchDate", "matchdate"),
    Map.entry("matchId", "matchid"),
    Map.entry("clearingDate", "clearingdate"),
    Map.entry("returnClearingDate", "returnclearingdate"),
    Map.entry("assignmentMarkBuy", "assignmentmarkbuy"),
    Map.entry("assignmentMarkSell", "assignmentmarksell"),
    Map.entry("fractionalMarkBuy", "fractionalmarkbuy"),
    Map.entry("fractionalMarkSell", "fractionalmarksell"),
    Map.entry("advanceStatus", "advancestatus"),
    Map.entry("exitIndicatorSettlement", "exitindicatorsettlement"),
    Map.entry("canceledStatus", "canceledstatus"),
    Map.entry("quantity", "quantity"),
    Map.entry("price", "price"),
    Map.entry("volume", "volume"),
    Map.entry("repurchaseRate", "repurchaserate"),
    Map.entry("repurchaseAmount", "repurchaseamount"),
    Map.entry("matchTime", "matchtime"),
    Map.entry("ownPositionSell", "ownpositionsell"),
    Map.entry("ownPositionBuy", "ownpositionbuy"),
    Map.entry("repurchaseAgreementDate", "repurchaseagreementdate"),
    Map.entry("daysToSettlement", "daystosettlement"),
    Map.entry("repoRate", "reporate"),
    Map.entry("repoAmount", "repoamount"),
    Map.entry("fundingAmount", "fundingamount"),
    Map.entry("netOutFlowTotal", "netoutflowtotal"),
    Map.entry("outFlowTurnOverValue", "outflowturnovervalue"),
    Map.entry("totalNetReturn", "totalnetreturn"),
    Map.entry("returnTurnoverValue", "returnturnovervalue"),
    Map.entry("deliveryVersusPaymentValue", "deliveryversuspaymentvalue"),
    Map.entry("reallocationIndicator", "reallocationindicator"),
    Map.entry("settlementIndicatorOutgoing", "settlementindicatoroutgoing"),
    Map.entry("settlementIndicatorReturn", "settlementindicatorreturn"),
    Map.entry("resettlementIndicatorAdvance", "resettlementindicatoradvance"),
    Map.entry("specialTradeId", "specialtradeid"),
    Map.entry("salesGuarantee", "salesguarantee"),
    Map.entry("purchaseGuarantee", "purchaseguarantee"),
    Map.entry("purchasePaymentIndicator", "purchasepaymentindicator"),
    Map.entry("returnIndicatorSettlement", "returnindicatorsettlement"),
    Map.entry("depositoryId", "depositoryid"),
    Map.entry("depositoryName", "depositorydescription"),
    Map.entry("countryId", "countryid"),
    Map.entry("countryName", "countryname"),
    Map.entry("countryCode", "countrycode"),
    Map.entry("typeId", "typeid"),
    Map.entry("typeDescription", "typedescription"),
    Map.entry("marketId", "marketid"),
    Map.entry("marketDescription", "marketdescription"),
    Map.entry("issuanceMarketId", "issuancemarketid"),
    Map.entry("issuanceMarketDescription", "issuancemarketdescription"),
    Map.entry("securityTitleId", "securitytitleequitycode"),
    Map.entry("securityTitleIsin", "securitytitleisin"),
    Map.entry("securityTitleMnemonic", "securitytitlemnemonic"),
    Map.entry("participantBuyId", "participantbuyid"),
    Map.entry("participantBuyName", "participantbuyname"),
    Map.entry("participantSellId", "participantsellid"),
    Map.entry("participantSellName", "participantsellname"),
    Map.entry("custodianBuyId", "custodianbuyid"),
    Map.entry("custodianBuyName", "custodianbuyname"),
    Map.entry("custodianSellId", "custodiansellid"),
    Map.entry("custodianSellName", "custodiansellname"),
    Map.entry("statusId", "statusid"),
    Map.entry("statusDescription", "statusdescription"),
    Map.entry("currencyId", "currencyid"),
    Map.entry("currencyCode", "currencycode"),
    Map.entry("currencyName", "currencyname"),
    Map.entry("tradingSystemId", "tradingsystemid"),
    Map.entry("tradingSystemDescription", "tradingsystemdescription"),
    Map.entry("tradingSessionId", "tradingsessionid"),
    Map.entry("tradingSessionDescription", "tradingsessiondescription"),
    Map.entry("businessTypeId", "businesstypeid"),
    Map.entry("businessTypeDescription", "businesstypedescription"),
    Map.entry("marketTypeId", "markettypeid"),
    Map.entry("marketTypeDescription", "markettypedescription"),
    Map.entry("originTypeId", "origintypeid"),
    Map.entry("originTypeDescription", "origintypedescription"),
    Map.entry("paymentTypeId", "paymenttypeid"),
    Map.entry("paymentTypeDescription", "paymenttypedescription"),
    Map.entry("settlementTypeId", "settlementtypeid"),
    Map.entry("settlementTypeDescription", "settlementtypedescription"),
    Map.entry("custodianStatusId", "custodianstatusid"),
    Map.entry("custodianStatusDescription", "custodianstatusdescription"),
    Map.entry("settlementStatusId", "settlementstatusid"),
    Map.entry("settlementStatusDescription", "settlementstatusdescription"),
    Map.entry("bloquingStatusId", "bloquingstatusid"),
    Map.entry("bloquingStatusDescription", "bloquingstatusdescription")
);

    public String mapFieldNameToRedisField(String fieldName) {
        return FIELD_NAME_TO_REDIS_MAPPING.get(fieldName);
    }

    public List<TradeOutDto> convertToTradeOutDto(List<Document> documents) {
        List<TradeOutDto> trades = new ArrayList<>();

        for (Document doc : documents) {
            try {
                TradeOutDto trade = mapDocumentToTradeOutDto(doc);
                trades.add(trade);
            } catch (Exception e) {
                log.warn("Error converting document to TradeOutDto: {}", e.getMessage());
            }
        }

        return trades;
    }

    private TradeOutDto mapDocumentToTradeOutDto(Document doc) {
        return TradeOutDto.builder()
            .id(RedisMapperUtils.parseLong(doc.get("tradeid")))
            .matchDate(RedisMapperUtils.parseLocalDate(doc.get("matchdate")))
            .matchId(RedisMapperUtils.parseLong(doc.get("matchid")))
            .clearingDate(RedisMapperUtils.parseLocalDate(doc.get("clearingdate")))
            .returnClearingDate(RedisMapperUtils.parseLocalDate(doc.get("returnclearingdate")))
            .assignmentMarkBuy(RedisMapperUtils.parseBoolean(doc.get("assignmentmarkbuy")))
            .assignmentMarkSell(RedisMapperUtils.parseBoolean(doc.get("assignmentmarksell")))
            .fractionalMarkBuy(RedisMapperUtils.parseBoolean(doc.get("fractionalmarkbuy")))
            .fractionalMarkSell(RedisMapperUtils.parseBoolean(doc.get("fractionalmarksell")))
            .advanceStatus(RedisMapperUtils.parseInt(doc.get("advancestatus")))
            .exitIndicatorSettlement(RedisMapperUtils.parseBoolean(doc.get("exitindicatorsettlement")))
            .canceledStatus(RedisMapperUtils.parseBoolean(doc.get("canceledstatus")))
            .quantity(RedisMapperUtils.parseBigDecimal(doc.get("quantity")))
            .price(RedisMapperUtils.parseBigDecimal(doc.get("price")))
            .volume(RedisMapperUtils.parseBigDecimal(doc.get("volume")))
            .repurchaseRate(RedisMapperUtils.parseBigDecimal(doc.get("repurchaserate")))
            .repurchaseAmount(RedisMapperUtils.parseBigDecimal(doc.get("repurchaseamount")))
            .matchTime(RedisMapperUtils.parseOffsetDateTime(doc.get("matchtime")))
            .ownPositionSell(RedisMapperUtils.parseBoolean(doc.get("ownpositionsell")))
            .ownPositionBuy(RedisMapperUtils.parseBoolean(doc.get("ownpositionbuy")))
            .repurchaseAgreementDate(RedisMapperUtils.parseLocalDate(doc.get("repurchaseagreementdate")))
            .daysToSettlement(RedisMapperUtils.parseInt(doc.get("daystosettlement")))
            .repoRate(RedisMapperUtils.parseBigDecimal(doc.get("reporate")))
            .repoAmount(RedisMapperUtils.parseBigDecimal(doc.get("repoamount")))
            .fundingAmount(RedisMapperUtils.parseBigDecimal(doc.get("fundingamount")))
            .netOutFlowTotal(RedisMapperUtils.parseBigDecimal(doc.get("netoutflowtotal")))
            .outFlowTurnOverValue(RedisMapperUtils.parseBigDecimal(doc.get("outflowturnovervalue")))
            .totalNetReturn(RedisMapperUtils.parseBigDecimal(doc.get("totalnetreturn")))
            .returnTurnoverValue(RedisMapperUtils.parseBigDecimal(doc.get("returnturnovervalue")))
            .deliveryVersusPaymentValue(RedisMapperUtils.parseBigDecimal(doc.get("deliveryversuspaymentvalue")))
            .reallocationIndicator(RedisMapperUtils.parseBoolean(doc.get("reallocationindicator")))
            .settlementIndicatorOutgoing(RedisMapperUtils.parseBoolean(doc.get("settlementindicatoroutgoing")))
            .settlementIndicatorReturn(RedisMapperUtils.parseBoolean(doc.get("settlementindicatorreturn")))
            .resettlementIndicatorAdvance(RedisMapperUtils.parseBoolean(doc.get("resettlementindicatoradvance")))
            .specialTradeId(RedisMapperUtils.parseLong(doc.get("specialtradeid")))
            .purchasePaymentIndicator(RedisMapperUtils.parseBoolean(doc.get("purchasepaymentindicator")))
            .returnIndicatorSettlement(RedisMapperUtils.parseBoolean(doc.get("returnindicatorsettlement")))
            .participantBuy(buildParticipantBuyDto(doc))
            .participantSell(buildParticipantSellDto(doc))
            .status(buildStatusDto(doc))
            .country(buildCountryDto(doc))
            .type(buildTypeDto(doc))
            .currency(buildCurrencyDto(doc))
            .securityTitle(buildSecurityTitleDto(doc))
            .market(buildMarketDto(doc))
            .issuanceMarket(buildIssuanceMarketDto(doc))
            .tradingSystem(buildTradingSystemDto(doc))
            .tradingSession(buildTradingSessionDto(doc))
            .build();
    }

    private ParticipantOutDto buildParticipantBuyDto(Document doc) {
        return ParticipantOutDto.builder()
            .id(RedisMapperUtils.parseLong(doc.get("participantbuyid")))
            .code(RedisMapperUtils.parseString(doc.get("participantbuycode")))
            .name(RedisMapperUtils.parseString(doc.get("participantbuyname")))
            .shortName(RedisMapperUtils.parseString(doc.get("participantbuyshortname")))
            .documentNumber(RedisMapperUtils.parseString(doc.get("participantbuydocumentnumber")))
            .mnemonic(RedisMapperUtils.parseString(doc.get("participantbuymnemonic")))
            .registrationDate(RedisMapperUtils.parseLocalDate(doc.get("participantbuyregistrationdate")))
            .taxCode(RedisMapperUtils.parseString(doc.get("participantbuytaxcode")))
            .mainAddress(RedisMapperUtils.parseString(doc.get("participantbuymainaddress")))
            .webPage(RedisMapperUtils.parseString(doc.get("participantbuywebpage")))
            .phoneNumber(RedisMapperUtils.parseString(doc.get("participantbuyphonenumber")))
            .nitClearingHouse(RedisMapperUtils.parseString(doc.get("participantbuynitclearinghouse")))
            .typeEntity(RedisMapperUtils.parseString(doc.get("participantbuytypeentity")))
            .marginAccount(RedisMapperUtils.parseString(doc.get("participantbuymarginaccount")))
            .masterAccount(RedisMapperUtils.parseString(doc.get("participantbuymasteraccount")))
            .directAllocation(RedisMapperUtils.parseString(doc.get("participantbuydirectallocation")))
            .marketMaker(RedisMapperUtils.parseString(doc.get("participantbuymarketmaker")))
            .enabled(RedisMapperUtils.parseBoolean(doc.get("participantbuyenabled")))
            .custodian(RedisMapperUtils.parseBoolean(doc.get("participantbuycustodian")))
            .build();
    }

    private ParticipantOutDto buildParticipantSellDto(Document doc) {
        return ParticipantOutDto.builder()
            .id(RedisMapperUtils.parseLong(doc.get("participantsellid")))
            .code(RedisMapperUtils.parseString(doc.get("participantsellcode")))
            .name(RedisMapperUtils.parseString(doc.get("participantsellname")))
            .shortName(RedisMapperUtils.parseString(doc.get("participantsellshortname")))
            .documentNumber(RedisMapperUtils.parseString(doc.get("participantselldocumentnumber")))
            .mnemonic(RedisMapperUtils.parseString(doc.get("participantsellmnemonic")))
            .registrationDate(RedisMapperUtils.parseLocalDate(doc.get("participantsellregistrationdate")))
            .taxCode(RedisMapperUtils.parseString(doc.get("participantselltaxcode")))
            .mainAddress(RedisMapperUtils.parseString(doc.get("participantsellmainaddress")))
            .webPage(RedisMapperUtils.parseString(doc.get("participantsellwebpage")))
            .phoneNumber(RedisMapperUtils.parseString(doc.get("participantsellphonenumber")))
            .nitClearingHouse(RedisMapperUtils.parseString(doc.get("participantsellnitclearinghouse")))
            .typeEntity(RedisMapperUtils.parseString(doc.get("participantselltypeentity")))
            .marginAccount(RedisMapperUtils.parseString(doc.get("participantsellmarginaccount")))
            .masterAccount(RedisMapperUtils.parseString(doc.get("participantsellmasteraccount")))
            .directAllocation(RedisMapperUtils.parseString(doc.get("participantselldirectallocation")))
            .marketMaker(RedisMapperUtils.parseString(doc.get("participantsellmarketmaker")))
            .enabled(RedisMapperUtils.parseBoolean(doc.get("participantsellenabled")))
            .custodian(RedisMapperUtils.parseBoolean(doc.get("participantsellcustodian")))
            .build();
    }

    private StatusOutDto buildStatusDto(Document doc) {
        return StatusOutDto.builder()
            .id(RedisMapperUtils.parseLong(doc.get("statusid")))
            .description(RedisMapperUtils.parseString(doc.get("statusdescription")))
            .category(RedisMapperUtils.parseString(doc.get("statuscategory")))
            .build();
    }

    private CountryOutDto buildCountryDto(Document doc) {
        return CountryOutDto.builder()
            .id(RedisMapperUtils.parseLong(doc.get("countryid")))
            .code(RedisMapperUtils.parseString(doc.get("countrycode")))
            .name(RedisMapperUtils.parseString(doc.get("countryname")))
            .timeZone(RedisMapperUtils.parseString(doc.get("countrytimezone")))
            .build();
    }

    private TypeOutDto buildTypeDto(Document doc) {
        return TypeOutDto.builder()
            .id(RedisMapperUtils.parseLong(doc.get("typeid")))
            .description(RedisMapperUtils.parseString(doc.get("typedescription")))
            .category(RedisMapperUtils.parseString(doc.get("typecategory")))
            .build();
    }

    private CurrencyOutDto buildCurrencyDto(Document doc) {
        return CurrencyOutDto.builder()
            .id(RedisMapperUtils.parseLong(doc.get("currencyid")))
            .code(RedisMapperUtils.parseString(doc.get("currencycode")))
            .name(RedisMapperUtils.parseString(doc.get("currencyname")))
            .build();
    }

    private SecurityTitleOutDto buildSecurityTitleDto(Document doc) {
        return SecurityTitleOutDto.builder()
            .equityCode(RedisMapperUtils.parseString(doc.get("securitytitleequitycode")))
            .mnemonic(RedisMapperUtils.parseString(doc.get("securitytitlemnemonic")))
            .isin(RedisMapperUtils.parseString(doc.get("securitytitleisin")))
            .currencyId(RedisMapperUtils.parseInt(doc.get("securitytitlecurrencyid")))
            .settlementPeriod(RedisMapperUtils.parseString(doc.get("securitytitlesettlementperiod")))
            .listingDate(RedisMapperUtils.parseLocalDateTime(doc.get("securitytitlelistingdate")))
            .delistingDate(RedisMapperUtils.parseLocalDate(doc.get("securitytitledelistingdate")))
            .parent(RedisMapperUtils.parseBoolean(doc.get("securitytitleparent")))
            .parentId(RedisMapperUtils.parseLong(doc.get("securitytitleparentid")))
            .countryId(RedisMapperUtils.parseInt(doc.get("securitytitlecountryid")))
            .amountIssued(RedisMapperUtils.parseBigInteger(doc.get("securitytitleamountissued")))
            .segmentId(RedisMapperUtils.parseInt(doc.get("securitytitlesegmentid")))
            .category(RedisMapperUtils.parseString(doc.get("securitytitlecategory")))
            .punishmentRepo(RedisMapperUtils.parseBigDecimal(doc.get("securitytitlepunishmentrepo")))
            .regulatoryCode(RedisMapperUtils.parseString(doc.get("securitytitleregulatorycode")))
            .build();
    }

    private MarketOutDto buildMarketDto(Document doc) {
        return MarketOutDto.builder()
            .id(RedisMapperUtils.parseString(doc.get("marketid")))
            .description(RedisMapperUtils.parseString(doc.get("marketdescription")))
            .category(RedisMapperUtils.parseString(doc.get("marketcategory")))
            .build();
    }

    private MarketOutDto buildIssuanceMarketDto(Document doc) {
        return MarketOutDto.builder()
            .id(RedisMapperUtils.parseString(doc.get("issuancemarketid")))
            .description(RedisMapperUtils.parseString(doc.get("issuancemarketdescription")))
            .category(RedisMapperUtils.parseString(doc.get("issuancemarketcategory")))
            .build();
    }

    private TradingSystemOutDto buildTradingSystemDto(Document doc) {
        return TradingSystemOutDto.builder()
            .id(RedisMapperUtils.parseLong(doc.get("tradingsystemid")))
            .description(RedisMapperUtils.parseString(doc.get("tradingsystemdescription")))
            .build();
    }

    private TradingSessionOutDto buildTradingSessionDto(Document doc) {
        return TradingSessionOutDto.builder()
            .id(RedisMapperUtils.parseString(doc.get("tradingsessionid")))
            .description(RedisMapperUtils.parseString(doc.get("tradingsessiondescription")))
            .build();
    }
}
