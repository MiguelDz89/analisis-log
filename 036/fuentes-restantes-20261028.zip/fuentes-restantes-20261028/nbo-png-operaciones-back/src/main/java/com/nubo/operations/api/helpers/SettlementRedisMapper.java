package com.nubo.operations.api.helpers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

import org.springframework.stereotype.Component;

import com.nubo.operations.api.models.dto.response.InvestorAccountOutDto;
import com.nubo.operations.api.models.dto.response.InvestorOutDto;
import com.nubo.operations.api.models.dto.response.ParticipantAccountOutDto;
import com.nubo.operations.api.models.dto.response.ParticipantOutDto;
import com.nubo.operations.api.models.dto.response.SettlementOutDto;
import com.nubo.operations.api.models.dto.response.SideOutDto;

import io.redisearch.Document;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SettlementRedisMapper {

    public static final Set<String> NUMERIC_FIELDS = Set.of(
        "tradeid", "fraction", "fractionquantity", "commissionpercentage", "commissionamount",
        "valtaxamount", "netamount", "transfervalue", "custodianid", "investorid",
        "tradestatusid", "tradespecialtradeid", "sideid", "matchid", "quantity", "price",
        "volume", "repurchaserate", "repurchaseamount", "daystosettlement", "reporate",
        "repoamount", "fundingamount", "netoutflowtotal", "outflowturnovervalue",
        "totalnetreturn", "returnturnovervalue", "deliveryversuspaymentvalue",
        "advancestatus", "depositoryid", "countryid", "typeid", "marketid",
        "issuancemarketid", "securitytitlecurrencyid", "securitytitlesettlementperiod",
        "securitytitleparentid", "securitytitlecountryid", "securitytitleamountissued",
        "securitytitlesegmentid", "participantbuyid", "participantsellid",
        "custodianbuyid", "custodiansellid", "settlementparticipantaccountid",
        "settlementtradingsystemid", "settlementstatusid", "settlementdirectdepositorid",
        "statusid", "currencyid", "tradingsystemid", "tradingsessionid",
        "businesstypeid", "markettypeid", "origintypeid", "paymenttypeid",
        "settlementtypeid", "custodianstatusid", "tradesettlementstatusid", "bloquingstatusid"
    );

    public static final Set<String> TAG_FIELDS = Set.of(
        "fiduciaryspecialist", "reference", "custodianname", "custodianceode", "masteraccount",
        "investorfirstname", "investorlastname", "investorcompanyname", "investordocumentnumber",
        "investoraccountnumber", "tradecanceledstatus", "matchdate", "clearingdate",
        "returnclearingdate", "assignmentmarkbuy", "assignmentmarksell", "fractionalmarkbuy",
        "fractionalmarksell", "exitindicatorsettlement", "canceledstatus", "matchtime",
        "ownpositionsell", "ownpositionbuy", "repurchaseagreementdate", "reallocationindicator",
        "settlementindicatoroutgoing", "settlementindicatorreturn", "resettlementindicatoradvance",
        "salesguarantee", "purchaseguarantee", "purchasepaymentindicator", "returnindicatorsettlement",
        "tradelastmodifyuser", "tradelastmodifyapplic", "tradelastmodifydate", "tradelastmodifyip",
        "settlementvaltax", "settlementwithholdingtax", "settlementwithholdingtaxamount",
        "settlementissuedreceipt", "settlementissuedreceiptnumber", "settlementrepoamount",
        "settlementfundingamount", "settlementnetoutflowtotal", "settlementoutflowturnovervalue",
        "settlementreturnturnovervalue", "settlementdeliveryversuspaymentvalue", "settlementamount",
        "settlementbrokerageservice", "settlementbankaccountid", "settlementcapitalgainvalue",
        "settlementdisbursementvalue", "settlementficadministratorid", "settlementreporate",
        "settlementlatepenality", "settlementcustodianstatus", "settlementparticipantinstructionid",
        "settlementvalidationdate", "settlementmodifyapplic", "settlementmodifyip",
        "settlementmodifydate", "settlementmodifyuser", "settlementlastmodifyuser",
        "settlementlastmodifyapplic", "settlementlastmodifydate", "settlementlastmodifyip",
        "depositorydescription", "countrycode", "countryname", "countrytimezone",
        "typedescription", "typecategory", "marketdescription", "marketcategory",
        "issuancemarketdescription", "issuancemarketcategory", "securitytitleequitycode",
        "securitytitlemnemonic", "securitytitleisin", "securitytitlelistingdate",
        "securitytitledelistingdate", "securitytitleparent", "securitytitlecategory",
        "securitytitlepunishmentrepo", "securitytitleregulatorycode", "participantbuycode",
        "participantbuydocumentnumber", "participantbuyname", "participantbuyshortname",
        "participantbuymnemonic", "participantbuyregistrationdate", "participantbuytaxcode",
        "participantbuymainaddress", "participantbuywebpage", "participantbuyphonenumber",
        "participantbuynitclearinghouse", "participantbuytypeentity", "participantbuymarginaccount",
        "participantbuydirectallocation", "participantbuymarketmaker", "participantbuyenabled",
        "participantbuycustodian", "participantsellcode", "participantselldocumentnumber",
        "participantsellname", "participantsellshortname", "participantsellmnemonic",
        "participantsellregistrationdate", "participantselltaxcode", "participantsellmainaddress",
        "participantsellwebpage", "participantsellphonenumber", "participantsellnitclearinghouse",
        "participantselltypeentity", "participantsellmarginaccount", "participantselldirectallocation",
        "participantsellmarketmaker", "participantsellenabled", "participantsellcustodian",
        "custodianbuycode", "custodianbuydocumentnumber", "custodianbuyname", "custodianbuyshortname",
        "custodianbuymnemonic", "custodianbuyregistrationdate", "custodianbuytaxcode",
        "custodianbuymainaddress", "custodianbuywebpage", "custodianbuyphonenumber",
        "custodianbuynitclearinghouse", "custodianbuytypeentity", "custodianbuymarginaccount",
        "custodianbuyenabled", "custodiansellcode", "custodianselldocumentnumber",
        "custodiansellname", "custodiansellshortname", "custodiansellmnemonic",
        "custodiansellregistrationdate", "custodianselltaxcode", "custodiansellmainaddress",
        "custodiansellwebpage", "custodiansellphonenumber", "custodiansellnitclearinghouse",
        "custodianselltypeentity", "custodiansellmarginaccount", "custodiansellencabled",
        "custodiansellcustodian", "settlementtradingsystemdescription", "settlementstatusdescription",
        "settlementstatuscategory", "settlementcustodiancode", "settlementcustodianshortname",
        "settlementsourcequotetypedescription", "settlementsourcequotetypecategory",
        "settlementdirectdepositorcode", "settlementdirectdepositorname", "settlementdirectdepositorshortname",
        "statusdescription", "statuscategory", "currencyname", "tradingsystemdescription",
        "tradingsessiondescription", "businesstypedescription", "businesstypecategory",
        "markettypedescription", "markettypecategory", "origintypedescription",
        "origintypecategory", "paymenttypedescription", "paymenttypecategory",
        "settlementtypedescription", "settlementtypecategory", "custodianstatusdescription",
        "custodianstatuscategory", "tradesettlementstatusdescription", "tradesettlementstatuscategory",
        "bloquingstatusdescription", "bloquingstatuscategory"
    );

    public static final Set<String> DATE_FIELDS = Set.of(
        "matchdate", "clearingdate", "returnclearingdate", "matchtime",
        "repurchaseagreementdate", "securitytitlelistingdate", "securitytitledelistingdate",
        "participantbuyregistrationdate", "participantsellregistrationdate",
        "custodianbuyregistrationdate", "custodiansellregistrationdate",
        "tradelastmodifydate", "settlementvalidationdate", "settlementmodifydate",
        "settlementlastmodifydate"
    );

    public static final Map<String, Function<RedisMapperUtils.FilterContext, String>> FILTER_STRATEGIES = Map.ofEntries(
        Map.entry("equals", ctx -> RedisMapperUtils.buildEqualsFilter(ctx, TAG_FIELDS)),
        Map.entry("contains", ctx -> RedisMapperUtils.buildContainsFilter(ctx, TAG_FIELDS)),
        Map.entry("greater_than", RedisMapperUtils::buildGreaterThanFilter),
        Map.entry("less_than", RedisMapperUtils::buildLessThanFilter),
        Map.entry("greater_than_or_equal", RedisMapperUtils::buildGreaterThanOrEqualFilter),
        Map.entry("less_than_or_equal", RedisMapperUtils::buildLessThanOrEqualFilter),
        Map.entry("starts_with", ctx -> RedisMapperUtils.buildStartsWithFilter(ctx, TAG_FIELDS)),
        Map.entry("ends_with", ctx -> RedisMapperUtils.buildEndsWithFilter(ctx, TAG_FIELDS)),
        Map.entry("not_equals", ctx -> RedisMapperUtils.buildNotEqualsFilter(ctx, TAG_FIELDS)),
        Map.entry("in", ctx -> RedisMapperUtils.buildInFilter(ctx, TAG_FIELDS)),
        Map.entry("not_in", ctx -> RedisMapperUtils.buildNotInFilter(ctx, TAG_FIELDS)),
        Map.entry("is_empty", ctx -> RedisMapperUtils.buildIsEmptyFilter(ctx, TAG_FIELDS)),
        Map.entry("is_not_empty", ctx -> RedisMapperUtils.buildIsNotEmptyFilter(ctx, TAG_FIELDS)),
        Map.entry("not_contains", ctx -> RedisMapperUtils.buildNotContainsFilter(ctx, TAG_FIELDS))
    );

    public static class FilterContext extends RedisMapperUtils.FilterContext {
        public FilterContext(String redisFieldName, String fieldValue, boolean isNumericField, boolean isDateField) {
            super(redisFieldName, fieldValue, isNumericField, isDateField);
        }
    }

    private static final Map<String, String> FIELD_NAME_TO_REDIS_MAPPING = Map.ofEntries(
        Map.entry("tradeId", "tradeid"),
        Map.entry("fraction", "fraction"),
        Map.entry("fiduciarySpecialist", "fiduciaryspecialist"),
        Map.entry("reference", "reference"),
        Map.entry("fractionQuantity", "fractionquantity"),
        Map.entry("commissionPercentage", "commissionpercentage"),
        Map.entry("commissionAmount", "commissionamount"),
        Map.entry("valTaxAmount", "valtaxamount"),
        Map.entry("netAmount", "netamount"),
        Map.entry("transferValue", "transfervalue"),
        Map.entry("custodianId", "custodianid"),
        Map.entry("custodianName", "custodianname"),
        Map.entry("custodianCode", "custodianceode"),
        Map.entry("masterAccount", "masteraccount"),
        Map.entry("investorId", "investorid"),
        Map.entry("investorFirstName", "investorfirstname"),
        Map.entry("investorLastName", "investorlastname"),
        Map.entry("investorCompanyName", "investorcompanyname"),
        Map.entry("investorDocumentNumber", "investordocumentnumber"),
        Map.entry("investorAccountNumber", "investoraccountnumber"),
        Map.entry("tradeStatusId", "tradestatusid"),
        Map.entry("tradeCanceledStatus", "tradecanceledstatus"),
        Map.entry("tradeSpecialTradeId", "tradespecialtradeid"),
        Map.entry("sideId", "sideid")
    );

    public String mapFieldNameToRedisField(String fieldName) {
        return FIELD_NAME_TO_REDIS_MAPPING.get(fieldName);
    }

    public List<SettlementOutDto> convertToSettlementOutDto(List<Document> documents) {
        List<SettlementOutDto> settlements = new ArrayList<>();
        
        for (Document doc : documents) {
            try {
                SettlementOutDto settlement = mapDocumentToSettlementOutDto(doc);
                settlements.add(settlement);
            } catch (Exception e) {
                log.warn("Error converting document to SettlementOutDto: {}", e.getMessage());
            }
        }
        
        return settlements;
    }

    private SettlementOutDto mapDocumentToSettlementOutDto(Document doc) {
        return SettlementOutDto.builder()
            .tradeId(RedisMapperUtils.parseLong(doc.get("tradeid")))
            .fraction(RedisMapperUtils.parseInt(doc.get("fraction")))
            .fiduciarySpecialist(RedisMapperUtils.parseBoolean(doc.get("fiduciaryspecialist")))
            .reference(RedisMapperUtils.parseString(doc.get("reference")))
            .fractionQuantity(RedisMapperUtils.parseBigDecimal(doc.get("fractionquantity")))
            .commissionPercentage(RedisMapperUtils.parseBigDecimal(doc.get("commissionpercentage")))
            .commissionAmount(RedisMapperUtils.parseBigDecimal(doc.get("commissionamount")))
            .valTaxAmount(RedisMapperUtils.parseBigDecimal(doc.get("valtaxamount")))
            .netAmount(RedisMapperUtils.parseBigDecimal(doc.get("netamount")))
            .transferValue(RedisMapperUtils.parseBigDecimal(doc.get("transfervalue")))
            .custodianId(RedisMapperUtils.parseLong(doc.get("custodianid")))
            .custodian(buildCustodianDto(doc))
            .investor(buildInvestorDto(doc))
            .investorAccount(buildInvestorAccountDto(doc))
            .participantAccount(buildParticipantAccountDto(doc))
            .side(buildSideDto(doc))
            .build();
    }

    private ParticipantOutDto buildCustodianDto(Document doc) {
        return ParticipantOutDto.builder()
            .id(RedisMapperUtils.parseLong(doc.get("custodianid")))
            .name(RedisMapperUtils.parseString(doc.get("custodianname")))
            .code(RedisMapperUtils.parseString(doc.get("custodianceode")))
            .build();
    }

    private InvestorOutDto buildInvestorDto(Document doc) {
        return InvestorOutDto.builder()
            .id(RedisMapperUtils.parseLong(doc.get("investorid")))
            .firstName(RedisMapperUtils.parseString(doc.get("investorfirstname")))
            .lastName(RedisMapperUtils.parseString(doc.get("investorlastname")))
            .companyName(RedisMapperUtils.parseString(doc.get("investorcompanyname")))
            .documentNumber(RedisMapperUtils.parseString(doc.get("investordocumentnumber")))
            .build();
    }

    private InvestorAccountOutDto buildInvestorAccountDto(Document doc) {
        return InvestorAccountOutDto.builder()
            .accountNumber(RedisMapperUtils.parseString(doc.get("investoraccountnumber")))
            .build();
    }

    private ParticipantAccountOutDto buildParticipantAccountDto(Document doc) {
        return ParticipantAccountOutDto.builder()
            .participant(buildParticipantDto(doc))
            .build();
    }

    private ParticipantOutDto buildParticipantDto(Document doc) {
        return ParticipantOutDto.builder()
            .masterAccount(RedisMapperUtils.parseString(doc.get("masteraccount")))
            .build();
    }

    private SideOutDto buildSideDto(Document doc) {
        return SideOutDto.builder()
            .id(RedisMapperUtils.parseString(doc.get("sideid")))
            .build();
    }
}
