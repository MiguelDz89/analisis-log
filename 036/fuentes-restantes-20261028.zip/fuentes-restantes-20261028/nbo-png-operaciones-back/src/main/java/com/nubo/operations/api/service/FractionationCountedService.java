package com.nubo.operations.api.service;

import com.nubo.operations.api.client.operation.fractionation.models.dto.request.AssignmentInDto;
import com.nubo.operations.api.client.operation.fractionation.models.dto.request.FractionInDto;
import com.nubo.operations.api.models.dto.response.SettlementOutDto;

import java.util.List;

public interface FractionationCountedService {

    List<SettlementOutDto> createFractions(Long tradeId, String sideId, List<FractionInDto> fractionInDtoList);

    List<SettlementOutDto> updateAssignment(Long tradeId, String sideId, List<AssignmentInDto> assignmentInDtoList);

}
