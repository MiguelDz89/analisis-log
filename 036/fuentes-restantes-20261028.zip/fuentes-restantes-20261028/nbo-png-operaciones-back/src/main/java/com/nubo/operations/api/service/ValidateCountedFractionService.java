package com.nubo.operations.api.service;

import com.nubo.operations.api.client.operation.rules.models.dto.request.FractionRuleInDto;
import com.nubo.operations.api.models.dto.response.FractionAccountOutDto;
import com.nubo.operations.api.models.dto.response.ParticipantOutDto;

import java.util.List;

public interface ValidateCountedFractionService {

    FractionAccountOutDto validateAccountFractionCorrection(String accountNumber, Long tradeId, String sideId);

    Boolean validateQuantityFractionsCorrection(Long tradeId, List<FractionRuleInDto> fractionRuleInDtoList);

    Boolean validateRangeQuantityFractionsCorrection(Long tradeId, List<FractionRuleInDto> fractionRuleInDtoList);

    Boolean validateMaximumLimitFractionsCorrection(Long tradeId, List<FractionRuleInDto> fractionRuleInDtoList);

    ParticipantOutDto validateDirectDepositorFractionCorrection(Long tradeId, String sideId);

}
