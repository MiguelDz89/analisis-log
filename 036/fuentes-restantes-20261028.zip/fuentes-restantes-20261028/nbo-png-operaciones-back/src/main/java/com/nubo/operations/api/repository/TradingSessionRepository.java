package com.nubo.operations.api.repository;

import com.nubo.operations.api.models.entity.TradingSessionEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TradingSessionRepository extends JpaRepository<TradingSessionEntity, String> {
}
