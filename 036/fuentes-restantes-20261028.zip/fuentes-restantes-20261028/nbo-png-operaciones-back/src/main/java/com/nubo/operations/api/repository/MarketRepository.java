package com.nubo.operations.api.repository;

import com.nubo.operations.api.models.entity.MarketEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MarketRepository extends JpaRepository<MarketEntity, String> {
}
