package com.nubo.operations.api.helpers;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.nubo.operations.api.models.domain.TradeParams;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class QueryFilterBuilder {

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final String MATCH_DATE_FIELD = "matchdate";
    private static final String CLEARING_DATE_FIELD = "clearingdate";

    public String buildMatchIdFilter(Long matchId) {
        return "@matchid:[" + matchId + " " + matchId + "]";
    }

    public String buildStatusFilter(Integer statusId) {
        return "@statusid:[" + statusId + " " + statusId + "]";
    }

    public String buildParticipantFilter(Long participantId) {
        return "(@participantbuyid:[" + participantId + " " + participantId + "]|@participantsellid:[" + participantId + " " + participantId + "])";
    }

    public String buildTypeFilter(Long typeId) {
        return "@typeid:[" + typeId + " " + typeId + "]";
    }

    public String buildCountryFilter(Long countryId) {
        return "@countryid:[" + countryId + " " + countryId + "]";
    }

    public String buildDateRangeFilter(LocalDate startDate, LocalDate endDate) {
        if (startDate != null && endDate != null) {
            String startStr = startDate.format(DATE_FORMATTER);
            String endStr = endDate.format(DATE_FORMATTER);
            return buildDateRangeFilter(MATCH_DATE_FIELD, startStr, endStr);
        } else if (startDate != null) {
            String startStr = startDate.format(DATE_FORMATTER);
            return buildDateTokenQuery(MATCH_DATE_FIELD, startStr);
        } else if (endDate != null) {
            String endStr = endDate.format(DATE_FORMATTER);
            return buildDateTokenQuery(MATCH_DATE_FIELD, endStr);
        }
        return null;
    }

    public String buildClearingDateFilter(LocalDate clearingDate) {
        if (clearingDate != null) {
            String dateStr = clearingDate.format(DATE_FORMATTER);
            return buildDateTokenQuery(CLEARING_DATE_FIELD, dateStr);
        }
        return null;
    }

    private String buildDateTokenQuery(String fieldName, String dateValue) {
        log.debug("Building date token query for field: {} with value: {}", fieldName, dateValue);

        if (dateValue.matches("\\d{4}-\\d{2}-\\d{2}")) {
            String[] parts = dateValue.split("-");
            String year = parts[0];
            String month = parts[1];
            String day = parts[2];

            String query = String.format("(@%s:*%s*) (@%s:*%s*) (@%s:*%s*)",
                           fieldName, year, fieldName, month, fieldName, day);
            log.debug("Generated date token query: {}", query);
            return query;
        }

        return "@" + fieldName + ":*" + dateValue + "*";
    }

    private String buildDateRangeFilter(String fieldName, String startDate, String endDate) {
        log.debug("Building date range filter for field: {} from {} to {}", fieldName, startDate, endDate);

        String[] startParts = startDate.split("-");
        String[] endParts = endDate.split("-");

        String startYear = startParts[0];
        String startMonth = startParts[1];
        String endYear = endParts[0];
        String endMonth = endParts[1];

        if (startYear.equals(endYear) && startMonth.equals(endMonth)) {
            String query = String.format("(@%s:*%s*) (@%s:*%s*)",
                           fieldName, startYear, fieldName, startMonth);
            log.debug("Generated same year-month range query: {}", query);
            return query;
        }

        if (startYear.equals(endYear)) {
            String query = String.format("@%s:*%s*", fieldName, startYear);
            log.debug("Generated same year range query: {}", query);
            return query;
        }

        String query = String.format("(@%s:*%s*|@%s:*%s*)",
                       fieldName, startYear, fieldName, endYear);
        log.debug("Generated multi-year range query: {}", query);
        return query;
    }

    public List<String> buildCommonFilters(TradeParams tradeParams) {
        List<String> filters = new ArrayList<>();

        if (tradeParams.matchId() != null) {
            filters.add(buildMatchIdFilter(tradeParams.matchId()));
        }

        if (tradeParams.statusId() != null) {
            filters.add(buildStatusFilter(tradeParams.statusId()));
        }

        if (tradeParams.participantId() != null) {
            filters.add(buildParticipantFilter(tradeParams.participantId()));
        }

        if (tradeParams.typeId() != null) {
            filters.add(buildTypeFilter(tradeParams.typeId()));
        }

        if (tradeParams.countryId() != null) {
            filters.add(buildCountryFilter(tradeParams.countryId()));
        }

        String dateRangeFilter = buildDateRangeFilter(tradeParams.startMatchDate(), tradeParams.endMatchDate());
        if (dateRangeFilter != null) {
            filters.add(dateRangeFilter);
        }

        String clearingDateFilter = buildClearingDateFilter(tradeParams.endClearingDate());
        if (clearingDateFilter != null) {
            filters.add(clearingDateFilter);
        }

        return filters;
    }
}
