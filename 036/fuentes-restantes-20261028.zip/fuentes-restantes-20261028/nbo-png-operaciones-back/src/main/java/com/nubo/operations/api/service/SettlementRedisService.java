package com.nubo.operations.api.service;

import org.springframework.data.domain.Pageable;

import com.nubo.operations.api.models.dto.response.PageResponseOutDto;
import com.nubo.operations.api.models.dto.response.SettlementOutDto;

public interface SettlementRedisService {

    PageResponseOutDto<SettlementOutDto> findAllSettlementsDynamic(
            Pageable pageable,
            String fieldName,
            String fieldValue,
            String operation,
            Long tradeId,
            String sideId,
            String investorDocumentNumber);

    PageResponseOutDto<SettlementOutDto> findAllSettlementsRedisOnly(
            Pageable pageable,
            String fieldName,
            String fieldValue,
            String operation,
            Long tradeId,
            String sideId,
            String investorDocumentNumber);
}
