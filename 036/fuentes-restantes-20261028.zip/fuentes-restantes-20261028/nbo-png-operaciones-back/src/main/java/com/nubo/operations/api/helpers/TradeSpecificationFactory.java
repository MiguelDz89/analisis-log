package com.nubo.operations.api.helpers;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.nubo.operations.api.models.domain.TradeParams;
import com.nubo.operations.api.models.entity.TradeEntity;
import com.nubo.operations.api.models.enums.SearchOperationEnum;

import jakarta.persistence.criteria.Path;


public class TradeSpecificationFactory {

    private TradeSpecificationFactory() {
        throw new IllegalStateException("Utility class");
    }

    public static Specification<TradeEntity> createStandardFilter(TradeParams tradeParams) {
        if (tradeParams == null) {
            return TradeSpecificationBuilder.builder()
                    .build();
        }
        var countryIds = tradeParams.countryIds();
        if ((countryIds == null || countryIds.isEmpty()) && tradeParams.countryId() != null) {
            countryIds = List.of(tradeParams.countryId());
        }

        return TradeSpecificationBuilder.builder()
                .withMatchId(tradeParams.matchId())
                .withCanceledStatus(tradeParams.canceledStatus())
                .withParticipantId(tradeParams.participantId())
                .withTypeId(tradeParams.typeId())
                .withCountryIds(countryIds)
                .withCountryId(tradeParams.countryId())
                .withMatchDateRange(tradeParams.startMatchDate(), tradeParams.endMatchDate())
                .withStatusId(tradeParams.statusId())
                .withEndClearingDate(tradeParams.endClearingDate())
                .withOnlyOperation(tradeParams.onlyOperation())
                .build();
    }

    public static Specification<TradeEntity> createDynamicFilter(
            String fieldName, String fieldValue, SearchOperationEnum operation) {

        return (root, query, cb) -> {
            try {
                Path<?> fieldPath = MapperTradeDynamicSearch.getTradeFieldPath(root, fieldName);
                if (fieldPath != null) {
                    return MapperTradeDynamicSearch.buildTradeFieldPredicate(cb, fieldPath, fieldValue, operation);
                }
                return cb.conjunction();
            } catch (Exception e) {
                return cb.conjunction();
            }
        };
    }

    public static Specification<TradeEntity> createCombinedFilter(
            TradeParams tradeParams,
            String fieldName, String fieldValue, SearchOperationEnum operation) {

        if (tradeParams == null) {
            return TradeSpecificationBuilder.builder()
                    .withDynamicFilter(fieldName, fieldValue, operation)
                    .build();
        }

        return TradeSpecificationBuilder.builder()
                .withMatchId(tradeParams.matchId())
                .withCanceledStatus(tradeParams.canceledStatus())
                .withParticipantId(tradeParams.participantId())
                .withTypeId(tradeParams.typeId())
                .withCountryId(tradeParams.countryId())
                .withMatchDateRange(tradeParams.startMatchDate(), tradeParams.endMatchDate())
                .withStatusId(tradeParams.statusId())
                .withEndClearingDate(tradeParams.endClearingDate())
                .withDynamicFilter(fieldName, fieldValue, operation)
                .build();
    }

    public static Specification<TradeEntity> createMatchIdFilter(Long matchId) {
        return TradeSpecificationBuilder.builder()
                .withMatchId(matchId)
                .build();
    }

    public static Specification<TradeEntity> createDateCountryFilter(LocalDate startMatchDate, LocalDate endMatchDate, Long countryId) {
        return TradeSpecificationBuilder.builder()
                .withMatchDateRange(startMatchDate, endMatchDate)
                .withCountryId(countryId)
                .build();
    }

    public static Specification<TradeEntity> createParticipantTypeFilter(Long participantId, Long typeId) {
        return TradeSpecificationBuilder.builder()
                .withParticipantId(participantId)
                .withTypeId(typeId)
                .build();
    }


}
