package com.nubo.operations.api.helpers;

import java.util.List;

import org.springframework.util.ObjectUtils;

import com.nubo.operations.api.client.operation.calculation.models.dto.response.SettleAccountsOutDto;
import com.nubo.operations.api.models.dto.response.AllTradeOutDto;
import com.nubo.operations.api.models.dto.response.CalculationOutDto;
import com.nubo.operations.api.models.dto.response.CfiOutDto;
import com.nubo.operations.api.models.dto.response.CityOutDto;
import com.nubo.operations.api.models.dto.response.ClassOutDto;
import com.nubo.operations.api.models.dto.response.CountryOutDto;
import com.nubo.operations.api.models.dto.response.CurrencyOutDto;
import com.nubo.operations.api.models.dto.response.DepartmentOutDto;
import com.nubo.operations.api.models.dto.response.DepositoryOutDto;
import com.nubo.operations.api.models.dto.response.GicsOutDto;
import com.nubo.operations.api.models.dto.response.IdentificationTypeOutDto;
import com.nubo.operations.api.models.dto.response.InvestorAccountOutDto;
import com.nubo.operations.api.models.dto.response.InvestorOutDto;
import com.nubo.operations.api.models.dto.response.MarketOutDto;
import com.nubo.operations.api.models.dto.response.ParticipantAccountOutDto;
import com.nubo.operations.api.models.dto.response.ParticipantOutDto;
import com.nubo.operations.api.models.dto.response.SecurityTitleOutDto;
import com.nubo.operations.api.models.dto.response.SettlementOutDto;
import com.nubo.operations.api.models.dto.response.SideOutDto;
import com.nubo.operations.api.models.dto.response.StatusOutDto;
import com.nubo.operations.api.models.dto.response.TaxStatusOutDto;
import com.nubo.operations.api.models.dto.response.TradeEquityOutDto;
import com.nubo.operations.api.models.dto.response.TradeOutDto;
import com.nubo.operations.api.models.dto.response.TradingSessionOutDto;
import com.nubo.operations.api.models.dto.response.TradingSystemOutDto;
import com.nubo.operations.api.models.dto.response.TypeOutDto;
import com.nubo.operations.api.models.entity.CfiEntity;
import com.nubo.operations.api.models.entity.CityEntity;
import com.nubo.operations.api.models.entity.ClassEntity;
import com.nubo.operations.api.models.entity.CountryEntity;
import com.nubo.operations.api.models.entity.CurrencyEntity;
import com.nubo.operations.api.models.entity.DepartmentEntity;
import com.nubo.operations.api.models.entity.DepositoryEntity;
import com.nubo.operations.api.models.entity.GicsEntity;
import com.nubo.operations.api.models.entity.IdentificationTypeEntity;
import com.nubo.operations.api.models.entity.InvestorAccountEntity;
import com.nubo.operations.api.models.entity.InvestorEntity;
import com.nubo.operations.api.models.entity.MarketEntity;
import com.nubo.operations.api.models.entity.ParticipantAccountEntity;
import com.nubo.operations.api.models.entity.ParticipantEntity;
import com.nubo.operations.api.models.entity.SecurityTitleEntity;
import com.nubo.operations.api.models.entity.SettlementEntity;
import com.nubo.operations.api.models.entity.SideEntity;
import com.nubo.operations.api.models.entity.StatusEntity;
import com.nubo.operations.api.models.entity.TaxStatusEntity;
import com.nubo.operations.api.models.entity.TradeEntity;
import com.nubo.operations.api.models.entity.TradeEquityEntity;
import com.nubo.operations.api.models.entity.TradingSessionEntity;
import com.nubo.operations.api.models.entity.TradingSystemEntity;
import com.nubo.operations.api.models.entity.TypeEntity;
import com.nubo.operations.api.models.enums.SideEnum;

public final class MapperUtil {

    private MapperUtil() {
    }

    public static TradeOutDto tradeEntityToTradeOutDto(TradeEntity tradeEntity) {
        if (tradeEntity == null)
            return null;
        ParticipantOutDto participantSellDto = participantEntityToParticipantOutDto(tradeEntity.getParticipantSell());

        return TradeOutDto.builder()
                .id(tradeEntity.getId())
                .matchDate(tradeEntity.getMatchDate())
                .matchId(tradeEntity.getMatchId())
                .clearingDate(tradeEntity.getClearingDate())
                .returnClearingDate(tradeEntity.getReturnClearingDate())
                .depository(depositoryEntityToDepositoryOutDto(tradeEntity.getDepository()))
                .country(countryEntityToCountryOutDto(tradeEntity.getCountry()))
                .type(typeEntityToTypeOutDto(tradeEntity.getType()))
                .market(marketEntityToMarketOutDto(tradeEntity.getMarket()))
                .issuanceMarket(marketEntityToMarketOutDto(tradeEntity.getIssuanceMarket()))
                .securityTitle(securityTitleEntityToSecurityTitleOutDto(tradeEntity.getSecurityTitle()))
                .participantBuy(participantEntityToParticipantOutDto(tradeEntity.getParticipantBuy()))
                .participantSell(
                        Boolean.TRUE.equals(tradeEntity.getOwnPositionBuy()) && participantSellDto != null
                                ? participantSellDto.toBuilder().code("-").build()
                                : participantSellDto)
                .custodianBuy(participantEntityToParticipantOutDto(tradeEntity.getCustodianBuy()))
                .custodianSell(participantEntityToParticipantOutDto(tradeEntity.getCustodianSell()))
                .assignmentMarkBuy(tradeEntity.getAssignmentMarkBuy())
                .assignmentMarkSell(tradeEntity.getAssignmentMarkSell())
                .fractionalMarkBuy(tradeEntity.getFractionalMarkBuy())
                .fractionalMarkSell(tradeEntity.getFractionalMarkSell())
                .advanceStatus(tradeEntity.getAdvanceStatus())
                .exitIndicatorSettlement(tradeEntity.getExitIndicatorSettlement())
                .canceledStatus(tradeEntity.getCanceledStatus())
                .quantity(tradeEntity.getQuantity())
                .price(tradeEntity.getPrice())
                .volume(tradeEntity.getVolume())
                .repurchaseRate(tradeEntity.getRepurchaseRate())
                .repurchaseAmount(tradeEntity.getRepurchaseAmount())
                .status(statusEntityToStatusOutDto(tradeEntity.getStatus()))
                .matchTime(tradeEntity.getMatchTime())
                .ownPositionSell(tradeEntity.getOwnPositionSell())
                .ownPositionBuy(tradeEntity.getOwnPositionBuy())
                .currency(currencyEntityToCurrencyOutDto(tradeEntity.getCurrency()))
                .tradingSystem(tradingSystemEntityToTradingSystemOutDto(tradeEntity.getTradingSystem()))
                .tradingSession(tradingSessionEntityToTradingSessionOutDto(tradeEntity.getTradingSession()))
                .repurchaseAgreementDate(tradeEntity.getRepurchaseAgreementDate())
                .daysToSettlement(tradeEntity.getDaysToSettlement())
                .repoRate(tradeEntity.getRepoRate())
                .repoAmount(tradeEntity.getRepoAmount())
                .fundingAmount(tradeEntity.getFundingAmount())
                .netOutFlowTotal(tradeEntity.getNetOutFlowTotal())
                .outFlowTurnOverValue(tradeEntity.getOutFlowTurnOverValue())
                .totalNetReturn(tradeEntity.getTotalNetReturn())
                .returnTurnoverValue(tradeEntity.getReturnTurnoverValue())
                .deliveryVersusPaymentValue(tradeEntity.getDeliveryVersusPaymentValue())
                .reallocationIndicator(tradeEntity.getReallocationIndicator())
                .businessType(typeEntityToTypeOutDto(tradeEntity.getBusinessType()))
                .marketType(typeEntityToTypeOutDto(tradeEntity.getMarketType()))
                .originType(typeEntityToTypeOutDto(tradeEntity.getOriginType()))
                .settlementIndicatorOutgoing(tradeEntity.getSettlementIndicatorOutgoing())
                .settlementIndicatorReturn(tradeEntity.getSettlementIndicatorReturn())
                .resettlementIndicatorAdvance(tradeEntity.getResettlementIndicatorAdvance())
                .specialTradeId(tradeEntity.getSpecialTradeId())
                .paymentType(typeEntityToTypeOutDto(tradeEntity.getPaymentType()))
                .settlementType(typeEntityToTypeOutDto(tradeEntity.getSettlementType()))
                .custodianStatus(statusEntityToStatusOutDto(tradeEntity.getCustodianStatus()))
                .settlementStatus(statusEntityToStatusOutDto(tradeEntity.getSettlementStatus()))
                .bloquingStatus(statusEntityToStatusOutDto(tradeEntity.getBloquingStatus()))
                .purchasePaymentIndicator(tradeEntity.getPurchasePaymentIndicator())
                .returnIndicatorSettlement(tradeEntity.getReturnIndicatorSettlement())
                .build();
    }

    public static CountryOutDto countryEntityToCountryOutDto(CountryEntity countryEntity) {
        if (ObjectUtils.isEmpty(countryEntity))
            return null;
        return CountryOutDto.builder()
                .id(countryEntity.getId())
                .code(countryEntity.getCode())
                .name(countryEntity.getName())
                .currency(currencyEntityToCurrencyOutDto(countryEntity.getCurrency()))
                .timeZone(countryEntity.getTimeZone())
                .build();
    }

    public static CurrencyOutDto currencyEntityToCurrencyOutDto(CurrencyEntity currencyEntity) {
        if (ObjectUtils.isEmpty(currencyEntity))
            return null;
        return CurrencyOutDto.builder()
                .id(currencyEntity.getId())
                .code(currencyEntity.getCode())
                .name(currencyEntity.getName())
                .build();
    }

    public static SecurityTitleOutDto securityTitleEntityToSecurityTitleOutDto(
            SecurityTitleEntity securityTitleEntity) {
        if (ObjectUtils.isEmpty(securityTitleEntity))
            return null;
        return SecurityTitleOutDto.builder()
                .id(securityTitleEntity.getId())
                .market(marketEntityToMarketOutDto(securityTitleEntity.getMarket()))
                .equityCode(securityTitleEntity.getEquityCode())
                .mnemonic(securityTitleEntity.getMnemonic())
                .isin(securityTitleEntity.getIsin())
                .cfi(cfiEntityToCfiOutDto(securityTitleEntity.getCfi()))
                .currencyId(securityTitleEntity.getCurrencyId())
                .settlementPeriod(securityTitleEntity.getSettlementPeriod())
                .listingDate(securityTitleEntity.getListingDate())
                .delistingDate(securityTitleEntity.getDelistingDate())
                .parent(securityTitleEntity.getParent())
                .parentId(securityTitleEntity.getParentId())
                .status(statusEntityToStatusOutDto(securityTitleEntity.getStatus()))
                .issuerName(ObjectUtils.isEmpty(securityTitleEntity.getIssuer()) ? null
                        : securityTitleEntity.getIssuer().getName())
                .countryId(securityTitleEntity.getCountryId())
                .amountIssued(securityTitleEntity.getAmountIssued())
                .clazz(classEntityToClassOutDto(securityTitleEntity.getClazz()))
                .segmentId(securityTitleEntity.getSegmentId())
                .category(securityTitleEntity.getCategory())
                .depository(depositoryEntityToDepositoryOutDto(securityTitleEntity.getDepository()))
                .punishmentRepo(securityTitleEntity.getPunishmentRepo())
                .regulatoryCode(securityTitleEntity.getRegulatoryCode())
                .build();
    }

    public static ParticipantOutDto participantEntityToParticipantOutDto(ParticipantEntity participantEntity) {
        if (ObjectUtils.isEmpty(participantEntity))
            return null;
        return ParticipantOutDto.builder()
                .id(participantEntity.getId())
                .code(participantEntity.getCode())
                .documentNumber(participantEntity.getDocumentNumber())
                .identificationType(
                        identificationTypeEntityToIdentificationTypeOutDto(participantEntity.getIdentificationType()))
                .name(participantEntity.getName())
                .shortName(participantEntity.getShortName())
                .type(typeEntityToTypeOutDto(participantEntity.getType()))
                .mnemonic(participantEntity.getMnemonic())
                .country(countryEntityToCountryOutDto(participantEntity.getCountry()))
                .registrationDate(participantEntity.getRegistrationDate())
                .taxCode(participantEntity.getTaxCode())
                .department(departmentEntityToDepartmentOutDto(participantEntity.getDepartment()))
                .mainAddress(participantEntity.getMainAddress())
                .webPage(participantEntity.getWebPage())
                .phoneNumber(participantEntity.getPhoneNumber())
                .status(statusEntityToStatusOutDto(participantEntity.getStatus()))
                .nitClearingHouse(participantEntity.getNitClearingHouse())
                .taxStatus(taxStatusEntityToTaxStatusOutDto(participantEntity.getTaxStatus()))
                .typeEntity(participantEntity.getTypeEntity())
                .marginAccount(participantEntity.getMarginAccount())
                .masterAccount(participantEntity.getMasterAccount())
                .directAllocation(participantEntity.getDirectAllocation())
                .marketMaker(participantEntity.getMarketMaker())
                .enabled(participantEntity.getEnabled())
                .custodian(participantEntity.getCustodian())
                .build();
    }

    public static TradeEquityOutDto tradeEquityEntityToTradeEquityOutDto(TradeEquityEntity tradeEquityEntity) {
        return TradeEquityOutDto.builder()
                .tradeId(tradeEquityEntity.getTradeId())
                .foreignBrokerBuy(tradeEquityEntity.getForeignBrokerBuy())
                .foreignBrokerSell(tradeEquityEntity.getForeignBrokerSell())
                .directDepositorBuy(tradeEquityEntity.getDirectDepositorBuy())
                .directDepositorSell(tradeEquityEntity.getDirectDepositorSell())
                .sourceIndicatorBuy(tradeEquityEntity.getSourceIndicatorBuy())
                .sourceIndicatorSell(tradeEquityEntity.getSourceIndicatorSell())
                .responsibleTradeBuy(tradeEquityEntity.getResponsibleTradeBuy())
                .responsibleTradeSell(tradeEquityEntity.getResponsibleTradeSell())
                .referenceBuy(tradeEquityEntity.getReferenceBuy())
                .referenceSell(tradeEquityEntity.getReferenceSell())
                .orderBookId(tradeEquityEntity.getOrderBookId())
                .prearrangedOperation(tradeEquityEntity.getPrearrangedOperation())
                .aggressiveTip(tradeEquityEntity.getAggressiveTip())
                .exdividendPeriod(tradeEquityEntity.getExdividendPeriod())
                .build();
    }

    public static SettlementOutDto settlementEntityToSettlementOutDto(SettlementEntity settlementEntity) {
        var trade = settlementEntity.getTrade();
        var sideId = settlementEntity.getSide() != null ? settlementEntity.getSide().getId() : null;
        var sourceQuoteFromTrade = (sideId != null && sideId.equals(SideEnum.BUY.getValue()))
                ? (trade != null ? trade.getSourceQuoteBuyType() : null)
                : (sideId != null && sideId.equals(SideEnum.SELL.getValue()))
                        ? (trade != null ? trade.getSourceQuoteSellType() : null)
                        : null;

        return SettlementOutDto.builder()
                .tradeId(settlementEntity.getTrade().getId())
                .fraction(settlementEntity.getFraction())
                .side(sideEntityToSideOutDto(settlementEntity.getSide()))
                .investor(investorEntityToInvestorOutDto(settlementEntity.getInvestor()))// RTBOF-6147
                .investorAccount(investorAccountEntityToInvestorAccountOutDto(settlementEntity.getInvestorAccount()))
                .participantAccount(
                        participantAccountEntityToParticipantAccountOutDto(settlementEntity.getParticipantAccount()))
                .fractionQuantity(settlementEntity.getFractionQuantity())
                .fractionVolume(settlementEntity.getFractionVolume())
                .fiduciarySpecialist(settlementEntity.getFiduciarySpecialist())
                .commissionPercentage(settlementEntity.getCommissionPercentage())
                .commissionAmount(settlementEntity.getCommissionAmount())
                .valTax(settlementEntity.getValTax())
                .valTaxAmount(settlementEntity.getValTaxAmount())
                .withholdingTax(settlementEntity.getWithholdingTax())
                .withholdingTaxAmount(settlementEntity.getWithholdingTaxAmount())
                .netAmount(settlementEntity.getNetAmount())
                .transferValue(settlementEntity.getTransferValue())
                .issuedReceipt(settlementEntity.getIssuedReceipt())
                .issuedReceiptNumber(settlementEntity.getIssuedReceiptNumber())
                .referenceAllocId(settlementEntity.getReferenceAllocId())
                .repoAmount(settlementEntity.getRepoAmount())
                .fundingAmount(settlementEntity.getFundingAmount())
                .netOutFlowTotal(settlementEntity.getNetOutFlowTotal())
                .outFlowTurnoverValue(settlementEntity.getOutFlowTurnoverValue())
                .returnTurnoverValue(settlementEntity.getReturnTurnoverValue())
                .deliveryVersusPaymentValue(settlementEntity.getDeliveryVersusPaymentValue())
                .settlementAmount(settlementEntity.getSettlementAmount())
                .tradingSystem(tradingSystemEntityToTradingSystemOutDto(settlementEntity.getTradingSystem()))
                .status(statusEntityToStatusOutDto(settlementEntity.getStatus()))
                .brokerageService(settlementEntity.getBrokerageService())
                .custodianId(ObjectUtils.isEmpty(settlementEntity.getCustodian()) ? null
                        : settlementEntity.getCustodian().getId())
                .custodian(participantEntityToParticipantOutDto(settlementEntity.getCustodian()))
                .bankAccountId(settlementEntity.getBankAccountId())
                .reference(settlementEntity.getReference())
                .capitalGainValue(settlementEntity.getCapitalGainValue())
                .disbursementValue(settlementEntity.getDisbursementValue())
                .sourceQuoteType(typeEntityToTypeOutDto(sourceQuoteFromTrade))// RTBOF-6147
                .ficAdministratorId(settlementEntity.getFicAdministratorId())
                .directDepositor(participantEntityToParticipantOutDto(settlementEntity.getDirectDepositor()))
                .build();
    }

    public static InvestorOutDto investorEntityToInvestorOutDto(InvestorEntity investorEntity) {
        if (ObjectUtils.isEmpty(investorEntity))
            return null;
        return InvestorOutDto.builder()
                .id(investorEntity.getId())
                .code(investorEntity.getCode())
                .firstName(investorEntity.getFirstName())
                .lastName(investorEntity.getLastName())
                .companyName(investorEntity.getCompanyName())
                .type(typeEntityToTypeOutDto(investorEntity.getType()))
                .status(statusEntityToStatusOutDto(investorEntity.getStatus()))
                .country(countryEntityToCountryOutDto(investorEntity.getCountry()))
                .department(departmentEntityToDepartmentOutDto(investorEntity.getDepartment()))
                .city(cityEntityToCityOutDto(investorEntity.getCity()))
                .documentNumber(investorEntity.getDocumentNumber())
                .identificationType(
                        identificationTypeEntityToIdentificationTypeOutDto(investorEntity.getIdentificationType()))
                .nationality(investorEntity.getNationality())
                .address(investorEntity.getAddress())
                .phoneNumber(investorEntity.getPhoneNumber())
                .email(investorEntity.getEmail())
                .clearinghouseCode(investorEntity.getClearinghouseCode())
                .gics(gicsEntityToGicsOutDto(investorEntity.getGics()))
                .moneyLaunderingFlag(investorEntity.getMoneyLaunderingFlag())
                .taxStatus(taxStatusEntityToTaxStatusOutDto(investorEntity.getTaxStatus()))
                .build();
    }

    public static InvestorAccountOutDto investorAccountEntityToInvestorAccountOutDto(
            InvestorAccountEntity investorAccountEntity) {
        if (ObjectUtils.isEmpty(investorAccountEntity))
            return null;
        return InvestorAccountOutDto.builder()
                .id(investorAccountEntity.getId())
                .investor(investorEntityToInvestorOutDto(investorAccountEntity.getInvestor()))
                .accountNumber(investorAccountEntity.getAccountNumber())
                .status(statusEntityToStatusOutDto(investorAccountEntity.getStatus()))
                .type(typeEntityToTypeOutDto(investorAccountEntity.getType()))
                .originType(typeEntityToTypeOutDto(investorAccountEntity.getOriginType()))
                .depository(depositoryEntityToDepositoryOutDto(investorAccountEntity.getDepository()))
                .participant(participantEntityToParticipantOutDto(investorAccountEntity.getParticipant()))
                .build();
    }

    public static ParticipantAccountOutDto participantAccountEntityToParticipantAccountOutDto(
            ParticipantAccountEntity participantAccountEntity) {
        if (ObjectUtils.isEmpty(participantAccountEntity))
            return null;
        return ParticipantAccountOutDto.builder()
                .id(participantAccountEntity.getId())
                .participant(participantEntityToParticipantOutDto(participantAccountEntity.getParticipant()))
                .accountNumber(participantAccountEntity.getAccountNumber())
                .status(statusEntityToStatusOutDto(participantAccountEntity.getStatus()))
                .type(typeEntityToTypeOutDto(participantAccountEntity.getType()))
                .originType(typeEntityToTypeOutDto(participantAccountEntity.getOriginType()))
                .build();
    }

    public static DepositoryOutDto depositoryEntityToDepositoryOutDto(DepositoryEntity depositoryEntity) {
        if (ObjectUtils.isEmpty(depositoryEntity))
            return null;
        return DepositoryOutDto.builder()
                .id(depositoryEntity.getId())
                .description(depositoryEntity.getDescription())
                .build();
    }

    public static MarketOutDto marketEntityToMarketOutDto(MarketEntity marketEntity) {
        if (ObjectUtils.isEmpty(marketEntity))
            return null;
        return MarketOutDto.builder()
                .id(marketEntity.getId())
                .description(marketEntity.getDescription())
                .category(marketEntity.getCategory())
                .build();
    }

    public static StatusOutDto statusEntityToStatusOutDto(StatusEntity statusEntity) {
        if (ObjectUtils.isEmpty(statusEntity))
            return null;
        return StatusOutDto.builder()
                .id(statusEntity.getId())
                .description(statusEntity.getDescription())
                .category(statusEntity.getCategory())
                .build();
    }

    public static TypeOutDto typeEntityToTypeOutDto(TypeEntity typeEntity) {
        if (ObjectUtils.isEmpty(typeEntity))
            return null;
        return TypeOutDto.builder()
                .id(typeEntity.getId())
                .description(typeEntity.getDescription())
                .category(typeEntity.getCategory())
                .build();
    }

    public static CfiOutDto cfiEntityToCfiOutDto(CfiEntity cfiEntity) {
        if (ObjectUtils.isEmpty(cfiEntity))
            return null;
        return CfiOutDto.builder()
                .id(cfiEntity.getId())
                .description(cfiEntity.getDescription())
                .build();
    }

    public static SideOutDto sideEntityToSideOutDto(SideEntity sideEntity) {
        if (ObjectUtils.isEmpty(sideEntity))
            return null;
        return SideOutDto.builder()
                .id(sideEntity.getId())
                .description(sideEntity.getDescription())
                .build();
    }

    public static DepartmentOutDto departmentEntityToDepartmentOutDto(DepartmentEntity departmentEntity) {
        if (ObjectUtils.isEmpty(departmentEntity))
            return null;
        return DepartmentOutDto.builder()
                .id(departmentEntity.getId())
                .description(departmentEntity.getDescription())
                .build();
    }

    public static CityOutDto cityEntityToCityOutDto(CityEntity cityEntity) {
        if (ObjectUtils.isEmpty(cityEntity))
            return null;
        return CityOutDto.builder()
                .id(cityEntity.getId())
                .description(cityEntity.getDescription())
                .build();
    }

    public static GicsOutDto gicsEntityToGicsOutDto(GicsEntity gicsEntity) {
        if (ObjectUtils.isEmpty(gicsEntity))
            return null;
        return GicsOutDto.builder()
                .id(gicsEntity.getId())
                .description(gicsEntity.getDescription())
                .build();
    }

    public static TaxStatusOutDto taxStatusEntityToTaxStatusOutDto(TaxStatusEntity taxStatusEntity) {
        if (ObjectUtils.isEmpty(taxStatusEntity))
            return null;
        return TaxStatusOutDto.builder()
                .id(taxStatusEntity.getId())
                .description(taxStatusEntity.getDescription())
                .build();
    }

    public static TradingSessionOutDto tradingSessionEntityToTradingSessionOutDto(
            TradingSessionEntity tradingSessionEntity) {
        if (ObjectUtils.isEmpty(tradingSessionEntity))
            return null;
        return TradingSessionOutDto.builder()
                .id(tradingSessionEntity.getId())
                .description(tradingSessionEntity.getDescription())
                .build();
    }

    public static TradingSystemOutDto tradingSystemEntityToTradingSystemOutDto(
            TradingSystemEntity tradingSystemEntity) {
        if (ObjectUtils.isEmpty(tradingSystemEntity))
            return null;
        return TradingSystemOutDto.builder()
                .id(tradingSystemEntity.getId())
                .description(tradingSystemEntity.getDescription())
                .build();
    }

    public static IdentificationTypeOutDto identificationTypeEntityToIdentificationTypeOutDto(
            IdentificationTypeEntity identificationTypeEntity) {
        if (ObjectUtils.isEmpty(identificationTypeEntity))
            return null;
        return IdentificationTypeOutDto.builder()
                .id(identificationTypeEntity.getId())
                .description(identificationTypeEntity.getDescription())
                .build();
    }

    public static AllTradeOutDto tradeEntityToAllTradeOutDto(
            TradeEntity tradeEntity, TradeEquityEntity tradeEquityEntity, List<SettlementEntity> settlementEntityList) {
        return AllTradeOutDto.builder()
                .trade(tradeEntityToTradeOutDto(tradeEntity))
                .tradeEquity(ObjectUtils.isEmpty(tradeEntity) ? null
                        : tradeEquityEntityToTradeEquityOutDto(tradeEquityEntity))
                .settlement(settlementEntityList.stream()
                        .map(MapperUtil::settlementEntityToSettlementOutDto)
                        .toList())
                .build();
    }

    public static CalculationOutDto settleAccountsOutDtoToCalculationOutDto(SettleAccountsOutDto settleAccountsOutDto) {
        return CalculationOutDto.builder()
                .amount(settleAccountsOutDto.getAmount())
                .commissionAmount(settleAccountsOutDto.getCommissionAmount())
                .valTaxAmount(settleAccountsOutDto.getValTaxAmount())
                .netAmount(settleAccountsOutDto.getNetAmount())
                .transferValue(settleAccountsOutDto.getTransferValue())
                .build();
    }

    public static ClassOutDto classEntityToClassOutDto(ClassEntity classEntity) {
        if (ObjectUtils.isEmpty(classEntity))
            return null;
        return ClassOutDto.builder()
                .id(classEntity.getId())
                .description(classEntity.getDescription())
                .category(classEntity.getCategory())
                .build();
    }

}
