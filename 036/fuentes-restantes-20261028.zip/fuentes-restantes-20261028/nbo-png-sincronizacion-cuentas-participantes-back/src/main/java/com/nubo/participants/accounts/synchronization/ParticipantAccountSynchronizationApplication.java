package com.nubo.participants.accounts.synchronization;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParticipantAccountSynchronizationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParticipantAccountSynchronizationApplication.class, args);
	}

}
