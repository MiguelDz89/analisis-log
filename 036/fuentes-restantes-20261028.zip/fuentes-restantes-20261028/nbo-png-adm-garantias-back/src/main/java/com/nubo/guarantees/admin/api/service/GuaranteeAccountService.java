package com.nubo.guarantees.admin.api.service;

import com.nubo.guarantees.admin.api.models.dto.response.GuaranteeAccountOutDto;
import com.nubo.guarantees.admin.api.models.dto.response.PageResponseOutDto;
import com.nubo.guarantees.admin.api.models.dto.response.TypeOutDto;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface GuaranteeAccountService {

    List<TypeOutDto> findTypeAccountGuarantees();

    PageResponseOutDto<GuaranteeAccountOutDto> findAllGuaranteesAccount(Long accountTypeId,
                                                                        String text, Pageable pageable);

    PageResponseOutDto<GuaranteeAccountOutDto> findAllGuaranteesAccount(Long accountTypeId, String text, int page, int size, String sort, String order, boolean all);

}
