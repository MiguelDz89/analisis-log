package com.nubo.guarantees.admin.api.repository;

import com.nubo.guarantees.admin.api.models.entity.GuaranteeGlobalAccountEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface GuaranteeGlobalAccountRepository extends JpaRepository<GuaranteeGlobalAccountEntity, Long>,
        JpaSpecificationExecutor<GuaranteeGlobalAccountEntity> {
}
