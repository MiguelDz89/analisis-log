package com.nubo.guarantees.admin.api.repository;

import com.nubo.guarantees.admin.api.models.entity.TypeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface TypeRepository extends JpaRepository<TypeEntity, Long> {

    @Query("SELECT t FROM TypeEntity t WHERE t.category = :category")
    List<TypeEntity> findByCategory(String category);

}
