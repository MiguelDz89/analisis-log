package com.nubo.guarantees.admin.api.service;

import org.springframework.data.domain.Pageable;

import com.nubo.guarantees.admin.api.models.dto.request.GuaranteesInDto;
import com.nubo.guarantees.admin.api.models.dto.response.GuaranteesOutDto;
import com.nubo.guarantees.admin.api.models.dto.response.PageResponseOutDto;

public interface GuaranteesService {
    PageResponseOutDto<GuaranteesOutDto> findAllGuarantees(Pageable pageable, GuaranteesInDto
            guaranteesInDto);

    PageResponseOutDto<GuaranteesOutDto> findAllGuarantees(GuaranteesInDto guaranteesInDto, int page, int size, String sort, String order, boolean all);

    PageResponseOutDto<GuaranteesOutDto> findPagedDataGuaranteesByFiltersDynamic(
            Pageable pageable,
            String fieldName,
            String fieldValue,
            String operation,
            Long countryId,
            Long participantId,
            Long investorId,
            Long accountTypeId,
            Long guaranteeGlobalAccountId,
            Long guaranteeParticularAccountId,
            Long guaranteeId,
            Long statusId);
}
