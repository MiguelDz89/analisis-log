package com.nubo.guarantees.admin.api.helpers;

import com.nubo.guarantees.admin.api.models.dto.response.CountryOutDto;
import com.nubo.guarantees.admin.api.models.dto.response.GuaranteeGlobalAccountOutDto;
import com.nubo.guarantees.admin.api.models.dto.response.GuaranteeParticularAccountOutDto;
import com.nubo.guarantees.admin.api.models.dto.response.GuaranteesOutDto;
import com.nubo.guarantees.admin.api.models.dto.response.IdentificationTypeOutDto;
import com.nubo.guarantees.admin.api.models.dto.response.InvestorOutDto;
import com.nubo.guarantees.admin.api.models.dto.response.ParticipantOutDto;
import com.nubo.guarantees.admin.api.models.dto.response.StatusOutDto;
import com.nubo.guarantees.admin.api.models.dto.response.TypeOutDto;
import com.nubo.guarantees.admin.api.models.entity.CountryEntity;
import com.nubo.guarantees.admin.api.models.entity.GuaranteeGlobalAccountEntity;
import com.nubo.guarantees.admin.api.models.entity.GuaranteeParticularAccountEntity;
import com.nubo.guarantees.admin.api.models.entity.GuaranteesEntity;
import com.nubo.guarantees.admin.api.models.entity.IdentificationTypeEntity;
import com.nubo.guarantees.admin.api.models.entity.InvestorEntity;
import com.nubo.guarantees.admin.api.models.entity.ParticipantEntity;
import com.nubo.guarantees.admin.api.models.entity.StatusEntity;
import com.nubo.guarantees.admin.api.models.entity.TypeEntity;
import org.springframework.util.ObjectUtils;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

public class MapperUtil {

    private MapperUtil() {
    }

    public static GuaranteesOutDto guaranteesEntitytoGuaranteesOutDto(
            GuaranteesEntity guaranteesEntity, BigDecimal position) {
        if (ObjectUtils.isEmpty(guaranteesEntity)) return null;
        return GuaranteesOutDto.builder().id(guaranteesEntity.getId())
                .country(countryEntityToCountryOutDto(guaranteesEntity.getCountry()))
                .participant(participantEntityToParticipantOutDto(guaranteesEntity.getParticipant()))
                .custodian(participantEntityToParticipantOutDto(guaranteesEntity.getCustodian()))
                .investor(investorEntityToInvestorOutDto(guaranteesEntity.getInvestor()))
                .guaranteeType(typeEntityToTypeOutDto(guaranteesEntity.getGuaranteeType()))
                .accountType(typeEntityToTypeOutDto(guaranteesEntity.getAccountType()))
                .position(position)
                .status(statusEntityToStatusOutDto(guaranteesEntity.getStatus()))
                .guaranteeGlobalAccount(guaranteeGlobalAccountEntityToGuaranteeGlobalAccountOutDto(
                        guaranteesEntity.getGuaranteeGlobalAccount()))
                .guaranteeParticularAccount(guaranteeParticularAccountEntityToGuaranteeParticularAccountOutDto(
                        guaranteesEntity.getGuaranteeParticularAccount()))
                .build();
    }

    public static CountryOutDto countryEntityToCountryOutDto(CountryEntity countryEntity) {
        if (ObjectUtils.isEmpty(countryEntity)) return null;
        return CountryOutDto.builder()
                .id(countryEntity.getId())
                .name(countryEntity.getName())
                .code(countryEntity.getCode())
                .build();
    }

    public static ParticipantOutDto participantEntityToParticipantOutDto(ParticipantEntity participantEntity) {
        if (ObjectUtils.isEmpty(participantEntity)) return null;
        return ParticipantOutDto.builder()
                .id(participantEntity.getId())
                .code(participantEntity.getCode())
                .documentNumber((participantEntity.getDocumentNumber()))
                .shortName(participantEntity.getShortName())
                .name(participantEntity.getName())
                .codeAndName(participantEntity.getCode().concat(" ").concat(participantEntity.getName()))
                .build();
    }

    public static InvestorOutDto investorEntityToInvestorOutDto(InvestorEntity investorEntity) {
        if (ObjectUtils.isEmpty(investorEntity)) return null;
        return InvestorOutDto.builder()
                .id(investorEntity.getId())
                .firstName(investorEntity.getFirstName())
                .lastName(investorEntity.getLastName())
                .documentNumber(investorEntity.getDocumentNumber())
                .companyName(investorEntity.getCompanyName())
                .identificationType(identificationTypeEntityToIdentificationTypeOutDto(
                        investorEntity.getIdentificationType()))
                .fullName(investorEntity.getIdentificationType().getCode()
                        .concat(" ")
                        .concat(investorEntity.getDocumentNumber())
                        .concat(" ")
                        .concat(investorEntity.getFirstName())
                        .concat(" ")
                        .concat(investorEntity.getLastName()))
                .build();
    }

    public static IdentificationTypeOutDto identificationTypeEntityToIdentificationTypeOutDto(
            IdentificationTypeEntity identificationTypeEntity) {
        if (ObjectUtils.isEmpty(identificationTypeEntity)) return null;
        return IdentificationTypeOutDto.builder()
                .id(identificationTypeEntity.getId())
                .description(identificationTypeEntity.getDescription())
                .build();
    }

    public static StatusOutDto statusEntityToStatusOutDto(StatusEntity statusEntity) {
        if (ObjectUtils.isEmpty(statusEntity)) return null;
        return StatusOutDto.builder()
                .id(statusEntity.getId())
                .description(statusEntity.getDescription())
                .category(statusEntity.getCategory())
                .detail(statusEntity.getDetail())
                .build();
    }

    public static List<StatusOutDto> statusEntityListToGuaranteesStatusList(List<StatusEntity> statusEntityList) {
        if (statusEntityList == null || statusEntityList.isEmpty()) {
            return Collections.emptyList();
        }
        return statusEntityList.stream()
                .map(MapperUtil::statusEntityToStatusOutDto).toList();
    }

    public static TypeOutDto typeEntityToTypeOutDto(TypeEntity typeEntity) {
        if (ObjectUtils.isEmpty(typeEntity)) return null;
        return TypeOutDto.builder()
                .id(typeEntity.getId())
                .detail(typeEntity.getDetail())
                .build();
    }

    private static GuaranteeGlobalAccountOutDto guaranteeGlobalAccountEntityToGuaranteeGlobalAccountOutDto(
            GuaranteeGlobalAccountEntity guaranteeGlobalAccountEntity) {
        if (ObjectUtils.isEmpty(guaranteeGlobalAccountEntity)) return null;
        return GuaranteeGlobalAccountOutDto.builder()
                .id(guaranteeGlobalAccountEntity.getId())
                .accountCode(guaranteeGlobalAccountEntity.getAccountCode())
                .accountName(guaranteeGlobalAccountEntity.getAccountName())
                .build();
    }

    private static GuaranteeParticularAccountOutDto guaranteeParticularAccountEntityToGuaranteeParticularAccountOutDto(
            GuaranteeParticularAccountEntity guaranteeParticularAccountEntity) {
        if (ObjectUtils.isEmpty(guaranteeParticularAccountEntity)) return null;
        return GuaranteeParticularAccountOutDto.builder()
                .id(guaranteeParticularAccountEntity.getId())
                .accountParticularCode(guaranteeParticularAccountEntity.getAccountParticularCode())
                .build();
    }

}
