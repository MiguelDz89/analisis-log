package com.nubo.guarantees.admin.api.repository;

import com.nubo.guarantees.admin.api.models.entity.InvestorEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface InvestorRepository extends JpaRepository<InvestorEntity, Long>,
        JpaSpecificationExecutor<InvestorEntity> {
}
