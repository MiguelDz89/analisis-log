package com.nubo.guarantees.admin.api.service;

import com.nubo.guarantees.admin.api.models.dto.response.PageResponseOutDto;
import com.nubo.guarantees.admin.api.models.dto.response.ParticipantOutDto;
import org.springframework.data.domain.Pageable;

public interface ParticipantService {

    PageResponseOutDto<ParticipantOutDto> findByParticipant(String text, Pageable pageable);

    PageResponseOutDto<ParticipantOutDto> findByParticipant(String text, int page, int size, String sort, String order, boolean all);

}
