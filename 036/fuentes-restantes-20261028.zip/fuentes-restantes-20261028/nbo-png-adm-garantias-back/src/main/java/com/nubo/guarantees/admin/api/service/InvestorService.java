package com.nubo.guarantees.admin.api.service;

import com.nubo.guarantees.admin.api.models.dto.response.InvestorOutDto;
import com.nubo.guarantees.admin.api.models.dto.response.PageResponseOutDto;
import org.springframework.data.domain.Pageable;

public interface InvestorService {

    PageResponseOutDto<InvestorOutDto> findByInvestor(String text, Pageable pageable);

    PageResponseOutDto<InvestorOutDto> findByInvestor(String text, int page, int size, String sort, String order, boolean all);

}
