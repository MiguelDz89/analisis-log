package com.nubo.guarantees.admin.api.service;

import com.nubo.guarantees.admin.api.models.dto.response.CountryOutDto;

import java.util.List;

public interface CountryService {

    List<CountryOutDto> findCountries();

}
