package com.nubo.guarantees.admin.api.helpers;

import com.nubo.guarantees.admin.api.models.dto.response.PageResponseOutDto;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MapperPageUtil {
    private MapperPageUtil() {
    }

    public static <T, U> PageResponseOutDto<T> pageToPageResponseOutDto(List<T> list, Page<U> page) {
        PageResponseOutDto<T> paginationResponseDto = new PageResponseOutDto<>();
        paginationResponseDto.setContent(list);
        paginationResponseDto.setPageSize(page.getSize());
        paginationResponseDto.setPageNumber(page.getNumber());
        paginationResponseDto.setTotalElements(page.getTotalElements());
        paginationResponseDto.setTotalPages(page.getTotalPages());

        return paginationResponseDto;
    }

    public static <T> PageResponseOutDto<T> pageToPageResponseOutDto(List<T> list, int pageNumber, int pageSize,
                                                                     long totalFilteredElements) {
        PageResponseOutDto<T> paginationResponseDto = new PageResponseOutDto<>();
        paginationResponseDto.setContent(list);
        paginationResponseDto.setPageSize(pageSize);
        paginationResponseDto.setPageNumber(pageNumber);
        paginationResponseDto.setTotalElements(totalFilteredElements);

        int totalPages = (int) Math.ceil((double) totalFilteredElements / pageSize);
        paginationResponseDto.setTotalPages(totalPages);

        return paginationResponseDto;
    }

    public static <T> List<T> getPageContent(Pageable pageable, List<T> list) {
        if (list == null || list.isEmpty()) {
            return Collections.emptyList();
        }

        if (pageable.getSort().isSorted()) {
            Comparator<T> comparator = pageable.getSort().stream()
                    .map(order -> {
                        Comparator<T> cmp = Comparator.comparing(item -> {
                            BeanWrapper wrapper = new BeanWrapperImpl(item);

                            if (!wrapper.isReadableProperty(order.getProperty())) {
                                return null;
                            }

                            Object value = wrapper.getPropertyValue(order.getProperty());
                            return (Comparable) value;
                        }, Comparator.nullsLast(Comparator.naturalOrder()));

                        return order.isAscending() ? cmp : cmp.reversed();
                    })
                    .reduce(Comparator::thenComparing)
                    .orElse(null);

            if (comparator != null) {
                list = new ArrayList<>(list);
                list.sort(comparator);
            }
        }

        int start = (int) pageable.getOffset();
        int end = Math.min(start + pageable.getPageSize(), list.size());

        return start >= list.size() ? Collections.emptyList() : list.subList(start, end);
    }

}
