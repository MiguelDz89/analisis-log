package com.nubo.guarantees.admin.api.repository;

import com.nubo.guarantees.admin.api.models.entity.GuaranteesEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.util.List;

public interface GuaranteesRepository extends JpaRepository<GuaranteesEntity, Long>, JpaSpecificationExecutor<GuaranteesEntity> {

    @Query("""
                SELECT COALESCE(SUM(v.guaranteeInteger), 0)
                FROM GuaranteeValuationEntity v
                WHERE v.guarantee IN (
                    SELECT g
                    FROM GuaranteesEntity g
                    WHERE (
                             :participantId IS NULL
                             OR (
                                    g.participant.id = :participantId
                                    AND :custodianId IS NULL
                                    AND g.custodian.id IS NULL
                                )
                           )
                      AND (:custodianId IS NULL OR g.custodian.id = :custodianId)
                      AND (:investorId IS NULL OR g.investor.id = :investorId)
                      AND (:guaranteeGlobalAccountId IS NULL OR g.guaranteeGlobalAccount.id = :guaranteeGlobalAccountId)
                      AND (:guaranteeParticularAccountId IS NULL OR g.guaranteeParticularAccount.id = :guaranteeParticularAccountId)
                )
                AND v.valuationDate = (
                    SELECT MAX(v2.valuationDate)
                    FROM GuaranteeValuationEntity v2
                    WHERE v2.guarantee = v.guarantee
                )
            """)
    BigDecimal sumGuaranteeIntegerByFilters(
            @Param("participantId") Long participantId,
            @Param("custodianId") Long custodianId,
            @Param("investorId") Long investorId,
            @Param("guaranteeGlobalAccountId") Long guaranteeGlobalAccountId,
            @Param("guaranteeParticularAccountId") Long guaranteeParticularAccountId
    );

    @Query("""
                SELECT COALESCE(SUM(gt.requirementAmount), 0)
                FROM GuaranteeTradeEntity gt
                JOIN SettlementEntity s
                  ON s.trade = gt.trade
                 AND s.fraction = gt.fraction
                 AND s.side = gt.side
                WHERE (:participantId IS NULL OR gt.participant.id = :participantId
                        AND (:participantId IS NOT NULL AND :custodianId IS NULL AND gt.custodian.id IS NULL))
                  AND (:custodianId IS NULL OR gt.custodian.id = :custodianId)
                  AND (:investorId IS NULL OR gt.investor.id = :investorId)
                  AND (:guaranteeGlobalAccountId IS NULL OR gt.guaranteeGlobalAccount.id = :guaranteeGlobalAccountId)
                  AND (:guaranteeParticularAccountId IS NULL OR gt.guaranteeParticularAccount.id = :guaranteeParticularAccountId)
                  AND (:custodianTradeStatusIds IS NULL OR s.custodianStatus.id IN :custodianTradeStatusIds)
            """)
    BigDecimal sumGuaranteeExigencyByFilters(
            @Param("participantId") Long participantId,
            @Param("custodianId") Long custodianId,
            @Param("investorId") Long investorId,
            @Param("guaranteeGlobalAccountId") Long guaranteeGlobalAccountId,
            @Param("guaranteeParticularAccountId") Long guaranteeParticularAccountId,
            @Param("custodianTradeStatusIds") List<Long> custodianTradeStatusIds
    );

    @Query("""
                SELECT COALESCE(SUM(v.limitAmount), 0)
                FROM GuaranteeLimitsValuationEntity v
                WHERE v.guarantee IN (
                    SELECT g
                    FROM GuaranteesEntity g
                    WHERE (
                             :participantId IS NULL
                             OR (
                                    g.participant.id = :participantId
                                    AND :custodianId IS NULL
                                    AND g.custodian.id IS NULL
                                )
                           )
                      AND (:custodianId IS NULL OR g.custodian.id = :custodianId)
                      AND (:investorId IS NULL OR g.investor.id = :investorId)
                      AND (:guaranteeGlobalAccountId IS NULL OR g.guaranteeGlobalAccount.id = :guaranteeGlobalAccountId)
                      AND (:guaranteeParticularAccountId IS NULL OR g.guaranteeParticularAccount.id = :guaranteeParticularAccountId)
                      AND (:marketId IS NULL OR g.isinNumber.market.id = :marketId)
                )
                AND v.valuationDate = (
                    SELECT MAX(v2.valuationDate)
                    FROM GuaranteeLimitsValuationEntity v2
                    WHERE v2.guarantee = v.guarantee
                )
            """)
    BigDecimal sumGuaranteeLimitsByFilters(
            @Param("participantId") Long participantId,
            @Param("custodianId") Long custodianId,
            @Param("investorId") Long investorId,
            @Param("guaranteeGlobalAccountId") Long guaranteeGlobalAccountId,
            @Param("guaranteeParticularAccountId") Long guaranteeParticularAccountId,
            @Param("marketId") String marketId
    );

}
