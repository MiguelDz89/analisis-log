package com.nubo.guarantees.admin.api.repository;

import com.nubo.guarantees.admin.api.models.entity.GuaranteeParticularAccountEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface GuaranteeParticularAccountRepository extends JpaRepository<GuaranteeParticularAccountEntity, Long>,
        JpaSpecificationExecutor<GuaranteeParticularAccountEntity> {
}
