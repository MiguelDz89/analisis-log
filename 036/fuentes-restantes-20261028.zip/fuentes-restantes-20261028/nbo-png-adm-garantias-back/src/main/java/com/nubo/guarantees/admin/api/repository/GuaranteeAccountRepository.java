package com.nubo.guarantees.admin.api.repository;

import com.nubo.guarantees.admin.api.models.entity.GuaranteesAccountEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GuaranteeAccountRepository extends JpaRepository<GuaranteesAccountEntity, Long> {
}
