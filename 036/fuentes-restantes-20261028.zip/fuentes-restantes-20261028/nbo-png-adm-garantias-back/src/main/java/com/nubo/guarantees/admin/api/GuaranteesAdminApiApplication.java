package com.nubo.guarantees.admin.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GuaranteesAdminApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(GuaranteesAdminApiApplication.class, args);
	}

}
