package com.nubo.guarantees.admin.api.service;

import com.nubo.guarantees.admin.api.models.dto.response.StatusOutDto;

import java.util.List;

public interface StatusService {
    List<StatusOutDto> findAllGuaranteesStatus();
}
