package com.nubo.guarantees.admin.api.repository;

import com.nubo.guarantees.admin.api.models.entity.StatusEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface StatusRepository extends JpaRepository<StatusEntity, Long> {

    @Query("SELECT s FROM StatusEntity s WHERE UPPER(s.category) = :category")
    List<StatusEntity> findAllGuaranteesStatus(String category);

}
