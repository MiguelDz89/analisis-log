package com.nubo.assignment.service17.client.operations.cmd.models.response;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.ALWAYS)
public class InvestorOutDto {

    private Long id;

    private String code;

    private String firstName;

    private String lastName;

    private String companyName;

    private TypeOutDto type;

    private StatusOutDto status;

    private CountryOutDto country;

    private String documentNumber;

    //private IdentificationTypeOutDto identificationType;

    private String nationality;

    private String clearinghouseCode;

    //private GicsOutDto gics;

    private Boolean moneyLaunderingFlag;

    //private TaxStatusOutDto taxStatus;

}
