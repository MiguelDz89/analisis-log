package com.nubo.assignment.service17.client.operations.cmd.service.impl;

import java.net.URI;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.web.util.UriComponentsBuilder;

import com.nubo.assignment.service17.application.properties.PropertiesConfig;
import com.nubo.assignment.service17.application.properties.PropertiesContext;
import com.nubo.assignment.service17.application.util.ApplicationUtils;
import com.nubo.assignment.service17.application.util.RestClientUtils;
import com.nubo.assignment.service17.client.operations.cmd.models.request.FractionClientInDto;
import com.nubo.assignment.service17.client.operations.cmd.models.response.FractionAccountOutDto;
import com.nubo.assignment.service17.client.operations.cmd.models.response.ParticipantBankAccountOutDto;
import com.nubo.assignment.service17.client.operations.cmd.models.response.SettlementOutDto;
import com.nubo.assignment.service17.client.operations.cmd.service.OperationsCmdClient;
import com.nubo.assignment.service17.exception.ClientException;
import com.nubo.assignment.service17.exception.error.ErrorCode;
import com.nubo.assignment.service17.models.enums.PropertiesEnum;
import com.nubo.assignment.service17.models.enums.VersionApiEnum;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class OperationsCmdClientImpl implements OperationsCmdClient {

    private final PropertiesConfig propertiesConfig;
    private final RestClientUtils restClientUtils;

    private static final String PATH_FRACTIONATION = "fractionation/counted-operation";
    private static final String PATH_ACCOUNT_VALIDATION = "validate/counted-fraction";

    @Override
    public List<SettlementOutDto> fractionationCreateAssignment(Long tradeId, String sideId,
            List<FractionClientInDto> fractionInDtoList) {
        URI uri = UriComponentsBuilder
                .fromUriString(propertiesConfig.getUrlNuboOperationCmd())
                .pathSegment(VersionApiEnum.V1.getValue(), PATH_FRACTIONATION)
                .path("/create-fractions/trade/{tradeId}/side/{sideId}")
                .buildAndExpand(tradeId, sideId)
                .toUri();

        try {
            ResponseEntity<SettlementOutDto[]> response = restClientUtils.requestBodyWithResponseObject(uri,
                    HttpMethod.POST, getHttpHeaders(), fractionInDtoList, SettlementOutDto[].class);
            if (!ObjectUtils.isEmpty(response.getBody())) {
                return List.of(response.getBody());
            }
        } catch (Exception ex) {
            throw new ClientException(ErrorCode.CLIENT_OPERATION_FRACTIONATION_ERROR, HttpStatus.BAD_GATEWAY, ex);
        }

        return List.of(SettlementOutDto.builder().build());
    }

    @Override
    public List<SettlementOutDto> fractionationUpdateAssignment(Long tradeId, String sideId,
            List<FractionClientInDto> fractionInDtoList) {
        URI uri = UriComponentsBuilder
                .fromUriString(propertiesConfig.getUrlNuboOperationCmd())
                .pathSegment(VersionApiEnum.V1.getValue(), PATH_FRACTIONATION)
                .path("/update-assignments/trade/{tradeId}/side/{sideId}")
                .buildAndExpand(tradeId, sideId)
                .toUri();

        try {
            ResponseEntity<SettlementOutDto[]> response = restClientUtils.requestBodyWithResponseObject(uri,
                    HttpMethod.PUT, getHttpHeaders(), fractionInDtoList, SettlementOutDto[].class);
            if (!ObjectUtils.isEmpty(response.getBody())) {
                return List.of(response.getBody());
            }
        } catch (Exception ex) {
            throw new ClientException(ErrorCode.CLIENT_OPERATION_FRACTIONATION_ERROR, HttpStatus.BAD_GATEWAY, ex);
        }

        return List.of(SettlementOutDto.builder().build());
    }

    @Override
    public FractionAccountOutDto validateAccountFractionAssignment(String accountNumber, Long tradeId, String sideId,
            Long originId) {
        URI uri = UriComponentsBuilder
                .fromUriString(propertiesConfig.getUrlNuboOperationCmd())
                .pathSegment(VersionApiEnum.V1.getValue(), PATH_ACCOUNT_VALIDATION)
                .path("/assignment/account-fraction/account-number/{accountNumber}/trade/{tradeId}/side/{sideId}/origin/{originId}")
                .buildAndExpand(accountNumber, tradeId, sideId, originId)
                .toUri();

        try {
            ResponseEntity<FractionAccountOutDto> response = restClientUtils.requestWithResponseObject(uri,
                    HttpMethod.GET, getHttpHeaders(), FractionAccountOutDto.class);
            if (!ObjectUtils.isEmpty(response.getBody())) {
                return response.getBody();
            }
        } catch (Exception ex) {
            throw new ClientException(ErrorCode.CLIENT_OPERATION_ACCOUNT_VALIDATION_ERROR, HttpStatus.BAD_GATEWAY, ex);
        }

        return FractionAccountOutDto.builder().build();
    }

    @Override
    public ParticipantBankAccountOutDto validateCudAccountFractionAssignment(Long tradeId, String sideId) {
        URI uri = UriComponentsBuilder
                .fromUriString(propertiesConfig.getUrlNuboOperationCmd())
                .pathSegment(VersionApiEnum.V1.getValue(), PATH_ACCOUNT_VALIDATION)
                .path("/assignment/cud-account/trade/{tradeId}/side/{sideId}")
                .buildAndExpand(tradeId, sideId)
                .toUri();

        try {
            ResponseEntity<ParticipantBankAccountOutDto> response = restClientUtils.requestWithResponseObject(uri,
                    HttpMethod.GET, getHttpHeaders(), ParticipantBankAccountOutDto.class);
            if (!ObjectUtils.isEmpty(response.getBody())) {
                return response.getBody();
            }
        } catch (Exception ex) {
            throw new ClientException(ErrorCode.CLIENT_OPERATION_ACCOUNT_VALIDATION_ERROR, HttpStatus.BAD_GATEWAY, ex);
        }

        return ParticipantBankAccountOutDto.builder().build();
    }

    private static HttpHeaders getHttpHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.set(PropertiesEnum.CLIENT_BACKEND.getValue(), "true");
        headers.set(PropertiesEnum.CLIENT_USER.getValue(), PropertiesContext.getClientUser());
        headers.set(PropertiesEnum.CLIENT_DATETIME.getValue(),
                ApplicationUtils.convertLocalDateTimeToString(PropertiesContext.getClientDatetime()));
        headers.setContentType(MediaType.APPLICATION_JSON);
        log.debug("Generated HTTP Headers for client request: {}", headers);
        return headers;
    }
}
