package com.nubo.assignment.service17.models.dto.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Trama {

    @JsonProperty("TIPO_TRAMA")
    private String type;

    @JsonProperty("DIGITO")
    private String digit;

    @JsonProperty("CODIGO")
    private String code;

    @JsonProperty("AFILIADO")
    private String affiliate;

    @JsonProperty("HORA_TRAMA")
    private String dateTime;

    @JsonProperty("FECHA_OPERACION")
    private String operationDate;

    @JsonProperty("FOLIO")
    private Long folio;

    @JsonProperty("PUNTA")
    private String side;

    @JsonProperty("NUM_IND_ADICIONAL")
    private Integer fractionNumber;

    @JsonProperty("TOT_ADICIONALES")
    private Integer totalFractions;

    @JsonProperty("OFE_PUBLICA")
    private String publicOffer;

    @JsonProperty("TIPO_IDENTIFICACION1")
    private String identificationType1;

    @JsonProperty("NUM_DENTIFICACION1")
    private String identificationNum1;

    @JsonProperty("FDO_FIDUCIARIO1")
    private String fiduciaryFund1;

    @JsonProperty("TIPO_IDENTIFICACION2")
    private String identificationType2;

    @JsonProperty("NUM_DENTIFICACION2")
    private String identificationNum2;

    @JsonProperty("FDO_FIDUCIARIO2")
    private String fiduciaryFund2;

    @JsonProperty("TIPO_IDENTIFICACION3")
    private String identificationType3;

    @JsonProperty("NUM_DENTIFICACION3")
    private String identificationNum3;

    @JsonProperty("FDO_FIDUCIARIO3")
    private String fiduciaryFund3;

    @JsonProperty("COD_DEPOSITANTE")
    private String depositorCode;

    @JsonProperty("CTA_DVL_DCV")
    private String dvlDcvAccount;

    @JsonProperty("CTA_SEBRA")
    private String sebraAccount;

    @JsonProperty("IND_TITULAR")
    private String holderIndicator;

    @JsonProperty("NIT-COMPEN")
    private String compensatingNit;

    @JsonProperty("CODIGO_ENTIDAD")
    private String entityCode;

    @JsonProperty("ORIGEN")
    private String origin;

    @JsonProperty("TRAS_SER_BOLSA")
    private String tradedOnStockExchange;

    @JsonProperty("TIPO_OPERACION")
    private String operationType;

    @JsonProperty("NRO_SWAP")
    private String swapNumber;

    @JsonProperty("IND_COMISION")
    private String commissionIndicator;

    @JsonProperty("PORC_COMISION")
    private String commissionPercentage;

    @JsonProperty("PRECIO_COMISION")
    private String commissionPrice;

    @JsonProperty("IND_CONSTANCIA")
    private String certificateIndicator;

    @JsonProperty("DESC_BASE")
    private String baseDescription;

    @JsonProperty("VAL_CONSTANCIA")
    private String certificateValue;

    @JsonProperty("FEC_CONSTANCIA")
    private String certificateDate;

    @JsonProperty("TASA_CONSTANCIA")
    private String certificateRate;

    @JsonProperty("NOMINAL_FRACCION")
    private String fractionalNominal;

    @JsonProperty("ISIN")
    private String isin;

    @JsonProperty("FUNGIBLE")
    private String fungible;

    @JsonProperty("FEC_INICIAL")
    private String initialDate;

    @JsonProperty("FEC_FINAL")
    private String finalDate;

    @JsonProperty("PRECIO_FINAL")
    private String finalPrice;

    @JsonProperty("CASO_ESP")
    private String specialCase;

    @JsonProperty("FOLIO_VTA")
    private String saleFolio;

    @JsonProperty("FECHA_VTA")
    private String saleDate;

    @JsonProperty("CANT_VTA")
    private String saleQuantity;

    @JsonProperty("NUM_RADICA")
    private String radicaNumber;

    @JsonProperty("COD_RESPON")
    private String responsibleCode;

    @JsonProperty("ADR")
    private String address;

    @JsonProperty("TIPOID_ADR")
    private String addressIdType;

    @JsonProperty("IDENTIF_ADR")
    private String addressIdNumber;

    @JsonProperty("ESP_ADR")
    private String addressSpecial;

    @JsonProperty("NOMBRE_ADR")
    private String addressName;

    @JsonProperty("PAIS_ADR")
    private String addressCountry;

    @JsonProperty("REFERENCIA")
    private String reference;

    @JsonProperty("CONS_ENAJENA")
    private String alienationConsent;

    @JsonProperty("GEN_PAPELETA")
    private String generatePapeleta;

    @JsonProperty("CODIGO_REFERENCIA")
    private String referenceCode;

    @JsonProperty("CUENTA_MARGEN")
    private String marginAccount;

    @JsonProperty("BONO_PENSIONAL")
    private String pensionBond;

    @JsonProperty("ACTIVAR_DVP")
    private String activateDvp;

    @JsonProperty("CUENTA_VALORES")
    private String securitiesAccount;
}
