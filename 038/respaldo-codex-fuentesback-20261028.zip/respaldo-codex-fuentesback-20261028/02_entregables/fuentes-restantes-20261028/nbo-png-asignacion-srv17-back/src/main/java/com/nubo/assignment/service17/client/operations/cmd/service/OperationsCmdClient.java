package com.nubo.assignment.service17.client.operations.cmd.service;

import java.util.List;

import com.nubo.assignment.service17.client.operations.cmd.models.request.FractionClientInDto;
import com.nubo.assignment.service17.client.operations.cmd.models.response.FractionAccountOutDto;
import com.nubo.assignment.service17.client.operations.cmd.models.response.ParticipantBankAccountOutDto;
import com.nubo.assignment.service17.client.operations.cmd.models.response.SettlementOutDto;

public interface OperationsCmdClient {

    List<SettlementOutDto> fractionationCreateAssignment(Long tradeId, String sideId,
            List<FractionClientInDto> fractionInDtoList);

    List<SettlementOutDto> fractionationUpdateAssignment(Long tradeId, String sideId,
            List<FractionClientInDto> fractionInDtoList);

    FractionAccountOutDto validateAccountFractionAssignment(String accountNumber, Long tradeId, String sideId,
            Long originId);

    ParticipantBankAccountOutDto validateCudAccountFractionAssignment(Long tradeId, String sideId);
}
