package com.nubo.assignment.service17.client.operations.rules.models.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StatusAllowedOptionsInDto {

    private String code;

    private Long statusId;

    private Long countryId;

    private Long typeId;

}
