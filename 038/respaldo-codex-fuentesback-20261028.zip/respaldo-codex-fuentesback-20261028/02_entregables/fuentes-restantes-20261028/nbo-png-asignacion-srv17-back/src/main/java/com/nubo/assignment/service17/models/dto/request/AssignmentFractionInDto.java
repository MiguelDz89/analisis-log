package com.nubo.assignment.service17.models.dto.request;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AssignmentFractionInDto {

    @NotBlank
    private String dvlDcvAccount;

    @Builder.Default
    private BigDecimal commissionPercentage = BigDecimal.ZERO;

    @NotNull
    private BigDecimal fractionalNominal;

    @Size(max = 3)
    private String referenceCode;

    @JsonProperty("referencePackage")
    @JsonAlias({ "reference_package", "packageCode", "package_code", "referenceCode" })
    @Size(max = 10)
    private String referencePackage;

    private Long custodian;

    // ---  not used ---
    
    private Integer fractionNumber;

    private List<BeneficiaryInDto> beneficiary;

    private String depositorCode;

    private String sebraAccount;

    private String holderIndicator;

    private String compensatingNit;

    private String entityCode;

    private String origin;

    private String tradedOnStockExchange;

    private String commissionIndicator;

    private String commissionPrice;

    private String certificateIndicator;

    private String baseDescription;

    private String certificateValue;

    private LocalDate certificateDate;

    private String certificateRate;

    private LocalDate initialDate;

    private LocalDate finalDate;

    private String finalPrice;

    private String radicaNumber;

    private String responsibleCode;

    private String address;

    private String adrIdentificationType;

    private String adrIdentificationNumber;

    private String adrSpecial;

    private String adrName;

    private String country;

    private String reference;

    private String marginAccount;

    private String securitiesAccount;
}
