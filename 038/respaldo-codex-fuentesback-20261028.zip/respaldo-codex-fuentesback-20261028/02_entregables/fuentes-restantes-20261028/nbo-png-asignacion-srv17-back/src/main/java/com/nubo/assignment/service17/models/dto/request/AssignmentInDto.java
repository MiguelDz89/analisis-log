package com.nubo.assignment.service17.models.dto.request;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.ALWAYS)
public class AssignmentInDto {

    @NotBlank
    private String affiliate;

    @NotNull
    @JsonProperty("folio")
    private Long matchId;

    @NotNull
    private LocalDate operationDate;

    @NotBlank
    private String side;

    @Valid
    @JsonProperty("complementations")
    private List<AssignmentFractionInDto> assignmentFractions;

    // --- not used ---

    private LocalDateTime dateTime;

    private Integer totalFractions;

    private String publicOffer;

    private String operationType;

    private String isin;

    private String fungible;

    private String specialCase;

    private String saleFolio;

    private LocalDate saleDate;

    private String saleQuantity;

    private String alienationConsent;

    private String generatePapeleta;

    private String pensionBond;
}
