package com.nubo.assignment.service17.client.operations.rules.service;

import com.nubo.assignment.service17.client.operations.rules.models.dto.request.StatusUpdateTradeInDto;
import com.nubo.assignment.service17.client.operations.rules.models.dto.response.BusinessRuleOutDto;
import com.nubo.assignment.service17.client.operations.rules.models.dto.response.StatusUpdateTradeOutDto;

public interface OperationBusinessRuleClient {

    BusinessRuleOutDto findBusinessRuleByCountryIdAndCode(Long countryId, String code);

    StatusUpdateTradeOutDto validateUpdateStatusTrade(StatusUpdateTradeInDto statusUpdateTradeInDto);

    BusinessRuleOutDto findBusinessRuleByCountryIdAndCodeValid(Long countryId, String code);

}
