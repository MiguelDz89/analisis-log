package com.nubo.assignment.service17.models.dto.response;

import java.time.Instant;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.ALWAYS)
public class AssignmentOutDto {

    private String affiliate;

    private Long tradeId;

    private Long matchId;

    private LocalDate matchDate;

    private SideOutDto side;

    private ParticipantOutDto participant;

    private Instant timestamp;

    private String messageAssignment;

}
