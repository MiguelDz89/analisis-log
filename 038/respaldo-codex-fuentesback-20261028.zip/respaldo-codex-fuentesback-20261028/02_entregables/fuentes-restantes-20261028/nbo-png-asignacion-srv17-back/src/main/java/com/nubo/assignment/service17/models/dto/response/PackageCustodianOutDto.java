package com.nubo.assignment.service17.models.dto.response;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PackageCustodianOutDto {

    private String clientUser;

    @NotNull
    private String marketId;

    @NotNull
    private Long uniqueFractionId;

    @NotNull
    private Long participantId;

    private String codeSCB;

    private String referencePackage;

}
