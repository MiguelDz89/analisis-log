package com.nubo.assignment.service17.models.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BeneficiaryInDto {

    private String identificationNum;

    private String identificationType;
    
    private String fiduciaryFund;

}
