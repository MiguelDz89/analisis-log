package com.nubo.assignment.service17.client.operations.cmd.models.request;

import java.math.BigDecimal;

import com.nubo.assignment.service17.application.util.ApplicationUtils;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FractionClientInDto {

    @Min(value = 1)
    private Long investorAccountId;

    @Min(value = 1)
    private Long participantAccountId;

    @Min(value = 1)
    private Long directDepositorId;

    @NotNull
    private Boolean fiduciarySpecialist;

    @NotNull
    @Min(value = 1)
    private Long sourceQuoteTypeId;

    private String reference;

    @NotNull
    private BigDecimal fractionQuantity;

    @NotNull
    private BigDecimal commissionPercentage;

    @NotNull
    private BigDecimal valTax;

    private String cashAccount;

    @Min(value = 1)
    private Long custodianId;

    @Min(value = 1)
    private Long ficAdministratorId;

    private String referencePackage;

    @Override
    public String toString() {
        return ApplicationUtils.convertObjectToJson(this);
    }
}
