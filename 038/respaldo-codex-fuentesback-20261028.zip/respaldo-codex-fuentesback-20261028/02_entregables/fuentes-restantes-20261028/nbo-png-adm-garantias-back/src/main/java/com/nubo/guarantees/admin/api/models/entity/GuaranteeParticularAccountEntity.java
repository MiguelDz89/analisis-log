package com.nubo.guarantees.admin.api.models.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "\"GUARANTEE_PARTICULAR_ACCOUNT\"", schema = "\"NUANBODB\"")
public class GuaranteeParticularAccountEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "\"GUARANTEE_PARTICULAR_ACCOUNT_ID\"", nullable = false)
    private Long id;

    @Column(name = "\"ACCOUNT_PARTICULAR_CODE\"")
    private String accountParticularCode;

}
