package com.nubo.guarantees.admin.api.models.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum StatusGuaranteeAdmEnum {

    COVERED(148L),
    PENDING(149L);

    private final Long id;
}
