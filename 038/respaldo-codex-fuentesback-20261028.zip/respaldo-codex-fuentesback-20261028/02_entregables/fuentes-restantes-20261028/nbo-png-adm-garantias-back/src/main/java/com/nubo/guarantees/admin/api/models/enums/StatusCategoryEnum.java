package com.nubo.guarantees.admin.api.models.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum StatusCategoryEnum {

    GUARANTEES_ADMIN("GARANTIA_ADMIN");

    private final String value;
}

