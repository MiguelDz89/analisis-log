package com.nubo.guarantees.admin.api.models.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.ALWAYS)
public class InvestorOutDto {

    private Long id;

    private String firstName;

    private String lastName;

    private String documentNumber;

    private IdentificationTypeOutDto identificationType;

    private String companyName;

    private String fullName;

}
