package com.nubo.guarantees.admin.api.models.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GuaranteesInDto {

    private Long countryId;

    private Long participantId;

    private Long investorId;

    private Long accountTypeId;

    private Long guaranteeGlobalAccountId;

    private Long guaranteeParticularAccountId;

    private Long statusId;

}
