package com.nubo.guarantees.admin.api.service.impl;

import com.nubo.guarantees.admin.api.application.properties.PropertiesContext;
import com.nubo.guarantees.admin.api.exception.ServiceException;
import com.nubo.guarantees.admin.api.exception.error.ErrorCode;
import com.nubo.guarantees.admin.api.helpers.MapperPageUtil;
import com.nubo.guarantees.admin.api.helpers.MapperUtil;
import com.nubo.guarantees.admin.api.models.dto.response.GuaranteeAccountOutDto;
import com.nubo.guarantees.admin.api.models.dto.response.PageResponseOutDto;
import com.nubo.guarantees.admin.api.models.dto.response.TypeOutDto;
import com.nubo.guarantees.admin.api.models.entity.GuaranteeGlobalAccountEntity;
import com.nubo.guarantees.admin.api.models.entity.GuaranteeParticularAccountEntity;
import com.nubo.guarantees.admin.api.models.entity.GuaranteesEntity;
import com.nubo.guarantees.admin.api.models.entity.TypeEntity;
import com.nubo.guarantees.admin.api.models.enums.TypeAccountEnum;
import com.nubo.guarantees.admin.api.models.enums.TypeCategoryEnum;
import com.nubo.guarantees.admin.api.models.enums.VersionApiEnum;
import com.nubo.guarantees.admin.api.repository.GuaranteeGlobalAccountRepository;
import com.nubo.guarantees.admin.api.repository.GuaranteeParticularAccountRepository;
import com.nubo.guarantees.admin.api.repository.TypeRepository;
import com.nubo.guarantees.admin.api.service.GuaranteeAccountService;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Subquery;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicLong;

@Service
@RequiredArgsConstructor
@Slf4j
public class GuaranteeAccountServiceImpl implements GuaranteeAccountService {

    private final GuaranteeParticularAccountRepository guaranteeParticularAccountRepository;
    private final GuaranteeGlobalAccountRepository guaranteeGlobalAccountRepository;
    private final TypeRepository typeRepository;

    @Override
    public List<TypeOutDto> findTypeAccountGuarantees() {
        if (Objects.requireNonNull(VersionApiEnum.fromValue(PropertiesContext.getVersion())) == VersionApiEnum.V1) {
            return findTypeAccountGuaranteesV1();
        } else {
            throw new ServiceException(ErrorCode.VERSION_API_NOT_FOUND, HttpStatus.NOT_FOUND);
        }
    }

    private List<TypeOutDto> findTypeAccountGuaranteesV1() {
        log.info("Start method findTypeAccountGuaranteesV1");

        List<TypeEntity> typeEntityList = typeRepository
                .findByCategory(TypeCategoryEnum.TYPE_ACCOUNT_GUARANTEE.getValue());

        List<TypeOutDto> typeOutDtoList = typeEntityList.stream()
                .map(MapperUtil::typeEntityToTypeOutDto).filter(Objects::nonNull)
                .toList();

        log.debug("End method findTypeAccountGuaranteesV1, typeOutDtoList -> {}", typeOutDtoList);

        return typeOutDtoList;
    }

    @Override
    public PageResponseOutDto<GuaranteeAccountOutDto> findAllGuaranteesAccount(Long accountTypeId, String text, Pageable pageable) {
        if (Objects.requireNonNull(VersionApiEnum.fromValue(PropertiesContext.getVersion())) == VersionApiEnum.V1) {
            return findAllGuaranteesAccountV1(accountTypeId, text, pageable);
        } else {
            throw new ServiceException(ErrorCode.VERSION_API_NOT_FOUND, HttpStatus.NOT_FOUND);
        }
    }

    private PageResponseOutDto<GuaranteeAccountOutDto> findAllGuaranteesAccountV1(Long accountTypeId, String text, Pageable pageable) {
        log.info("Start method findAllGuaranteesAccountV1");

        List<GuaranteeAccountOutDto> guaranteeAccountOutDtoList;

        AtomicLong consecutiveIdCounter = new AtomicLong(1);
        if (TypeAccountEnum.GENERAL_ACCOUNT.getValue().equals(accountTypeId)) {
            Page<GuaranteeGlobalAccountEntity> guaranteeGlobalAccountEntityPage = guaranteeGlobalAccountRepository.findAll(
                    specificationGuaranteeGlobalAccount(text), pageable);
            guaranteeAccountOutDtoList = guaranteeGlobalAccountEntityPage.getContent()
                    .stream().map(guaranteeGlobalAccountEntity ->
                            GuaranteeAccountOutDto.builder()
                                    .consecutiveId(consecutiveIdCounter.getAndIncrement())
                                    .guaranteeGlobalAccountId(guaranteeGlobalAccountEntity.getId())
                                    .fullName(guaranteeGlobalAccountEntity.getAccountCode()
                                            .concat(" ")
                                            .concat(guaranteeGlobalAccountEntity.getAccountName()))
                                    .build()

                    ).toList();
            return MapperPageUtil.pageToPageResponseOutDto(guaranteeAccountOutDtoList, guaranteeGlobalAccountEntityPage);
        } else if (TypeAccountEnum.SPECIFIC_ACCOUNT.getValue().equals(accountTypeId)) {
            Page<GuaranteeParticularAccountEntity> guaranteeParticularAccountEntityPage = guaranteeParticularAccountRepository.findAll(
                    specificationGuaranteeParticularAccount(text), pageable);
            guaranteeAccountOutDtoList = guaranteeParticularAccountEntityPage.getContent()
                    .stream().map(guaranteeParticularAccountEntity ->
                            GuaranteeAccountOutDto.builder()
                                    .consecutiveId(consecutiveIdCounter.getAndIncrement())
                                    .guaranteeParticularAccountId(guaranteeParticularAccountEntity.getId())
                                    .fullName(guaranteeParticularAccountEntity.getAccountParticularCode())
                                    .build()
                    ).toList();
            return MapperPageUtil.pageToPageResponseOutDto(guaranteeAccountOutDtoList, guaranteeParticularAccountEntityPage);
        } else {
            throw new ServiceException(ErrorCode.ACCOUNT_TYPE_NOT_FOUND, HttpStatus.NOT_FOUND);
        }
    }

    @Override
    public PageResponseOutDto<GuaranteeAccountOutDto> findAllGuaranteesAccount(Long accountTypeId, String text, int page, int size, String sort, String order, boolean all) {
        if (Objects.requireNonNull(VersionApiEnum.fromValue(PropertiesContext.getVersion())) == VersionApiEnum.V1) {
            return findAllGuaranteesAccountV1WithPagination(accountTypeId, text, page, size, sort, order, all);
        } else {
            throw new ServiceException(ErrorCode.VERSION_API_NOT_FOUND, HttpStatus.NOT_FOUND);
        }
    }

    private PageResponseOutDto<GuaranteeAccountOutDto> findAllGuaranteesAccountV1WithPagination(Long accountTypeId, String text, int page, int size, String sort, String order, boolean all) {
        log.info("Start method findAllGuaranteesAccountV1WithPagination");

        AtomicLong consecutiveIdCounter = new AtomicLong(1);
        
   
        Sort.Direction direction = "desc".equalsIgnoreCase(order) ? 
            Sort.Direction.DESC : 
            Sort.Direction.ASC;
        Sort sortObj = Sort.by(direction, sort != null ? sort : "id");

        if (TypeAccountEnum.GENERAL_ACCOUNT.getValue().equals(accountTypeId)) {
            if (all) {
                List<GuaranteeGlobalAccountEntity> allResults = guaranteeGlobalAccountRepository.findAll(
                    specificationGuaranteeGlobalAccount(text), sortObj);
                List<GuaranteeAccountOutDto> guaranteeAccountOutDtoList = allResults
                    .stream().map(guaranteeGlobalAccountEntity ->
                        GuaranteeAccountOutDto.builder()
                                .consecutiveId(consecutiveIdCounter.getAndIncrement())
                                .guaranteeGlobalAccountId(guaranteeGlobalAccountEntity.getId())
                                .fullName(guaranteeGlobalAccountEntity.getAccountCode()
                                        .concat(" ")
                                        .concat(guaranteeGlobalAccountEntity.getAccountName()))
                                .build()
                    ).toList();
                return buildPageResponseAccount(guaranteeAccountOutDtoList, 0, guaranteeAccountOutDtoList.size(), guaranteeAccountOutDtoList.size());
            } else {
                Pageable pageable = PageRequest.of(page, size, sortObj);
                Page<GuaranteeGlobalAccountEntity> guaranteeGlobalAccountEntityPage = guaranteeGlobalAccountRepository.findAll(
                    specificationGuaranteeGlobalAccount(text), pageable);
                List<GuaranteeAccountOutDto> guaranteeAccountOutDtoList = guaranteeGlobalAccountEntityPage.getContent()
                    .stream().map(guaranteeGlobalAccountEntity ->
                        GuaranteeAccountOutDto.builder()
                                .consecutiveId(consecutiveIdCounter.getAndIncrement())
                                .guaranteeGlobalAccountId(guaranteeGlobalAccountEntity.getId())
                                .fullName(guaranteeGlobalAccountEntity.getAccountCode()
                                        .concat(" ")
                                        .concat(guaranteeGlobalAccountEntity.getAccountName()))
                                .build()
                    ).toList();
                return buildPageResponseAccount(guaranteeAccountOutDtoList, page, size, (int) guaranteeGlobalAccountEntityPage.getTotalElements());
            }
        } else if (TypeAccountEnum.SPECIFIC_ACCOUNT.getValue().equals(accountTypeId)) {
            if (all) {
                List<GuaranteeParticularAccountEntity> allResults = guaranteeParticularAccountRepository.findAll(
                    specificationGuaranteeParticularAccount(text), sortObj);
                List<GuaranteeAccountOutDto> guaranteeAccountOutDtoList = allResults
                    .stream().map(guaranteeParticularAccountEntity ->
                        GuaranteeAccountOutDto.builder()
                                .consecutiveId(consecutiveIdCounter.getAndIncrement())
                                .guaranteeParticularAccountId(guaranteeParticularAccountEntity.getId())
                                .fullName(guaranteeParticularAccountEntity.getAccountParticularCode())
                                .build()
                    ).toList();
                return buildPageResponseAccount(guaranteeAccountOutDtoList, 0, guaranteeAccountOutDtoList.size(), guaranteeAccountOutDtoList.size());
            } else {
                Pageable pageable = PageRequest.of(page, size, sortObj);
                Page<GuaranteeParticularAccountEntity> guaranteeParticularAccountEntityPage = guaranteeParticularAccountRepository.findAll(
                    specificationGuaranteeParticularAccount(text), pageable);
                List<GuaranteeAccountOutDto> guaranteeAccountOutDtoList = guaranteeParticularAccountEntityPage.getContent()
                    .stream().map(guaranteeParticularAccountEntity ->
                        GuaranteeAccountOutDto.builder()
                                .consecutiveId(consecutiveIdCounter.getAndIncrement())
                                .guaranteeParticularAccountId(guaranteeParticularAccountEntity.getId())
                                .fullName(guaranteeParticularAccountEntity.getAccountParticularCode())
                                .build()
                    ).toList();
                return buildPageResponseAccount(guaranteeAccountOutDtoList, page, size, (int) guaranteeParticularAccountEntityPage.getTotalElements());
            }
        } else {
            throw new ServiceException(ErrorCode.ACCOUNT_TYPE_NOT_FOUND, HttpStatus.NOT_FOUND);
        }
    }

    private PageResponseOutDto<GuaranteeAccountOutDto> buildPageResponseAccount(List<GuaranteeAccountOutDto> content, int page, int size, int totalElements) {
        Page<GuaranteeAccountOutDto> guaranteePage = new PageImpl<>(content, 
            PageRequest.of(page, size), totalElements);
        return MapperPageUtil.pageToPageResponseOutDto(content, guaranteePage);
    }

    private Specification<GuaranteeGlobalAccountEntity> specificationGuaranteeGlobalAccount(String text) {
        return (root, query, cb) -> {
            query.distinct(true);

            List<Predicate> predicates = new ArrayList<>();

            if (text != null && !text.isBlank()) {
                String textLike = "%" + text.toLowerCase().trim() + "%";

                Predicate accountCodeLike = cb.like(cb.lower(root.get("accountCode")), textLike);
                Predicate accountNameLike = cb.like(cb.lower(root.get("accountName")), textLike);

                Subquery<Long> subquery = query.subquery(Long.class);
                Root<GuaranteesEntity> g2 = subquery.from(GuaranteesEntity.class);
                subquery.select(cb.literal(1L));
                subquery.where(
                        cb.equal(g2.get("guaranteeGlobalAccount"), root),
                        cb.or(
                                cb.like(cb.lower(g2.get("guaranteeGlobalAccount").get("accountCode")), textLike),
                                cb.like(cb.lower(g2.get("guaranteeGlobalAccount").get("accountName")), textLike)
                        )
                );

                predicates.add(cb.or(accountCodeLike, accountNameLike, cb.exists(subquery)));
            }

            Subquery<Long> existsGlobal = query.subquery(Long.class);
            Root<GuaranteesEntity> g3 = existsGlobal.from(GuaranteesEntity.class);
            existsGlobal.select(cb.literal(1L));
            existsGlobal.where(cb.equal(g3.get("guaranteeGlobalAccount"), root));

            predicates.add(cb.exists(existsGlobal));

            return cb.and(predicates.toArray(new Predicate[0]));
        };
    }

    private Specification<GuaranteeParticularAccountEntity> specificationGuaranteeParticularAccount(String text) {
        return (root, query, cb) -> {
            query.distinct(true);

            List<Predicate> predicates = new ArrayList<>();

            if (text != null && !text.isBlank()) {
                String textLike = "%" + text.toLowerCase().trim() + "%";

                Predicate codeLike = cb.like(cb.lower(root.get("accountParticularCode")), textLike);

                Subquery<Long> subquery = query.subquery(Long.class);
                Root<GuaranteesEntity> g2 = subquery.from(GuaranteesEntity.class);
                subquery.select(cb.literal(1L));
                subquery.where(
                        cb.equal(g2.get("guaranteeParticularAccount"), root),
                        cb.like(cb.lower(g2.get("guaranteeParticularAccount").get("accountParticularCode")), textLike)
                );

                predicates.add(cb.or(codeLike, cb.exists(subquery)));
            }

            Subquery<Long> existsParticular = query.subquery(Long.class);
            Root<GuaranteesEntity> g3 = existsParticular.from(GuaranteesEntity.class);
            existsParticular.select(cb.literal(1L));
            existsParticular.where(cb.equal(g3.get("guaranteeParticularAccount"), root));

            predicates.add(cb.exists(existsParticular));

            return cb.and(predicates.toArray(new Predicate[0]));
        };
    }

}
