package com.nubo.guarantees.admin.api.models.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "\"GUARANTEE_TRANSACTION\"", schema = "\"NUANBODB\"")
public class GuaranteeTransactionEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "\"TRANSACTION_ID\"", nullable = false)
    private Long id;

    @Column(name = "\"GUARANTEE_ACCOUNT_ID\"", nullable = false)
    private Long guaranteesAccountId;

    @Column(name = "\"GUARANTEE_ACCOUNT_DESCRIPTION\"")
    private String guaranteesAccountDescription;

    @Column(name = "\"SPECIFIC_ACCOUNT\"")
    private String specificAccount;

    @Column(name = "\"CLEARING_DATE\"")
    private LocalDate clearingDate;

    @Column(name = "\"MATURITY_DATE\"")
    private LocalDate maturityDate;

    @Column(name = "\"SIDE_ID\"")
    private Long sideId;

    @Column(name = "\"SIDE_DESCRIPTION\"")
    private String sideDescription;

    @Column(name = "\"ASSIGNED_QUANTITY\"", precision = 18, scale = 4)
    private BigDecimal assignedQuantity;

    @Column(name = "\"CURRENCY_RISK\"", precision = 10, scale = 6)
    private BigDecimal currencyRisk;

    @Column(name = "\"ASSIGNED_AMOUNT\"", precision = 18, scale = 4)
    private BigDecimal assignedAmount;

    @Column(name = "\"GUARANTEE_ID\"", nullable = false)
    private Long guaranteeId;

    @Column(name = "\"TRADE_ID\"")
    private Long tradeId;

    @Column(name = "\"FRACTION\"", precision = 10, scale = 6)
    private BigDecimal fraction;

    @Column(name = "\"TRANSFER_BENEFITS\"")
    private Boolean transferBenefits;

    @Column(name = "\"BALANCE_BLOCKING\"")
    private Boolean balanceBlocking;

    @Column(name = "\"HOLDING_SECURITY\"")
    private Boolean holdingSecurity;

    @Column(name = "\"LAST_MODIFY_USER\"", nullable = false)
    private String lastModifyUser;

    @Column(name = "\"LAST_MODIFY_APPLIC\"", nullable = false)
    private String lastModifyApplication;

    @Column(name = "\"LAST_MODIFY_DATE\"", nullable = false)
    private LocalDateTime lastModifyDate;

    @Column(name = "\"LAST_MODIFY_IP\"", nullable = false)
    private String lastModifyIp;
}
