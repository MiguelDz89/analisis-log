package com.nubo.guarantees.admin.api.helpers.dynamicQuery.dataBase;

import com.nubo.guarantees.admin.api.models.entity.GuaranteesEntity;
import com.nubo.guarantees.admin.api.models.enums.SearchOperationEnum;
import jakarta.persistence.criteria.Path;
import org.springframework.data.jpa.domain.Specification;

import java.util.ArrayList;
import java.util.List;

public class GuaranteesSpecificationBuilder {

    private final List<Specification<GuaranteesEntity>> specifications = new ArrayList<>();

    public static GuaranteesSpecificationBuilder builder() {
        return new GuaranteesSpecificationBuilder();
    }

    public GuaranteesSpecificationBuilder withCountryId(Long countryId) {
        if (countryId != null) {
            specifications.add((root, query, cb) ->
                    cb.equal(root.get("country").get("id"), countryId));
        }
        return this;
    }

    public GuaranteesSpecificationBuilder withParticipantId(Long participantId) {
        if (participantId != null) {
            specifications.add((root, query, cb) ->
                    cb.equal(root.get("participant").get("id"), participantId));
        }
        return this;
    }

    public GuaranteesSpecificationBuilder withInvestorId(Long investorId) {
        if (investorId != null) {
            specifications.add((root, query, cb) ->
                    cb.equal(root.get("investor").get("id"), investorId));
        }
        return this;
    }

    public GuaranteesSpecificationBuilder withAccountTypeId(Long accountTypeId) {
        if (accountTypeId != null) {
            specifications.add((root, query, cb) ->
                    cb.equal(root.get("accountType").get("id"), accountTypeId));
        }
        return this;
    }

    public GuaranteesSpecificationBuilder withGuaranteeGlobalAccountId(Long guaranteeGlobalAccountId) {
        if (guaranteeGlobalAccountId != null) {
            specifications.add((root, query, cb) ->
                    cb.equal(root.get("guaranteeGlobalAccount").get("id"), guaranteeGlobalAccountId));
        }
        return this;
    }

    public GuaranteesSpecificationBuilder withGuaranteeParticularAccountId(Long guaranteeParticularAccountId) {
        if (guaranteeParticularAccountId != null) {
            specifications.add((root, query, cb) ->
                    cb.equal(root.get("guaranteeParticularAccount").get("id"), guaranteeParticularAccountId));
        }
        return this;
    }

    public GuaranteesSpecificationBuilder withGuaranteeId(Long guaranteeId) {
        if (guaranteeId != null) {
            specifications.add((root, query, cb) ->
                    cb.equal(root.get("id"), guaranteeId));
        }
        return this;
    }

    public GuaranteesSpecificationBuilder withStatusId(Long statusId) {
        if (statusId != null) {
            specifications.add((root, query, cb) ->
                    cb.equal(root.get("status").get("id"), statusId));
        }
        return this;
    }

    public GuaranteesSpecificationBuilder withDynamicFilter(String fieldName, String fieldValue, SearchOperationEnum operation) {
        if (fieldName != null && fieldValue != null && operation != null) {
            specifications.add((root, query, cb) -> {
                try {
                    Path<?> fieldPath = MapperGuaranteesDynamicSearch.getGuaranteesFieldPath(root, fieldName);
                    if (fieldPath != null) {
                        return MapperGuaranteesDynamicSearch.buildGuaranteesFieldPredicate(cb, fieldPath, fieldValue, operation);
                    }
                    return cb.conjunction();
                } catch (Exception e) {
                    return cb.conjunction();
                }
            });
        }
        return this;
    }

    public Specification<GuaranteesEntity> build() {
        return specifications.stream()
                .reduce(Specification.<GuaranteesEntity>anyOf(), Specification::and);
    }
}
