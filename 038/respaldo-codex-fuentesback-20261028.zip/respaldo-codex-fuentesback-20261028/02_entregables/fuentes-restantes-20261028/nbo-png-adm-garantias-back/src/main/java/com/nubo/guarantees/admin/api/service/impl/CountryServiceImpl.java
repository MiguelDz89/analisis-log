package com.nubo.guarantees.admin.api.service.impl;

import com.nubo.guarantees.admin.api.application.properties.PropertiesContext;
import com.nubo.guarantees.admin.api.exception.ServiceException;
import com.nubo.guarantees.admin.api.exception.error.ErrorCode;
import com.nubo.guarantees.admin.api.helpers.MapperUtil;
import com.nubo.guarantees.admin.api.models.dto.response.CountryOutDto;
import com.nubo.guarantees.admin.api.models.enums.CountryEnum;
import com.nubo.guarantees.admin.api.models.enums.VersionApiEnum;
import com.nubo.guarantees.admin.api.repository.CountryRepository;
import com.nubo.guarantees.admin.api.service.CountryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
@Slf4j
public class CountryServiceImpl implements CountryService {

    private final CountryRepository countryRepository;

    @Override
    public List<CountryOutDto> findCountries() {
        if (Objects.requireNonNull(VersionApiEnum.fromValue(PropertiesContext.getVersion())) == VersionApiEnum.V1) {
            return findCountriesV1();
        } else {
            throw new ServiceException(ErrorCode.VERSION_API_NOT_FOUND, HttpStatus.NOT_FOUND);
        }
    }

    private List<CountryOutDto> findCountriesV1() {
        log.info("Start method findCountriesV1");

        List<Long> countries = new ArrayList<>();
        countries.add(CountryEnum.CHILE.getValue());
        countries.add(CountryEnum.COLOMBIA.getValue());
        countries.add(CountryEnum.PERU.getValue());

        List<CountryOutDto> countryOutDto = countryRepository.findCountriesByIds(countries).stream()
                .map(MapperUtil::countryEntityToCountryOutDto)
                .toList();

        log.info("End method findCountriesV1, number of countries found: {}", countryOutDto.size());

        return countryOutDto;
    }

}
