package com.nubo.guarantees.admin.api.service.impl;

import com.nubo.guarantees.admin.api.application.properties.PropertiesContext;
import com.nubo.guarantees.admin.api.exception.ServiceException;
import com.nubo.guarantees.admin.api.exception.error.ErrorCode;
import com.nubo.guarantees.admin.api.helpers.MapperUtil;
import com.nubo.guarantees.admin.api.models.dto.response.StatusOutDto;
import com.nubo.guarantees.admin.api.models.entity.StatusEntity;
import com.nubo.guarantees.admin.api.models.enums.StatusCategoryEnum;
import com.nubo.guarantees.admin.api.models.enums.VersionApiEnum;
import com.nubo.guarantees.admin.api.repository.StatusRepository;
import com.nubo.guarantees.admin.api.service.StatusService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
@Slf4j
public class StatusServiceImpl implements StatusService {

    private final StatusRepository statusRepository;

    @Override
    public List<StatusOutDto> findAllGuaranteesStatus() {
        if (Objects.requireNonNull(VersionApiEnum.fromValue(PropertiesContext.getVersion())) == VersionApiEnum.V1) {
            return MapperUtil.statusEntityListToGuaranteesStatusList(findAllGuaranteesStatusV1());
        } else {
            throw new ServiceException(ErrorCode.VERSION_API_NOT_FOUND, HttpStatus.NOT_FOUND);
        }
    }

    private List<StatusEntity> findAllGuaranteesStatusV1() {
        log.info("Start method findAllGuaranteesStatusV1");

        List<StatusEntity> statusEntityList = statusRepository.findAllGuaranteesStatus(
                StatusCategoryEnum.GUARANTEES_ADMIN.getValue());

        log.debug("End method findAllGuaranteesStatusV1, statusOutDtoList -> {}",
                statusEntityList.size());

        return statusEntityList;
    }

}
