package com.nubo.guarantees.admin.api.web.controller;

import com.nubo.guarantees.admin.api.models.dto.request.GuaranteesInDto;
import com.nubo.guarantees.admin.api.models.dto.response.GuaranteesOutDto;
import com.nubo.guarantees.admin.api.models.dto.response.PageResponseOutDto;
import com.nubo.guarantees.admin.api.service.GuaranteesService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "Guarantees")
@RestController
@RequestMapping("/{version}/guarantees")
@RequiredArgsConstructor
public class GuaranteesRestController {

    private final GuaranteesService guaranteesService;

    @Operation(summary = "Find all guarantees for administration", description = "Find all guarantees for administration")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Successfully Response",
            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = GuaranteesOutDto.class)))})
    @GetMapping("/guarantees-admin-by-filters")
    public ResponseEntity<PageResponseOutDto<GuaranteesOutDto>> findPagedDataGuaranteesByFilters(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "countryId") String sort,
            @RequestParam(defaultValue = "asc") String order,
            @RequestParam(defaultValue = "false") boolean all,
            @Parameter(example = "1") @RequestParam(required = false) Long countryId,
            @Parameter(example = "1") @RequestParam(required = false) Long participantId,
            @Parameter(example = "1") @RequestParam(required = false) Long investorId,
            @Parameter(example = "1") @RequestParam(required = false) Long accountTypeId,
            @Parameter(example = "1") @RequestParam(required = false) Long guaranteeGlobalAccountId,
            @Parameter(example = "1") @RequestParam(required = false) Long guaranteeParticularAccountId,
            @Parameter(example = "1") @RequestParam(required = false) Long statusId) {
        GuaranteesInDto guaranteesInDto = GuaranteesInDto.builder()
                .countryId(countryId)
                .participantId(participantId)
                .investorId(investorId)
                .accountTypeId(accountTypeId)
                .guaranteeGlobalAccountId(guaranteeGlobalAccountId)
                .guaranteeParticularAccountId(guaranteeParticularAccountId)
                .statusId(statusId)
                .build();
        Sort sortBy = order.equalsIgnoreCase(Sort.Direction.ASC.name()) ?
                Sort.by(Sort.Order.asc(sort), Sort.Order.asc("id")) :
                Sort.by(Sort.Order.desc(sort), Sort.Order.desc("id"));
        Pageable pageable = PageRequest.of(page, size, sortBy);
        return ResponseEntity.ok(guaranteesService.findAllGuarantees(pageable, guaranteesInDto));
    }

    @Operation(summary = "Find all guarantees with dynamic filters", description = "Find all guarantees with dynamic filters")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Successfully Response",
            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = GuaranteesOutDto.class)))})
    @GetMapping("/guarantees-admin-dynamic")
    public ResponseEntity<PageResponseOutDto<GuaranteesOutDto>> findPagedDataGuaranteesByFiltersDynamic(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String fieldName,
            @RequestParam(required = false) String fieldValue,
            @RequestParam(required = false) String operation,
            @RequestParam(required = false) String sort,
            @RequestParam(required = false) String order,
            @Parameter(example = "1") @RequestParam(required = false) Long countryId,
            @Parameter(example = "1") @RequestParam(required = false) Long participantId,
            @Parameter(example = "1") @RequestParam(required = false) Long investorId,
            @Parameter(example = "1") @RequestParam(required = false) Long accountTypeId,
            @Parameter(example = "1") @RequestParam(required = false) Long guaranteeGlobalAccountId,
            @Parameter(example = "1") @RequestParam(required = false) Long guaranteeParticularAccountId,
            @Parameter(example = "1") @RequestParam(required = false) Long guaranteeId,
            @Parameter(example = "1") @RequestParam(required = false) Long statusId) {

        Pageable pageable;
        if (sort != null && order != null) {
            Sort.Direction direction = "desc".equalsIgnoreCase(order) ? Sort.Direction.DESC : Sort.Direction.ASC;
            Sort sorting = Sort.by(direction, sort);
            pageable = PageRequest.of(page, size, sorting);
        } else {
            pageable = PageRequest.of(page, size);
        }

        return ResponseEntity.ok(
                guaranteesService.findPagedDataGuaranteesByFiltersDynamic(
                        pageable, fieldName, fieldValue, operation,
                        countryId, participantId, investorId, accountTypeId, guaranteeGlobalAccountId, guaranteeParticularAccountId,
                        guaranteeId, statusId
                )
        );
    }

}
