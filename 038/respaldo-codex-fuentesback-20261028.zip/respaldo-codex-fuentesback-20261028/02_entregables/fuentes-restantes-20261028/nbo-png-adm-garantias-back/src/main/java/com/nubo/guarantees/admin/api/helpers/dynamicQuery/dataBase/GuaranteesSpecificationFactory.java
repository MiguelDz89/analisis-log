package com.nubo.guarantees.admin.api.helpers.dynamicQuery.dataBase;

import org.springframework.data.jpa.domain.Specification;

import com.nubo.guarantees.admin.api.models.entity.GuaranteesEntity;
import com.nubo.guarantees.admin.api.models.enums.SearchOperationEnum;

import jakarta.persistence.criteria.Path;

public class GuaranteesSpecificationFactory {
    
    private GuaranteesSpecificationFactory() {
        throw new IllegalStateException("Utility class");
    }

    public static Specification<GuaranteesEntity> createStandardFilter(
            Long countryId, Long participantId, Long investorId, 
            Long guaranteeGlobalAccountId,Long guaranteeParticularAccountId, Long guaranteeId, Long statusId) {
        
        return GuaranteesSpecificationBuilder.builder()
                .withCountryId(countryId)
                .withParticipantId(participantId)
                .withInvestorId(investorId)
                .withGuaranteeGlobalAccountId(guaranteeGlobalAccountId)
                .withGuaranteeId(guaranteeId)
                .withStatusId(statusId)
                .build();
    }

    public static Specification<GuaranteesEntity> createDynamicFilter(
            String fieldName, String fieldValue, SearchOperationEnum operation) {
        
        return (root, query, cb) -> {
            try {
                Path<?> fieldPath = MapperGuaranteesDynamicSearch
                    .getGuaranteesFieldPath(root, fieldName);
                if (fieldPath != null) {
                    return MapperGuaranteesDynamicSearch
                        .buildGuaranteesFieldPredicate(cb, fieldPath, fieldValue, operation);
                }
                return cb.conjunction();
            } catch (Exception e) {
                return cb.conjunction();
            }
        };
    }

    public static Specification<GuaranteesEntity> createCombinedFilter(
            Long countryId, Long participantId, Long investorId, Long accountTypeId,
            Long guaranteeGlobalAccountId,
            Long guaranteeParticularAccountId, Long guaranteeId, Long statusId,
            String fieldName, String fieldValue, SearchOperationEnum operation) {
        
        return GuaranteesSpecificationBuilder.builder()
                .withCountryId(countryId)
                .withParticipantId(participantId)
                .withInvestorId(investorId)
                .withAccountTypeId(accountTypeId)
                .withGuaranteeGlobalAccountId(guaranteeGlobalAccountId)
                .withGuaranteeParticularAccountId(guaranteeParticularAccountId)
                .withGuaranteeId(guaranteeId)
                .withStatusId(statusId)
                .withDynamicFilter(fieldName, fieldValue, operation)
                .build();
    }
}
