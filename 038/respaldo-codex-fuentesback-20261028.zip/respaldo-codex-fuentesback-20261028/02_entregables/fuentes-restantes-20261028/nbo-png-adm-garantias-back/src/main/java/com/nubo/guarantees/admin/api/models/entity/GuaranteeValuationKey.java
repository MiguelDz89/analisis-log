package com.nubo.guarantees.admin.api.models.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GuaranteeValuationKey implements Serializable {

    private Long guarantee;

    private LocalDateTime valuationDate;

}
