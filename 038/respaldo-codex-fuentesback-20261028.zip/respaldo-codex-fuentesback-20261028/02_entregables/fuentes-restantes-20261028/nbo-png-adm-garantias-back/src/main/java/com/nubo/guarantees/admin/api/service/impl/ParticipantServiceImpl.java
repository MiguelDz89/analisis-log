package com.nubo.guarantees.admin.api.service.impl;

import com.nubo.guarantees.admin.api.application.properties.PropertiesContext;
import com.nubo.guarantees.admin.api.exception.ServiceException;
import com.nubo.guarantees.admin.api.exception.error.ErrorCode;
import com.nubo.guarantees.admin.api.helpers.MapperPageUtil;
import com.nubo.guarantees.admin.api.helpers.MapperUtil;
import com.nubo.guarantees.admin.api.models.dto.response.PageResponseOutDto;
import com.nubo.guarantees.admin.api.models.dto.response.ParticipantOutDto;
import com.nubo.guarantees.admin.api.models.entity.GuaranteesEntity;
import com.nubo.guarantees.admin.api.models.entity.ParticipantEntity;
import com.nubo.guarantees.admin.api.models.enums.VersionApiEnum;
import com.nubo.guarantees.admin.api.repository.ParticipantRepository;
import com.nubo.guarantees.admin.api.service.ParticipantService;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Subquery;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
@Slf4j
public class ParticipantServiceImpl implements ParticipantService {

    private final ParticipantRepository participantRepository;

    @Override
    public PageResponseOutDto<ParticipantOutDto> findByParticipant(String text, Pageable pageable) {
        if (Objects.requireNonNull(VersionApiEnum.fromValue(PropertiesContext.getVersion())) == VersionApiEnum.V1) {
            return findByParticipantV1(text, pageable);
        } else {
            throw new ServiceException(ErrorCode.VERSION_API_NOT_FOUND, HttpStatus.NOT_FOUND);
        }
    }

    private PageResponseOutDto<ParticipantOutDto> findByParticipantV1(String text,
                                                                      Pageable pageable) {
        log.info("Start method findByParticipantV1");

        Page<ParticipantEntity> participantEntityPage = participantRepository.findAll(
                this.specificationParticipantAndCustodian(text), pageable);

        List<ParticipantOutDto> participantOutDtoList = participantEntityPage.getContent().stream()
                .map(MapperUtil::participantEntityToParticipantOutDto)
                .toList();

        log.info("End method findByParticipantV1, participantOutDtoList -> {}", participantOutDtoList);

        return MapperPageUtil.pageToPageResponseOutDto(participantOutDtoList, participantEntityPage);
    }

    @Override
    public PageResponseOutDto<ParticipantOutDto> findByParticipant(String text, int page, int size, String sort, String order, boolean all) {
        if (Objects.requireNonNull(VersionApiEnum.fromValue(PropertiesContext.getVersion())) == VersionApiEnum.V1) {
            return findByParticipantV1WithPagination(text, page, size, sort, order, all);
        } else {
            throw new ServiceException(ErrorCode.VERSION_API_NOT_FOUND, HttpStatus.NOT_FOUND);
        }
    }

    private PageResponseOutDto<ParticipantOutDto> findByParticipantV1WithPagination(String text, int page, int size, String sort, String order, boolean all) {
        log.info("Start method findByParticipantV1WithPagination");

        // Create sort object
        Sort.Direction direction = "desc".equalsIgnoreCase(order) ? 
            Sort.Direction.DESC : 
            Sort.Direction.ASC;
        Sort sortObj = Sort.by(direction, sort != null ? sort : "id");

        Specification<ParticipantEntity> spec = specificationParticipantAndCustodian(text);

        if (all) {
            // Return all results
            List<ParticipantEntity> allResults = participantRepository.findAll(spec, sortObj);
            List<ParticipantOutDto> participantOutDtoList = allResults.stream()
                .map(MapperUtil::participantEntityToParticipantOutDto)
                .toList();
            return buildPageResponseParticipant(participantOutDtoList, 0, participantOutDtoList.size(), participantOutDtoList.size());
        } else {
            // Return paginated results
            Pageable pageable = PageRequest.of(page, size, sortObj);
            Page<ParticipantEntity> participantEntityPage = participantRepository.findAll(spec, pageable);
            List<ParticipantOutDto> participantOutDtoList = participantEntityPage.getContent().stream()
                .map(MapperUtil::participantEntityToParticipantOutDto)
                .toList();
            return buildPageResponseParticipant(participantOutDtoList, page, size, (int) participantEntityPage.getTotalElements());
        }
    }

    private PageResponseOutDto<ParticipantOutDto> buildPageResponseParticipant(List<ParticipantOutDto> content, int page, int size, int totalElements) {
        Page<ParticipantOutDto> participantPage = new PageImpl<>(content, 
            PageRequest.of(page, size), totalElements);
        return MapperPageUtil.pageToPageResponseOutDto(content, participantPage);
    }

    private Specification<ParticipantEntity> specificationParticipantAndCustodian(String text) {
        return (root, query, cb) -> {
            query.distinct(true);

            List<Predicate> predicates = new ArrayList<>();

            if (text != null && !text.isBlank()) {
                String textLike = "%" + text.toLowerCase().trim() + "%";

                Predicate codeLike = cb.like(cb.lower(root.get("code")), textLike);

                Predicate documentNumberLike = cb.like(cb.lower(root.get("documentNumber")), textLike);

                Predicate nameLike = cb.like(cb.lower(root.get("name")), textLike);

                Subquery<Long> subquery = query.subquery(Long.class);
                Root<GuaranteesEntity> g2 = subquery.from(GuaranteesEntity.class);
                subquery.select(cb.literal(1L));
                subquery.where(
                        cb.equal(g2.get("custodian"), root),
                        cb.or(
                                cb.like(cb.lower(g2.get("custodian").get("documentNumber")), textLike),
                                cb.like(cb.lower(g2.get("custodian").get("code")), textLike),
                                cb.like(cb.lower(g2.get("custodian").get("name")), textLike)
                        )
                );

                predicates.add(cb.or(documentNumberLike, codeLike, nameLike, cb.exists(subquery)));
            }

            Subquery<Long> existsParticipant = query.subquery(Long.class);
            Root<GuaranteesEntity> g3 = existsParticipant.from(GuaranteesEntity.class);
            existsParticipant.select(cb.literal(1L));
            existsParticipant.where(cb.equal(g3.get("participant"), root));

            Subquery<Long> existsCustodian = query.subquery(Long.class);
            Root<GuaranteesEntity> g4 = existsCustodian.from(GuaranteesEntity.class);
            existsCustodian.select(cb.literal(1L));
            existsCustodian.where(cb.equal(g4.get("custodian"), root));

            predicates.add(cb.or(cb.exists(existsParticipant), cb.exists(existsCustodian)));

            return cb.and(predicates.toArray(new Predicate[0]));
        };
    }

}
