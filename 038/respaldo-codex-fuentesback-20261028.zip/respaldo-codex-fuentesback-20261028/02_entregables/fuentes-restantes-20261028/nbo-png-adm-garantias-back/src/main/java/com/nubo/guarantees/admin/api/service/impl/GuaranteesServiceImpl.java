package com.nubo.guarantees.admin.api.service.impl;

import com.nubo.guarantees.admin.api.application.properties.PropertiesContext;
import com.nubo.guarantees.admin.api.exception.ServiceException;
import com.nubo.guarantees.admin.api.exception.error.ErrorCode;
import com.nubo.guarantees.admin.api.helpers.MapperPageUtil;
import com.nubo.guarantees.admin.api.helpers.MapperUtil;
import com.nubo.guarantees.admin.api.helpers.dynamicQuery.dataBase.GuaranteesSpecificationFactory;
import com.nubo.guarantees.admin.api.models.dto.request.GuaranteesInDto;
import com.nubo.guarantees.admin.api.models.dto.response.GuaranteesOutDto;
import com.nubo.guarantees.admin.api.models.dto.response.PageResponseOutDto;
import com.nubo.guarantees.admin.api.models.entity.GuaranteesEntity;
import com.nubo.guarantees.admin.api.models.entity.ParticipantEntity;
import com.nubo.guarantees.admin.api.models.enums.CountryEnum;
import com.nubo.guarantees.admin.api.models.enums.MarketEnum;
import com.nubo.guarantees.admin.api.models.enums.ParticipantEnum;
import com.nubo.guarantees.admin.api.models.enums.SearchOperationEnum;
import com.nubo.guarantees.admin.api.models.enums.StatusGuaranteeAdmEnum;
import com.nubo.guarantees.admin.api.models.enums.StatusTradeCustodianEnum;
import com.nubo.guarantees.admin.api.models.enums.TypeAccountEnum;
import com.nubo.guarantees.admin.api.models.enums.VersionApiEnum;
import com.nubo.guarantees.admin.api.repository.GuaranteesRepository;
import com.nubo.guarantees.admin.api.repository.ParticipantRepository;
import com.nubo.guarantees.admin.api.repository.StatusRepository;
import com.nubo.guarantees.admin.api.service.GuaranteesService;
import jakarta.persistence.criteria.Predicate;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

@Service
@RequiredArgsConstructor
@Slf4j
public class GuaranteesServiceImpl implements GuaranteesService {

    private final GuaranteesRepository guaranteesRepository;
    private final StatusRepository statusRepository;
    private final ParticipantRepository participantRepository;

    public PageResponseOutDto<GuaranteesOutDto> findAllGuarantees(Pageable pageable, GuaranteesInDto
            guaranteesInDto) {
        if (Objects.requireNonNull(VersionApiEnum.fromValue(PropertiesContext.getVersion())) == VersionApiEnum.V1) {
            return findAllGuaranteesV1(pageable, guaranteesInDto);
        } else {
            throw new ServiceException(ErrorCode.VERSION_API_NOT_FOUND, HttpStatus.NOT_FOUND);
        }
    }

    private PageResponseOutDto<GuaranteesOutDto> findAllGuaranteesV1(Pageable pageable, GuaranteesInDto
            guaranteesInDto) {
        log.info("Start method findAllGuaranteesV1");

        Long participantId = null;
        Long custodianId = null;
        if (!ObjectUtils.isEmpty(guaranteesInDto.getParticipantId())) {
            Optional<ParticipantEntity> participantEntity = participantRepository.findById(guaranteesInDto.getParticipantId());
            if (participantEntity.isPresent() && participantEntity.get().getCustodian()) {
                custodianId = participantEntity.get().getId();
            } else if (participantEntity.isPresent()) {
                participantId = participantEntity.get().getId();
            }
        }

        List<GuaranteesEntity> allGuarantees = guaranteesRepository.findAll(guaranteesSpecification(guaranteesInDto, participantId, custodianId));
        List<GuaranteesOutDto> guaranteesOutDtoList = getGuaranteesOutDtoList(allGuarantees, guaranteesInDto.getStatusId());

        List<GuaranteesOutDto> pageContent = MapperPageUtil.getPageContent(pageable, guaranteesOutDtoList);
        Page<GuaranteesOutDto> guaranteePage = new PageImpl<>(pageContent,
                pageable, guaranteesOutDtoList.size());


        log.debug("End method findAllGuaranteesV1, guaranteesOutDtoList -> {}", guaranteesOutDtoList);

        return MapperPageUtil.pageToPageResponseOutDto(pageContent, guaranteePage);
    }

    @Override
    public PageResponseOutDto<GuaranteesOutDto> findAllGuarantees(GuaranteesInDto guaranteesInDto, int page, int size, String sort, String order, boolean all) {
        if (Objects.requireNonNull(VersionApiEnum.fromValue(PropertiesContext.getVersion())) == VersionApiEnum.V1) {
            return findAllGuaranteesV1WithPagination(guaranteesInDto, page, size, sort, order, all);
        } else {
            throw new ServiceException(ErrorCode.VERSION_API_NOT_FOUND, HttpStatus.NOT_FOUND);
        }
    }

    private PageResponseOutDto<GuaranteesOutDto> findAllGuaranteesV1WithPagination(GuaranteesInDto guaranteesInDto, int page, int size, String sort, String order, boolean all) {
        log.info("Start method findAllGuaranteesV1WithPagination");

        Long participantId = null;
        Long custodianId = null;
        if (!ObjectUtils.isEmpty(guaranteesInDto.getParticipantId())) {
            Optional<ParticipantEntity> participantEntity = participantRepository.findById(guaranteesInDto.getParticipantId());
            if (participantEntity.isPresent() && participantEntity.get().getCustodian()) {
                custodianId = participantEntity.get().getId();
            } else if (participantEntity.isPresent()) {
                participantId = participantEntity.get().getId();
            }
        }

        Specification<GuaranteesEntity> spec = guaranteesSpecification(guaranteesInDto, participantId, custodianId);


        Direction direction = "desc".equalsIgnoreCase(order) ?
                Direction.DESC :
                Direction.ASC;
        Sort sortObj = Sort.by(direction, sort != null ? sort : "id");

        if (all) {
            List<GuaranteesEntity> allResults = guaranteesRepository.findAll(spec, sortObj);
            List<GuaranteesOutDto> guaranteesOutDtoList = getGuaranteesOutDtoList(allResults, guaranteesInDto.getStatusId());
            return buildPageResponse(guaranteesOutDtoList, 0, guaranteesOutDtoList.size(), guaranteesOutDtoList.size());
        } else {
            Pageable pageable = PageRequest.of(page, size, sortObj);
            Page<GuaranteesEntity> pageResult = guaranteesRepository.findAll(spec, pageable);
            List<GuaranteesOutDto> guaranteesOutDtoList = getGuaranteesOutDtoList(pageResult.getContent(), guaranteesInDto.getStatusId());
            return buildPageResponse(guaranteesOutDtoList, page, size, (int) pageResult.getTotalElements());
        }
    }

    private PageResponseOutDto<GuaranteesOutDto> buildPageResponse(List<GuaranteesOutDto> content, int page, int size, int totalElements) {
        Page<GuaranteesOutDto> guaranteePage = new PageImpl<>(content,
                PageRequest.of(page, size), totalElements);
        return MapperPageUtil.pageToPageResponseOutDto(content, guaranteePage);
    }

    public List<GuaranteesOutDto> getGuaranteesOutDtoList(List<GuaranteesEntity> guaranteesEntities, Long statusId) {
        List<GuaranteesOutDto> guaranteesOutDtoList = guaranteesEntities.stream()
                .map(guaranteesEntity -> {

                    BigDecimal guaranteeIntegerTotal = calculateGuaranteeIntegerTotal(guaranteesEntity);
                    BigDecimal guaranteeExigencyTotal = calculateGuaranteeTotalExigency(guaranteesEntity);
                    BigDecimal limitGuaranteeTotal = calculateLimitGuaranteeTotal(guaranteesEntity);

                    BigDecimal position = guaranteeIntegerTotal.subtract(guaranteeExigencyTotal);

                    Long idStatus = (position.compareTo(BigDecimal.ZERO) > 0)
                            ? StatusGuaranteeAdmEnum.COVERED.getId()
                            : StatusGuaranteeAdmEnum.PENDING.getId();

                    guaranteesEntity.setStatus(statusRepository.findById(idStatus).orElse(null));

                    GuaranteesOutDto guaranteesOutDto = MapperUtil.guaranteesEntitytoGuaranteesOutDto(guaranteesEntity, position);
                    assert guaranteesOutDto != null;
                    guaranteesOutDto.setGuaranteeIntegerTotal(guaranteeIntegerTotal);
                    guaranteesOutDto.setGuaranteeExigencyTotal(guaranteeExigencyTotal);

                    String marketId = guaranteesEntity.getIsinNumber().getMarket().getId();

                    if(MarketEnum.RV.getId().equals(marketId)) {
                        guaranteesOutDto.setLimitRV(limitGuaranteeTotal);
                    } else if(MarketEnum.DP.getId().equals(marketId)) {
                        guaranteesOutDto.setLimitDP(limitGuaranteeTotal);
                    }else if(MarketEnum.PR.getId().equals(marketId)) {
                        guaranteesOutDto.setLimitPR(limitGuaranteeTotal);
                    }else if(MarketEnum.IF.getId().equals(marketId)) {
                        guaranteesOutDto.setLimitIF(limitGuaranteeTotal);
                    }else if(MarketEnum.EF.getId().equals(marketId)) {
                        guaranteesOutDto.setLimitEF(limitGuaranteeTotal);
                    }

                    String guaranteeAccountDescription = "";
                    if (TypeAccountEnum.GENERAL_ACCOUNT.getValue().equals(guaranteesOutDto.getAccountType().getId())
                            && !ObjectUtils.isEmpty(guaranteesOutDto.getGuaranteeGlobalAccount())) {
                        guaranteeAccountDescription = guaranteesOutDto.getGuaranteeGlobalAccount().getAccountCode()
                                .concat(" ")
                                .concat(guaranteesOutDto.getGuaranteeGlobalAccount().getAccountName());
                    } else if (TypeAccountEnum.SPECIFIC_ACCOUNT.getValue().equals(guaranteesOutDto.getAccountType().getId())
                            && !ObjectUtils.isEmpty(guaranteesOutDto.getGuaranteeParticularAccount())) {
                        guaranteeAccountDescription = guaranteesOutDto.getGuaranteeParticularAccount().getAccountParticularCode();
                    }
                    guaranteesOutDto.setGuaranteeAccountDescription(guaranteeAccountDescription);

                    return guaranteesOutDto;
                }).filter(guaranteesOutDto -> statusId == null ||
                        (guaranteesOutDto.getStatus() != null && guaranteesOutDto.getStatus().getId().equals(statusId)))
                .toList();

        Map<String, GuaranteesOutDto> uniqueMap = new LinkedHashMap<>();

        for (GuaranteesOutDto dto : guaranteesOutDtoList) {
            String key = buildFullGroupKey(dto);

            uniqueMap.merge(key, dto, (existing, incoming) -> {
                mergeLimits(existing, incoming);
                return existing;
            });
        }

        AtomicInteger counter = new AtomicInteger(1);

        return uniqueMap.values().stream()
                .sorted(Comparator.comparing(this::buildFullGroupKey))
                .map(dto -> {
                    dto.setId((long) counter.getAndIncrement());
                    return dto;
                })
                .toList();
    }

    private String buildFullGroupKey(GuaranteesOutDto dto) {
        String custodianKey = dto.getCustodian() != null
                ? dto.getCustodian().getId().toString()
                : "NO_CUSTODIAN";

        String participantKey;
        if (dto.getCustodian() != null) {
            participantKey = "IGNORED_PARTICIPANT";
        } else {
            participantKey = dto.getParticipant() != null
                    ? dto.getParticipant().getId().toString()
                    : "NO_PARTICIPANT";
        }

        return String.join("|",
                dto.getCountry() != null ? dto.getCountry().getId().toString() : "NO_COUNTRY",
                participantKey,
                custodianKey,
                dto.getInvestor() != null ? dto.getInvestor().getId().toString() : "NO_INVESTOR",
                dto.getGuaranteeGlobalAccount() != null ? "G-" + dto.getGuaranteeGlobalAccount().getId() : "NO_GLB",
                dto.getGuaranteeParticularAccount() != null ? "P-" + dto.getGuaranteeParticularAccount().getId() : "NO_PRT",
                dto.getGuaranteeIntegerTotal() != null ? dto.getGuaranteeIntegerTotal().toPlainString() : "NO_INT",
                dto.getGuaranteeExigencyTotal() != null ? dto.getGuaranteeExigencyTotal().toPlainString() : "NO_EXG"
        );
    }

    private void mergeLimits(GuaranteesOutDto base, GuaranteesOutDto incoming) {

        base.setLimitRV(mergeBigDecimal(base.getLimitRV(), incoming.getLimitRV()));
        base.setLimitDP(mergeBigDecimal(base.getLimitDP(), incoming.getLimitDP()));
        base.setLimitPR(mergeBigDecimal(base.getLimitPR(), incoming.getLimitPR()));
        base.setLimitEF(mergeBigDecimal(base.getLimitEF(), incoming.getLimitEF()));
        base.setLimitIF(mergeBigDecimal(base.getLimitIF(), incoming.getLimitIF()));
    }

    private BigDecimal mergeBigDecimal(BigDecimal original, BigDecimal incoming) {

        if (original == null) return incoming;
        if (incoming == null) return original;

        if (original.compareTo(incoming) == 0) return original;

        return original.add(incoming);
    }

    public Specification<GuaranteesEntity> guaranteesSpecification(GuaranteesInDto guaranteesInDto,
                                                                   Long participantId, Long custodianId) {
        return (root, query, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();
            if (guaranteesInDto.getCountryId() != null) {
                predicates.add(criteriaBuilder.equal(root.get("country").get("id"), guaranteesInDto.getCountryId()));
            }
            if (custodianId != null) {
                predicates.add(criteriaBuilder.equal(root.get(ParticipantEnum.CUSTODIAN.getValue()).get("id"),
                        custodianId));
            }
            if (participantId != null) {
                predicates.add(criteriaBuilder.equal(root.get(ParticipantEnum.PARTICIPANT.getValue()).get("id"),
                        participantId));
            }
            if (guaranteesInDto.getInvestorId() != null) {
                predicates.add(criteriaBuilder.equal(root.get("investor").get("id"), guaranteesInDto.getInvestorId()));
            }
            if (guaranteesInDto.getAccountTypeId() != null) {
                predicates.add(criteriaBuilder.equal(root.get("accountType").get("id"), guaranteesInDto.getAccountTypeId()));
            }
            if (guaranteesInDto.getGuaranteeGlobalAccountId() != null) {
                predicates.add(criteriaBuilder.equal(root.get("guaranteeGlobalAccount").get("id"),
                        guaranteesInDto.getGuaranteeGlobalAccountId()));
            }
            if (guaranteesInDto.getGuaranteeParticularAccountId() != null) {
                predicates.add(criteriaBuilder.equal(root.get("guaranteeParticularAccount").get("id"),
                        guaranteesInDto.getGuaranteeParticularAccountId()));
            }
            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        };
    }

    private BigDecimal calculateGuaranteeIntegerTotal(GuaranteesEntity guaranteesEntity) {

        Long participantId = ObjectUtils.isEmpty(guaranteesEntity.getParticipant()) ? null : guaranteesEntity.getParticipant().getId();
        Long custodianId = ObjectUtils.isEmpty(guaranteesEntity.getCustodian()) ? null : guaranteesEntity.getCustodian().getId();
        Long investorId = ObjectUtils.isEmpty(guaranteesEntity.getInvestor()) ? null : guaranteesEntity.getInvestor().getId();
        Long guaranteeGlobalAccountId = ObjectUtils.isEmpty(guaranteesEntity.getGuaranteeGlobalAccount())
                ? null : guaranteesEntity.getGuaranteeGlobalAccount().getId();
        Long guaranteeParticularAccountId = ObjectUtils.isEmpty(guaranteesEntity.getGuaranteeParticularAccount())
                ? null : guaranteesEntity.getGuaranteeParticularAccount().getId();

        BigDecimal guaranteeIntegerTotal = BigDecimal.ZERO;
        if (CountryEnum.CHILE.getValue().equals(guaranteesEntity.getCountry().getId())) {
            if ((!ObjectUtils.isEmpty(participantId) ||
                    !ObjectUtils.isEmpty(custodianId)) &&
                    (!ObjectUtils.isEmpty(guaranteeGlobalAccountId) ||
                            !ObjectUtils.isEmpty(guaranteeParticularAccountId))) {
                if (!ObjectUtils.isEmpty(custodianId)) {
                    guaranteeIntegerTotal = guaranteesRepository.sumGuaranteeIntegerByFilters(
                            null,
                            custodianId,
                            null,
                            guaranteeGlobalAccountId,
                            guaranteeParticularAccountId);
                } else {
                    guaranteeIntegerTotal = guaranteesRepository.sumGuaranteeIntegerByFilters(
                            participantId,
                            null,
                            null,
                            guaranteeGlobalAccountId,
                            guaranteeParticularAccountId);
                }

            }
        } else if (CountryEnum.COLOMBIA.getValue().equals(guaranteesEntity.getCountry().getId()) ||
                CountryEnum.PERU.getValue().equals(guaranteesEntity.getCountry().getId())) {
            if ((!ObjectUtils.isEmpty(participantId) ||
                    !ObjectUtils.isEmpty(custodianId)) &&
                    (!ObjectUtils.isEmpty(guaranteeGlobalAccountId) ||
                            !ObjectUtils.isEmpty(guaranteeParticularAccountId)) &&
                    !ObjectUtils.isEmpty(investorId)) {
                if (!ObjectUtils.isEmpty(custodianId)) {
                    guaranteeIntegerTotal = guaranteesRepository.sumGuaranteeIntegerByFilters(
                            null,
                            custodianId,
                            investorId,
                            guaranteeGlobalAccountId,
                            guaranteeParticularAccountId);
                } else {
                    guaranteeIntegerTotal = guaranteesRepository.sumGuaranteeIntegerByFilters(
                            participantId,
                            null,
                            investorId,
                            guaranteeGlobalAccountId,
                            guaranteeParticularAccountId);
                }
            }
        }
        return guaranteeIntegerTotal;
    }

    private BigDecimal calculateGuaranteeTotalExigency(GuaranteesEntity guaranteesEntity) {
        Long participantId = ObjectUtils.isEmpty(guaranteesEntity.getParticipant()) ? null : guaranteesEntity.getParticipant().getId();
        Long custodianId = ObjectUtils.isEmpty(guaranteesEntity.getCustodian()) ? null : guaranteesEntity.getCustodian().getId();
        Long investorId = ObjectUtils.isEmpty(guaranteesEntity.getInvestor()) ? null : guaranteesEntity.getInvestor().getId();
        Long guaranteeGlobalAccountId = ObjectUtils.isEmpty(guaranteesEntity.getGuaranteeGlobalAccount())
                ? null : guaranteesEntity.getGuaranteeGlobalAccount().getId();
        Long guaranteeParticularAccountId = ObjectUtils.isEmpty(guaranteesEntity.getGuaranteeParticularAccount())
                ? null : guaranteesEntity.getGuaranteeParticularAccount().getId();
        List<Long> custodianTradeStatusIds = List.of(StatusTradeCustodianEnum.TRANSFER.getValue(),
                StatusTradeCustodianEnum.PRE_MATCH.getValue(), StatusTradeCustodianEnum.ADMITTED.getValue());

        BigDecimal guaranteeExigencyTotal = BigDecimal.ZERO;
        if (CountryEnum.CHILE.getValue().equals(guaranteesEntity.getCountry().getId())) {
            if ((!ObjectUtils.isEmpty(participantId) ||
                    !ObjectUtils.isEmpty(custodianId)) &&
                    (!ObjectUtils.isEmpty(guaranteeGlobalAccountId) ||
                            !ObjectUtils.isEmpty(guaranteeParticularAccountId))) {
                if (!ObjectUtils.isEmpty(custodianId)) {
                    guaranteeExigencyTotal = guaranteesRepository.sumGuaranteeExigencyByFilters(
                            null,
                            custodianId,
                            null,
                            guaranteeGlobalAccountId,
                            guaranteeParticularAccountId,
                            custodianTradeStatusIds);
                } else {
                    guaranteeExigencyTotal = guaranteesRepository.sumGuaranteeExigencyByFilters(
                            participantId,
                            null,
                            null,
                            guaranteeGlobalAccountId,
                            guaranteeParticularAccountId,
                            null);
                }
            }
        } else if (CountryEnum.COLOMBIA.getValue().equals(guaranteesEntity.getCountry().getId()) ||
                CountryEnum.PERU.getValue().equals(guaranteesEntity.getCountry().getId())) {
            if ((!ObjectUtils.isEmpty(participantId) ||
                    !ObjectUtils.isEmpty(custodianId)) &&
                    (!ObjectUtils.isEmpty(guaranteeGlobalAccountId) ||
                            !ObjectUtils.isEmpty(guaranteeParticularAccountId)) &&
                    !ObjectUtils.isEmpty(investorId)) {
                if (!ObjectUtils.isEmpty(custodianId)) {
                    guaranteeExigencyTotal = guaranteesRepository.sumGuaranteeExigencyByFilters(
                            null,
                            custodianId,
                            investorId,
                            guaranteeGlobalAccountId,
                            guaranteeParticularAccountId,
                            custodianTradeStatusIds);
                } else {
                    guaranteeExigencyTotal = guaranteesRepository.sumGuaranteeExigencyByFilters(
                            participantId,
                            null,
                            investorId,
                            guaranteeGlobalAccountId,
                            guaranteeParticularAccountId,
                            null);
                }
            }
        }
        return guaranteeExigencyTotal;
    }

    private BigDecimal calculateLimitGuaranteeTotal(GuaranteesEntity guaranteesEntity) {
        Long participantId = ObjectUtils.isEmpty(guaranteesEntity.getParticipant()) ? null : guaranteesEntity.getParticipant().getId();
        Long custodianId = ObjectUtils.isEmpty(guaranteesEntity.getCustodian()) ? null : guaranteesEntity.getCustodian().getId();
        Long investorId = ObjectUtils.isEmpty(guaranteesEntity.getInvestor()) ? null : guaranteesEntity.getInvestor().getId();
        Long guaranteeGlobalAccountId = ObjectUtils.isEmpty(guaranteesEntity.getGuaranteeGlobalAccount())
                ? null : guaranteesEntity.getGuaranteeGlobalAccount().getId();
        Long guaranteeParticularAccountId = ObjectUtils.isEmpty(guaranteesEntity.getGuaranteeParticularAccount())
                ? null : guaranteesEntity.getGuaranteeParticularAccount().getId();
        String marketId = ObjectUtils.isEmpty(guaranteesEntity.getIsinNumber().getMarket()) ?
                null : guaranteesEntity.getIsinNumber().getMarket().getId();

        BigDecimal limitGuaranteeTotal = BigDecimal.ZERO;
        if (CountryEnum.CHILE.getValue().equals(guaranteesEntity.getCountry().getId())) {
            if ((!ObjectUtils.isEmpty(participantId) ||
                    !ObjectUtils.isEmpty(custodianId)) &&
                    (!ObjectUtils.isEmpty(guaranteeGlobalAccountId) ||
                            !ObjectUtils.isEmpty(guaranteeParticularAccountId))) {
                if (!ObjectUtils.isEmpty(custodianId)) {
                    limitGuaranteeTotal = guaranteesRepository.sumGuaranteeLimitsByFilters(
                            null,
                            custodianId,
                            null,
                            guaranteeGlobalAccountId,
                            guaranteeParticularAccountId,
                            marketId);
                } else {
                    limitGuaranteeTotal = guaranteesRepository.sumGuaranteeLimitsByFilters(
                            participantId,
                            null,
                            null,
                            guaranteeGlobalAccountId,
                            guaranteeParticularAccountId,
                            marketId);
                }

            }
        } else if (CountryEnum.COLOMBIA.getValue().equals(guaranteesEntity.getCountry().getId()) ||
                CountryEnum.PERU.getValue().equals(guaranteesEntity.getCountry().getId())) {
            if ((!ObjectUtils.isEmpty(participantId) ||
                    !ObjectUtils.isEmpty(custodianId)) &&
                    (!ObjectUtils.isEmpty(guaranteeGlobalAccountId) ||
                            !ObjectUtils.isEmpty(guaranteeParticularAccountId)) &&
                    !ObjectUtils.isEmpty(investorId)) {
                if (!ObjectUtils.isEmpty(custodianId)) {
                    limitGuaranteeTotal = guaranteesRepository.sumGuaranteeLimitsByFilters(
                            null,
                            custodianId,
                            investorId,
                            guaranteeGlobalAccountId,
                            guaranteeParticularAccountId,
                            marketId);
                } else {
                    limitGuaranteeTotal = guaranteesRepository.sumGuaranteeLimitsByFilters(
                            participantId,
                            null,
                            investorId,
                            guaranteeGlobalAccountId,
                            guaranteeParticularAccountId,
                            marketId);
                }
            }
        }
        return limitGuaranteeTotal;
    }

    public PageResponseOutDto<GuaranteesOutDto> findPagedDataGuaranteesByFiltersDynamic(
            Pageable pageable,
            String fieldName,
            String fieldValue,
            String operation,
            Long countryId,
            Long participantId,
            Long investorId,
            Long accountTypeId,
            Long guaranteeGlobalAccountId,
            Long guaranteeParticularAccountId,
            Long guaranteeId,
            Long statusId) {

        if (Objects.requireNonNull(VersionApiEnum.fromValue(PropertiesContext.getVersion())) == VersionApiEnum.V1) {
            return findPagedDataGuaranteesByFiltersDynamicV1(pageable, fieldName, fieldValue, operation,
                    countryId, participantId, investorId, accountTypeId, guaranteeGlobalAccountId,
                    guaranteeParticularAccountId, guaranteeId, statusId);
        } else {
            throw new ServiceException(ErrorCode.VERSION_API_NOT_FOUND, HttpStatus.NOT_FOUND);
        }
    }

    public PageResponseOutDto<GuaranteesOutDto> findPagedDataGuaranteesByFiltersDynamicV1(
            Pageable pageable,
            String fieldName,
            String fieldValue,
            String operation,
            Long countryId,
            Long participantId,
            Long investorId,
            Long accountTypeId,
            Long guaranteeGlobalAccountId,
            Long guaranteeParticularAccountId,
            Long guaranteeId,
            Long statusId) {

        log.info("Searching guarantees with combined filters");

        SearchOperationEnum searchOperation = (operation != null) ? SearchOperationEnum.fromValue(operation) : null;

        if (operation != null && searchOperation == null) {
            log.warn("Invalid operation: {}", operation);
            throw new ServiceException(ErrorCode.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }

        Specification<GuaranteesEntity> spec = GuaranteesSpecificationFactory.createCombinedFilter(
                countryId, participantId, investorId, accountTypeId, guaranteeGlobalAccountId, guaranteeParticularAccountId,
                guaranteeId, statusId,
                fieldName, fieldValue, searchOperation);

        Page<GuaranteesEntity> pagedResult = guaranteesRepository.findAll(spec, pageable);

        return buildPageResponse(pagedResult, statusId);
    }

    private PageResponseOutDto<GuaranteesOutDto> buildPageResponse(Page<GuaranteesEntity> entities, Long
            statusId) {
        List<GuaranteesOutDto> guaranteesOutDtoList = getGuaranteesOutDtoList(entities.getContent(), statusId);

        return MapperPageUtil.pageToPageResponseOutDto(guaranteesOutDtoList, entities);
    }
}
