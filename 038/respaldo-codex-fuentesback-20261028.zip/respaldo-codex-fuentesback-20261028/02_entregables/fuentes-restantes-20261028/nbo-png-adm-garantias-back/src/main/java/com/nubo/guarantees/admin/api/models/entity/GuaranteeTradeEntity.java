package com.nubo.guarantees.admin.api.models.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "\"GUARANTEE_TRADE\"", schema = "\"NUANBODB\"")
public class GuaranteeTradeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "\"GURANTEE_TRADE_ID\"", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "\"TRADE_ID\"", nullable = false)
    private TradeEntity trade;

    @Column(name = "\"FRACTION\"", nullable = false)
    private Integer fraction;

    @ManyToOne
    @JoinColumn(name = "\"SIDE_ID\"", nullable = false)
    private SideEntity side;

    @ManyToOne
    @JoinColumn(name = "\"PARTICIPANT_ID\"")
    private ParticipantEntity participant;

    @ManyToOne
    @JoinColumn(name = "\"CUSTODIAN_ID\"")
    private ParticipantEntity custodian;

    @ManyToOne
    @JoinColumn(name = "\"INVESTOR_ID\"")
    private InvestorEntity investor;

    @ManyToOne
    @JoinColumn(name = "\"SECURITY_ID\"")
    private SecurityTitleEntity securityTitle;

    @ManyToOne
    @JoinColumn(name = "\"ISIN_NUMBER_ID\"")
    private IsinNumberEntity isinNumber;

    @ManyToOne
    @JoinColumn(name = "\"STATUS_ID\"")
    private StatusEntity status;

    @ManyToOne
    @JoinColumn(name = "\"GUARANTEE_ACCOUNT_TYPE_ID\"")
    private TypeEntity guaranteeAccountType;

    @ManyToOne
    @JoinColumn(name = "\"GUARANTEE_GLOBAL_ACCOUNT_ID\"")
    private GuaranteeGlobalAccountEntity guaranteeGlobalAccount;

    @ManyToOne
    @JoinColumn(name = "\"GUARANTEE_PARTICULAR_ACCOUNT_ID\"")
    private GuaranteeParticularAccountEntity guaranteeParticularAccount;

    @Column(name = "\"RISK_MODEL_PRICE\"", precision = 16, scale = 4)
    private BigDecimal riskModelPrice;

    @Column(name = "\"RISK_MODEL_PERCENTAGE\"", precision = 6, scale = 4)
    private BigDecimal riskModelPercentage;

    @Column(name = "\"ASSIGNED_QUANTITY\"", precision = 16, scale = 4)
    private BigDecimal assignedQuantity;

    @Column(name = "\"ASSIGNED_AMOUNT\"", precision = 16, scale = 4)
    private BigDecimal assignedAmount;

    @Column(name = "\"REQUIREMENT_AMOUNT\"", precision = 16, scale = 4)
    private BigDecimal requirementAmount;

    @ManyToOne
    @JoinColumn(name = "\"COUNTRY_ID\"", nullable = false)
    private CountryEntity country;

    @Column(name = "\"LAST_MODIFY_USER\"", length = 250, nullable = false)
    private String lastModifyUser;

    @Column(name = "\"LAST_MODIFY_APPLIC\"", length = 30, nullable = false)
    private String lastModifyApplication;

    @Column(name = "\"LAST_MODIFY_DATE\"", nullable = false)
    private LocalDateTime lastModifyDate;

    @Column(name = "\"LAST_MODIFY_IP\"", length = 30, nullable = false)
    private String lastModifyIp;

}
