package com.nubo.guarantees.admin.api.models.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.Arrays;
import java.util.Objects;

@Getter
@RequiredArgsConstructor
public enum StatusTradeCustodianEnum {

    TRANSFER(1071L),
    PRE_MATCH(1072L),
    ADMITTED(1073L);

    private final Long value;

    @JsonValue
    public Long getValue() {
        return value;
    }

    @JsonCreator
    public static StatusTradeCustodianEnum fromValue(Long value) {
        return Arrays.stream(StatusTradeCustodianEnum.values())
                .filter(status -> Objects.equals(status.value, value))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Unknown value: " + value));
    }

}
