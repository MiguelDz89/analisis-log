package com.nubo.guarantees.admin.api.models.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum ParticipantEnum {

    PARTICIPANT("participant"),
    CUSTODIAN("custodian");

    private final String value;
}

