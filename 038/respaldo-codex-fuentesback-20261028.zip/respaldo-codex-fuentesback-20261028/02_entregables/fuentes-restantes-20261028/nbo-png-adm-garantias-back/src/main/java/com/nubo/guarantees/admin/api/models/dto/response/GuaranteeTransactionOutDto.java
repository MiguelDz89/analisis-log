package com.nubo.guarantees.admin.api.models.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Response DTO for guarantee transaction details")
public class GuaranteeTransactionOutDto {

    @JsonProperty("guaranteesAccountId")
    @Schema(description = "ID of the guarantee account", example = "1")
    private Long guaranteesAccountId;

    @JsonProperty("guaranteesAccountDescription")
    @Schema(description = "Description of the guarantee account", example = "Cuenta Principal")
    private String guaranteesAccountDescription;

    @JsonProperty("specificAccount")
    @Schema(description = "Specific account identifier", example = "ACC-001")
    private String specificAccount;

    @JsonProperty("clearingDate")
    @Schema(description = "Clearing date", example = "2025-09-10")
    private LocalDate clearingDate;

    @JsonProperty("maturityDate")
    @Schema(description = "Maturity date", example = "2025-12-10")
    private LocalDate maturityDate;

    @JsonProperty("side")
    @Schema(description = "Side information")
    private SideDto side;

    @JsonProperty("assignedQuantity")
    @Schema(description = "Assigned quantity", example = "100.00")
    private BigDecimal assignedQuantity;

    @JsonProperty("currencyRisk")
    @Schema(description = "Currency risk", example = "0.15")
    private BigDecimal currencyRisk;

    @JsonProperty("assignedAmount")
    @Schema(description = "Assigned amount", example = "15000.75")
    private BigDecimal assignedAmount;

    @JsonProperty("guarantee")
    @Schema(description = "Guarantee information")
    private GuaranteeDto guarantee;

    @JsonProperty("trade")
    @Schema(description = "Trade information")
    private TradeDto trade;

    @JsonProperty("fraction")
    @Schema(description = "Fraction", example = "0.5")
    private BigDecimal fraction;

    @JsonProperty("transferBenefits")
    @Schema(description = "Transfer benefits flag", example = "true")
    private Boolean transferBenefits;

    @JsonProperty("balanceBlocking")
    @Schema(description = "Balance blocking flag", example = "false")
    private Boolean balanceBlocking;

    @JsonProperty("holdingSecurity")
    @Schema(description = "Holding security flag", example = "true")
    private Boolean holdingSecurity;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @Schema(description = "Side information")
    public static class SideDto {
        @JsonProperty("id")
        @Schema(description = "Side ID", example = "1")
        private Long id;

        @JsonProperty("description")
        @Schema(description = "Side description", example = "Compra")
        private String description;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @Schema(description = "Guarantee information")
    public static class GuaranteeDto {
        @JsonProperty("id")
        @Schema(description = "Guarantee ID", example = "123")
        private Long id;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @Schema(description = "Trade information")
    public static class TradeDto {
        @JsonProperty("id")
        @Schema(description = "Trade ID", example = "456")
        private Long id;
    }
}
