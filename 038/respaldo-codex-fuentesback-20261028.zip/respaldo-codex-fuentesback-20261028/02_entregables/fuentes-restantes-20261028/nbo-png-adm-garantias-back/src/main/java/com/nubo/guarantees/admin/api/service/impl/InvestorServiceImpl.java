package com.nubo.guarantees.admin.api.service.impl;

import java.util.List;
import java.util.Objects;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.nubo.guarantees.admin.api.application.properties.PropertiesContext;
import com.nubo.guarantees.admin.api.exception.ServiceException;
import com.nubo.guarantees.admin.api.exception.error.ErrorCode;
import com.nubo.guarantees.admin.api.helpers.MapperPageUtil;
import com.nubo.guarantees.admin.api.helpers.MapperUtil;
import com.nubo.guarantees.admin.api.models.dto.response.InvestorOutDto;
import com.nubo.guarantees.admin.api.models.dto.response.PageResponseOutDto;
import com.nubo.guarantees.admin.api.models.entity.GuaranteesEntity;
import com.nubo.guarantees.admin.api.models.entity.InvestorEntity;
import com.nubo.guarantees.admin.api.models.enums.VersionApiEnum;
import com.nubo.guarantees.admin.api.repository.InvestorRepository;
import com.nubo.guarantees.admin.api.service.InvestorService;

import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Subquery;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class InvestorServiceImpl implements InvestorService {

    private final InvestorRepository investorRepository;

    public PageResponseOutDto<InvestorOutDto> findByInvestor(
            String text, Pageable pageable) {
        if (Objects.requireNonNull(VersionApiEnum.fromValue(PropertiesContext.getVersion())) == VersionApiEnum.V1) {
            return findByInvestorV1(text, pageable);
        } else {
            throw new ServiceException(ErrorCode.VERSION_API_NOT_FOUND, HttpStatus.NOT_FOUND);
        }
    }

    private PageResponseOutDto<InvestorOutDto> findByInvestorV1(
            String text, Pageable pageable) {
        log.info("Start method findByInvestorV1");

        Page<InvestorEntity> investorEntityPage = investorRepository.findAll(
                specificationInvestor(text), pageable);

        List<InvestorOutDto> investorOutDtoList = investorEntityPage.getContent().stream()
                .map(MapperUtil::investorEntityToInvestorOutDto)
                .toList();

        log.info("End method findInvestorByIdentificationOrNameV1, investorOutDtoList -> {}", investorOutDtoList);

        return MapperPageUtil.pageToPageResponseOutDto(investorOutDtoList, investorEntityPage);
    }

    @Override
    public PageResponseOutDto<InvestorOutDto> findByInvestor(String text, int page, int size, String sort, String order, boolean all) {
        if (Objects.requireNonNull(VersionApiEnum.fromValue(PropertiesContext.getVersion())) == VersionApiEnum.V1) {
            return findByInvestorV1WithPagination(text, page, size, sort, order, all);
        } else {
            throw new ServiceException(ErrorCode.VERSION_API_NOT_FOUND, HttpStatus.NOT_FOUND);
        }
    }

    private PageResponseOutDto<InvestorOutDto> findByInvestorV1WithPagination(String text, int page, int size, String sort, String order, boolean all) {
        log.info("Start method findByInvestorV1WithPagination");

  
        Sort.Direction direction = "desc".equalsIgnoreCase(order) ? 
            Sort.Direction.DESC : 
            Sort.Direction.ASC;
        Sort sortObj = Sort.by(direction, sort != null ? sort : "id");

        Specification<InvestorEntity> spec = specificationInvestor(text);

        if (all) {
            List<InvestorEntity> allResults = investorRepository.findAll(spec, sortObj);
            List<InvestorOutDto> investorOutDtoList = allResults.stream()
                .map(MapperUtil::investorEntityToInvestorOutDto)
                .toList();
            return buildPageResponseInvestor(investorOutDtoList, 0, investorOutDtoList.size(), investorOutDtoList.size());
        } else {
            Pageable pageable = PageRequest.of(page, size, sortObj);
            Page<InvestorEntity> investorEntityPage = investorRepository.findAll(spec, pageable);
            List<InvestorOutDto> investorOutDtoList = investorEntityPage.getContent().stream()
                .map(MapperUtil::investorEntityToInvestorOutDto)
                .toList();
            return buildPageResponseInvestor(investorOutDtoList, page, size, (int) investorEntityPage.getTotalElements());
        }
    }
    
    

    private PageResponseOutDto<InvestorOutDto> buildPageResponseInvestor(List<InvestorOutDto> content, int page, int size, int totalElements) {
        Page<InvestorOutDto> investorPage = new PageImpl<>(content, 
            PageRequest.of(page, size), totalElements);
        return MapperPageUtil.pageToPageResponseOutDto(content, investorPage);
    }

    private Specification<InvestorEntity> specificationInvestor(String text) {
        return (root, query, criteriaBuilder) -> {
            if (text == null || text.trim().isEmpty()) {
                return criteriaBuilder.conjunction();
            }

            Subquery<Long> subquery = query.subquery(Long.class);
            Root<GuaranteesEntity> guaranteeRoot = subquery.from(GuaranteesEntity.class);

            subquery.select(guaranteeRoot.get("investor").get("id")).distinct(true);

            Predicate predicate = criteriaBuilder.or(
                    criteriaBuilder.like(
                            criteriaBuilder.lower(guaranteeRoot.get("investor").get("documentNumber")),
                            "%" + text.toLowerCase().trim() + "%"
                    ),
                    criteriaBuilder.like(
                            criteriaBuilder.lower(guaranteeRoot.get("investor").get("firstName")),
                            "%" + text.toLowerCase().trim() + "%"
                    ),
                    criteriaBuilder.like(
                            criteriaBuilder.lower(guaranteeRoot.get("investor").get("lastName")),
                            "%" + text.toLowerCase().trim() + "%"
                    )
            );

            subquery.where(predicate);

            return criteriaBuilder.in(root.get("id")).value(subquery);
        };
    }

}
