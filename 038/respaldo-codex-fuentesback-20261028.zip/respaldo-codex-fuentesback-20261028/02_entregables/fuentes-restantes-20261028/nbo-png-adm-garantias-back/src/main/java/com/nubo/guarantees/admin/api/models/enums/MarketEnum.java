package com.nubo.guarantees.admin.api.models.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum MarketEnum {

    RV("1"),
    DP("70"),
    PR("71"),
    IF("72"),
    EF("9");

    private final String id;

}
