package com.nubo.guarantees.admin.api.models.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@IdClass(GuaranteeValuationKey.class)
@Table(name = "\"GUARANTEE_VALUATION\"", schema = "\"NUANBODB\"")
public class GuaranteeValuationEntity {

    @Id
    @ManyToOne
    @JoinColumn(name = "\"GUARANTEE_ID\"", nullable = false)
    private GuaranteesEntity guarantee;

    @Id
    @Column(name = "\"VALUATION_DATE\"", nullable = false)
    private LocalDateTime valuationDate;

    @Column(name = "\"GUARANTEE_INTEGER\"", precision = 18, scale = 2, nullable = false)
    private BigDecimal guaranteeInteger;

    @Column(name = "\"LAST_MODIFY_USER\"", length = 250, nullable = false)
    private String lastModifyUser;

    @Column(name = "\"LAST_MODIFY_APPLIC\"", length = 250, nullable = false)
    private String lastModifyApplication;

    @Column(name = "\"LAST_MODIFY_DATE\"", nullable = false)
    private LocalDateTime lastModifyDate;

    @Column(name = "\"LAST_MODIFY_IP\"", length = 50, nullable = false)
    private String lastModifyIp;

}
