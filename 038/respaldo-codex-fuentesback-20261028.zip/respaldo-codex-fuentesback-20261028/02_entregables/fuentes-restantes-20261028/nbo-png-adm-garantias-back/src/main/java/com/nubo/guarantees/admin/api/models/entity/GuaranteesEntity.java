package com.nubo.guarantees.admin.api.models.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "\"GUARANTEE\"", schema = "\"NUANBODB\"")
public class GuaranteesEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "\"GUARANTEE_ID\"", nullable = false)
    private Long id;

    @Column(name = "\"REGISTRATION_DATE\"")
    private LocalDate registrationDate;

    @ManyToOne
    @JoinColumn(name = "\"PARTICIPANT_ID\"")
    private ParticipantEntity participant;

    @ManyToOne
    @JoinColumn(name = "\"CUSTODIAN_ID\"")
    private ParticipantEntity custodian;

    @Column(name = "\"FOUND_ID\"")
    private Integer foundId;

    @ManyToOne
    @JoinColumn(name = "\"INVESTOR_ID\"", nullable = false)
    private InvestorEntity investor;

    @ManyToOne
    @JoinColumn(name = "\"INVESTOR_ACCOUNT_ID\"")
    private InvestorAccountEntity investorAccount;

    @Column(name = "\"GUARANTEE_NUMBER\"")
    private String guaranteeNumber;

    @ManyToOne
    @JoinColumn(name = "\"STATUS_ID\"", nullable = false)
    private StatusEntity status;

    @ManyToOne
    @JoinColumn(name = "\"DEPOSITORY_ID\"", nullable = false)
    private DepositoryEntity depository;

    @ManyToOne
    @JoinColumn(name = "\"MARKET_ID\"")
    private MarketEntity market;

    @ManyToOne
    @JoinColumn(name = "\"COUNTRY_ID\"", nullable = false)
    private CountryEntity country;

    @ManyToOne
    @JoinColumn(name = "\"SECURITY_ID\"")
    private SecurityTitleEntity securityTitle;

    @Column(name = "\"GUARANTEE_PRICE\"", precision = 16, scale = 4)
    private BigDecimal guaranteePrice;

    @Column(name = "\"GUARANTEE_QUANTITY\"", precision = 18, scale = 4)
    private BigDecimal guaranteeQuantity;

    @Column(name = "\"GUARANTEE_VOLUME\"", precision = 18, scale = 4)
    private BigDecimal guaranteeVolume;

    @ManyToOne
    @JoinColumn(name = "\"GUARANTEE_TYPE_ID\"")
    private TypeEntity guaranteeType;

    @ManyToOne
    @JoinColumn(name = "\"ACCOUNT_TYPE_ID\"")
    private TypeEntity accountType;

    @ManyToOne
    @JoinColumn(name = "\"ISIN_NUMBER_ID\"")
    private IsinNumberEntity isinNumber;

    @ManyToOne
    @JoinColumn(name = "\"GUARANTEE_GLOBAL_ACCOUNT_ID\"")
    private GuaranteeGlobalAccountEntity guaranteeGlobalAccount;

    @ManyToOne
    @JoinColumn(name = "\"GUARANTEE_PARTICULAR_ACCOUNT_ID\"")
    private GuaranteeParticularAccountEntity guaranteeParticularAccount;

    @Column(name = "\"LAST_MODIFY_USER\"", nullable = false)
    private String lastModifyUser;

    @Column(name = "\"LAST_MODIFY_APPLIC\"", nullable = false)
    private String lastModifyApplication;

    @Column(name = "\"LAST_MODIFY_DATE\"", nullable = false)
    private LocalDateTime lastModifyDate;

    @Column(name = "\"LAST_MODIFY_IP\"", nullable = false)
    private String lastModifyIp;

    @Transient
    GuaranteeValuationEntity guaranteeValuation;
}
