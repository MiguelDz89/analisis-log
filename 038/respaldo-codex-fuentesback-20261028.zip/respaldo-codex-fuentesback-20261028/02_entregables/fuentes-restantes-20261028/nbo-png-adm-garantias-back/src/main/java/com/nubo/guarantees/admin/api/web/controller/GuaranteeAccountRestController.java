package com.nubo.guarantees.admin.api.web.controller;

import com.nubo.guarantees.admin.api.models.dto.response.GuaranteeAccountOutDto;
import com.nubo.guarantees.admin.api.models.dto.response.PageResponseOutDto;
import com.nubo.guarantees.admin.api.models.dto.response.TypeOutDto;
import com.nubo.guarantees.admin.api.service.GuaranteeAccountService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Tag(name = "Guarantee Account")
@RestController
@RequestMapping("/{version}/guarantee-account")
@RequiredArgsConstructor
public class GuaranteeAccountRestController {

    private final GuaranteeAccountService guaranteeAccountService;

    @Operation(summary = "Find type account guarantee", description = "Find type account guarantee")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully Response",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = TypeOutDto[].class)))})
    @GetMapping("/type")
    public ResponseEntity<List<TypeOutDto>> findTypeAccountGuarantees() {
        return ResponseEntity.ok(guaranteeAccountService.findTypeAccountGuarantees());
    }

    @Operation(summary = "Find all guarantees account", description = "Find all guarantees account")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Successfully Response",
            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = GuaranteeAccountOutDto[].class)))})
    @GetMapping("/search")
    public ResponseEntity<PageResponseOutDto<GuaranteeAccountOutDto>> findAllGuaranteesAccount(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sort,
            @RequestParam(defaultValue = "asc") String order,
            @RequestParam(defaultValue = "false") boolean all,
            @Parameter(example = "1") Long accountTypeId,
            @Parameter(example = "001") @RequestParam(required = false) String text
    ) {
        return ResponseEntity.ok(guaranteeAccountService.findAllGuaranteesAccount(accountTypeId, text, page, size, sort, order, all));
    }

}
