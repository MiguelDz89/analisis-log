package com.nubo.guarantees.admin.api.web.controller;

import com.nubo.guarantees.admin.api.models.dto.response.CountryOutDto;
import com.nubo.guarantees.admin.api.service.CountryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Tag(name = "Country")
@RequestMapping("/{version}/country")
@RestController
@RequiredArgsConstructor
public class CountryRestController {

    private final CountryService countryService;

    @Operation(summary = "Find all countries", description = "Find all countries")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Successfully Response",
            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = CountryOutDto.class)))})
    @GetMapping
    public ResponseEntity<List<CountryOutDto>> findCountries() {
        return ResponseEntity.ok(countryService.findCountries());
    }

}
