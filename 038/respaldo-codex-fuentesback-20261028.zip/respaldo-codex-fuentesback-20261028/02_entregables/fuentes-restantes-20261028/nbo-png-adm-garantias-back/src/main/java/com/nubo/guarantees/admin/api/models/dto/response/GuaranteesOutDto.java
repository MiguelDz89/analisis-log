package com.nubo.guarantees.admin.api.models.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.ALWAYS)
public class GuaranteesOutDto {

    private Long id;

    private CountryOutDto country;

    private ParticipantOutDto participant;

    private ParticipantOutDto custodian;

    private InvestorOutDto investor;

    private TypeOutDto guaranteeType;

    private TypeOutDto accountType;

    private String guaranteeAccountDescription;

    private BigDecimal guaranteeIntegerTotal;

    private BigDecimal guaranteeExigencyTotal;

    private BigDecimal position;

    private StatusOutDto status;

    private GuaranteeGlobalAccountOutDto guaranteeGlobalAccount;

    private GuaranteeParticularAccountOutDto guaranteeParticularAccount;

    private BigDecimal limitRV;

    private BigDecimal limitDP;

    private BigDecimal limitPR;

    private BigDecimal limitEF;

    private BigDecimal limitIF;

}
