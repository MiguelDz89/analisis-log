package com.nubo.risk.model.load.api.models.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum NotificationProfileEnum {
    
    ADMIN_PROFILE(1L),
    SUPERVISOR_PROFILE(2L);
    
    private final Long profileId;
}