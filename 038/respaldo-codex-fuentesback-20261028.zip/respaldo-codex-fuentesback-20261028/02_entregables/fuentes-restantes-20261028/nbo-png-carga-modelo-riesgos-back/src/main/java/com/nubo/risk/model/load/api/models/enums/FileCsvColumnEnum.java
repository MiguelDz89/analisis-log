package com.nubo.risk.model.load.api.models.enums;

import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

@Getter
public enum FileCsvColumnEnum {
    DATE("fecha", "date"),
    MNEMONIC("nemotecnico", "mnemonic"),
    ISIN("isin", "isin"),
    MARKET("Mercado", "market"),
    PRICE("Precio", "price"),
    CURRENCY("Moneda", "currency"),
    COUNTRY("Pais", "country"),
    ADMISSIBILITY("Admisibilidad", "admissibility"),
    CURRENCY_RISK("Riesgo Moneda", "generalRisk"),
    GENERAL_RISK("Riesgo General", "currencyRisk"),
    REGISTER_COUNT("Cantidad registros", "");

    private final String csvHeader;
    private final String dtoField;

    FileCsvColumnEnum(String csvHeader, String dtoField) {
        this.csvHeader = csvHeader;
        this.dtoField = dtoField;
    }

    public String getCsvHeader() {
        return csvHeader;
    }

    public String getDtoField() {
        return dtoField;
    }

    public static Map<String, String> toColumnMapping() {
        Map<String, String> map = new HashMap<>();
        for (FileCsvColumnEnum column : values()) {
            map.put(column.getCsvHeader(), column.getDtoField());
        }
        return map;
    }
}
