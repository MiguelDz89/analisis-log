package com.nubo.risk.model.load.api.client.kafka.producer.service;

import com.nubo.risk.model.load.api.client.kafka.producer.dto.request.RiskModelInDto;

public interface KafkaNuboProducer {

    void sendMessageRiskModelLoad(RiskModelInDto riskModelOutDto);

}
