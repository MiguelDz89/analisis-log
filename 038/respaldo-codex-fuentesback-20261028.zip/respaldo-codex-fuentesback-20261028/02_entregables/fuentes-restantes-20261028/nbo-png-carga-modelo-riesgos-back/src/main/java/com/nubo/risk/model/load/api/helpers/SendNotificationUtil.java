package com.nubo.risk.model.load.api.helpers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.nubo.risk.model.load.api.application.properties.PropertiesConfig;
import com.nubo.risk.model.load.api.client.kafka.producer.service.impl.KafkaNuboProducerImpl;
import com.nubo.risk.model.load.api.models.dto.request.NotificationRequestDto;
import com.nubo.risk.model.load.api.models.enums.NotificationMessageEnum;
import com.nubo.risk.model.load.api.models.enums.NotificationTypeEnum;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Log4j2
@Component
@RequiredArgsConstructor
public class SendNotificationUtil {
    
    private final ObjectMapper objectMapper;
    private final PropertiesConfig propertiesConfig;
    
    @Autowired(required = false)
    private KafkaNuboProducerImpl kafkaNuboAdapter;
    
    public void sendNotification(NotificationTypeEnum notificationType, NotificationMessageEnum notificationMessage, Long scheduleExtensionId, List<Long> userIds) {
        if (kafkaNuboAdapter != null) {
            log.info("Enviando notificación tipo: {} - mensaje: {} - scheduleExtensionId: {} - userIds: {}", 
                    notificationType.getDescription(), notificationMessage.getDescription(), scheduleExtensionId, userIds);
            try {
                ObjectMapper mapper = new ObjectMapper();
                ObjectNode metadataNode = mapper.createObjectNode();
                if (scheduleExtensionId != null) {
                    metadataNode.put("id", scheduleExtensionId.toString());
                }
                
                NotificationRequestDto notification = NotificationRequestDto.builder()
                        .notificacionId(notificationMessage.getCode().longValue())
                        .tipoNotificacion(notificationType.getDescription())
                        .eventType(propertiesConfig.getKafkaNuboNotificationEventType())
                        .modulo(propertiesConfig.getKafkaNuboNotificationModule())
                        .usuariosIds(userIds != null ? userIds : List.of())
                        .timestamp(
                                java.time.OffsetDateTime.now(java.time.ZoneOffset.UTC)
                                        .withNano(0)
                                        .toString())
                        .metadata(metadataNode)
                        .build();
                        
                kafkaNuboAdapter.sendMessageNotification(objectMapper.writeValueAsString(notification));
                log.info("Notificación enviada exitosamente para usuarios: {}", userIds);
                
            } catch (Exception e) {
                log.error("Error enviando notificación a Kafka", e);
            }
        } else {
            log.info("KafkaNuboAdapter no disponible, omitiendo envío de notificación");
        }
    }
}
