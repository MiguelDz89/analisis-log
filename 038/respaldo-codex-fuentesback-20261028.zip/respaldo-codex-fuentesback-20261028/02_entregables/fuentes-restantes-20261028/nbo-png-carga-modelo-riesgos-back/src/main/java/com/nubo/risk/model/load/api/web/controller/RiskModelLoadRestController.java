package com.nubo.risk.model.load.api.web.controller;

import com.nubo.risk.model.load.api.client.risk.model.loader.models.dto.response.InstrumentFinancialOutDto;
import com.nubo.risk.model.load.api.models.dto.response.RiskModelExternalOutDto;
import com.nubo.risk.model.load.api.models.dto.response.RiskModelLoadOutDto;
import com.nubo.risk.model.load.api.service.RiskModelApiLoadService;
import com.nubo.risk.model.load.api.service.RiskModelAutomaticService;
import com.nubo.risk.model.load.api.service.RiskModelLoadService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.util.List;

@Tag(name = "Risk Model Load")
@RestController
@RequestMapping("/{version}/risk-model")
@RequiredArgsConstructor
public class RiskModelLoadRestController {

    private final RiskModelLoadService riskModelLoadService;
    private final RiskModelAutomaticService riskModelAutomaticService;
    private final RiskModelApiLoadService riskModelApiLoadService;

    @Operation(summary = "Allow to load the risk model", description = "Allow to load the risk model")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Successfully Response",
            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = RiskModelLoadOutDto.class)))})
    @PostMapping("/load")
    public ResponseEntity<RiskModelLoadOutDto> loadManualRiskModel(@RequestParam("file") MultipartFile file) {
        return ResponseEntity.ok(riskModelLoadService.loadManualRiskModel(file));
    }


    @PostMapping("/instrumentos")
    public ResponseEntity<String> getFinancialInstrument() {
        riskModelAutomaticService.getFinancialInstrument();
        return ResponseEntity.ok("Importación ejecutada correctamente.");
    }


    @Operation(summary = "API Load ", description = "API Load ")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully Response", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = RiskModelExternalOutDto[].class)))
    })
    @GetMapping("/load-api")
    public ResponseEntity<List<InstrumentFinancialOutDto>> findAllTrades() {

        return ResponseEntity.ok(riskModelApiLoadService.findAllApis());
    }

}
