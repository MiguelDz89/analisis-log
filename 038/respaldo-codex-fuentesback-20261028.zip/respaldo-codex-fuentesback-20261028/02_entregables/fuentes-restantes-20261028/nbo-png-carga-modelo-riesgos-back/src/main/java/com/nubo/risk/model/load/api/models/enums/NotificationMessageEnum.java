package com.nubo.risk.model.load.api.models.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum NotificationMessageEnum {
    
    UPLOAD_RISK_MODEL_STAR(31, "Upload risk model to STAR"),
    UPLOAD_RISK_MODEL_SUCCESS(32, "Upload risk model successful"),
    UPLOAD_RISK_MODEL_FAILED(33, "Upload risk model failed");

    
    private final Integer code;
    private final String description;
}