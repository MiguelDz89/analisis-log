package com.nubo.risk.model.load.api.client.risk.model.loader.service;

import com.nubo.risk.model.load.api.client.risk.model.loader.models.dto.response.InstrumentFinancialOutDto;

import java.util.List;

public interface RiskModelLoadFastApiService {

    List<InstrumentFinancialOutDto> getInstrumentsFastAPI();

}
