package com.nubo.risk.model.load.api.service.impl;

import com.nubo.risk.model.load.api.application.properties.PropertiesContext;
import com.nubo.risk.model.load.api.application.util.CsvValidatorUtils;
import com.nubo.risk.model.load.api.application.util.NonEmptyLineFilter;
import com.nubo.risk.model.load.api.client.kafka.producer.dto.request.RiskModelInDto;
import com.nubo.risk.model.load.api.client.kafka.producer.service.KafkaNuboProducer;
import com.nubo.risk.model.load.api.exception.ServiceException;
import com.nubo.risk.model.load.api.exception.error.ErrorCode;
import com.nubo.risk.model.load.api.exception.handler.CsvFileExceptionHandler;
import com.nubo.risk.model.load.api.helpers.SendNotificationUtil;
import com.nubo.risk.model.load.api.models.dto.request.RiskModelParameterCsvInDto;
import com.nubo.risk.model.load.api.models.dto.response.RiskModelLoadOutDto;
import com.nubo.risk.model.load.api.models.entity.TypeEntity;
import com.nubo.risk.model.load.api.models.enums.ErrorLoadEnum;
import com.nubo.risk.model.load.api.models.enums.FileCsvColumnEnum;
import com.nubo.risk.model.load.api.models.enums.NotificationMessageEnum;
import com.nubo.risk.model.load.api.models.enums.NotificationProfileEnum;
import com.nubo.risk.model.load.api.models.enums.NotificationTypeEnum;
import com.nubo.risk.model.load.api.models.enums.TypeEnum;
import com.nubo.risk.model.load.api.models.enums.VersionApiEnum;
import com.nubo.risk.model.load.api.repository.TypeRepository;
import com.nubo.risk.model.load.api.repository.UserNuboRepository;
import com.nubo.risk.model.load.api.service.RiskModelLoadService;
import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.HeaderColumnNameTranslateMappingStrategy;
import com.opencsv.enums.CSVReaderNullFieldIndicator;
import com.opencsv.exceptions.CsvValidationException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.IntStream;

@Service
@RequiredArgsConstructor
@Slf4j
public class RiskModelLoadServiceImpl implements RiskModelLoadService {

    private final TypeRepository typeRepository;
    private final KafkaNuboProducer kafkaNuboProducer;
    private final UserNuboRepository userNuboRepository;
    private final SendNotificationUtil sendNotificationUtil;

    public RiskModelLoadOutDto loadManualRiskModel(MultipartFile file) {
        if (Objects.requireNonNull(VersionApiEnum.fromValue(PropertiesContext.getVersion())) == VersionApiEnum.V1) {
            return loadManualRiskModelV1(file);
        } else {
            throw new ServiceException(ErrorCode.VERSION_API_NOT_FOUND, HttpStatus.NOT_FOUND);
        }
    }

    private RiskModelLoadOutDto loadManualRiskModelV1(MultipartFile file) {
        log.info("Start method loadManualRiskModelV1, file -> {}", file.getOriginalFilename());

        List<Long> userIds = getUserIdsByProfiles(NotificationProfileEnum.values());
        sendNotificationUtil.sendNotification(NotificationTypeEnum.INFORMATIVE, NotificationMessageEnum.UPLOAD_RISK_MODEL_STAR, null, userIds);

        validateFileIsCsv(file);

        try {
            List<RiskModelParameterCsvInDto> dataFile = parseAndValidateCsv(file);

            RiskModelInDto riskModelInDto = RiskModelInDto.builder()
                    .riskModels(new ArrayList<>(dataFile))
                    .loadType(getManualType().getDescription())
                    .build();

            sendKafkaMessageRiskModelManual(riskModelInDto);

            sendNotificationUtil.sendNotification(NotificationTypeEnum.INFORMATIVE, NotificationMessageEnum.UPLOAD_RISK_MODEL_SUCCESS, null, userIds);

            log.debug("End method loadManualRiskModelV1, size dataFile -> {}", dataFile.size());

            return RiskModelLoadOutDto.builder()
                    .isLoaded(true)
                    .uploadDate(LocalDate.now())
                    .build();

        } catch (IOException e) {
            log.error("IOException reading CSV file: {}", e.getMessage());
            sendNotificationUtil.sendNotification(NotificationTypeEnum.ERROR, NotificationMessageEnum.UPLOAD_RISK_MODEL_FAILED, null, userIds);
            throw new CsvFileExceptionHandler(ErrorLoadEnum.INVALID_READ.getValue(), HttpStatus.BAD_REQUEST,
                    ErrorCode.INVALID_CSV_STRUCTURE);
        } catch (Exception e) {
            log.error("Processing error CSV: {}", e.getMessage());
            sendNotificationUtil.sendNotification(NotificationTypeEnum.ERROR, NotificationMessageEnum.UPLOAD_RISK_MODEL_FAILED, null, userIds);
            throw new CsvFileExceptionHandler(ErrorLoadEnum.INVALID_FORMAT.getValue(),
                    HttpStatus.BAD_REQUEST, ErrorCode.INVALID_CSV_STRUCTURE);
        }
    }

    private void validateFileIsCsv(MultipartFile file) {
        String filename = file.getOriginalFilename();
        String contentType = file.getContentType();

        if (file.isEmpty()) {
            throw new CsvFileExceptionHandler(ErrorLoadEnum.EMPTY_FILE.getValue(),
                    HttpStatus.BAD_REQUEST, ErrorCode.ERROR_INVALID_FILE);
        }

        if (filename == null || !filename.toLowerCase().endsWith(".csv")) {
            throw new CsvFileExceptionHandler(ErrorLoadEnum.INVALID_EXTENSION.getValue(),
                    HttpStatus.UNSUPPORTED_MEDIA_TYPE,
                    ErrorCode.ERROR_UNSUPPORTED_MEDIA_TYPE);
        }

        if (contentType == null || !contentType.equals("text/csv")) {
            throw new CsvFileExceptionHandler(ErrorLoadEnum.INVALID_CONTENT.getValue(),
                    HttpStatus.UNSUPPORTED_MEDIA_TYPE,
                    ErrorCode.ERROR_UNSUPPORTED_MEDIA_TYPE);
        }
    }

    private List<RiskModelParameterCsvInDto> parseAndValidateCsv(MultipartFile file) throws IOException, CsvValidationException {
        InputStream inputStream = file.getInputStream();
        BufferedReader reader = new BufferedReader(CsvValidatorUtils.getReaderAdaptive(inputStream));
        reader.mark(10 * 1024);
        String header = reader.readLine();
        reader.reset();
        String separator = CsvValidatorUtils.detectSeparator(header);

        CSVParser parser = new CSVParserBuilder()
                .withSeparator(separator.charAt(0))
                .build();
        CSVReader headerReader = new CSVReaderBuilder(reader)
                .withCSVParser(parser)
                .build();
        String[] headerLine = headerReader.readNext();
        if (!validateHeaderLine(headerLine)) {
            throw new CsvFileExceptionHandler(ErrorLoadEnum.INVALID_FORMAT.getValue(),
                    HttpStatus.BAD_REQUEST, ErrorCode.INVALID_CSV_STRUCTURE);
        }
        reader.reset();

        CSVReader dataReader = new CSVReaderBuilder(reader)
                .withCSVParser(parser)
                .build();
        HeaderColumnNameTranslateMappingStrategy<RiskModelParameterCsvInDto> strategy = new HeaderColumnNameTranslateMappingStrategy<>();
        strategy.setType(RiskModelParameterCsvInDto.class);
        strategy.setColumnMapping(FileCsvColumnEnum.toColumnMapping());

        CsvToBean<RiskModelParameterCsvInDto> csvToBean = new CsvToBeanBuilder<RiskModelParameterCsvInDto>(dataReader)
                .withMappingStrategy(strategy)
                .withIgnoreLeadingWhiteSpace(true)
                .withFieldAsNull(CSVReaderNullFieldIndicator.EMPTY_SEPARATORS)
                .withFilter(new NonEmptyLineFilter())
                .build();

        return csvToBean.parse();

    }

    private boolean validateHeaderLine(String[] headerLine) {
        if (!headerLine[0].trim().equalsIgnoreCase(FileCsvColumnEnum.DATE.getCsvHeader())) {
            return false;
        }
        List<String> expectedHeaders = Arrays.stream(FileCsvColumnEnum.values())
                .map(FileCsvColumnEnum::getCsvHeader)
                .filter(h -> h != null && !h.isBlank())
                .toList();

        int start = IntStream.range(0, headerLine.length)
                .filter(i -> headerLine[i] != null && !headerLine[i].trim().isEmpty())
                .findFirst()
                .orElse(headerLine.length);

        int end = IntStream.iterate(headerLine.length - 1, i -> i - 1)
                .limit(headerLine.length)
                .filter(i -> headerLine[i] != null && !headerLine[i].trim().isEmpty())
                .findFirst()
                .orElse(-1);

        if (end < start) {
            log.debug("Completely empty CSV header or no valid columns. Original: {}", Arrays.toString(headerLine));
            return false;
        }

        List<String> actualHeaders = Arrays.stream(headerLine, start, end + 1)
                .map(String::trim)
                .toList();
        List<String> expectedLower = expectedHeaders.stream()
                .map(String::toLowerCase)
                .toList();
        List<String> actualLower = actualHeaders.stream()
                .map(String::toLowerCase)
                .toList();

        if (!expectedLower.equals(actualLower)) {
            log.debug("CSV header validation failed. Expected: {}, but found: {}", expectedHeaders, actualHeaders);
            return false;
        }
        return true;
    }

    private TypeEntity getManualType() {
        return typeRepository.findById(TypeEnum.LOAD_MANUAL.getId())
                .orElseThrow(() -> new ServiceException(ErrorCode.MANUAL_TYPE_NOT_FOUND, HttpStatus.NOT_FOUND));
    }

    private void sendKafkaMessageRiskModelManual(
            RiskModelInDto riskModelInDto) {
        log.debug("Start method sendKafkaMessageRiskModelManualLoad, riskModelInDto -> {}", riskModelInDto);
        try {
            kafkaNuboProducer.sendMessageRiskModelLoad(riskModelInDto);
        } catch (Exception ex) {
            log.error("Error sendKafkaMessageRiskModelManualLoad -> {}", ex.getMessage());
        }
        log.info("End method sendKafkaMessageRiskModelManualLoad");
    }

    private List<Long> getUserIdsByProfiles(NotificationProfileEnum... profiles) {
        if (profiles.length == 1) {
            return userNuboRepository.findAllIdsByProfileId(profiles[0].getProfileId());
        }
        List<Long> profileIds = List.of(profiles).stream()
                .map(NotificationProfileEnum::getProfileId)
                .toList();
        return userNuboRepository.findAllIdsByProfileIds(profileIds);
    }

}