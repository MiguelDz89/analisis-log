package com.nubo.risk.model.load.api.models.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum TypeEnum {

    LOAD_MANUAL(700),
    LOAD_AUTOMATIC(701);

    private final Integer id;

}
