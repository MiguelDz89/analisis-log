package com.nubo.risk.model.load.api.exception.handler;

import com.nubo.risk.model.load.api.exception.error.ErrorCode;
import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public class CsvFileExceptionHandler extends RuntimeException {
    private final HttpStatus status;
    private final ErrorCode errorCode;

    public CsvFileExceptionHandler(String message, HttpStatus status, ErrorCode errorCode) {
        super(message);
        this.status = status;
        this.errorCode = errorCode;
    }

}
