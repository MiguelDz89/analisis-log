package com.nubo.risk.model.load.api.repository;

import com.nubo.risk.model.load.api.models.entity.TypeEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TypeRepository extends JpaRepository<TypeEntity, Integer> {
}
