package com.nubo.risk.model.load.api.service;

public interface RiskModelInterface {
}
