package com.nubo.risk.model.load.api.models.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum ErrorLoadEnum {

    EMPTY_FILE("El archivo se encuentra vacío"),
    INVALID_EXTENSION("El archivo debe tener extensión .csv"),
    INVALID_CONTENT("Tipo de contenido no válido. Se espera text/csv"),
    INVALID_FORMAT("Error en formato/cabecera del archivo CSV"),
    INVALID_READ("Error leyendo el archivo CSV");


    private final String value;
}
