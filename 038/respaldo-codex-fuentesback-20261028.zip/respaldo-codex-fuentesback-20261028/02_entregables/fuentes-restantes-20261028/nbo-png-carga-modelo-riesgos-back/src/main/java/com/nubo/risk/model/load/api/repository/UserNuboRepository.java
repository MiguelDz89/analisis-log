package com.nubo.risk.model.load.api.repository;


import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nubo.risk.model.load.api.models.entity.UserNuboEntity;
import com.nubo.risk.model.load.api.models.enums.UserGroupEnum;
import com.nubo.risk.model.load.api.models.enums.UserTypeEnum;

public interface UserNuboRepository extends JpaRepository<UserNuboEntity, Long>
{

    @Query("SELECT u FROM UserNuboEntity u " +
            "WHERE u.userName = :userName")
    Optional<UserNuboEntity> findByUserName(String userName);

    @Query("SELECT u.email FROM UserNuboEntity u " +
            "WHERE u.userGroup = :userGroup")
    List<String> findAllEmailsByUserGroup(UserGroupEnum userGroup);

    @Query("SELECT u.email FROM UserNuboEntity u " +
            "WHERE u.userGroup = :userGroup AND u.userType = :userType")
    List<String> findAllEmailsByUserGroupAndUserType(UserGroupEnum userGroup, UserTypeEnum userType);

    @Query("SELECT u.id FROM UserNuboEntity u WHERE u.profileId = :profileId")
    List<Long> findAllIdsByProfileId(Long profileId);

    @Query("SELECT u.id FROM UserNuboEntity u WHERE u.profileId IN :profileIds")
    List<Long> findAllIdsByProfileIds(List<Long> profileIds);
}
