package com.nubo.risk.model.load.api.service;

import com.nubo.risk.model.load.api.models.dto.response.RiskModelLoadOutDto;

public interface RiskModelAutomaticService {
    RiskModelLoadOutDto getFinancialInstrument();
}
