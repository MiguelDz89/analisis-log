package com.nubo.risk.model.load.api.service.impl;

import com.nubo.risk.model.load.api.application.properties.PropertiesContext;
import com.nubo.risk.model.load.api.client.risk.model.loader.models.dto.response.InstrumentFinancialOutDto;
import com.nubo.risk.model.load.api.exception.ServiceException;
import com.nubo.risk.model.load.api.exception.error.ErrorCode;
import com.nubo.risk.model.load.api.models.dto.response.RiskModelExternalOutDto;
import com.nubo.risk.model.load.api.models.enums.VersionApiEnum;
import com.nubo.risk.model.load.api.service.RiskModelApiLoadService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Objects;
@Service
@RequiredArgsConstructor
@Slf4j
public class RiskModelApiLoadServiceImpl implements RiskModelApiLoadService {


    @Override
    @Transactional
    public List<InstrumentFinancialOutDto> findAllApis()
    {
        if (Objects.requireNonNull(VersionApiEnum.fromValue(PropertiesContext.getVersion())) == VersionApiEnum.V1)
        {
            return findAllApisV1();
        }
        else
        {
            throw new ServiceException(ErrorCode.VERSION_API_NOT_FOUND, HttpStatus.NOT_FOUND);
        }
    }

    private List<InstrumentFinancialOutDto> findAllApisV1()
    {
        log.info("Start method findAllApisV1");

        List<InstrumentFinancialOutDto> result = List.of(
                InstrumentFinancialOutDto.builder()
                        .date("20/11/2025")
                        .mnemonic("CDTAVVILLA08")
                        .isin("PRU012345028")
                        .market("RV")
                        .price("123.43761")
                        .currency("COP")
                        .country("CO")
                        .admissibility("Y")
                        .currencyRisk("2")
                        .generalRisk("3")
                        .quantity("1")
                        .build(),
                InstrumentFinancialOutDto.builder()
                        .date("20/11/2025")
                        .mnemonic("CDTAVVILLA09")
                        .isin("PRU012345029")
                        .market("RV")
                        .price("345.43761")
                        .currency("COP")
                        .country("CO")
                        .admissibility("Y")
                        .currencyRisk("2")
                        .generalRisk("3")
                        .quantity("2")
                        .build(),
                InstrumentFinancialOutDto.builder()
                        .date("20/11/2025")
                        .mnemonic("CDTAVVILLA10")
                        .isin("PRU012345030")
                        .market("RV")
                        .price("567.43761")
                        .currency("COP")
                        .country("CO")
                        .admissibility("Y")
                        .currencyRisk("2")
                        .generalRisk("3")
                        .quantity("3")
                        .build()
        );

        log.info("End method findAllApisV1, number of records: {}", result.size());
        return result;
    }
}
