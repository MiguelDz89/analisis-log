package com.nubo.risk.model.load.api.client.kafka.producer.service.impl;

import com.nubo.risk.model.load.api.application.properties.PropertiesConfig;
import com.nubo.risk.model.load.api.application.properties.PropertiesContext;
import com.nubo.risk.model.load.api.application.util.ApplicationUtils;
import com.nubo.risk.model.load.api.client.kafka.producer.dto.request.RiskModelInDto;
import com.nubo.risk.model.load.api.client.kafka.producer.service.KafkaNuboProducer;
import com.nubo.risk.model.load.api.exception.ServiceException;
import com.nubo.risk.model.load.api.exception.error.ErrorCode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;

@Service
@RequiredArgsConstructor
@Slf4j
public class KafkaNuboProducerImpl implements KafkaNuboProducer {

    private final PropertiesConfig propertiesConfig;
    private final KafkaTemplate<String, String> kafkaNuboTemplate;

    public void sendMessageRiskModelLoad(RiskModelInDto riskModelInDto) {
        log.debug("Start method sendKafkaMessageRiskModelLoad, riskModelInDto -> {}", riskModelInDto);

        riskModelInDto.setClientUser(PropertiesContext.getClientUser());
        riskModelInDto.setClientIp(PropertiesContext.getClientIp());

        String topic = propertiesConfig.getKafkaNuboTopicNameRiskModelLoad();
        String jsonString = ApplicationUtils.convertObjectToJson(riskModelInDto, true);
        CompletableFuture<SendResult<String, String>> future = kafkaNuboTemplate.send(topic, jsonString).toCompletableFuture();

        future.thenAccept(result -> log.info("Send message Kafka Risk Model -- Topic: {} -- offset: {} -- json: {} ",
                        topic, result.getRecordMetadata().offset(), jsonString))
                .exceptionally(ex -> {
                    throw new ServiceException(ErrorCode.ERROR_KAFKA_PRODUCER_NUBO, ex);
                });
    }

    public void sendMessageNotification(String message) {
        if(message != null){
            String topic = propertiesConfig.getKafkaNuboNotificationTopic();
            CompletableFuture<SendResult<String, String>> future = kafkaNuboTemplate.send(topic, message).toCompletableFuture();

            future.thenAccept(result -> log.info("Send message -- Topic: {} -- offset: {} -- json: {} ",
                            topic, result.getRecordMetadata().offset(), message) )
                    .exceptionally(ex -> {
                        throw new ServiceException(ErrorCode.ERROR_KAFKA_PRODUCER_NUBO, ex);
                    });
        }
    }

}
