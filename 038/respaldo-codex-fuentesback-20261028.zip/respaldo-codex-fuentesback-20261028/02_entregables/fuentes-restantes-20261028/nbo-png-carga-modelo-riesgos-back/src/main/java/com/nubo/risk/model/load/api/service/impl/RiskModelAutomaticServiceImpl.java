package com.nubo.risk.model.load.api.service.impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.nubo.risk.model.load.api.models.dto.response.RiskModelExternalOutDto;
import com.nubo.risk.model.load.api.service.RiskModelApiLoadService;
import org.springframework.http.HttpStatus;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import com.nubo.risk.model.load.api.application.properties.PropertiesContext;
import com.nubo.risk.model.load.api.client.kafka.producer.dto.request.RiskModelInDto;
import com.nubo.risk.model.load.api.client.kafka.producer.service.KafkaNuboProducer;
import com.nubo.risk.model.load.api.client.risk.model.loader.models.dto.response.InstrumentFinancialOutDto;
import com.nubo.risk.model.load.api.client.risk.model.loader.service.RiskModelLoadFastApiService;
import com.nubo.risk.model.load.api.exception.ServiceException;
import com.nubo.risk.model.load.api.exception.error.ErrorCode;
import com.nubo.risk.model.load.api.helpers.SendNotificationUtil;
import com.nubo.risk.model.load.api.models.dto.response.RiskModelLoadOutDto;
import com.nubo.risk.model.load.api.models.entity.TypeEntity;
import com.nubo.risk.model.load.api.models.enums.NotificationMessageEnum;
import com.nubo.risk.model.load.api.models.enums.NotificationProfileEnum;
import com.nubo.risk.model.load.api.models.enums.NotificationTypeEnum;
import com.nubo.risk.model.load.api.models.enums.TypeEnum;
import com.nubo.risk.model.load.api.models.enums.VersionApiEnum;
import com.nubo.risk.model.load.api.repository.TypeRepository;
import com.nubo.risk.model.load.api.repository.UserNuboRepository;
import com.nubo.risk.model.load.api.service.RiskModelAutomaticService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class RiskModelAutomaticServiceImpl implements RiskModelAutomaticService {

    private final TypeRepository typeRepository;
    private final RiskModelLoadFastApiService riskModelLoadFastApiService;
    private final KafkaNuboProducer kafkaNuboProducer;
    private final UserNuboRepository userNuboRepository;
    private final SendNotificationUtil sendNotificationUtil;
    private final RiskModelApiLoadService riskModelApiLoadService;

    @Retryable(value = {RuntimeException.class}, maxAttempts = 3, backoff = @Backoff(delay = 3000))
    public RiskModelLoadOutDto getFinancialInstrument() {
        if (Objects.requireNonNull(VersionApiEnum.fromValue(PropertiesContext.getVersion())) == VersionApiEnum.V1) {
            return getFinancialInstrumentV1();
        } else {
            throw new ServiceException(ErrorCode.VERSION_API_NOT_FOUND, HttpStatus.NOT_FOUND);
        }
    }

    private RiskModelLoadOutDto getFinancialInstrumentV1() {
        log.info("Start method getFinancialInstrumentV1  -> ");

        List<Long> userIds = getUserIdsByProfiles(NotificationProfileEnum.values());
        sendNotificationUtil.sendNotification(NotificationTypeEnum.INFORMATIVE, NotificationMessageEnum.UPLOAD_RISK_MODEL_STAR, null, userIds);

        RiskModelLoadOutDto riskModelLoadOutDto = RiskModelLoadOutDto.builder()
                .isLoaded(false)
                .build();

        try {
            List<InstrumentFinancialOutDto> listInstrument = riskModelApiLoadService.findAllApis();

            //List<InstrumentFinancialOutDto> listInstrument = riskModelLoadFastApiService.getInstrumentsFastAPI();

            if (!listInstrument.isEmpty()) {

                RiskModelInDto riskModelInDto = RiskModelInDto.builder()
                        .riskModels(new ArrayList<>(listInstrument))
                        .loadType(getAutomaticType().getDescription())
                        .build();
                log.info("before sendKafkaMessageRiskModelAutomatic");
                sendKafkaMessageRiskModelAutomatic(riskModelInDto);

                riskModelLoadOutDto.setLoaded(true);
                riskModelLoadOutDto.setUploadDate(LocalDate.now());

                log.info("before sendNotification");
                sendNotificationUtil.sendNotification(NotificationTypeEnum.INFORMATIVE, NotificationMessageEnum.UPLOAD_RISK_MODEL_SUCCESS, null, userIds);

            }

            log.info("End method getFinancialInstrumentV1, listInstrument -> {}", listInstrument.size());

            return riskModelLoadOutDto;

        } catch (Exception e) {
            log.error("Error processing automatic risk model load: {}", e.getMessage());
            sendNotificationUtil.sendNotification(NotificationTypeEnum.ERROR, NotificationMessageEnum.UPLOAD_RISK_MODEL_FAILED, null, userIds);
            throw e;
        }
    }

    private TypeEntity getAutomaticType() {
        return typeRepository.findById(TypeEnum.LOAD_AUTOMATIC.getId())
                .orElseThrow(() -> new ServiceException(ErrorCode.AUTOMATIC_TYPE_NOT_FOUND, HttpStatus.NOT_FOUND));
    }

    private void sendKafkaMessageRiskModelAutomatic(
            RiskModelInDto riskModelInDto) {
        log.debug("Start method sendKafkaMessageRiskModelAutomatic, riskModelInDto -> {}", riskModelInDto);
        try {
            kafkaNuboProducer.sendMessageRiskModelLoad(riskModelInDto);
        } catch (Exception ex) {
            log.error("Error sendKafkaMessageRiskModelAutomatic -> {}", ex.getMessage());
        }
        log.info("End method sendKafkaMessageRiskModelAutomatic");
    }

    private List<Long> getUserIdsByProfiles(NotificationProfileEnum... profiles) {
        if (profiles.length == 1) {
            return userNuboRepository.findAllIdsByProfileId(profiles[0].getProfileId());
        }
        List<Long> profileIds = List.of(profiles).stream()
                .map(NotificationProfileEnum::getProfileId)
                .toList();
        return userNuboRepository.findAllIdsByProfileIds(profileIds);
    }

}
