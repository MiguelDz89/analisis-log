package com.nubo.risk.model.load.api.models.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.Arrays;

@Getter
@RequiredArgsConstructor
public enum UserGroupEnum
{

    NA("N/A"),
    USER_GROUP("USER_GROUP"),
    ADMIN_GROUP("ADMIN_GROUP");

    private final String value;

    @JsonValue
    public String getValue()
    {
        return value;
    }

    @JsonCreator
    public static UserGroupEnum fromValue(String value)
    {
        return Arrays.stream(UserGroupEnum.values())
                .filter(status -> status.value.equalsIgnoreCase(value))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Unknown value: " + value));
    }

    @Converter(autoApply = true)
    public static class UserGroupEnumConverter implements AttributeConverter<UserGroupEnum, String>
    {

        @Override
        public String convertToDatabaseColumn(UserGroupEnum status)
        {
            return status != null ? status.getValue() : null;
        }

        @Override
        public UserGroupEnum convertToEntityAttribute(String dbData)
        {
            return dbData != null ? UserGroupEnum.fromValue(dbData) : null;
        }
    }

}
