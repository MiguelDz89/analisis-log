package com.nubo.risk.model.load.api.models.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RiskModelLoadOutDto {

    private LocalDate uploadDate;

    private boolean isLoaded;

}
