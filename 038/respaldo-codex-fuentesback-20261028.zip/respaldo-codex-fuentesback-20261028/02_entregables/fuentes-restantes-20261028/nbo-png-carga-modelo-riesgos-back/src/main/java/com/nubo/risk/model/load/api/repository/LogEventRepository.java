package com.nubo.risk.model.load.api.repository;

import com.nubo.risk.model.load.api.models.entity.LogEventEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LogEventRepository extends JpaRepository<LogEventEntity, Long> {
}
