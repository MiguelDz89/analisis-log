package com.nubo.risk.model.load.api.service;

import com.nubo.risk.model.load.api.models.dto.response.RiskModelLoadOutDto;
import org.springframework.web.multipart.MultipartFile;

public interface RiskModelLoadService {
    RiskModelLoadOutDto loadManualRiskModel(MultipartFile file);
}
