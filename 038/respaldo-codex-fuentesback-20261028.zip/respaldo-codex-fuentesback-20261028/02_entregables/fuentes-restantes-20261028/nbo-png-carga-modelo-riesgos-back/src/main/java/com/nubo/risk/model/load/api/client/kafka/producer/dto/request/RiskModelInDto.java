package com.nubo.risk.model.load.api.client.kafka.producer.dto.request;

import com.nubo.risk.model.load.api.models.dto.response.RiskModelExternalOutDto;
import com.nubo.risk.model.load.api.service.RiskModelInterface;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RiskModelInDto {

    private String clientIp;

    private String clientUser;

    private String loadType;

    private List<RiskModelInterface> riskModels;

    private List<RiskModelExternalOutDto> riskModelExternal;
}
