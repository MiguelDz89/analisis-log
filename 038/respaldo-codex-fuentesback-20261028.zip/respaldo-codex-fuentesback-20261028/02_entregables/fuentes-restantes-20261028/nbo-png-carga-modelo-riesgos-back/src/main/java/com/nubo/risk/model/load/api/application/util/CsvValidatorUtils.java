package com.nubo.risk.model.load.api.application.util;

import lombok.extern.slf4j.Slf4j;
import org.apache.tika.parser.txt.CharsetDetector;
import org.apache.tika.parser.txt.CharsetMatch;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Map;
import java.util.regex.Pattern;

@Slf4j
public class CsvValidatorUtils {

    private CsvValidatorUtils() {
    }

    private static final int DETECTION_BUFFER_SIZE = 4096;

    public static InputStreamReader getReaderAdaptive(InputStream is) throws IOException {
        BufferedInputStream bis = new BufferedInputStream(is);
        bis.mark(DETECTION_BUFFER_SIZE);

        CharsetDetector detector = new CharsetDetector();
        detector.setText(bis);
        CharsetMatch match = detector.detect();
        bis.reset();
        Charset charset = (match != null) ? Charset.forName(match.getName()) : StandardCharsets.UTF_8;

        bis.mark(3);
        byte[] bom = new byte[3];
        int bomRead = bis.read(bom);
        if (!(bomRead == 3 &&
                (bom[0] & 0xFF) == 0xEF &&
                (bom[1] & 0xFF) == 0xBB &&
                (bom[2] & 0xFF) == 0xBF)) {
            bis.reset();
        }

        return new InputStreamReader(bis, charset);
    }

    public static String detectSeparator(String headerLine) {
        String[] possibleSeparators = {",", ";", "\t", "|"};
        return Arrays.stream(possibleSeparators)
                .map(sep -> Map.entry(sep, countOccurrences(headerLine, sep)))
                .max(Comparator.comparingInt(Map.Entry::getValue))
                .orElse(Map.entry(",", 0))
                .getKey();
    }

    private static int countOccurrences(String line, String separator) {
        return line.split(Pattern.quote(separator), -1).length - 1;
    }
}
