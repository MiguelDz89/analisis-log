package com.nubo.risk.model.load.api.client.risk.model.loader.service.impl;


import com.nubo.risk.model.load.api.application.properties.PropertiesConfig;
import com.nubo.risk.model.load.api.client.risk.model.loader.models.dto.response.InstrumentFinancialOutDto;
import com.nubo.risk.model.load.api.client.risk.model.loader.service.RiskModelLoadFastApiService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
@Slf4j
public class RiskModelLoadFastApiServiceImpl implements RiskModelLoadFastApiService {

    private final PropertiesConfig propertiesConfig;

    private static final String SLASH = "/";
    private static final String AUTHORIZATION = "Authorization";
    private static final String BEARER = "Bearer";
    private static final String PATH_OPERATION_SPECIAL_RULES = "operation-special-business-rules";
    private final RestTemplate restTemplate = new RestTemplate();
    private static final String BASE_URL = "http://api-modelo-riesgos-service";


    public List<InstrumentFinancialOutDto> getInstrumentsFastAPI() {
        String url = BASE_URL + "/instrumentos";
        ResponseEntity<InstrumentFinancialOutDto[]> response =
                restTemplate.getForEntity(url, InstrumentFinancialOutDto[].class);
        return Arrays.asList(Objects.requireNonNull(response.getBody()));
    }
}
