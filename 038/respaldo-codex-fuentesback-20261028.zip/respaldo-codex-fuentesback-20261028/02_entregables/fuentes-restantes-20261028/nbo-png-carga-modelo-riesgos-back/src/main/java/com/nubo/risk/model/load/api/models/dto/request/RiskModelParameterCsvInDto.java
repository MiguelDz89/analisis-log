package com.nubo.risk.model.load.api.models.dto.request;

import com.nubo.risk.model.load.api.service.RiskModelInterface;
import com.opencsv.bean.CsvBindByName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RiskModelParameterCsvInDto implements RiskModelInterface {

    @CsvBindByName(column = "fecha", required = true)
    private String date;

    @CsvBindByName(column = "nemotecnico", required = true)
    private String mnemonic;

    @CsvBindByName(column = "isin", required = true)
    private String isin;

    @CsvBindByName(column = "Precio", required = true)
    private String price;

    @CsvBindByName(column = "Mercado", required = true)
    private String market;

    @CsvBindByName(column = "Moneda", required = true)
    private String currency;

    @CsvBindByName(column = "Pais", required = true)
    private String country;

    @CsvBindByName(column = "Admisibilidad", required = true)
    private String admissibility;

    @CsvBindByName(column = "Riesgo General", required = true)
    private String generalRisk;

    @CsvBindByName(column = "Riesgo Moneda", required = true)
    private String currencyRisk;
}
