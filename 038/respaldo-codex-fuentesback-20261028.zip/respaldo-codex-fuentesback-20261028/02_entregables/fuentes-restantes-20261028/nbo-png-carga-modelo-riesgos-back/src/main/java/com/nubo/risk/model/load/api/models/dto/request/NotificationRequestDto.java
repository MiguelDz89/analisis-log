package com.nubo.risk.model.load.api.models.dto.request;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NotificationRequestDto
{

    String eventType;

    Long notificacionId;

    List<Long> usuariosIds;

    String modulo;

    List<String> perfiles;

    String tipoNotificacion;

    JsonNode metadata;

    String timestamp;

}
