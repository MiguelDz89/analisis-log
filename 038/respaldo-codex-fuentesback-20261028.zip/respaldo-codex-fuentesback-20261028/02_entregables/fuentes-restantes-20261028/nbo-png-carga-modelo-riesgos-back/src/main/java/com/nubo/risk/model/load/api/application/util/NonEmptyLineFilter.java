package com.nubo.risk.model.load.api.application.util;

import com.opencsv.bean.CsvToBeanFilter;

public class NonEmptyLineFilter implements CsvToBeanFilter {
    @Override
    public boolean allowLine(String[] line) {
        for (String cell : line) {
            if (cell != null && !cell.trim().isEmpty()) {
                return true;
            }
        }
        return false;
    }
}
