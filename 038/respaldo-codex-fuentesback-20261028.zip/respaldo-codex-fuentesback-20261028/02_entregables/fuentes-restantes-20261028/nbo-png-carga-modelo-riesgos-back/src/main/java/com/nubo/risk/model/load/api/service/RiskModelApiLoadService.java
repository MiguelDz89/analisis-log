package com.nubo.risk.model.load.api.service;

import com.nubo.risk.model.load.api.client.risk.model.loader.models.dto.response.InstrumentFinancialOutDto;
import com.nubo.risk.model.load.api.models.dto.response.RiskModelExternalOutDto;

import java.util.List;

public interface RiskModelApiLoadService {
     List<InstrumentFinancialOutDto> findAllApis();
}
