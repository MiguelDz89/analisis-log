package com.nubo.risk.model.load.api.models.dto.response;

import com.nubo.risk.model.load.api.service.RiskModelInterface;
import com.opencsv.bean.CsvBindByName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RiskModelExternalOutDto  {

    private String date;

    private String mnemonic;

    private String isin;

    private String market;

    private String price;

    private String currency;

    private String country;

    private String admissibility;

    private String generalRisk;

    private String currencyRisk;
    
    private String quantity;
}
