package com.nubo.risk.model.load.api.client.risk.model.loader.models.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.nubo.risk.model.load.api.service.RiskModelInterface;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.ALWAYS)
public class InstrumentFinancialOutDto implements RiskModelInterface {

    @NotNull
    @JsonProperty("Fecha")
    private String date;

    @JsonProperty("Nemotecnico")
    private String mnemonic;

    @JsonProperty("ISIN")
    private String isin;

    @JsonProperty("Precio")
    private String price;

    @JsonProperty("Mercado")
    private String market;

    @JsonProperty("Moneda")
    private String currency;

    @JsonProperty("Pais")
    private String country;

    @JsonProperty("Admisibilidad")
    private String admissibility;

    @JsonProperty("Riesgo_General")
    private String generalRisk;

    @JsonProperty("Riesgo_Moneda")
    private String currencyRisk;

    @JsonProperty("Cantidad_registros")
    private String quantity;
}
