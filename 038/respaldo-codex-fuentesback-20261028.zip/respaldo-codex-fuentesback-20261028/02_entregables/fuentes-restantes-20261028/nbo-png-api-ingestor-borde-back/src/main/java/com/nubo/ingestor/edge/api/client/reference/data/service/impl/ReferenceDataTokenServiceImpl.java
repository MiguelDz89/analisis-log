package com.nubo.ingestor.edge.api.client.reference.data.service.impl;

import com.nubo.ingestor.edge.api.application.properties.PropertiesConfig;
import com.nubo.ingestor.edge.api.application.util.RestClientUtils;
import com.nubo.ingestor.edge.api.client.reference.data.models.dto.response.AccessTokenOutDto;
import com.nubo.ingestor.edge.api.client.reference.data.service.ReferenceDataTokenService;
import com.nubo.ingestor.edge.api.exception.ClientException;
import com.nubo.ingestor.edge.api.exception.error.ErrorCode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;

import java.net.URI;
import java.time.Instant;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class ReferenceDataTokenServiceImpl implements ReferenceDataTokenService {

    private static final long TOKEN_EXPIRATION_SAFETY_SECONDS = 30L;

    private final RestClientUtils restClientUtils;
    private final PropertiesConfig propertiesConfig;

    private volatile String cachedAccessToken;
    private volatile Instant accessTokenExpiresAt = Instant.EPOCH;

    @Override
    public String getValidAccessToken() {
        if (StringUtils.hasText(cachedAccessToken) && Instant.now().isBefore(accessTokenExpiresAt)) {
            return cachedAccessToken;
        }

        synchronized (this) {
            if (StringUtils.hasText(cachedAccessToken) && Instant.now().isBefore(accessTokenExpiresAt)) {
                return cachedAccessToken;
            }

            AccessTokenOutDto tokenResponse = requestToken();

            if (tokenResponse == null || !StringUtils.hasText(tokenResponse.getAccessToken())) {
                throw new ClientException(ErrorCode.CLIENT_REFERENCE_DATA_ERROR, HttpStatus.BAD_GATEWAY);
            }

            long expiresIn = tokenResponse.getExpiresIn() != null ? tokenResponse.getExpiresIn() : 60L;
            long cachedTtl = Math.max(1L, expiresIn - TOKEN_EXPIRATION_SAFETY_SECONDS);

            cachedAccessToken = tokenResponse.getAccessToken();
            accessTokenExpiresAt = Instant.now().plusSeconds(cachedTtl);

            log.info("Access token refreshed for reference-data client. Expires in {} seconds", expiresIn);
            return cachedAccessToken;
        }
    }

    private AccessTokenOutDto requestToken() {
        String tokenUrl = requireAuthValue(propertiesConfig.getReferenceDataAuthTokenUrl(), "client.reference-data.auth.token-url");
        String grantType = propertiesConfig.getReferenceDataAuthGrantType();
        String clientId = requireAuthValue(propertiesConfig.getReferenceDataAuthClientId(), "client.reference-data.auth.client-id");
        String clientSecret = requireAuthValue(propertiesConfig.getReferenceDataAuthClientSecret(), "client.reference-data.auth.client-secret");
        String username = requireAuthValue(propertiesConfig.getReferenceDataAuthUsername(), "client.reference-data.auth.username");
        String password = requireAuthValue(propertiesConfig.getReferenceDataAuthPassword(), "client.reference-data.auth.password");

        MultiValueMap<String, String> body = new LinkedMultiValueMap<>();
        body.add("grant_type", StringUtils.hasText(grantType) ? grantType : "password");
        body.add("client_id", clientId);
        body.add("client_secret", clientSecret);
        body.add("username", username);
        body.add("password", password);

        try {
            ResponseEntity<AccessTokenOutDto> tokenResponse = restClientUtils.requestWithResponseObject(
                    URI.create(tokenUrl),
                    HttpMethod.POST,
                    getTokenRequestHeaders(),
                    body,
                    AccessTokenOutDto.class);

            return tokenResponse.getBody();
        } catch (Exception ex) {
            throw new ClientException(ErrorCode.CLIENT_REFERENCE_DATA_ERROR, HttpStatus.BAD_GATEWAY, ex);
        }
    }

    private HttpHeaders getTokenRequestHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.setAccept(List.of(MediaType.APPLICATION_JSON));
        return headers;
    }

    private String requireAuthValue(String value, String propertyName) {
        if (!StringUtils.hasText(value)) {
            throw new ClientException(ErrorCode.CLIENT_REFERENCE_DATA_ERROR, HttpStatus.INTERNAL_SERVER_ERROR,
                    new IllegalArgumentException("Missing required property: " + propertyName));
        }
        return value;
    }
}