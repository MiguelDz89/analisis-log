package com.nubo.ingestor.edge.api.client.kafka.producer;

import com.nubo.ingestor.edge.api.application.properties.PropertiesConfig;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

@Component
@RequiredArgsConstructor
@Slf4j
public class KafkaNuboAdapter {

    private final PropertiesConfig propertiesConfig;
    private final KafkaTemplate<String, String> kafkaNuboTemplate;

    public void sendMessage(String message) {
        sendSingleAsync(resolveTopic(), message);
    }

    public CompletableFuture<Long> sendMessagesBatch(List<String> messages) {
        if (messages == null || messages.isEmpty()) {
            return CompletableFuture.completedFuture(0L);
        }

        String topic = resolveTopic();
        List<CompletableFuture<SendResult<String, String>>> futures = new ArrayList<>(messages.size());
        for (String message : messages) {
            futures.add(sendSingleAsync(topic, message));
        }

        return CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]))
                .thenApply(ignored -> (long) messages.size());
    }

    private CompletableFuture<SendResult<String, String>> sendSingleAsync(String topic, String message) {
        CompletableFuture<SendResult<String, String>> future = kafkaNuboTemplate.send(topic, message)
                .toCompletableFuture();

        future.thenAccept(result -> {
            if (log.isDebugEnabled()) {
                log.debug("Kafka ack topic={} partition={} offset={}",
                        topic,
                        result.getRecordMetadata().partition(),
                        result.getRecordMetadata().offset());
            }
        }).exceptionally(ex -> {
            log.error("Error sending message to Kafka topic {}: {}", topic, ex.getMessage());
            return null;
        });

        return future;
    }

    private String resolveTopic() {
        return propertiesConfig.getKafkaNuboTopicName();
    }
}
