package com.nubo.ingestor.edge.api.application.util;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ContentAsStringListDeserializer extends JsonDeserializer<List<String>> {

    @Override
    public List<String> deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        List<String> list = new ArrayList<>();
        JsonNode node = p.getCodec().readTree(p);
        for (JsonNode element : node) {
            list.add(element.toString());
        }
        return list;
    }
}
