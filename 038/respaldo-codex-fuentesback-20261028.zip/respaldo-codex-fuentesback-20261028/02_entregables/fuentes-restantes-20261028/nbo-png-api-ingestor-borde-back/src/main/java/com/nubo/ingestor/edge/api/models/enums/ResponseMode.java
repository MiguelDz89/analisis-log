package com.nubo.ingestor.edge.api.models.enums;

public enum ResponseMode {
    PAGE,
    ARRAY
}
