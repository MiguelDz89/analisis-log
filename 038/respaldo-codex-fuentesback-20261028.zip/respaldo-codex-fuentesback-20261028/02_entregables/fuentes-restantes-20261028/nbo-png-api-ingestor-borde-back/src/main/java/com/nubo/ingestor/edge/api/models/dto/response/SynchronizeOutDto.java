package com.nubo.ingestor.edge.api.models.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SynchronizeOutDto {

    private LocalDateTime processingStartTime;

    private LocalDateTime processingEndTime;

    private Long totalProcessed;

}
