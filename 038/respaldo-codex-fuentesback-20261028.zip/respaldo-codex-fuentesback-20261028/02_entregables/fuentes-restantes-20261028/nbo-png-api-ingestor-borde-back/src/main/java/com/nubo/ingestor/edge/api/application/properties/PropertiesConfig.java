package com.nubo.ingestor.edge.api.application.properties;

import com.nubo.ingestor.edge.api.models.enums.ResponseMode;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Getter
public class PropertiesConfig {

    @Value("${spring.application.name}")
    private String apiName;

    @Value("${kafka.nubo.bootstrap-servers}")
    private String kafkaNuboBootstrapServers;

    @Value("${kafka.nubo.producer.topic-name}")
    private String kafkaNuboTopicName;

    @Value("${kafka.nubo.producer.acks:all}")
    private String kafkaNuboProducerAcks;

    @Value("${kafka.nubo.producer.compression-type:snappy}")
    private String kafkaNuboProducerCompressionType;

    @Value("${kafka.nubo.producer.batch-size:65536}")
    private Integer kafkaNuboProducerBatchSize;

    @Value("${kafka.nubo.producer.linger-ms:20}")
    private Integer kafkaNuboProducerLingerMs;

    @Value("${kafka.nubo.producer.max-in-flight-requests-per-connection:5}")
    private Integer kafkaNuboProducerMaxInFlightRequestsPerConnection;

    @Value("${kafka.nubo.producer.delivery-timeout-ms:120000}")
    private Integer kafkaNuboProducerDeliveryTimeoutMs;

    @Value("${kafka.nubo.group-id}")
    private String kafkaNuboGroupId;

    @Value("${kafka.nubo.sasl.mechanism}")
    private String kafkaNuboSaslMechanism;

    @Value("${kafka.nubo.sasl.jaas.config}")
    private String kafkaNuboSaslJaasConfig;

    @Value("${kafka.nubo.security.protocol}")
    private String kafkaNuboSecurityProtocol;

    @Value("${kafka.nubo.auto-offset-reset}")
    private String kafkaNuboAutoOffsetReset;

    @Value("${kafka.nubo.retries}")
    private Integer kafkaNuboRetries;

    @Value("${client.reference-data.url}")
    private String referenceDataUrl;

    @Value("${client.reference-data.complement}")
    private String complementUrl;

    @Value("${client.reference-data.response-mode:PAGE}")
    private ResponseMode responseMode;

    @Value("${client.reference-data.auth.enabled:false}")
    private boolean referenceDataAuthEnabled;

    @Value("${client.reference-data.auth.token-url:}")
    private String referenceDataAuthTokenUrl;

    @Value("${client.reference-data.auth.grant-type:password}")
    private String referenceDataAuthGrantType;

    @Value("${client.reference-data.auth.client-id:}")
    private String referenceDataAuthClientId;

    @Value("${client.reference-data.auth.client-secret:}")
    private String referenceDataAuthClientSecret;

    @Value("${client.reference-data.auth.username:}")
    private String referenceDataAuthUsername;

    @Value("${client.reference-data.auth.password:}")
    private String referenceDataAuthPassword;

    @Value("${performance.sync.default-page-size:500}")
    private Integer syncDefaultPageSize;

    @Value("${performance.sync.page-concurrency:4}")
    private Integer syncPageConcurrency;

    @Value("${performance.sync.publish-timeout-seconds:180}")
    private Integer syncPublishTimeoutSeconds;

    @Value("${performance.sync.startup-enabled:true}")
    private boolean syncStartupEnabled;

}
