package com.nubo.ingestor.edge.api.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

import org.springframework.http.HttpStatus;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import com.nubo.ingestor.edge.api.application.properties.PropertiesConfig;
import com.nubo.ingestor.edge.api.application.properties.PropertiesContext;
import com.nubo.ingestor.edge.api.client.kafka.producer.KafkaNuboAdapter;
import com.nubo.ingestor.edge.api.client.reference.data.models.dto.response.DataReferenceOutDto;
import com.nubo.ingestor.edge.api.client.reference.data.models.dto.response.PageMetadataOutDto;
import com.nubo.ingestor.edge.api.client.reference.data.service.ClientReferenceDataService;
import com.nubo.ingestor.edge.api.exception.ServiceException;
import com.nubo.ingestor.edge.api.exception.error.ErrorCode;
import com.nubo.ingestor.edge.api.models.dto.response.SynchronizeOutDto;
import com.nubo.ingestor.edge.api.models.enums.VersionApiEnum;
import com.nubo.ingestor.edge.api.service.SynchronizationService;

import io.micrometer.core.instrument.MeterRegistry;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class SynchronizationServiceImpl implements SynchronizationService {

    private final ClientReferenceDataService clientReferenceDataService;
    private final KafkaNuboAdapter kafkaNuboAdapter;
    private final PropertiesConfig propertiesConfig;
    @Qualifier("synchronizationTaskExecutor")
    private final Executor synchronizationTaskExecutor;
    private final MeterRegistry meterRegistry;

    @PostConstruct
    private void initSynchronizeDataReference() {
        if (!propertiesConfig.isSyncStartupEnabled()) {
            log.info("Skipping startup synchronization because performance.sync.startup-enabled=false");
            return;
        }

        try {
            LocalDateTime startDateTime = LocalDateTime.now();
            DataReferenceOutDto data = clientReferenceDataService
                    .getExternalInformation(propertiesConfig.getSyncDefaultPageSize(), 0);
            long totalProcessed = sendMessages(data.getContent(), 0);
            log.info("{}", SynchronizeOutDto.builder()
                    .processingStartTime(startDateTime)
                    .processingEndTime(LocalDateTime.now())
                    .totalProcessed(totalProcessed)
                    .build());
        } catch (Exception e) {
            log.error("Error PostConstruct -> {}", e.getMessage());
        }
    }

    @Override
    public SynchronizeOutDto synchronizeDataReference(Integer size) {
        if (Objects.requireNonNull(VersionApiEnum.fromValue(PropertiesContext.getVersion())) == VersionApiEnum.V1) {
            return synchronizeDataReferenceV1(size);
        } else {
            throw new ServiceException(ErrorCode.VERSION_API_NOT_FOUND, HttpStatus.NOT_FOUND);
        }
    }

    private SynchronizeOutDto synchronizeDataReferenceV1(Integer pageSize) {
        log.info("Start method synchronizeDataReferenceV1");

        LocalDateTime startDateTime = LocalDateTime.now();
        StopWatch stopWatch = new StopWatch("synchronizeDataReferenceV1");
        stopWatch.start("sync_total");

        long totalProcessed = 0L;
        int requestedPageSize = pageSize != null ? pageSize : propertiesConfig.getSyncDefaultPageSize();

        DataReferenceOutDto firstPage = clientReferenceDataService.getExternalInformation(requestedPageSize, 0);
        totalProcessed += sendMessages(firstPage.getContent(), 0);

        PageMetadataOutDto pageMetadata = firstPage.getPage();
        if (pageMetadata != null && pageMetadata.getTotalPages() != null) {
            int totalPages = pageMetadata.getTotalPages();
            totalProcessed += processRemainingPages(requestedPageSize, totalPages);
            if (log.isInfoEnabled()) {
                log.info("Synchronization pages processed: {}", totalPages);
            }
        }

        stopWatch.stop();
        meterRegistry.timer("ingestor.sync.total.time").record(stopWatch.getTotalTimeNanos(), TimeUnit.NANOSECONDS);
        meterRegistry.counter("ingestor.sync.records.processed").increment(totalProcessed);

        log.info("End method synchronizeDataReferenceV1");
        return SynchronizeOutDto.builder()
                .processingStartTime(startDateTime)
                .processingEndTime(LocalDateTime.now())
                .totalProcessed(totalProcessed)
                .build();
    }

    private long processRemainingPages(int pageSize, int totalPages) {
        int pageConcurrency = Math.max(1, propertiesConfig.getSyncPageConcurrency());
        long totalProcessed = 0L;

        for (int startPage = 1; startPage < totalPages; startPage += pageConcurrency) {
            int endPageExclusive = Math.min(startPage + pageConcurrency, totalPages);
            List<CompletableFuture<Long>> chunk = new ArrayList<>(endPageExclusive - startPage);

            for (int currentPage = startPage; currentPage < endPageExclusive; currentPage++) {
                final int page = currentPage;
                chunk.add(CompletableFuture.supplyAsync(
                                () -> clientReferenceDataService.getExternalInformation(pageSize, page),
                                synchronizationTaskExecutor)
                        .thenApply(data -> sendMessages(data.getContent(), page)));
            }

            for (CompletableFuture<Long> future : chunk) {
                totalProcessed += safeJoin(future);
            }
        }

        return totalProcessed;
    }

    private long sendMessages(List<String> content, int pageNumber) {
        if (content == null || content.isEmpty()) {
            return 0L;
        }

        StopWatch stopWatch = new StopWatch("kafka_batch_publish");
        stopWatch.start("publish_batch");
        long processed = safeJoin(kafkaNuboAdapter.sendMessagesBatch(content));
        stopWatch.stop();

        meterRegistry.timer("ingestor.sync.kafka.batch.time")
                .record(stopWatch.getTotalTimeNanos(), TimeUnit.NANOSECONDS);
        if (log.isDebugEnabled()) {
            log.debug("Published page {} with {} records in {} ms",
                    pageNumber,
                    processed,
                    stopWatch.getTotalTimeMillis());
        }
        return processed;
    }

    private long safeJoin(CompletableFuture<Long> future) {
        try {
            return future.get(propertiesConfig.getSyncPublishTimeoutSeconds(), TimeUnit.SECONDS);
        } catch (Exception ex) {
            throw new CompletionException(ex);
        }
    }
}
