package com.nubo.ingestor.edge.api.application.config;

import com.nubo.ingestor.edge.api.application.properties.PropertiesConfig;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

@Configuration
@RequiredArgsConstructor
public class SynchronizationExecutorConfig {

    private final PropertiesConfig propertiesConfig;

    @Bean(name = "synchronizationTaskExecutor")
    public Executor synchronizationTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        int concurrency = Math.max(1, propertiesConfig.getSyncPageConcurrency());
        executor.setCorePoolSize(concurrency);
        executor.setMaxPoolSize(concurrency);
        executor.setQueueCapacity(concurrency * 4);
        executor.setThreadNamePrefix("sync-page-");
        executor.initialize();
        return executor;
    }
}