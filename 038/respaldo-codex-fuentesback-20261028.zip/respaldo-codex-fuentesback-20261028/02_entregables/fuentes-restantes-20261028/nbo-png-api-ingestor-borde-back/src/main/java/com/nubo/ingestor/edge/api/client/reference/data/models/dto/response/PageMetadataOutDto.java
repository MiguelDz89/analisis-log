package com.nubo.ingestor.edge.api.client.reference.data.models.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PageMetadataOutDto {

    private Integer size;

    private Integer number;

    private Long totalElements;

    private Integer totalPages;


}
