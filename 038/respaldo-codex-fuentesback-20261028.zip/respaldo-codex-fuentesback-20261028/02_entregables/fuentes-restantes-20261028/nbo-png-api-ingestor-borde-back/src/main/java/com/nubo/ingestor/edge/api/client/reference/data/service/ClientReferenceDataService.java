package com.nubo.ingestor.edge.api.client.reference.data.service;

import com.nubo.ingestor.edge.api.client.reference.data.models.dto.response.DataReferenceOutDto;

public interface ClientReferenceDataService {

    DataReferenceOutDto getExternalInformation(Integer size);

    DataReferenceOutDto getExternalInformation(Integer size, Integer page);
}
