package com.nubo.ingestor.edge.api.web.controller;

import com.nubo.ingestor.edge.api.models.dto.response.SynchronizeOutDto;
import com.nubo.ingestor.edge.api.service.SynchronizationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@Tag(name = "Synchronization")
@RequestMapping("/{version}/synchronization")
@RestController
@RequiredArgsConstructor
public class SynchronizationRestController {

    private final SynchronizationService synchronizationService;

    @Operation(summary = "Synchronize Data Reference and Participants Nubo", description = "Synchronize Data Reference and Participants Nubo")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Successfully Response",
            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = SynchronizeOutDto.class)))})
    @GetMapping("/reference-data")
    public ResponseEntity<SynchronizeOutDto> synchronize(@RequestParam(required = false) Integer size) {
        return ResponseEntity.ok(synchronizationService.synchronizeDataReference(size));
    }
}