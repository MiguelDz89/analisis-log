package com.nubo.ingestor.edge.api.client.reference.data.service.impl;

import java.net.URI;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.util.UriComponentsBuilder;

import com.nubo.ingestor.edge.api.application.properties.PropertiesConfig;
import com.nubo.ingestor.edge.api.application.util.ApplicationUtils;
import com.nubo.ingestor.edge.api.application.util.RestClientUtils;
import com.nubo.ingestor.edge.api.client.reference.data.models.dto.response.DataReferenceOutDto;
import com.nubo.ingestor.edge.api.client.reference.data.models.dto.response.PageMetadataOutDto;
import com.nubo.ingestor.edge.api.client.reference.data.service.ClientReferenceDataService;
import com.nubo.ingestor.edge.api.client.reference.data.service.ReferenceDataTokenService;
import com.nubo.ingestor.edge.api.exception.ClientException;
import com.nubo.ingestor.edge.api.exception.error.ErrorCode;
import com.nubo.ingestor.edge.api.models.enums.ResponseMode;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class ClientReferenceDataServiceImpl implements ClientReferenceDataService {

    private final RestClientUtils restClientUtils;
    private final PropertiesConfig propertiesConfig;
    private final ReferenceDataTokenService referenceDataTokenService;

    @Override
    public DataReferenceOutDto getExternalInformation(Integer size) {
        return getExternalInformation(size, 0);
    }

    @Override
    public DataReferenceOutDto getExternalInformation(Integer size, Integer page) {
        if (propertiesConfig.getResponseMode() == ResponseMode.ARRAY) {
            return getArrayResponse();
        }
        return getPageResponse(size, page);
    }

    private DataReferenceOutDto getPageResponse(Integer size, Integer page) {
        try {
            URI uri = buildUriWithSize(size, page);
            HttpMethod method = HttpMethod.GET;

            log.info("Consulting external URI -> [GET] {}", uri);

            ResponseEntity<DataReferenceOutDto> response = restClientUtils.requestNoBodyWithResponseObject(
                    uri,
                    method,
                    getHttpHeaders(),
                    DataReferenceOutDto.class);

            if (!ObjectUtils.isEmpty(response.getBody())) {
                DataReferenceOutDto dataReferenceOutDto = response.getBody();
                log.info("Client response, page -> {}", dataReferenceOutDto.getPage());
                return dataReferenceOutDto;
            }

        } catch (ClientException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new ClientException(ErrorCode.CLIENT_REFERENCE_DATA_ERROR, HttpStatus.BAD_GATEWAY, ex);
        }

        return DataReferenceOutDto.builder().build();
    }

    private DataReferenceOutDto getArrayResponse() {
        try {
            URI uri = buildUriWithDate();
            log.info("Consulting ARRAY endpoint -> [GET] {}", uri);

            ResponseEntity<List<?>> response = restClientUtils.requestNoBodyWithResponseObject(
                    uri,
                    HttpMethod.GET,
                    getHttpHeaders(),
                    new ParameterizedTypeReference<List<?>>() {
                    });

            if (response.getBody() != null) {
                List<?> rawList = response.getBody();
                List<String> content = rawList.stream()
                        .map(obj -> {
                            try {
                                if (obj instanceof String) {
                                    return (String) obj;
                                }
                                return ApplicationUtils.writeValueAsString(obj);
                            } catch (Exception e) {
                                log.error("Error serializing object in getArrayResponse", e);
                                return null;
                            }
                        })
                        .filter(Objects::nonNull)
                        .toList();

                return buildDataReferenceOutDto(content);
            } else {
                log.warn("Empty or unsuccessful response in getArrayResponse: status {}", response.getStatusCode());
                return buildDataReferenceOutDto(List.of());
            }
        } catch (ClientException ex) {
            throw ex;
        } catch (Exception ex) {
            log.error("Error in getArrayResponse", ex);
            throw new ClientException(ErrorCode.CLIENT_REFERENCE_DATA_ERROR, HttpStatus.BAD_GATEWAY, ex);
        }
    }

    private HttpHeaders getHttpHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        if (propertiesConfig.isReferenceDataAuthEnabled()) {
            headers.setBearerAuth(referenceDataTokenService.getValidAccessToken());
        }
        return headers;
    }

    private URI buildUriWithSize(Integer size, Integer page) {
        String complement = propertiesConfig.getComplementUrl();
        String baseUrl = propertiesConfig.getReferenceDataUrl();
        String v2Prefix = propertiesConfig.isReferenceDataAuthEnabled() ? "/v2" : "";

        String fullUrl = baseUrl;
        if (StringUtils.hasText(complement)) {
            fullUrl = baseUrl + v2Prefix + (complement.startsWith("/") ? complement : "/" + complement);
        }

        return UriComponentsBuilder.fromUriString(fullUrl)
                .queryParam("size", size != null ? size : 500)
                .queryParam("page", page != null ? page : 0)
                .build()
                .toUri();
    }

    private URI buildUriWithDate() {
        String complement = propertiesConfig.getComplementUrl();
        String baseUrl = propertiesConfig.getReferenceDataUrl();
        String v2Prefix = propertiesConfig.isReferenceDataAuthEnabled() ? "/v2" : "";

        String today = LocalDate.now().toString();

        if (StringUtils.hasText(complement)) {
            complement = complement.replace("{date}", today);
        }

        return UriComponentsBuilder
                .fromUriString(baseUrl)
                .path(v2Prefix)
                .path(complement)
                .build()
                .toUri();
    }

    private DataReferenceOutDto buildDataReferenceOutDto(List<String> content) {
        return DataReferenceOutDto.builder()
                .content(content)
                .page(PageMetadataOutDto.builder()
                        .size(content.size())
                        .totalElements((long) content.size())
                        .totalPages(1)
                        .number(0)
                        .build())
                .build();
    }

}
