package com.nubo.ingestor.edge.api.client.reference.data.models.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.nubo.ingestor.edge.api.application.util.ContentAsStringListDeserializer;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DataReferenceOutDto {

    @NotNull
    @JsonDeserialize(using = ContentAsStringListDeserializer.class)
    private List<String> content;

    private PageMetadataOutDto page;

}
