package com.nubo.ingestor.edge.api.client.reference.data.service;

public interface ReferenceDataTokenService {

    String getValidAccessToken();

}