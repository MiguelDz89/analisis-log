package com.nubo.master.closure.process.rate.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClosureProcessApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ClosureProcessApiApplication.class, args);
    }

}
