package com.nubo.master.closure.process.rate.api.models.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SystemClosureOutDto {

    private Long id;

    private List<PreClosureCountryOutDto> preClosureCountries;

    private LocalDateTime closureDate;

    private StatusOutDto closureStatus;

    private String closureUser;

    private String observation;

    private String lastModifyUser;

    private String lastModifyApplication;

    private LocalDateTime lastModifyDate;

    private String lastModifyIp;

}
