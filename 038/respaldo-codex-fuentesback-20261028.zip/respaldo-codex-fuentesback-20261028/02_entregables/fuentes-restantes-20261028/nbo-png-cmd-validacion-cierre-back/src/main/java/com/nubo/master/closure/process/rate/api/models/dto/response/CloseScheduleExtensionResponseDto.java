package com.nubo.master.closure.process.rate.api.models.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Respuesta del cierre de ampliaciones de horario")
public class CloseScheduleExtensionResponseDto {

    @Schema(description = "Total de extensiones procesadas", example = "3")
    private Integer totalProcessed;

    @Schema(description = "Cantidad exitosa", example = "2")
    private Integer successCount;

    @Schema(description = "Cantidad con errores", example = "1")
    private Integer errorCount;

    @Schema(description = "Lista de extensiones cerradas exitosamente")
    private List<ScheduleExtensionClosedDto> successful;

    @Schema(description = "Lista de extensiones con errores")
    private List<ScheduleExtensionErrorDto> errors;

}
