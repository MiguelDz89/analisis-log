package com.nubo.master.closure.process.rate.api.models.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum ParamsScriptEnum {

    PM_COUNTRY_ID("pm_pais_id"),
    PM_CLEARING_DATE("pm_clearing_date");

    private final String param;

}
