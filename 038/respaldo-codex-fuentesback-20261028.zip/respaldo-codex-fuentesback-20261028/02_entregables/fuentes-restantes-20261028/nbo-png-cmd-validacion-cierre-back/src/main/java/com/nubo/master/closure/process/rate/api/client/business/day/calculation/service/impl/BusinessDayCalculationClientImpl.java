package com.nubo.master.closure.process.rate.api.client.business.day.calculation.service.impl;

import com.nubo.master.closure.process.rate.api.application.properties.PropertiesConfig;
import com.nubo.master.closure.process.rate.api.application.properties.PropertiesContext;
import com.nubo.master.closure.process.rate.api.application.util.ApplicationUtils;
import com.nubo.master.closure.process.rate.api.application.util.RestClientUtils;
import com.nubo.master.closure.process.rate.api.client.business.day.calculation.models.dto.response.BusinessDayOutDto;
import com.nubo.master.closure.process.rate.api.client.business.day.calculation.service.BusinessDayCalculationClient;
import com.nubo.master.closure.process.rate.api.exception.ClientException;
import com.nubo.master.closure.process.rate.api.exception.error.ErrorCode;
import com.nubo.master.closure.process.rate.api.models.enums.PropertiesEnum;
import com.nubo.master.closure.process.rate.api.models.enums.VersionApiEnum;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class BusinessDayCalculationClientImpl implements BusinessDayCalculationClient {

    private final PropertiesConfig propertiesConfig;
    private final RestClientUtils restClientUtils;

    private static final String PATH_BUSINESS_DAY = "business-day";

    @Override
    public BusinessDayOutDto businessNextDayCalculation(Long countryId) {
        URI uri = UriComponentsBuilder
                .fromUriString(propertiesConfig.getUrlNuboBusinessDayCalculation())
                .pathSegment(VersionApiEnum.V1.getValue(), PATH_BUSINESS_DAY)
                .path("/calculation/next-day/country/{countryId}")
                .buildAndExpand(countryId)
                .toUri();

        try {
            ResponseEntity<BusinessDayOutDto> response = restClientUtils.requestWithoutBodyWithResponseObject(uri,
                    HttpMethod.GET, getHttpHeaders(), BusinessDayOutDto.class);

            if (!ObjectUtils.isEmpty(response.getBody())) {
                return response.getBody();
            }
        } catch (Exception ex) {
            throw new ClientException(ErrorCode.CLIENT_BUSINESS_DAY_CALCULATION_ERROR, HttpStatus.BAD_GATEWAY, ex);
        }

        return BusinessDayOutDto.builder().build();
    }

    @Override
    public BusinessDayOutDto businessNextDayCalculationClosureDate(LocalDateTime closureDate) {
        URI uri = UriComponentsBuilder
                .fromUriString(propertiesConfig.getUrlNuboBusinessDayCalculation())
                .pathSegment(VersionApiEnum.V1.getValue(), PATH_BUSINESS_DAY)
                .path("/calculation/closure-date/next-day")
                .queryParam("closureDate", closureDate).build().toUri();

        try {
            ResponseEntity<BusinessDayOutDto> response = restClientUtils.requestWithoutBodyWithResponseObject(uri,
                    HttpMethod.GET, getHttpHeaders(), BusinessDayOutDto.class);

            if (!ObjectUtils.isEmpty(response.getBody())) {
                return response.getBody();
            }
        } catch (Exception ex) {
            throw new ClientException(ErrorCode.CLIENT_BUSINESS_DAY_CALCULATION_ERROR, HttpStatus.BAD_GATEWAY, ex);
        }

        return BusinessDayOutDto.builder().build();
    }

    @Override
    public BusinessDayOutDto validBusinessDay(Long countryId) {
        URI uri = UriComponentsBuilder
                .fromUriString(propertiesConfig.getUrlNuboBusinessDayCalculation())
                .pathSegment(VersionApiEnum.V1.getValue(), PATH_BUSINESS_DAY)
                .path("/valid/current-day/country/{countryId}")
                .buildAndExpand(countryId)
                .toUri();

        try {
            ResponseEntity<BusinessDayOutDto> response = restClientUtils.requestWithoutBodyWithResponseObject(uri,
                    HttpMethod.GET, getHttpHeaders(), BusinessDayOutDto.class);

            if (!ObjectUtils.isEmpty(response.getBody())) {
                return response.getBody();
            }
        } catch (Exception ex) {
            throw new ClientException(ErrorCode.CLIENT_BUSINESS_DAY_CALCULATION_ERROR, HttpStatus.BAD_GATEWAY, ex);
        }

        return BusinessDayOutDto.builder().build();
    }

    private HttpHeaders getHttpHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.set(PropertiesEnum.CLIENT_IP.getValue(), PropertiesContext.getClientIp());
        headers.set(PropertiesEnum.CLIENT_USER.getValue(), PropertiesContext.getClientUser());
        headers.set(PropertiesEnum.CLIENT_DATETIME.getValue(),
                ApplicationUtils.convertLocalDateTimeToString(PropertiesContext.getClientDatetime()));
        headers.setContentType(MediaType.APPLICATION_JSON);
        return headers;
    }

}
