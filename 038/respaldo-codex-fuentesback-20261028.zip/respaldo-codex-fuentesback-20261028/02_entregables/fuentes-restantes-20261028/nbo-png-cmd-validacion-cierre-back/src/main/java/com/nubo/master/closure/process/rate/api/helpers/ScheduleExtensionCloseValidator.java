package com.nubo.master.closure.process.rate.api.helpers;

import com.nubo.master.closure.process.rate.api.models.entity.ScheduleExtensionEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;

@Component
@Slf4j
public class ScheduleExtensionCloseValidator {

    private static final Long APPROVED_STATUS_ID = 924L;

    public String validate(ScheduleExtensionEntity extension) {
        
        if (!APPROVED_STATUS_ID.equals(extension.getStatus().getId())) {
            return "La extensión debe estar en estado APROBADO para poder cerrarse";
        }

        LocalDate today = LocalDate.now();
        LocalDate extensionDate = extension.getLastModifyDate().toLocalDate();
        
        if (!extensionDate.equals(today)) {
            return "Solo se pueden cerrar extensiones del mismo día de la consulta";
        }

        LocalTime originalClosingTime = extension.getSchedule().getClosingTime();
        LocalTime extendedClosingTime = extension.getNewClosingTime();

        if (extendedClosingTime.isBefore(originalClosingTime)) {
            return "La ampliación del horario ya fue cerrada previamente";
        }

        ZoneId zoneId = getZoneId(extension);
        LocalTime currentTime = LocalTime.now(zoneId);

        if (currentTime.isBefore(originalClosingTime)) {
            return String.format(
                    "La hora actual (%s) es anterior al horario de cierre original (%s). " +
                    "El cierre anticipado solo aplica durante el horario ampliado",
                    currentTime, originalClosingTime);
        }

        if (currentTime.isAfter(extendedClosingTime) || currentTime.equals(extendedClosingTime)) {
            return String.format(
                    "La ampliación del horario ya finalizó (hora de cierre: %s, hora actual: %s)",
                    extendedClosingTime, currentTime);
        }

        log.debug("Extension {} validated successfully", extension.getId());
        return null;
    }

    private ZoneId getZoneId(ScheduleExtensionEntity extension) {
        String timezone = extension.getSchedule().getCountry().getTimeZone();
        return timezone != null ? parseTimeZone(timezone) : ZoneId.systemDefault();
    }

    private ZoneId parseTimeZone(String timeZone) {
        try {
            if (!timeZone.startsWith("UTC")) {
                return ZoneId.of(timeZone);
            }

            String offset = timeZone.substring(3).split(" a ")[0].trim();

            if (offset.isEmpty()) {
                return ZoneId.of("UTC");
            }

            if (!offset.startsWith("+") && !offset.startsWith("-")) {
                offset = "+" + offset;
            }

            String sign = offset.substring(0, 1);
            String[] parts = offset.substring(1).split(":");
            int hours = Integer.parseInt(parts[0]);
            String minutes = parts.length > 1 ? parts[1] : "00";

            offset = String.format("%s%02d:%s", sign, hours, minutes);

            return ZoneId.of(offset);
        } catch (Exception e) {
            log.error("Error parsing timezone: {}", timeZone, e);
            return ZoneId.systemDefault();
        }
    }

}
