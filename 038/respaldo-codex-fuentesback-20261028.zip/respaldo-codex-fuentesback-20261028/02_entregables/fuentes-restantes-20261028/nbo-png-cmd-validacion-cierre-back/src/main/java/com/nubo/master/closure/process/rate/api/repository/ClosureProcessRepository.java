package com.nubo.master.closure.process.rate.api.repository;

import com.nubo.master.closure.process.rate.api.models.entity.ClosureProcessEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface ClosureProcessRepository extends JpaRepository<ClosureProcessEntity, Long>,
        JpaSpecificationExecutor<ClosureProcessEntity> {

}
