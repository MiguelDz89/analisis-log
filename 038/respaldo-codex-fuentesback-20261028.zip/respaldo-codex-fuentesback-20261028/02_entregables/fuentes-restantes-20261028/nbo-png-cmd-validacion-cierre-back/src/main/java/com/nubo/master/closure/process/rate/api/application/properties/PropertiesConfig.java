package com.nubo.master.closure.process.rate.api.application.properties;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Getter
public class PropertiesConfig {

    @Value("${spring.application.name}")
    private String apiName;

    @Value("${client.nubo.url-business-day-calculation}")
    private String urlNuboBusinessDayCalculation;

}
