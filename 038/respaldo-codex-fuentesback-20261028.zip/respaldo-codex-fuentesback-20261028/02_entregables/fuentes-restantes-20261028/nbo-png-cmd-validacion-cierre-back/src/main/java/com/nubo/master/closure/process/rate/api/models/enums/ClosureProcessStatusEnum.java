package com.nubo.master.closure.process.rate.api.models.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum ClosureProcessStatusEnum {

    WITH_PENDING_RECORDS(1152L),
    WITHOUT_PENDING_RECORDS(1153L),
    COMPLETED(1155L),
    PENDING(1154L),
    SYSTEM_CLOSED(1157L),
    SYSTEM_INITIAL(1158L);

    private final Long statusId;

}
