package com.nubo.master.closure.process.rate.api.client.business.day.calculation.service;

import com.nubo.master.closure.process.rate.api.client.business.day.calculation.models.dto.response.BusinessDayOutDto;

import java.time.LocalDateTime;

public interface BusinessDayCalculationClient {

    BusinessDayOutDto businessNextDayCalculation(Long countryId);

    BusinessDayOutDto businessNextDayCalculationClosureDate(LocalDateTime closureDate);

    BusinessDayOutDto validBusinessDay(Long countryId);

}
