package com.nubo.master.closure.process.rate.api.models.dto.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Request para cerrar ampliaciones de horario anticipadamente")
public class CloseScheduleExtensionRequestDto {

    @NotNull(message = "La lista de IDs de extensiones es requerida")
    @NotEmpty(message = "Debe proporcionar al menos un ID de extensión")
    @Schema(description = "Lista de IDs de extensiones de horario a cerrar", 
            example = "[1, 2, 3]", 
            required = true)
    private List<Long> scheduleExtensionIds;

}
