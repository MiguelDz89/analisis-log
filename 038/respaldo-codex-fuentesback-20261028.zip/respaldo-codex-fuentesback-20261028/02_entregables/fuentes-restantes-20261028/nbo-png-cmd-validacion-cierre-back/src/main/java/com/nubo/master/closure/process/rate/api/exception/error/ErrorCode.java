package com.nubo.master.closure.process.rate.api.exception.error;

import lombok.Getter;

@Getter
public enum ErrorCode {

    UNAUTHORIZED("Not unauthorized"),
    FORBIDDEN("Access denied"),
    UNEXPECTED("An unexpected error occurred"),
    METHOD_ARGUMENT_TYPE("Invalid request path"),
    METHOD_NOT_ALLOWED("Http method not allowed"),
    NOT_FOUND("Resource not found"),
    UNSUPPORTED_MEDIA_TYPE("Content Type is not supported"),
    MESSAGE_NOT_READABLE("Error reading the message body request"),
    BAD_REQUEST("Invalid request body"),
    HEADER_CLIENT_IP_REQUIRED("Header client_ip required"),
    HEADER_CLIENT_IP_INVALID("Header client_ip is invalid"),
    HEADER_CLIENT_USER_REQUIRED("Header client_user is required"),
    HEADER_CLIENT_DATETIME_REQUIRED("Header client_datetime is required"),
    HEADER_CLIENT_DATETIME_INVALID("Header client_datetime is invalid"),
    VERSION_API_NOT_FOUND("Version API not found"),
    CLIENT_BUSINESS_DAY_CALCULATION_ERROR("An unexpected error occurred in Business Day Calculation"),
    BUSINESS_DAY_NOT_VALID("Business day not valid"),
    PRE_CLOSURE_COUNTRY_BUSINESS_DAY_NOT_VALID("Pre closure country business day not valid"),
    CLOSURE_PROCESS_NOT_FOUND("Closure process not found"),
    SCRIPT_NOT_FOUND("Script not found in closure process"),
    SCRIPT_EXECUTION_ERROR("Error executing script"),
    SYSTEM_CLOSURE_NOT_FOUND("System closure not found"),
    NOT_A_WORKING_DAY("NO SE ENCUENTRA EN UN DIA HABIL"),
    SCHEDULE_EXTENSION_NOT_FOUND("Schedule extension not found"),
    SCHEDULE_EXTENSION_INVALID_STATUS("Schedule extension must be in APPROVED status"),
    SCHEDULE_EXTENSION_NOT_TODAY("Schedule extension must be from today"),
    SCHEDULE_EXTENSION_EXPIRED("Schedule extension has already expired"),
    SCHEDULE_EXTENSION_OUT_OF_RANGE("Current time is outside the extended schedule range"),
    SCHEDULE_EXTENSION_ALREADY_CLOSED("Schedule extension has already been closed"),
    INVALID_TIMEZONE("Invalid timezone format");

    private final String message;

    ErrorCode(String message) {
        this.message = message;
    }

    public String getName() {
        return this.name();
    }

}
