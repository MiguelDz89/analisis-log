package com.nubo.master.closure.process.rate.api.models.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum SystemClosureMessageEnum {

    PENDING_PROCESSES("Existen procesos pendientes de cierre ¿Deseas continuar con la confirmación de cierre?"),
    PROCESSES_COMPLETED("Procesos de cierre finalizados, ¿Desea Continuar?"),
    CLOSURE_EXECUTED_SUCCESSFULLY("Proceso de cierre ejecutado exitosamente");

    private final String message;

}
