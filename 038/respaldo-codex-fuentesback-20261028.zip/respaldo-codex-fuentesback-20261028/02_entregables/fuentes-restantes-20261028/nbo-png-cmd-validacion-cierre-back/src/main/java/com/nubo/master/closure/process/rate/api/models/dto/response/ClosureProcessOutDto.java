package com.nubo.master.closure.process.rate.api.models.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClosureProcessOutDto {

    private Long id;

    private ModuleOutDto module;

    private String description;

    private String result;

    private Integer pendingRecords;

    private StatusOutDto status;

    private String script;

    private CountryOutDto country;

    private String lastModifyUser;

    private String lastModifyApplication;

    private LocalDateTime lastModifyDate;

    private String lastModifyIp;

}
