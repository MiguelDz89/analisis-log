package com.nubo.master.closure.process.rate.api.helpers.specification;

import com.nubo.master.closure.process.rate.api.models.entity.ClosureProcessEntity;
import jakarta.persistence.criteria.Predicate;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.ObjectUtils;

import java.util.ArrayList;
import java.util.List;

public class ClosureProcessSpecification {

    public static Specification<ClosureProcessEntity> buildSpecification(Long countryId,
                                                                         Long moduleId,
                                                                         Integer statusId) {
        return (root, query, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (!ObjectUtils.isEmpty(countryId)) {
                predicates.add(criteriaBuilder.equal(root.get("country").get("id"), countryId));
            }

            if (!ObjectUtils.isEmpty(moduleId)) {
                predicates.add(criteriaBuilder.equal(root.get("module").get("id"), moduleId));
            }

            if (!ObjectUtils.isEmpty(statusId)) {
                predicates.add(criteriaBuilder.equal(root.get("status").get("id"), statusId));
            }

            return criteriaBuilder.and(predicates.toArray(Predicate[]::new));
        };
    }
}
