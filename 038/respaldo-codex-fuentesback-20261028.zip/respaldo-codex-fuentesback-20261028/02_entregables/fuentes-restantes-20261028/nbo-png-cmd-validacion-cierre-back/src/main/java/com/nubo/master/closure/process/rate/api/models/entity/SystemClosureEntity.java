package com.nubo.master.closure.process.rate.api.models.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "\"SYSTEM_CLOSURE\"", schema = "\"NUANBODB\"")
public class SystemClosureEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "\"SYSTEM_CLOSURE_ID\"", nullable = false)
    private Long id;

    @OneToMany(mappedBy = "systemClosure", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<PreClosureCountryEntity> preClosureCountries;

    @Column(name = "\"CLOSURE_DATE\"")
    private LocalDateTime closureDate;

    @ManyToOne
    @JoinColumn(name = "\"STATUS_ID\"")
    private StatusEntity closureStatus;

    @Column(name = "\"CLOSURE_USER\"", length = 250)
    private String closureUser;

    @Column(name = "\"OBSERVATION\"", columnDefinition = "TEXT")
    private String observation;

    @Column(name = "\"LAST_MODIFY_USER\"", length = 250, nullable = false)
    private String lastModifyUser;

    @Column(name = "\"LAST_MODIFY_APPLIC\"", length = 250, nullable = false)
    private String lastModifyApplication;

    @Column(name = "\"LAST_MODIFY_DATE\"", nullable = false)
    private LocalDateTime lastModifyDate;

    @Column(name = "\"LAST_MODIFY_IP\"", length = 50, nullable = false)
    private String lastModifyIp;

}
