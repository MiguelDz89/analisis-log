package com.nubo.master.closure.process.rate.api.models.dto.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Extensión cerrada exitosamente")
public class ScheduleExtensionClosedDto {

    @Schema(description = "ID de la extensión", example = "1")
    private Long scheduleExtensionId;

    @Schema(description = "Nombre del participante", example = "Banco XYZ")
    private String participantName;

    @Schema(description = "Nombre/descripción del horario", example = "Horario Compensación")
    private String scheduleName;

    @Schema(description = "Nueva hora de cierre actualizada", example = "16:45:00")
    @JsonFormat(pattern = "HH:mm:ss")
    private LocalTime closedAt;

}
