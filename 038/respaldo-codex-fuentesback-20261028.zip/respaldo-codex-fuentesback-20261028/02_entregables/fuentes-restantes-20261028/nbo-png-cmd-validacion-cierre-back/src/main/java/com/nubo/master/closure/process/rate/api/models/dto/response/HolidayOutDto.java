package com.nubo.master.closure.process.rate.api.models.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.OffsetDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class HolidayOutDto {

    private Long id;
    private CountryOutDto country;
    private LocalDate holidayDate;
    private String description;
    private String lastModifyUser;
    private String lastModifyApplication;
    private OffsetDateTime lastModifyDate;
    private String lastModifyIp;
}
