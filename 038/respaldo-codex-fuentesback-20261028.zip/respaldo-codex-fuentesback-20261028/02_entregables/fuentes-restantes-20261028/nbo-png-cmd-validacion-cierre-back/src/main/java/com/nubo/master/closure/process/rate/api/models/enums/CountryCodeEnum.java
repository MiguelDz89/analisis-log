package com.nubo.master.closure.process.rate.api.models.enums;

import java.util.Arrays;
import java.util.List;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum CountryCodeEnum {

    CHILE("CL"),
    COLOMBIA("CO"),
    PERU("PE");

    private final String code;

    public static List<String> getAllCountriesCodes() {
        return Arrays.stream(CountryCodeEnum.values())
                .map(CountryCodeEnum::getCode)
                .toList();
    }

    public static boolean isValidCode(String code) {
        return Arrays.stream(CountryCodeEnum.values())
                .anyMatch(country -> country.getCode().equalsIgnoreCase(code));
    }
}