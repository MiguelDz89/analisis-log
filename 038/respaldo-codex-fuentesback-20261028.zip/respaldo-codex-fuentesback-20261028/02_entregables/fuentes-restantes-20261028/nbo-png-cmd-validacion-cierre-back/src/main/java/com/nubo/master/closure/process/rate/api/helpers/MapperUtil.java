package com.nubo.master.closure.process.rate.api.helpers;

import java.util.stream.Collectors;

import org.springframework.util.ObjectUtils;

import com.nubo.master.closure.process.rate.api.models.dto.response.ClosureProcessOutDto;
import com.nubo.master.closure.process.rate.api.models.dto.response.CountryOutDto;
import com.nubo.master.closure.process.rate.api.models.dto.response.CurrencyOutDto;
import com.nubo.master.closure.process.rate.api.models.dto.response.HolidayOutDto;
import com.nubo.master.closure.process.rate.api.models.dto.response.ModuleOutDto;
import com.nubo.master.closure.process.rate.api.models.dto.response.PreClosureCountryOutDto;
import com.nubo.master.closure.process.rate.api.models.dto.response.StatusOutDto;
import com.nubo.master.closure.process.rate.api.models.dto.response.SystemClosureOutDto;
import com.nubo.master.closure.process.rate.api.models.entity.ClosureProcessEntity;
import com.nubo.master.closure.process.rate.api.models.entity.CountryEntity;
import com.nubo.master.closure.process.rate.api.models.entity.CurrencyEntity;
import com.nubo.master.closure.process.rate.api.models.entity.HolidayEntity;
import com.nubo.master.closure.process.rate.api.models.entity.ModuleEntity;
import com.nubo.master.closure.process.rate.api.models.entity.PreClosureCountryEntity;
import com.nubo.master.closure.process.rate.api.models.entity.StatusEntity;
import com.nubo.master.closure.process.rate.api.models.entity.SystemClosureEntity;


public class MapperUtil {

    private MapperUtil() {
    }


    public static CountryOutDto countryEntityToCountryOutDto(CountryEntity countryEntity) {
        return CountryOutDto.builder()
                .id(countryEntity.getId())
                .code(countryEntity.getCode())
                .name(countryEntity.getName())
                .currency(ObjectUtils.isEmpty(countryEntity.getCurrency()) ?
                        null:currencyEntityToCurrencyOutDto(countryEntity.getCurrency()))
                .timeZone(countryEntity.getTimeZone())
                .build();
    }

    public static CurrencyOutDto currencyEntityToCurrencyOutDto(CurrencyEntity currencyEntity) {
        return CurrencyOutDto.builder()
                .id(currencyEntity.getId())
                .code(currencyEntity.getCode())
                .name(currencyEntity.getName())
                .build();
    }


    public static ModuleOutDto moduleEntityToModuleOutDto(ModuleEntity moduleEntity) {
        return ModuleOutDto.builder()
                .id(moduleEntity.getId())
                .name(moduleEntity.getName())
                .description(moduleEntity.getDescription())
                .build();
    }

    public static StatusOutDto statusEntityToStatusOutDto(StatusEntity statusEntity) {
        return StatusOutDto.builder()
                .id(Math.toIntExact(statusEntity.getId()))
                .name(statusEntity.getCategory())
                .description(statusEntity.getDescription())
                .build();
    }

    public static ClosureProcessOutDto closureProcessEntityToClosureProcessOutDto(ClosureProcessEntity closureProcessEntity) {
        return ClosureProcessOutDto.builder()
                .id(closureProcessEntity.getId())
                .module(ObjectUtils.isEmpty(closureProcessEntity.getModule()) ?
                        null : moduleEntityToModuleOutDto(closureProcessEntity.getModule()))
                .description(closureProcessEntity.getDescription())
                .result(closureProcessEntity.getResult())
                .pendingRecords(closureProcessEntity.getPendingRecords())
                .status(ObjectUtils.isEmpty(closureProcessEntity.getStatus()) ?
                        null : statusEntityToStatusOutDto(closureProcessEntity.getStatus()))
                .script(closureProcessEntity.getScript())
                .country(ObjectUtils.isEmpty(closureProcessEntity.getCountry()) ?
                        null : countryEntityToCountryOutDto(closureProcessEntity.getCountry()))
                .lastModifyUser(closureProcessEntity.getLastModifyUser())
                .lastModifyApplication(closureProcessEntity.getLastModifyApplication())
                .lastModifyDate(closureProcessEntity.getLastModifyDate())
                .lastModifyIp(closureProcessEntity.getLastModifyIp())
                .build();
    }

    public static SystemClosureOutDto systemClosureEntityToSystemClosureOutDto(SystemClosureEntity systemClosureEntity) {
        return SystemClosureOutDto.builder()
                .id(systemClosureEntity.getId())
                .preClosureCountries(ObjectUtils.isEmpty(systemClosureEntity.getPreClosureCountries()) ? 
                        null : systemClosureEntity.getPreClosureCountries().stream()
                                .map(MapperUtil::preClosureCountryEntityToPreClosureCountryOutDto)
                                .collect(Collectors.toList()))
                .closureDate(systemClosureEntity.getClosureDate())
                .closureStatus(ObjectUtils.isEmpty(systemClosureEntity.getClosureStatus()) ?
                        null : statusEntityToStatusOutDto(systemClosureEntity.getClosureStatus()))
                .closureUser(systemClosureEntity.getClosureUser())
                .observation(systemClosureEntity.getObservation())
                .lastModifyUser(systemClosureEntity.getLastModifyUser())
                .lastModifyApplication(systemClosureEntity.getLastModifyApplication())
                .lastModifyDate(systemClosureEntity.getLastModifyDate())
                .lastModifyIp(systemClosureEntity.getLastModifyIp())
                .build();
    }

    public static PreClosureCountryOutDto preClosureCountryEntityToPreClosureCountryOutDto(PreClosureCountryEntity entity) {
        return PreClosureCountryOutDto.builder()
                .id(entity.getId())
                .countryCode(ObjectUtils.isEmpty(entity.getCountry()) ? null : entity.getCountry().getCode())
                .preClosureDate(entity.getPreClosureDate())
                .status(ObjectUtils.isEmpty(entity.getStatus()) ? null : statusEntityToStatusOutDto(entity.getStatus()))
                .build();
    }

    public static HolidayOutDto holidayEntityToHolidayOutDto(HolidayEntity holidayEntity) {
        return HolidayOutDto.builder()
                .id(holidayEntity.getId())
                .country(ObjectUtils.isEmpty(holidayEntity.getCountryId()) ?
                        null : countryEntityToCountryOutDto(holidayEntity.getCountryId()))
                .holidayDate(holidayEntity.getHolidayDate())
                .description(holidayEntity.getDescription())
                .lastModifyUser(holidayEntity.getLastModifyUser())
                .lastModifyApplication(holidayEntity.getLastModifyApplication())
                .lastModifyDate(holidayEntity.getLastModifyDate())
                .lastModifyIp(holidayEntity.getLastModifyIp())
                .build();
    }

}
