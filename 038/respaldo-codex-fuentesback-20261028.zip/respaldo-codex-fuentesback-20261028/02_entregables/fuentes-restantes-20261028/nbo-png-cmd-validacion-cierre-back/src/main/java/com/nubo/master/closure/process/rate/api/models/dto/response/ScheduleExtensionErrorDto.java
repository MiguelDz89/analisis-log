package com.nubo.master.closure.process.rate.api.models.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Extensión con error al cerrar")
public class ScheduleExtensionErrorDto {

    @Schema(description = "ID de la extensión", example = "123")
    private Long scheduleExtensionId;

    @Schema(description = "Código del error", example = "EXTENSION_EXPIRED")
    private String errorCode;

    @Schema(description = "Mensaje del error", example = "La ampliación ya expiró y no puede cerrarse")
    private String errorMessage;

}
