# Respaldo del trabajo en Codex — FuentesBack

Captura: 28/10/2026.

Conversaciones locales asociadas a este workspace: 55. Con mensajes recuperados: 55. Mensajes: 3800. Archivos copiados y verificados: 4734.

- 01_conversaciones: transcripciones legibles y datos JSON de mensajes del usuario y respuestas visibles.
- 02_entregables: copia de todos los entregables existentes antes de iniciar este respaldo.
- 03_documentacion_workspace: informes, diagramas y scripts de la raíz.
- 04_documentacion_proyectos: docs y workflows de los proyectos, excepto automatización de pruebas.
- 05_logs_analizados: logs locales empleados en los análisis.
- 06_estado_git: estado, HEAD, últimos 30 commits, diff de cambios sin confirmar e inventario de archivos sin seguimiento.

Alcance y límites: solo FuentesBack; no incluye chats de FuentesFront, Info ni conversaciones de ChatGPT. Es una captura local, no una exportación restaurable de toda la cuenta ni de Git: no copia las bases de datos de Codex, los repositorios .git ni todo el historial de commits. El código fuente disponible está en los entregables exportados previamente. Los archivos sin seguimiento se enumeran; solo se copian cuando pertenecen a los entregables o documentos incluidos. Los adjuntos externos y archivos eliminados no se recuperan automáticamente. El chat actual se captura hasta el instante de ejecución; este mensaje final y actividad posterior no están incluidos. No se modificó el historial original.
