# Conversaciones de Codex — FuentesBack

1. [Listar proyectos y ramas](019edac1-bb12-7ba1-b168-d9cbea840aa4.md) — 41 mensajes.
2. [Analiza error de arranque](019edba1-9230-7003-adef-4aa55856cfbb.md) — 20 mensajes.
3. [Analizar origen de datos GET](019ee050-0283-7f93-a821-f429cc0fc8e1.md) — 10 mensajes.
4. [SincronizaCuentasBancariasParticipante](019ee084-6a3f-7f01-a1cd-252f4f3f5c98.md) — 39 mensajes.
5. [Analiza consulta participants](019ee08f-5648-78d3-9189-4535427e27b9.md) — 6 mensajes.
6. [Corrige ClassNotFoundException](019ee1b2-3c57-7230-891a-4ffdfebcb18b.md) — 18 mensajes.
7. [Analiza rendimiento ingestor](019ee537-7955-7dd2-b942-5ea1845cca03.md) — 28 mensajes.
8. [SincronizaInstrumentos](019ee5df-7fd7-7ec1-b628-9fa39373bcc4.md) — 162 mensajes.
9. [Analiza empaquetamiento RV](019eef79-91b0-7cc2-be65-4a39396b5193.md) — 13 mensajes.
10. [Corrige error year en HolidayEntity](019ef195-1ea1-7843-bb00-12c1fa804a16.md) — 14 mensajes.
11. [Analiza participant.name](019ef55a-5331-7331-8093-cb8471ff3f3a.md) — 14 mensajes.
12. [CMD Verificar regla punta propia](019ef62e-5a78-7003-a24c-8a5adc9c08c5.md) — 39 mensajes.
13. [Analiza horarios y proyectos](019ef6aa-ea19-7582-8927-02b31205d437.md) — 6 mensajes.
14. [Analizar error de deploy](019efa51-be0d-7070-82b1-8330212b755f.md) — 79 mensajes.
15. [Agregar logs de mnemonic y errores](019f004f-b012-7a43-a8d8-a3b404f58365.md) — 15 mensajes.
16. [Corrige sincronización de cuentas](019f0433-8f0e-75f0-8857-7a3cd8d0b2cf.md) — 19 mensajes.
17. [paquetes-custodios-cmd-back](019f193e-bf83-73a1-8998-c3da8033afa2.md) — 27 mensajes.
18. [reglas y estados backend](019f230c-0581-79a2-99f9-78a7fb18ac58.md) — 4 mensajes.
19. [Localiza foreignBrokerSell](019f2a42-f24e-75c3-b68f-b1afda4e1eb1.md) — 13 mensajes.
20. [Implementar endpoint empaquetado RV](019f3897-7f4a-75b2-a523-70df70d41f2b.md) — 1221 mensajes.
21. [Crear esquema NUANBODB](019f59bf-83ec-75a1-9fcb-965fe4ae1d4c.md) — 15 mensajes.
22. [Clonar repos nbo-png back](019f59d7-95e0-75d0-885c-ff80ef455dc5.md) — 8 mensajes.
23. [Localiza generación de Archivo liquе](019fd223-93dd-7300-8d22-37a7a0af8bc2.md) — 20 mensajes.
24. [Crear scripts SQL de prueba](019ff2fb-2e97-75c1-bba9-198fea3e1b01.md) — 5 mensajes.
25. [Investigar asignación de operaciones](019ffc1e-9d7b-7553-b791-54d2799d8a45.md) — 726 mensajes.
26. [Analizar flujo TRADE y asignación](01a01df2-66df-7250-9a68-9f0c2d6d17b1.md) — 9 mensajes.
27. [Analiza rendimiento de asignaciones](01a01df3-ba05-7bf2-8516-87745606241f.md) — 9 mensajes.
28. [Investiga configuración Flux](01a02728-e389-7a62-9a44-6c20b85433ba.md) — 10 mensajes.
29. [Optimizar performance de asignações](01a08281-e431-7501-969d-63c860a74450.md) — 91 mensajes.
30. [Actualizar fracciones a Java 21](01a08f10-8849-71f3-b74b-4f662760fd0a.md) — 37 mensajes.
31. [Responder saludo](01a0a558-6b64-7d23-9bc1-f8fd1880508e.md) — 91 mensajes.
32. [Revisar error en nbo-png-operaciones](01a0b4b8-5e97-76f2-b1b0-9ad6cc49ba47.md) — 6 mensajes.
33. [Investigar bugs en Recepción de Ant](01a0b4bd-56f6-7c33-b39a-7f4bdc8a84b6.md) — 19 mensajes.
34. [Mejora logs de asignaciones](01a0b5a4-a117-7c30-a959-6d2560b5a59c.md) — 21 mensajes.
35. [Ubica el origen de correctionNumber](01a0b63b-cd98-74e1-ad3d-93146f5800cf.md) — 3 mensajes.
36. [Implementar rechazo batch de custód̄](01a0e8e3-529a-75b3-a763-a6a659e77388.md) — 74 mensajes.
37. [Diagnostica error 502](01a0edf8-c5e0-79f1-90ce-f283836b7e3b.md) — 13 mensajes.
38. [Optimizar performance de asignações (2)](01a0fdb2-a916-7383-8663-ecc415e08f76.md) — 8 mensajes.
39. [Analiza errores por item](01a0fdcb-3611-7a31-871b-5fae9e7c04cd.md) — 41 mensajes.
40. [Paquetes performance](01a112e7-ebd5-7412-9026-0dbf5416a27a.md) — 193 mensajes.
41. [Revisar notificaciones duplicadas](01a117f9-3b0f-7751-aee1-9827c6a5b339.md) — 34 mensajes.
42. [orquestador logs RTBOF-18033](01a12109-05d9-76f3-b03e-92165841772e.md) — 16 mensajes.
43. [Anticipos](01a12366-d624-7582-a84e-3ffb05346d5b.md) — 70 mensajes.
44. [Analiza rechazo de ValidatorUtil](01a13641-b404-70b1-b915-75cc97c5bd46.md) — 14 mensajes.
45. [Analiza reinicios en Kafka Transfer](01a13b6d-0a83-7933-a2ab-1b5dd68b486a.md) — 70 mensajes.
46. [60K empaquetamiento](01a144d4-dcd3-7e03-b79c-4c328c39f9e6.md) — 238 mensajes.
47. [Revisar comprobantes y consultas SQL](01a159b6-341c-7772-ab26-d925fedd10e0.md) — 47 mensajes.
48. [Comparar dos fuentes de datos](01a15b1f-e9a7-7551-8e19-d8600252eb42.md) — 37 mensajes.
49. [Investiga error OTP por correo](01a160a6-b8f9-75c3-b480-0492182f1f82.md) — 11 mensajes.
50. [Mapea status rechazado en NuBO](01a168f4-ac7d-7752-9728-680d88e11d27.md) — 5 mensajes.
51. [Analiza lecturas y escrituras MS](01a178d4-bd74-7bb3-adc7-227f874e9e76.md) — 13 mensajes.
52. [Auditar concurrencia y particiones](01a17925-4446-79a3-95a2-3f21117c8d98.md) — 10 mensajes.
53. [Validar causa raíz de Kafka Protobuf](01a17a94-d146-71c2-b77b-afc04048ef1e.md) — 6 mensajes.
54. [Prepárate para la reunión con tugerR](01a182ed-7924-75f0-8ddb-197e1636b9ce.md) — 2 mensajes.
55. [Resume código y lista proyectos](01a18316-fde3-7882-a791-ffeebc460cec.md) — 40 mensajes.
